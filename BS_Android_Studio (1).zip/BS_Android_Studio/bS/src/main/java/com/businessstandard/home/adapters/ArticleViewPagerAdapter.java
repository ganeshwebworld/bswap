/**
 * Project      : Economist
 * Filename     : ArticleViewPagerAdapter.java
 * Author       : poojarani
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */

package com.businessstandard.home.adapters;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.ui.ArticleDetailFragment;
import com.businessstandard.analytics.FirebaseAnalyticsTracker;
import com.businessstandard.analytics.GAConstants;
import com.businessstandard.analytics.GoogleAnalytics;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import java.io.File;
import java.util.Date;
import java.util.List;

/**
 * @author poojarani
 */

public class ArticleViewPagerAdapter extends PagerAdapter {

    private List<SubNewsItem> mNewsList;
    private int mPosition;
    private Context mContext;
    SharedPreferences sharedpreferences;
    String tgpref;
    int count = 1;
    private GoogleAnalytics mGoogleAnalytics;
    private FirebaseAnalyticsTracker mFirebaseAnalyticsTracker;

    public ArticleViewPagerAdapter(Context context, List<SubNewsItem> newsList, int position) {
        mNewsList = newsList;
        mPosition = position;
        mContext = context;
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        mFirebaseAnalyticsTracker = FirebaseAnalyticsTracker.getInstance(context);
    }

    @Override
    public int getCount() {
        return mNewsList.size();
    }

    @Override
    public void destroyItem(View container, int position, Object object) {
        ((ViewPager) container).removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(View arg0, Object arg1) {
        return arg0 == ((View) arg1);
    }

    class ViewHolder {
        TextView title;
        TextView author;
        TextView date;
        TextView time;
        WebView description;
        //BonzaiAdView headerAd;
    }

    @Override
    public java.lang.Object instantiateItem(ViewGroup collection, int position) {
        android.view.LayoutInflater inflater = (android.view.LayoutInflater) collection.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View view = inflater.inflate(R.layout.view_pager_item, null);
        ViewHolder holder = new ViewHolder();

        holder.author = (TextView) view.findViewById(R.id.articleAuthor);
        holder.title = (TextView) view.findViewById(R.id.articleTitle);
        holder.date = (TextView) view.findViewById(R.id.articleDate);
        holder.time = (TextView) view.findViewById(R.id.articleTime);
        holder.description = (WebView) view.findViewById(R.id.articleDesc);
        holder.description.getSettings().setJavaScriptEnabled(true);
        holder.description.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        holder.description.getSettings().setLoadWithOverviewMode(true);
        holder.description.getSettings().setDomStorageEnabled(true);
        holder.description.getSettings().setAllowFileAccess(true);
        holder.description.getSettings().setLoadsImagesAutomatically(true);
        holder.description.getSettings().setAppCacheEnabled(true);
        holder.description.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            // chromium, enable hardware acceleration
            holder.description.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            // older android version, disable hardware acceleration
            holder.description.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        //holder.headerAd = (BonzaiAdView) view.findViewById(R.id.header_ad_holder);

        Date dateTime = Utility.getUpdatedDatenew(mNewsList.get(position).dateTime);

        holder.author.setText(mNewsList.get(position).author);
        holder.title.setText(Html.fromHtml(mNewsList.get(position).title));
        holder.date.setText(Utility.getDate(dateTime));

        String publishedRelativeTime = Utility.getPublishedTime(mNewsList.get(position).dateTime);

        if (publishedRelativeTime != null
                && publishedRelativeTime.length() > 0
                && (publishedRelativeTime.contains(" hours ago")
                || publishedRelativeTime.contains(" minutes ago") || publishedRelativeTime
                .contains(" days ago"))) {
            holder.time.setText(publishedRelativeTime);
        } else {
            holder.time.setVisibility(View.INVISIBLE);
        }
        //
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        tgpref = preferences.getString("value", null);

      /*  if (Utility.isInternetOn(mContext)) {
            // Comment added by Satish
            *//*
         * Enable this block If Subscription implemented String fileDirPath
         * = mContext.getFilesDir()+"/userinfo.json"; File file = new
         * File(fileDirPath); if(file.exists()){
         * holder.description.loadUrl(mNewsList.get(position).newsUrl);
         * }else{
         * holder.description.loadUrl(mNewsList.get(position).briefDescription
         * ); }
         *//*
            String pass = null;

//			if(MainFragmentActivity.sabcat.equals("Opinion")){
//				fullpass="<span style='font-weight: bold; font-size: 20px;'>" + mNewsList.get(position).title+"</span><br/>"+"<span style='color:#a61f0e; font-size: 14px;'>"+mNewsList.get(position).author+" | "+Utility.getDate(dateTime)+" | "+publishedRelativeTime+ "</span><br/><br/>" +"<div style='padding: 6px 0px 6px 0px;'>"+
//				"<center><img class='scale' data-scale :'best-fit-down' data-align='center'   alt='' align='center'  src='"+mNewsList.get(position).authorBigImageUrl+"' style='border: 1px solid #DDD; max-width:100%; z-index: 0;' /></div>"+mNewsList.get(position).newscontent;	
//			}else{

            String fullpass = "<span style='font-weight: bold; font-size: 20px;'>" + mNewsList.get(position).title + "</span><br/>" + "<span style='color:#a61f0e; font-size: 14px;'>" + mNewsList.get(position).author + " | " + Utility.getDate(dateTime) + " | " + publishedRelativeTime + "</span><br/><br/>" + mNewsList.get(position).newscontent;
//			}
//		String dada=mNewsList.get(position).newscontent;

//			if (mNewsList.get(position).ispaid!=null) {
            if (mNewsList.get(position).ispaid.equals("Y")) {
                //                count=2;
                String fileDirPath = mContext.getFilesDir() + "/userinfo.json";
                File file = new File(fileDirPath);
                if (file.exists()) {

                    if (tgpref.equals("N")) {
                        //						String summary = "<html><body>You scored <b>192</b> points.</body></html>";
                        String title = mNewsList.get(position).title;
                        pass = mNewsList.get(position).newscontent;
                        String author = mNewsList.get(position).author;
                        holder.description.loadDataWithBaseURL("file:///android_asset/", fullpass, "text/html", "UTF-8", null);
                        //						holder.description.loadDataWithBaseURL("file:///android_asset/",title, "text/html", "UTF-8",null);
                        ArticleDetailFragment.forgotpass.setVisibility(View.GONE);
                        ArticleDetailFragment.mLoginNow.setVisibility(View.GONE);
                        ArticleDetailFragment.mSubscribeNow.setVisibility(View.GONE);
                        ArticleDetailFragment.buttonView.setVisibility(View.GONE);
                        ArticleDetailFragment.image.setVisibility(View.GONE);
                        ArticleDetailFragment.text.setVisibility(View.GONE);
                        //
                    } else {
                        String title = mNewsList.get(position).title;
                        pass = mNewsList.get(position).newscontent;
                        String author = mNewsList.get(position).author;
                        holder.description.loadDataWithBaseURL("file:///android_asset/", fullpass, "text/html", "UTF-8", null);
                        //						holder.description.loadDataWithBaseURL("file:///android_asset/",title, "text/html", "UTF-8",null);
                        ArticleDetailFragment.forgotpass.setVisibility(View.GONE);
                        ArticleDetailFragment.mLoginNow.setVisibility(View.GONE);
                        ArticleDetailFragment.mSubscribeNow.setVisibility(View.VISIBLE);
                        ArticleDetailFragment.buttonView.setVisibility(View.VISIBLE);
                        ArticleDetailFragment.image.setVisibility(View.VISIBLE);
                        ArticleDetailFragment.text.setVisibility(View.VISIBLE);
                        //uncomment this code in case of paid version and delete else remaining  code gaurav diwaker
                        pass = mNewsList.get(position).briefDescription;
                        holder.description.loadDataWithBaseURL("file:///android_asset/", pass, "text/html", "UTF-8", null);
                        ArticleDetailFragment.forgotpass.setVisibility(View.GONE);
                        //
                        ArticleDetailFragment.mLoginNow.setVisibility(View.GONE);
                    }
                } else {
                    String title = mNewsList.get(position).title;
                    pass = mNewsList.get(position).newscontent;
                    String author = mNewsList.get(position).author;
                    //					holder.description.loadDataWithBaseURL("file:///android_asset/",fullpass, "text/html", "UTF-8",null);
                    holder.description.loadDataWithBaseURL("file:///android_asset/", title, "text/html", "UTF-8", null);
                    //uncomment these line for paid version and delete else code gaurav diwaker
                    pass = mNewsList.get(position).briefDescription;
                    holder.description.loadDataWithBaseURL("file:///android_asset/", pass, "text/html", "UTF-8", null);
                    //
                }
            } else {
                String title = mNewsList.get(position).title;
                pass = mNewsList.get(position).newscontent;
                String author = mNewsList.get(position).author;
                holder.description.loadDataWithBaseURL("file:", fullpass, "text/html", "UTF-8", null);
                //				holder.description.loadDataWithBaseURL("file:///android_asset/",title, "text/html", "UTF-8",null);
            }
			*//*}else {
				String title = mNewsList.get(position).title;
				pass = mNewsList.get(position).newscontent;
				String author = mNewsList.get(position).author;

				holder.description.loadDataWithBaseURL("file:///android_asset/",fullpass, "text/html", "UTF-8",null);
				//				holder.description.loadDataWithBaseURL("file:///android_asset/",title, "text/html", "UTF-8",null);
			}*//*
        } else {
            holder.description.loadUrl(mContext.getResources().getString(R.string.errorpage_url));
        }*/

        // Comment added by Satish
        /*
         * Enable this block If Subscription implemented String fileDirPath
         * = mContext.getFilesDir()+"/userinfo.json"; File file = new
         * File(fileDirPath); if(file.exists()){
         * holder.description.loadUrl(mNewsList.get(position).newsUrl);
         * }else{
         * holder.description.loadUrl(mNewsList.get(position).briefDescription
         * ); }
         */
        String pass = null;

//			if(MainFragmentActivity.sabcat.equals("Opinion")){
//				fullpass="<span style='font-weight: bold; font-size: 20px;'>" + mNewsList.get(position).title+"</span><br/>"+"<span style='color:#a61f0e; font-size: 14px;'>"+mNewsList.get(position).author+" | "+Utility.getDate(dateTime)+" | "+publishedRelativeTime+ "</span><br/><br/>" +"<div style='padding: 6px 0px 6px 0px;'>"+
//				"<center><img class='scale' data-scale :'best-fit-down' data-align='center'   alt='' align='center'  src='"+mNewsList.get(position).authorBigImageUrl+"' style='border: 1px solid #DDD; max-width:100%; z-index: 0;' /></div>"+mNewsList.get(position).newscontent;
//			}else{

        String fullpass = "<span style='font-weight: bold; font-size: 20px;'>" + mNewsList.get(position).title + "</span><br/>" + "<span style='color:#a61f0e; font-size: 14px;'>" + mNewsList.get(position).author + " | " + Utility.getDate(dateTime) + " | " + publishedRelativeTime + "</span><br/><br/>" + mNewsList.get(position).newscontent;
//			}
//		String dada=mNewsList.get(position).newscontent;

//			if (mNewsList.get(position).ispaid!=null) {
        if (mNewsList.get(position).ispaid.equals("Y")) {
            //                count=2;
            String fileDirPath = mContext.getFilesDir() + "/userinfo.json";
            File file = new File(fileDirPath);
            if (file.exists()) {
                if (tgpref.equals("N")) {
                    //Article is Paid and User is logged in
                    trackPaidArticlePaidLoginGAEvent();

                    //						String summary = "<html><body>You scored <b>192</b> points.</body></html>";
                    String title = mNewsList.get(position).title;
                    pass = mNewsList.get(position).newscontent;
                    String author = mNewsList.get(position).author;
                    holder.description.loadDataWithBaseURL("file:///android_asset/", fullpass, "text/html", "UTF-8", null);
                    //						holder.description.loadDataWithBaseURL("file:///android_asset/",title, "text/html", "UTF-8",null);
                    ArticleDetailFragment.forgotpass.setVisibility(View.GONE);
                    ArticleDetailFragment.mLoginNow.setVisibility(View.GONE);
                    ArticleDetailFragment.mSubscribeNow.setVisibility(View.GONE);
                    ArticleDetailFragment.buttonView.setVisibility(View.GONE);
                    ArticleDetailFragment.image.setVisibility(View.GONE);
                    ArticleDetailFragment.text.setVisibility(View.GONE);
                    //
                } else {

                    //Article is Paid and No Login
                    if (!TextUtils.isEmpty(mNewsList.get(position).newsUrl)) {
                        trackPaidArticleNoLogin(mNewsList.get(position).newsUrl);
                    }

                    String title = mNewsList.get(position).title;
                    pass = mNewsList.get(position).newscontent;
                    String author = mNewsList.get(position).author;
                    holder.description.loadDataWithBaseURL("file:///android_asset/", fullpass, "text/html", "UTF-8", null);
                    //						holder.description.loadDataWithBaseURL("file:///android_asset/",title, "text/html", "UTF-8",null);
                    ArticleDetailFragment.forgotpass.setVisibility(View.GONE);
                    ArticleDetailFragment.mLoginNow.setVisibility(View.GONE);
                    ArticleDetailFragment.mSubscribeNow.setVisibility(View.VISIBLE);
                    ArticleDetailFragment.buttonView.setVisibility(View.VISIBLE);
                    ArticleDetailFragment.image.setVisibility(View.VISIBLE);
                    ArticleDetailFragment.text.setVisibility(View.VISIBLE);
                    //uncomment this code in case of paid version and delete else remaining  code gaurav diwaker
                    pass = mNewsList.get(position).briefDescription;
                    holder.description.loadDataWithBaseURL("file:///android_asset/", pass, "text/html", "UTF-8", null);
                    ArticleDetailFragment.forgotpass.setVisibility(View.GONE);
                    //
                    ArticleDetailFragment.mLoginNow.setVisibility(View.GONE);
                }
            } else {

                //Article is Paid and No Login
                if (!TextUtils.isEmpty(mNewsList.get(position).newsUrl)) {
                    trackPaidArticleNoLogin(mNewsList.get(position).newsUrl);
                }

                String title = mNewsList.get(position).title;
                pass = mNewsList.get(position).newscontent;
                String author = mNewsList.get(position).author;
                //					holder.description.loadDataWithBaseURL("file:///android_asset/",fullpass, "text/html", "UTF-8",null);
                holder.description.loadDataWithBaseURL("file:///android_asset/", title, "text/html", "UTF-8", null);
                //uncomment these line for paid version and delete else code gaurav diwaker
                pass = mNewsList.get(position).briefDescription;
                holder.description.loadDataWithBaseURL("file:///android_asset/", pass, "text/html", "UTF-8", null);
                //
            }
        } else {
            //Article is Free
            //Article is Paid and No Login
            if (!TextUtils.isEmpty(mNewsList.get(position).newsUrl)) {
                trackFreeArticleGAEvent(mNewsList.get(position).newsUrl);
            }

            String title = mNewsList.get(position).title;
            pass = mNewsList.get(position).newscontent;
            String author = mNewsList.get(position).author;
            holder.description.loadDataWithBaseURL("file:", fullpass, "text/html", "UTF-8", null);
            //				holder.description.loadDataWithBaseURL("file:///android_asset/",title, "text/html", "UTF-8",null);
        }
			/*}else {
				String title = mNewsList.get(position).title;
				pass = mNewsList.get(position).newscontent;
				String author = mNewsList.get(position).author;

				holder.description.loadDataWithBaseURL("file:///android_asset/",fullpass, "text/html", "UTF-8",null);
				//				holder.description.loadDataWithBaseURL("file:///android_asset/",title, "text/html", "UTF-8",null);
			}*/

        //initialiseAd(holder.headerAd);

        ((ViewPager) collection).addView(view, 0);
        return view;
    }

    private void trackPaidArticlePaidLoginGAEvent() {
        if (mGoogleAnalytics != null) {
            mGoogleAnalytics.trackEvent(GAConstants.PAID_ARTICLE_PAID_LOGIN_EVENT_CATEGORY, GAConstants.PAID_ARTICLE_PAID_LOGIN_EVENT_ACTION, GAConstants.PAID_ARTICLE_PAID_LOGIN_EVENT_LABEL);
        }

        mFirebaseAnalyticsTracker.trackEvent(GAConstants.PAID_ARTICLE_PAID_LOGIN_EVENT_CATEGORY, GAConstants.PAID_ARTICLE_PAID_LOGIN_EVENT_ACTION, GAConstants.PAID_ARTICLE_PAID_LOGIN_EVENT_LABEL);
    }

    private void trackPaidArticleNoLogin(String newsUrl) {
        if (mGoogleAnalytics != null && !TextUtils.isEmpty(SaveSharedPref.getInstance(mContext).getString(SharedPreferencesKey.KEY_DEVICE_ID, ""))) {
            mGoogleAnalytics.trackEvent(GAConstants.PAID_ARTICLE_NO_LOGIN_EVENT_CATEGORY,
                    SaveSharedPref.getInstance(mContext).getString(SharedPreferencesKey.KEY_DEVICE_ID, ""),
                    newsUrl);
        }

        mFirebaseAnalyticsTracker.trackEvent(GAConstants.PAID_ARTICLE_NO_LOGIN_EVENT_CATEGORY, SaveSharedPref.getInstance(mContext).getString(SharedPreferencesKey.KEY_DEVICE_ID, ""), newsUrl);
    }

    private void trackFreeArticleGAEvent(String newsUrl) {
        if (mGoogleAnalytics != null) {
            mGoogleAnalytics.trackEvent(GAConstants.FREE_ARTICLE_EVENT_CATEGORY, GAConstants.FREE_ARTICLE_EVENT_ACTION, newsUrl);
        }

        mFirebaseAnalyticsTracker.trackEvent(GAConstants.FREE_ARTICLE_EVENT_CATEGORY, GAConstants.FREE_ARTICLE_EVENT_ACTION, newsUrl);
    }

/*	private void initialiseAd(BonzaiAdView headerAd) {
		headerAd.setVisibility(View.GONE); // just comment this if ad is
											// required above webview.
		AdManager admanager = new AdManager();
		admanager.displayBannerAdOnMainPage(headerAd, BonzaiZoneIds.MAST_HEAD);
	}*/

    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

}
