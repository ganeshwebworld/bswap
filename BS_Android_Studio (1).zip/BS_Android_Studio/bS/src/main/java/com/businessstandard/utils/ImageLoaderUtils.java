package com.businessstandard.utils;

import android.content.Context;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class ImageLoaderUtils {

    private static ImageLoaderUtils imageLoaderUtils;

    public static ImageLoaderUtils getInstance() {
        if (imageLoaderUtils == null) {
            imageLoaderUtils = new ImageLoaderUtils();
        }
        return imageLoaderUtils;
    }

    public void showImage(Context mContext, String imageUrl, ImageView imageView) {
        Glide.with(mContext)
                .load(imageUrl)
                .into(imageView);
    }
}
