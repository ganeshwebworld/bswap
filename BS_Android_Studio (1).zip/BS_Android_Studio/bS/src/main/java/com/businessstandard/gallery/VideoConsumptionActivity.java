package com.businessstandard.gallery;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.util.Utility;
import com.businessstandard.model.GalleryDetailResponseModel;
import com.businessstandard.model.GalleryVideo;
import com.businessstandard.network.NetworkClient;
import com.businessstandard.network.NetworkInterface;
import com.businessstandard.network.RequestCode;
import com.businessstandard.utils.AppConstants;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelection;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.TransferListener;
import com.google.android.exoplayer2.util.Util;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VideoConsumptionActivity extends Activity {

    private String galleryId = "";
    private SimpleExoPlayerView simpleExoPlayerView;
    private SimpleExoPlayer player;
    private DataSource.Factory mediaDataSourceFactory;
    private BandwidthMeter bandwidthMeter;
    private ImageView volume_off, volume_on, fullScreen, fullScreenExit;
    private Display display;
    boolean isButtonClick = false;
    private long currentPos;
    private String videoTitle;
    public static final String apiToken = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
    private NetworkInterface mNetworkInterface;
    private String detailUrl = "";
    private ProgressBar progressBar;
    private TextView mVideoTitle;
    private String baseUrl = "";
    private SaveSharedPref mSharedPreferenceManager;
    private com.businessstandard.model.Constants mConstants = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_consumption);
        mSharedPreferenceManager = SaveSharedPref.getInstance(this);
        mNetworkInterface = NetworkClient.getClient().create(NetworkInterface.class);
        bandwidthMeter = new DefaultBandwidthMeter();
        mediaDataSourceFactory = new DefaultDataSourceFactory(this, Util.getUserAgent(this, "BS"), (TransferListener<? super DataSource>) bandwidthMeter);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getIntentData();
        initView();
        getVideoDetailUrl();
        getVideoDetail();
    }

    private void getVideoDetailUrl() {
        if (mSharedPreferenceManager.exists(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA)) {
            if (mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class) != null) {
                mConstants = mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class);
            }
        }
        if (mConstants != null && !TextUtils.isEmpty(mConstants.getGetGalleryVideoDetails())) {
            detailUrl = mConstants.getGetGalleryVideoDetails();
        }
        if (mConstants != null && !TextUtils.isEmpty(mConstants.getBaseUrl())) {
            baseUrl = mConstants.getBaseUrl();
        }
    }

    private void getVideoDetail() {
        if (Utility.isInternetOn(VideoConsumptionActivity.this)) {
            if (!TextUtils.isEmpty(galleryId) && !TextUtils.isEmpty(detailUrl) && !TextUtils.isEmpty(baseUrl) && !TextUtils.isEmpty(apiToken)) {
                showProgress();
                getVideoDetails(RequestCode.GET_VIDEOS_DETAILS, detailUrl, apiToken, galleryId);
            }
        }
    }

    public void getVideoDetails(final int requestCode, String detailUrl, String apiToken, String galleryId) {
        Call<GalleryDetailResponseModel> galleryDetailResponseModelCall = mNetworkInterface.getVideosDetailsData(detailUrl, apiToken, galleryId);
        galleryDetailResponseModelCall.enqueue(new Callback<GalleryDetailResponseModel>() {
            @Override
            public void onResponse(Call<GalleryDetailResponseModel> call, Response<GalleryDetailResponseModel> response) {
                if (response.isSuccessful()) {
                    onResponseListener(requestCode, response.body());
                }
            }

            @Override
            public void onFailure(Call<GalleryDetailResponseModel> call, Throwable t) {
                onErrorListener(requestCode, t.getMessage());
            }
        });
    }

    private void onResponseListener(int requestCode, GalleryDetailResponseModel responseModel) {
        try {
            if (requestCode == RequestCode.GET_VIDEOS_DETAILS) {
                if (responseModel != null) {
                    hideProgress();
                    List<GalleryVideo> galleryVideoslist = responseModel.getGalleryVideo();
                    if (galleryVideoslist != null && galleryVideoslist.size() > 0) {
                        GalleryVideo galleryVideo = galleryVideoslist.get(0);
                        if (galleryVideo != null) {
                            if (!TextUtils.isEmpty(galleryVideo.getVideoRelpath()) && !TextUtils.isEmpty(galleryVideo.getVideoName())) {
                                String urlToPlay = baseUrl + galleryVideoslist.get(0).getVideoRelpath() + galleryVideoslist.get(0).getVideoName();
                                //initializePlayer(urlToPlay);
                                String sampleUrlToPlay = "https://bsmedia.business-standard.com/_media/bs/vdo/video-gallery/featured-videos/ebola-outbreak-why-isn-t-there-a-vaccine/full/ebola-outbreak-why-isn-t-there-a-vaccine-14068930739804.mp4";
                                initializePlayer(sampleUrlToPlay);
                            } else {
                                Utility.showToast(getString(R.string.some_error_please_try_again_message), this);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            hideProgress();
            e.printStackTrace();
        }
    }

    private void onErrorListener(int requestCode, String message) {
        hideProgress();
    }

    private void initView() {
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        mVideoTitle = (TextView) findViewById(R.id.videoTitle);
        display = getWindowManager().getDefaultDisplay();
        simpleExoPlayerView = (SimpleExoPlayerView) findViewById(R.id.player_view);
        volume_off = simpleExoPlayerView.findViewById(R.id.volume_off);
        volume_on = simpleExoPlayerView.findViewById(R.id.volume_on);
        fullScreen = simpleExoPlayerView.findViewById(R.id.goLandscape);
        fullScreenExit = simpleExoPlayerView.findViewById(R.id.goPortrait);
        //screen sizes
        display = getWindowManager().getDefaultDisplay();
        ViewGroup.LayoutParams layoutParams = simpleExoPlayerView.getLayoutParams();
        layoutParams.width = display.getWidth();
        layoutParams.height = (int) (display.getWidth() * .56f);
        simpleExoPlayerView.setLayoutParams(layoutParams);

        volume_off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                player.setVolume(0);
                volume_off.setVisibility(View.GONE);
                volume_on.setVisibility(View.VISIBLE);
            }
        });

        volume_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                player.setVolume(1);
                volume_off.setVisibility(View.VISIBLE);
                volume_on.setVisibility(View.GONE);
            }
        });

        fullScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fullScreenExit.setVisibility(View.VISIBLE);
                fullScreen.setVisibility(View.GONE);
                isButtonClick = true;
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            }
        });

        fullScreenExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fullScreenExit.setVisibility(View.GONE);
                fullScreen.setVisibility(View.VISIBLE);
                isButtonClick = true;
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        });
    }

    private void getIntentData() {
        if (getIntent() != null && !TextUtils.isEmpty(getIntent().getStringExtra(AppConstants.GALLERY_ID))) {
            galleryId = getIntent().getStringExtra(AppConstants.GALLERY_ID);
            videoTitle = getIntent().getStringExtra(AppConstants.GALLERY_VIDEO_TITLE);
        }
    }

    private void initializePlayer(String url) {

        simpleExoPlayerView.setVisibility(View.VISIBLE);

        simpleExoPlayerView.requestFocus();

        TrackSelection.Factory videoTrackSelectionFactory = new AdaptiveTrackSelection.Factory(bandwidthMeter);

        DefaultTrackSelector trackSelector = new DefaultTrackSelector(videoTrackSelectionFactory);

        LoadControl loadControl = new DefaultLoadControl();

        player = ExoPlayerFactory.newSimpleInstance(this, trackSelector, loadControl);

        player.addListener(eventListener);

        simpleExoPlayerView.setPlayer(player);

        MediaSource mediaSource = new ExtractorMediaSource(Uri.parse(url), mediaDataSourceFactory, new DefaultExtractorsFactory(), null, null);

        //MediaSource mediaSource = new HlsMediaSource(Uri.parse(url), mediaDataSourceFactory, null, null);

        player.prepare(mediaSource);

        player.setPlayWhenReady(true);

        if (!TextUtils.isEmpty(videoTitle)) {
            mVideoTitle.setVisibility(View.VISIBLE);
            mVideoTitle.setText(videoTitle);
        }
    }

    private ExoPlayer.EventListener eventListener = new ExoPlayer.EventListener() {

        @Override
        public void onTimelineChanged(Timeline timeline, Object manifest, int reason) {

        }

        @Override
        public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {

        }

        @Override
        public void onLoadingChanged(boolean isLoading) {

        }

        @Override
        public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {

            switch (playbackState) {
                case ExoPlayer.STATE_ENDED:

                    //Stop playback and return to start position
                    break;
                case ExoPlayer.STATE_READY:

                    break;
                case ExoPlayer.STATE_BUFFERING:

                    break;
                case ExoPlayer.STATE_IDLE:

                    break;
            }
        }

        @Override
        public void onRepeatModeChanged(int repeatMode) {

        }

        @Override
        public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {

        }

        @Override
        public void onPlayerError(ExoPlaybackException error) {

        }

        @Override
        public void onPositionDiscontinuity(int reason) {

        }

        @Override
        public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {

        }

        @Override
        public void onSeekProcessed() {

        }
    };

    private void releasePlayer() {
        if (player != null) {
            currentPos = player.getCurrentPosition();
            player.setPlayWhenReady(false);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (player != null) {
            player.seekTo(currentPos);
            player.setPlayWhenReady(true);

        } else if (player == null) {

        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (player != null) {
            releasePlayer();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (player != null) {
            releasePlayer();
        }
    }

    @Override
    public void onBackPressed() {
        int orientation = this.getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {

        } else {
            super.onBackPressed();
        }
    }


    public void showProgress() {
        if (progressBar != null) {
            progressBar.setVisibility(ProgressBar.VISIBLE);
        }
    }

    public void hideProgress() {
        if (progressBar != null) {
            progressBar.setVisibility(ProgressBar.INVISIBLE);
        }
    }

}
