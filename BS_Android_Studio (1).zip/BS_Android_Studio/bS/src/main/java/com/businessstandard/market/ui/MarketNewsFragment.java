/**
 * Project      : Economist
 * Filename     : MarketNewsFragment.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.market.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.SectionNewsItem;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.manager.BaseManager.SubNewsDloadCmpltListener;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.util.Constants.MarketKeys;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.ui.HomeFragment.OnNewsListDwnloadedListener;
import com.businessstandard.home.ui.NewsListAdapter;
import com.businessstandard.market.MarketsManager;
import com.businessstandard.analytics.GoogleAnalytics;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author lenesha
 */
public class MarketNewsFragment extends BaseFragment implements OnItemClickListener {

    private FragmentActivity mcontext;
    private FragmentListner mListner;
    private ListView mNewsListView;
    protected ArrayList<SubNewsItem> mSubnewsItem;
    private OnNewsListDwnloadedListener mOnNewsListDwnloadedListener;
    private TextView mEmptyView;
    private String mSelectedCatname;
    private NewsListAdapter mAdapter;
    private NewsItemClickListner mNewsClickListener;
    private String mMarketNewsUrl;
    private GoogleAnalytics mGoogleAnalytics;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mcontext = getActivity();
        mListner = (FragmentListner) mcontext;
        mOnNewsListDwnloadedListener = (OnNewsListDwnloadedListener) mcontext;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.news_list, container, false);
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        mNewsListView = (ListView) view.findViewById(R.id.news_listview);
        mNewsClickListener = castToListener(getActivity());

        mNewsListView.setOnItemClickListener(this);
        mEmptyView = (TextView) view.findViewById(android.R.id.empty);
        mAdapter = new NewsListAdapter(mcontext, R.layout.news_listitem);
        mNewsListView.setAdapter(mAdapter);
        getNewsFeeds();
        //AnalyticsUtils.getInstAnalyticsUtils(getActivity()).trackPageView(getString(R.string.tab_market) + getString(R.string.cat_market_news));
        if (mGoogleAnalytics != null && getActivity() != null) {
            mGoogleAnalytics.trackScreenView(getString(R.string.tab_market) + getString(R.string.cat_market_news), getActivity());
        }
        return view;
    }

    private NewsItemClickListner castToListener(Activity activity) {
        return (NewsItemClickListner) activity;
    }

    /* (non-Javadoc)
     * @see android.support.v4.app.Fragment#onCreate(android.os.Bundle)
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    /**
     *
     */
    private void getNewsFeeds() {
        if (getActivity() != null && Utility.isInternetOn(getActivity())) {
            if (mListner != null && mListner.getDataFromActivity() != null && mListner.getDataFromActivity().root != null) {
                ArrayList<SectionNewsItem> itemList = mListner.getDataFromActivity().root.getmMarket();
                if (itemList != null && itemList.size() > 0) {
                    HashMap<String, String> marketMapping = new HashMap<String, String>();
                    for (SectionNewsItem item : itemList) {
                        marketMapping.put(item.categoryName, item.feedUrl);
                    }
                    mMarketNewsUrl = marketMapping.get(MarketKeys.MARKETNEWS);
                    downloadNews(mMarketNewsUrl);
                }
            } else {
                mEmptyView.setVisibility(View.VISIBLE);
                if (getActivity() != null)

                    Utility.displayAlert(getActivity(), getString(R.string.app_name), getResources()
                                    .getString(R.string.unable_to_fetch_data), android.R.string.ok,
                            Utility.getOkButtonListener(getActivity()));

            }
        } else {
            mEmptyView.setVisibility(View.VISIBLE);
            if (getActivity() != null)

                Utility.displayAlert(getActivity(), getString(R.string.app_name), getResources()
                                .getString(R.string.no_connection), android.R.string.ok,
                        Utility.getOkButtonListener(getActivity()));
        }
    }

    private void downloadNews(String url) {
        String feedUrl = url;
        MarketsManager manager = new MarketsManager(getActivity());
        manager.downloadNewsFeedData(new SubNewsDloadCmpltListener() {

            @Override
            public void onFailure() {
                Utility.hideProgressDialog();

            }

            @Override
            public void onSubNewsDloadComplete(ArrayList<SubNewsItem> result) {
                mSubnewsItem = result;
                mOnNewsListDwnloadedListener.onNewsListDownloaded(result);
                Utility.hideProgressDialog();

                displayNews(result);
            }

        }, feedUrl);
    }

    /**
     * @param result
     */
    private void displayNews(ArrayList<SubNewsItem> result) {
        //itemlist null pointer handling
        mEmptyView.setVisibility(View.INVISIBLE);

        if (mSubnewsItem != null && result != null && result.size() > 0) {
            mAdapter.clear();
            for (SubNewsItem item : result) {
                mAdapter.add(item);
                mAdapter.setNotifyOnChange(false);
            }
            mAdapter.notifyDataSetChanged();

        } else {
            mEmptyView.setVisibility(View.VISIBLE);

        }

    }

    /* (non-Javadoc)
     * @see android.widget.AdapterView.OnItemClickListener#onItemClick(android.widget.AdapterView, android.view.View, int, long)
     */
    @Override
    public void onItemClick(AdapterView<?> arg0, View view, int position, long id) {
        SubNewsItem subNewsitemClicked = mAdapter.getItem(position);
        mNewsClickListener.onNewsItemClick(subNewsitemClicked, position, getString(R.string.cat_market_news), getString(R.string.cat_market_news));
    }

    /**
     *
     */
    public void refreshContent() {
        downloadNews(mMarketNewsUrl);

    }


}
