package com.businessstandard.model;

import java.io.Serializable;
import java.util.List;

public class MenuItemModel implements Serializable {

    private String menuName;
    private List<MenuItemModel> childMenuList;
    private String menuId;
    private String feedUrl;
    private String isMobile;

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public List<MenuItemModel> getChildMenuList() {
        return childMenuList;
    }

    public void setChildMenuList(List<MenuItemModel> childMenuList) {
        this.childMenuList = childMenuList;
    }

    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    public String getFeedUrl() {
        return feedUrl;
    }

    public void setFeedUrl(String feedUrl) {
        this.feedUrl = feedUrl;
    }

    public String getIsMobile() {
        return isMobile;
    }

    public void setIsMobile(String isMobile) {
        this.isMobile = isMobile;
    }
}
