
package com.businessstandard.common.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.manager.MenuCall;
import com.businessstandard.common.manager.MenuInterface;
import com.businessstandard.common.util.Utility;
import com.businessstandard.firebaseServices.Config;
import com.businessstandard.firebaseServices.NotificationUtils;
import com.businessstandard.home.ui.ComScore;
import com.businessstandard.model.ConfigResponseModel;
import com.businessstandard.model.Constants;
import com.businessstandard.model.DynamicSplash;
import com.businessstandard.network.NetworkClient;
import com.businessstandard.network.NetworkInterface;
import com.businessstandard.network.RequestCode;
import com.businessstandard.settings.ui.NotificationSettingsActivity;
import com.businessstandard.utils.AppConstants;
import com.businessstandard.utils.ImageLoaderUtils;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.kosalgeek.android.caching.FileCacheManager;

import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SplashScreenActivity extends FragmentActivity implements MenuInterface {

    private ProgressBar progressBar;
    private NetworkInterface mNetworkInterface;
    private SaveSharedPref mSharedPreferenceManager;
    private Boolean mFirstLaunch = true;
    private FileCacheManager mFileCacheManager;
    private Constants mConstants;
    private String uuid;
    public static String api_key = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
    private ImageView dynamicLogo;
    private TextView dynamicTitle;
    private RelativeLayout rootLayout;

    @SuppressWarnings("deprecation")
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen_layout);
        initViews();
        setupDynamicSplash();
        printFCMTokenInLog();
        if (mFirstLaunch) {
            getConfigData();
        } else {
            getConfigData();
            launchMainFragmentActivity();
        }
    }

    private void printFCMTokenInLog() {
        String token = FirebaseInstanceId.getInstance().getToken();
        if (!TextUtils.isEmpty(token)) {
            Log.d("token", token);
            com.twitter.android.NotificationUtils.getInstance().sendDataToServer(this, token);
        }
    }

    private void setupDynamicSplash() {

        if (mSharedPreferenceManager.exists(SharedPreferencesKey.KEY_CONFIG_SPLASH_DATA)) {
            if (mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_SPLASH_DATA, DynamicSplash.class) != null) {
                DynamicSplash dynamicSplash = mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_SPLASH_DATA, DynamicSplash.class);
                if (dynamicSplash.getIsDynamicSplash()) {
                    if (!TextUtils.isEmpty(dynamicSplash.getLogo())) {
                        dynamicLogo.setVisibility(View.VISIBLE);
                        ImageLoaderUtils.getInstance().showImage(this, dynamicSplash.getLogo(), dynamicLogo);
                    }
                    if (!TextUtils.isEmpty(dynamicSplash.getTitle()) && !TextUtils.isEmpty(dynamicSplash.getTitleColor())) {
                        dynamicTitle.setVisibility(View.VISIBLE);
                        dynamicTitle.setText(dynamicSplash.getTitle());
                        dynamicTitle.setTextColor(Color.parseColor(dynamicSplash.getTitleColor()));
                    }
                    if (!TextUtils.isEmpty(dynamicSplash.getBgColor())) {
                        rootLayout.setBackgroundColor(Color.parseColor(dynamicSplash.getBgColor()));
                    }
                    if (!TextUtils.isEmpty(dynamicSplash.getProgressIndicatorColor())) {
                        progressBar.setIndeterminateTintList(ColorStateList.valueOf(Color.parseColor(dynamicSplash.getProgressIndicatorColor())));
                    } else {
                        progressBar.setIndeterminateTintList(ColorStateList.valueOf(Color.parseColor("#FFFFFF")));
                    }
                } else {
                    rootLayout.setBackgroundResource(R.drawable.splash);
                }
            }
        } else {
            rootLayout.setBackgroundResource(R.drawable.splash);
            progressBar.setIndeterminateTintList(ColorStateList.valueOf(Color.parseColor("#B72026")));
        }
    }

    private void getConfigData() {
        if (Utility.isInternetOn(this)) {
            showProgress();
            getConfigApiResponse(RequestCode.GET_CONFIG);
        } else {
            hideProgress();
        }
    }

    public void showProgress() {
        if (progressBar != null) {
            progressBar.setVisibility(ProgressBar.VISIBLE);
        }
    }

    public void hideProgress() {
        if (progressBar != null) {
            progressBar.setVisibility(ProgressBar.INVISIBLE);
        }
    }

    @Override
    public void onSelectResult(String value) {
        if (mSharedPreferenceManager != null) {
            mSharedPreferenceManager.saveMenu(value);
        }
    }

    private void initViews() {
        uuid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
        mSharedPreferenceManager = SaveSharedPref.getInstance(SplashScreenActivity.this);
        mNetworkInterface = NetworkClient.getClient().create(NetworkInterface.class);
        mFirstLaunch = mSharedPreferenceManager.getBoolean(SharedPreferencesKey.FIRST_LAUNCH, true);
        mFileCacheManager = new FileCacheManager(this);
        progressBar = findViewById(R.id.progressBar);
        rootLayout = findViewById(R.id.rootlayout);
        dynamicTitle = findViewById(R.id.dynamicTitle);
        dynamicLogo = findViewById(R.id.dynamicLogo);
    }

    private void launchMainFragmentActivity() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashScreenActivity.this, MainFragmentActivity.class));
                finish();
            }
        }, AppConstants.SPLASH_SCREEN_HANDLER_DELAY);
    }

    public void getConfigApiResponse(final int requestCode) {
        Call<ConfigResponseModel> configCall = mNetworkInterface.getConfigData(AppConstants.CONFIG_API_KEY, ComScore.API_VERSION);
        configCall.enqueue(new Callback<ConfigResponseModel>() {
            @Override
            public void onResponse(Call<ConfigResponseModel> call, Response<ConfigResponseModel> response) {
                if (response.isSuccessful()) {
                    //Config Response Success
                    try {
                        if (response.body() != null) {
                            if (!TextUtils.isEmpty(response.body().getStatus()) && response.body().getStatus().equalsIgnoreCase(AppConstants.STATUS_SUCCESS)) {
                                onResponseListener(requestCode, response.body());
                            } else {
                                hideProgress();
                                Utility.showToast(getString(R.string.some_error_message), SplashScreenActivity.this);
                            }
                        }
                    } catch (Exception e) {
                        hideProgress();
                        e.printStackTrace();
                    }
                } else {
                    //Config Response Fail
                    hideProgress();
                }
            }

            @Override
            public void onFailure(Call<ConfigResponseModel> call, Throwable t) {
                onErrorListener(requestCode, t.getMessage());
            }
        });
    }

    private void onResponseListener(int requestCode, ConfigResponseModel responseModel) {
        try {
            if (requestCode == RequestCode.GET_CONFIG) {
                if (responseModel != null) {

                    if (responseModel.getMessage().getConstants() != null) {
                        //getting side menu response
                        new MenuCall(SplashScreenActivity.this, this);
                        mConstants = responseModel.getMessage().getConstants();

                        mSharedPreferenceManager.putObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, mConstants);

                        if (mConstants.getDynamicSplash() != null) {
                            mSharedPreferenceManager.putObject(SharedPreferencesKey.KEY_CONFIG_SPLASH_DATA, mConstants.getDynamicSplash());
                        }

                        if (!TextUtils.isEmpty(mConstants.getSigninApi())) {
                            mSharedPreferenceManager.saveString(SharedPreferencesKey.KEY_SIGN_IN_API, mConstants.getSigninApi());
                        }

                        if (!TextUtils.isEmpty(mConstants.getCommonJson())) {
                            mSharedPreferenceManager.saveString(SharedPreferencesKey.KEY_COMMON_JSON_API, mConstants.getCommonJson());
                        }

                        //Get Notification Setting For User Using Device ID Only For First Run
                        if (mFirstLaunch) {
                            if (Utility.isInternetOn(this)) {
                                new getNotificationSetting(SplashScreenActivity.this).execute(api_key, uuid);
                            }
                        }

                        if (mSharedPreferenceManager.getBoolean(SharedPreferencesKey.FIRST_LAUNCH, true)) {
                            mFileCacheManager.deleteAllCaches();
                            mSharedPreferenceManager.saveBoolean(SharedPreferencesKey.FIRST_LAUNCH, false);
                            launchActivityWithFinish(SplashScreenActivity.this, MainFragmentActivity.class);
                        }
                    }
                }
            }
        } catch (Exception e) {
            hideProgress();
            e.printStackTrace();
        }
    }

    private void onErrorListener(int requestCode, String message) {
        Utility.showToast(getString(R.string.some_error_message), SplashScreenActivity.this);
        hideProgress();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        NotificationUtils.clearNotifications(getApplicationContext());
    }

    public void launchActivityWithFinish(Activity context, Class activity) {
        Intent intent = new Intent(context, activity);
        startActivity(intent);
        finish();
    }

    public class getNotificationSetting extends AsyncTask<String, String, JSONObject> {

        Context context;

        getNotificationSetting(Context mContext) {
            context = mContext;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected JSONObject doInBackground(String... args) {
            //String strUrl = Constants.BaseUrl_V2;
            String activeNotificationUrl = "";
            String deviceNotificationSettingUrl = "";
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getActiveNotificationFieldV2())) {
                activeNotificationUrl = mConstants.getActiveNotificationFieldV2();
            }
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getGetDeviceNotificationSettingV2())) {
                deviceNotificationSettingUrl = mConstants.getGetDeviceNotificationSettingV2();
            }

            JSONObject json2 = null;
            JSONObject json = null;

            try {
                //1st API Call "Active Notification"
                OkHttpClient client = new OkHttpClient();

                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("api_token", args[0])
                        .addFormDataPart("device_uniqueid", args[1])
                        .build();

                Request request = new Request.Builder()
                        //.url(strUrl + Constants.ACTIVE_NOTIFICATION_FIELD_V2)
                        .url(activeNotificationUrl)
                        .post(requestBody)
                        .build();

                try (okhttp3.Response response = client.newCall(request).execute()) {
                    try {
                        assert response.body() != null;
                        json2 = new JSONObject(response.body().string());

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                //2st API Call "Get Notification Setting based on Device ID"
                OkHttpClient client = new OkHttpClient();

                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("api_token", args[0])
                        .addFormDataPart("device_uniqueid", args[1])
                        .build();

                Request request = new Request.Builder()
                        //.url(strUrl + Constants.GET_DEVICE_NOTIFICATION_SETTING_V2)
                        .url(deviceNotificationSettingUrl)
                        .post(requestBody)
                        .build();

                try (okhttp3.Response response = client.newCall(request).execute()) {
                    try {
                        assert response.body() != null;
                        json = new JSONObject(response.body().string());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

            } catch (Exception e1) {
                e1.printStackTrace();
            }

            try {
                if (json2 != null) {
                    if (json2.getString("status").equalsIgnoreCase("success")) {
                        JSONObject jsonObject = json2.getJSONObject("message");

                        JSONArray jsonArray = jsonObject.getJSONArray("settings");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                        }
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return json;
        }

        protected void onPostExecute(JSONObject json) {
            try {
                if (json != null) {
                    if (json.getString("status").equalsIgnoreCase("success")) {
                        JSONObject jsonObject = json.getJSONObject("message");

                        JSONArray jsonArray = jsonObject.getJSONArray("settings");

                        for (int i = 0; i < jsonArray.length(); i++) {
                            com.businessstandard.common.util.NotificationUtils notificationUtils = new com.businessstandard.common.util.NotificationUtils();
                            JSONObject object = jsonArray.getJSONObject(i);

                            if ((object.getString("name")).equalsIgnoreCase("Sound")) {
                                NotificationSettingsActivity.savedSoundAndNotification(getApplicationContext(), (object.getString("enabled")), null);
                            }
                            if ((object.getString("name")).equalsIgnoreCase("Vibration")) {
                                NotificationSettingsActivity.savedSoundAndNotification(getApplicationContext(), null, (object.getString("enabled")));
                            }
                        }

                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
