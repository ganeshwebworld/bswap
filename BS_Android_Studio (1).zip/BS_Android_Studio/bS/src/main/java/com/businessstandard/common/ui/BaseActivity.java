/**
 * Project      : Economist
 * Filename     : BaseActivity.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */

package com.businessstandard.common.ui;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.webkit.WebSettings.ZoomDensity;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.common.customviews.CategoryScrollView;
import com.businessstandard.common.customviews.CategoryScrollView.OnCategorySelectedListener;
import com.businessstandard.common.dto.SectionNewsItem;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.manager.BaseManager.CatgyDloadCmpltListener;
import com.businessstandard.common.manager.MenuCall;
import com.businessstandard.common.manager.MenuInterface;
import com.businessstandard.common.ui.BaseFragment.FragmentListner;
import com.businessstandard.common.ui.BaseFragment.NewsItemClickListner;
import com.businessstandard.common.util.Constants.MarketKeys;
import com.businessstandard.common.util.Constants.SearchStock;
import com.businessstandard.common.util.Constants.Sections;
import com.businessstandard.common.util.Constants.SelectedCat;
import com.businessstandard.common.util.Constants.SettingsKeys;
import com.businessstandard.common.util.FragmentHelper;
import com.businessstandard.common.util.TwitterHelper;
import com.businessstandard.common.util.TwitterShare;
import com.businessstandard.common.util.Utility;
import com.businessstandard.gallery.GalleryFragment;
import com.businessstandard.home.HomeManager;
import com.businessstandard.home.ui.ArticleDetailFragment.OnNewslistAvailabelListener;
import com.businessstandard.home.ui.HomeFragment;
import com.businessstandard.home.ui.HomeFragment.OnNewsListDwnloadedListener;
import com.businessstandard.market.ui.CommoditiesFragment;
import com.businessstandard.market.ui.IndicesFragment;
import com.businessstandard.market.ui.MarketActivity;
import com.businessstandard.market.ui.MarketNewsFragment;
import com.businessstandard.market.ui.StocksFragment;
import com.businessstandard.settings.ui.AccountSettingsActivity;
import com.businessstandard.settings.ui.FavouritesFragment;
import com.businessstandard.settings.ui.NotificationSettingsActivity;
import com.businessstandard.settings.ui.OffersPromotionsActivity;
import com.businessstandard.settings.ui.SendFeedbakActivity;
import com.businessstandard.settings.ui.SettingsContentActivity;
import com.businessstandard.settings.ui.SettingsFragment;
import com.businessstandard.settings.ui.SettingsFragment.SettingsItemClickListner;
import com.businessstandard.todayspaper.ui.TodaysPaperFragment;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.ShareUtility;
import com.comscore.analytics.comScore;
import com.facebook.Session;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author lenesha
 */
public class BaseActivity extends FragmentActivity implements NewsItemClickListner, OnCheckedChangeListener, OnClickListener, SettingsItemClickListner, OnNewsListDwnloadedListener,
        OnNewslistAvailabelListener, FragmentListner, OnCategorySelectedListener, MenuInterface {

    private FrameLayout mContentContainer;
    protected RadioGroup mRadioGroup;
    public Button mSearchButton;
    protected Button mRefreshBtn;
    // protected BonzaiAdView mCommonAd;
    protected LinearLayout mCommonAd;
    protected LinearLayout mCommonAd_up;
    protected ImageView mDivider;
    protected SectionNewsRootFeedItem mFeedItem;
    protected String mSelectedCategory;
    protected View mHeader, mSemsex;
    public static boolean sSelected;
    public CategoryScrollView mCategoryScroll;
    public ArrayList<String> mSubCategoryList;
    public HashMap<String, String> mSubCatgryMap;
    public int mSectionType;
    protected String mSelectedCatName;
    public ImageView mHeaderTxt;
    public RadioButton mHomeBtn;
    private String strAdDown;
    private String strAdUp;
    private Context mContext;
    private WebView webview;
    private WebView webview_Down;
    public static int numAdCount = 1;
    public static String upAds = "false";
    public static String lwrAds = "false";
    public static String popUpAds = "false";
    public static ListView lvMenu;
    private ListView lvMenunew;
    private String[] lvMenuItems;
    private String[] lvMenuItemsNew;
    private String[] lvMenuItemsmarket;
    private String[] lvMenuItemstodays;
    public static String name = null;
    MainLayout mainLayout;
    TextView date;
    TextView headerText;
    // Menu button
    Button btMenu;
    Button listbtMenu;
    int counter;
    String selectedItem;
    Button setting;
    public static int viewCounter = 0;
    public static String select = "";
    // Title according to fragment
    TextView tvTitle;
    String regid;
    boolean doubleBackToExitPressedOnce = false;
    public static final String EXTRA_MESSAGE = "message";
    public static final String PROPERTY_REG_ID = "registration_id";
    private static final String PROPERTY_APP_VERSION = "appVersion";
    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;

    AtomicInteger msgId = new AtomicInteger();
    SharedPreferences prefs;
    AsyncTask<Void, Void, Void> mRegisterTask;
    private int MY_PERMISSIONS_REQUEST_WRITE_CALENDAR = 0;

    @SuppressLint("InflateParams")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        // mainLayout = (MainLayout) this.getLayoutInflater().inflate(
        // R.layout.base_layout, null);
        setContentView(R.layout.base_layout);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setting = (Button) findViewById(R.id.setting_button);

        headerText = (TextView) findViewById(R.id.header_date);
        selectedItem = MainFragmentActivity.sabcat;

        new BsAdsCheck().execute();

        lvMenu = (ListView) findViewById(R.id.activity_main_menu_listview);
        lvMenunew = (ListView) findViewById(R.id.newlist);
        lvMenuItems = getResources().getStringArray(R.array.menu_items);
        lvMenu.setAdapter(new ArrayAdapter<String>(mContext, R.layout.text_view, lvMenuItems));

        mCommonAd = (LinearLayout) findViewById(R.id.common_ad_banner_layout);
        mCommonAd_up = (LinearLayout) findViewById(R.id.common_ad_banner_layout_up);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.BOTTOM;
        params.setMargins(0, 0, 0, 0);
        mCommonAd.setLayoutParams(params);
        webview = (WebView) findViewById(R.id.webView);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webview.getSettings().setLoadWithOverviewMode(true);
        webview.getSettings().setBuiltInZoomControls(false);
        webview.setHorizontalScrollBarEnabled(false);
        webview.getSettings().setDomStorageEnabled(true);
        webview.getSettings().setAllowFileAccess(true);
        webview.getSettings().setLoadsImagesAutomatically(true);
        webview.getSettings().setSupportZoom(false);
        webview.setInitialScale(100);
        webview.getSettings().setDefaultZoom(ZoomDensity.FAR);
        webview.getSettings().setUserAgentString("Safari/534.30 Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 ");
        // webview.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);

        webview_Down = (WebView) findViewById(R.id.webView1);
        webview_Down.getSettings().setJavaScriptEnabled(true);
        webview_Down.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webview_Down.getSettings().setLoadWithOverviewMode(true);
        webview_Down.getSettings().setBuiltInZoomControls(false);
        webview_Down.setHorizontalScrollBarEnabled(false);
        webview_Down.getSettings().setDomStorageEnabled(true);
        webview_Down.getSettings().setAllowFileAccess(true);
        webview_Down.getSettings().setLoadsImagesAutomatically(true);
        webview_Down.getSettings().setSupportZoom(false);
        webview_Down.setInitialScale(100);
        webview_Down.getSettings().setDefaultZoom(ZoomDensity.FAR);
        webview_Down.getSettings().setUserAgentString("Safari/534.30 Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 ");
        // webview_Down.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        // webview.loadUrl("file:///android_asset/ComScore.html");
        @SuppressWarnings("static-access")
        Display d = ((WindowManager) getSystemService(this.WINDOW_SERVICE)).getDefaultDisplay();
        @SuppressWarnings("deprecation")
        int width = d.getWidth();
        @SuppressWarnings("deprecation")
        int height = d.getHeight();
        // //System.out.println("Device Width-->>"+width);
        // //System.out.println("Device Height-->>"+height);
        if (width >= 220 && width < 260) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

            mCommonAd_up.setLayoutParams(lp);
            mCommonAd.removeAllViews();
            mCommonAd_up.removeAllViews();
            webview_Down.loadUrl("file:///android_asset/Ads_down240.html");
            mCommonAd.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up240.html");
            mCommonAd_up.addView(webview);
        } else if (width >= 300 && width < 340) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            mCommonAd_up.setLayoutParams(lp);
            mCommonAd.removeAllViews();
            mCommonAd_up.removeAllViews();
            webview_Down.loadUrl("file:///android_asset/Ads_down320.html");
            mCommonAd.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up320.html");
            mCommonAd_up.addView(webview);

        } else if (width >= 450 && width < 490) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            mCommonAd_up.setLayoutParams(lp);
            mCommonAd.removeAllViews();
            LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            params1.gravity = Gravity.BOTTOM;
            params1.setMargins(0, 0, 0, 0);
            mCommonAd.setLayoutParams(params1);
            mCommonAd_up.removeAllViews();
            webview.getSettings().setUseWideViewPort(false);
            webview_Down.loadUrl("file:///android_asset/Ads_down468.html");
            mCommonAd.addView(webview_Down);
            webview.getSettings().setUseWideViewPort(false);
            webview.loadUrl("file:///android_asset/Ads_up468.html");
            mCommonAd_up.addView(webview);

        } else if (width >= 590 && width < 700) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, 90);
            mCommonAd_up.setLayoutParams(lp);
            mCommonAd.removeAllViews();
            mCommonAd_up.removeAllViews();
            webview_Down.getSettings().setUseWideViewPort(false);
            webview_Down.loadUrl("file:///android_asset/Ads_down600.html");
            mCommonAd.addView(webview_Down);
            webview.getSettings().setUseWideViewPort(false);
            webview.loadUrl("file:///android_asset/Ads_up600.html");
            mCommonAd_up.addView(webview);

        } else if (width >= 700 && width < 730) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, 90);
            mCommonAd_up.setLayoutParams(lp);
            LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            params1.gravity = Gravity.BOTTOM;
            params1.setMargins(0, 0, 0, 0);
            mCommonAd.setLayoutParams(params1);
            mCommonAd.removeAllViews();
            mCommonAd_up.removeAllViews();
            webview_Down.getSettings().setUseWideViewPort(false);
            webview_Down.loadUrl("file:///android_asset/Ads_down720.html");
            mCommonAd.addView(webview_Down);
            webview.getSettings().setUseWideViewPort(false);
            webview.loadUrl("file:///android_asset/Ads_up720.html");
            mCommonAd_up.addView(webview);

        } else if (width >= 730 && width < 770) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, 90);
            mCommonAd_up.setLayoutParams(lp);
            mCommonAd.removeAllViews();
            mCommonAd_up.removeAllViews();
            webview_Down.getSettings().setUseWideViewPort(false);
            webview_Down.loadUrl("file:///android_asset/Ads_down768.html");
            mCommonAd.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up768.html");
            mCommonAd_up.addView(webview);

        } else if (width >= 770 && width <= 800) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, 90);
            mCommonAd_up.setLayoutParams(lp);
            mCommonAd.removeAllViews();
            mCommonAd_up.removeAllViews();
            webview_Down.getSettings().setUseWideViewPort(false);
            webview_Down.loadUrl("file:///android_asset/Ads_down800.html");
            mCommonAd.addView(webview_Down);
            webview.getSettings().setUseWideViewPort(false);
            webview.loadUrl("file:///android_asset/Ads_down800.html");
            mCommonAd_up.addView(webview);

        } else if (width >= 1000) {
            mCommonAd.removeAllViews();
            mCommonAd_up.removeAllViews();
            webview_Down.getSettings().setUseWideViewPort(false);
            webview_Down.loadUrl("file:///android_asset/Ads_down1024.html");
            mCommonAd.addView(webview_Down);
            webview.getSettings().setUseWideViewPort(false);
            webview.loadUrl("file:///android_asset/Ads_up1024.html");
            mCommonAd_up.addView(webview);

        } else {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
            mCommonAd_up.setLayoutParams(lp);
            mCommonAd.removeAllViews();
            mCommonAd_up.removeAllViews();
            webview_Down.getSettings().setUseWideViewPort(false);
            webview_Down.loadUrl("file:///android_asset/Ads_down468.html");
            mCommonAd.addView(webview_Down);
            webview.getSettings().setUseWideViewPort(false);
            webview.loadUrl("file:///android_asset/Ads_up468.html");
            mCommonAd_up.addView(webview);
        }
        init();
        // initCommonAds();
        initListeners();
        // intermercialAds();
        new DownloadImageFromURL().execute();
        // headerText.setText(MainFragmentActivity.sabcat);

        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // String result=data.getStringExtra("result");
                if (Utility.isInternetOn(BaseActivity.this)) {
                    hideCatScrollView();
                    hideTickers();
                    onSettingsTabClicked();
                    date.setText("Settings");
                    selectedItem = "Settings";
                } else {
                    Utility.displayAlert(BaseActivity.this, getResources().getString(R.string.app_name), getResources().getString(R.string.no_connection), android.R.string.ok,
                            Utility.getOkButtonListener(BaseActivity.this));
                }
            }
        });
    }

    /**
     * @author nagaraj
     */
    public void intermercialAds() {

        if (popUpAds.equalsIgnoreCase("true")) {

            Timer t1 = new Timer();
            final Handler handler1 = new Handler();
            TimerTask adsTask = new TimerTask() {
                public void run() {
                    handler1.post(new Runnable() {
                        public void run() {
                            if (numAdCount == 1) {
                                System.out.println("numAdCount--->>" + numAdCount);
                                System.out.println("Intromercial Ads------");
                                Intent intent = new Intent(BaseActivity.this, PopupAdsActivity.class);
                                BaseActivity.this.startActivityFromChild(BaseActivity.this, intent, -1);
                            }
                        }
                    });
                }
            };
            t1.schedule(adsTask, 1000);
        } else {

        }
    }

    private void initListeners() {
        mCategoryScroll.setOnCategorySelectedListener(this);
        mHeaderTxt.setOnClickListener(this);
    }

    public void adViewStatus() {
        this.strAdUp = upAds;
        this.strAdDown = lwrAds;
        if (strAdUp.equalsIgnoreCase("true")) {
            mCommonAd_up.setVisibility(View.VISIBLE);
        } else {
            mCommonAd_up.setVisibility(View.GONE);
        }
        if (strAdDown.equalsIgnoreCase("true")) {
            mCommonAd.setVisibility(View.VISIBLE);
        } else {
            mCommonAd.setVisibility(View.GONE);
        }
    }

    /**
     * @author nagaraj
     */
    public void loadFragment(String cat) {
        if (!mCommonAd.isShown())
            mCommonAd.setVisibility(View.VISIBLE);
        if (!mCommonAd_up.isShown())
            mCommonAd_up.setVisibility(View.VISIBLE);
        if (!mRadioGroup.isShown())
            mRadioGroup.setVisibility(View.GONE);

        switch (mSectionType) {
            case Sections.HOME:
                onHomeTabClicked();
                break;
            case Sections.MARKET:
                marketCatOnClick(mSubCategoryList.get(0), mSubCategoryList.indexOf(cat));
                break;
            case Sections.TODAYS:
                onTodaysPaperTabClicked();
                break;
        }
    }

    protected void hideTickers() {
        // mHeader.setVisibility(View.GONE);
        mSemsex.setVisibility(View.GONE);
        // System.out.println(" Ashish 9->>>>");
    }

    protected void showTickers() {
        // mHeader.setVisibility(View.VISIBLE);
        mSemsex.setVisibility(View.GONE);
        // System.out.println(" Ashish 10->>>>");
    }

    protected void setLayout(int layoutId) {
        mContentContainer.addView(getLayoutInflater().inflate(layoutId, null));
    }

    protected void init() {
        mContentContainer = (FrameLayout) findViewById(R.id.content);
        mRadioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        mRadioGroup.setOnCheckedChangeListener(this);
        date = (TextView) findViewById(R.id.header_date);
        date.setOnClickListener(this);
        // date.setText(MainFragmentActivity.sabcat);
        mDivider = (ImageView) findViewById(R.id.tabs_divider);
        mSearchButton = (Button) findViewById(R.id.search_button);
        mRefreshBtn = (Button) findViewById(R.id.refresh_btn);
        mRefreshBtn.setOnClickListener(this);
        mSearchButton.setOnClickListener(this);
        // mHeader = (View) findViewById(R.id.header_scroll);
        mSemsex = (View) findViewById(R.id.sensex_ticker);
        mCategoryScroll = (CategoryScrollView) findViewById(R.id.category_scrollview);
        mSubCatgryMap = new HashMap<String, String>();
        mSubCategoryList = new ArrayList<String>();
        mHeaderTxt = (ImageView) findViewById(R.id.header_txt);
        mHomeBtn = (RadioButton) mRadioGroup.findViewById(R.id.home);
        btMenu = (Button) findViewById(R.id.menu);
        // listbtMenu = (Button) findViewById(R.id.menunew);
        btMenu.setOnClickListener(this);
        // listbtMenu.setOnClickListener(this);
        // System.out.println(" Ashish 10->>>>");
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
        switch (checkedId) {
            case R.id.home:
                mSectionType = Sections.HOME;
                hideTickers();
                showCatScrollView();
                cleardata();
                onHomeTabClicked();
                // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
                // lvMenuItems = getResources().getStringArray(R.array.menu_items);
                // lvMenu.setAdapter(new ArrayAdapter<String>(mContext,
                // android.R.layout.simple_list_item_1, lvMenuItems));
                break;
            case R.id.markets:
                mSectionType = Sections.MARKET;
                showCatScrollView();
                onMarketsTabClicked();
                if (MainFragmentActivity.sabcat.equals("Market Data")) {
                    Fragment stockFragment;
                    headerText.setText("Stock");
                    stockFragment = new StocksFragment();
                    FragmentHelper.replaceContentFragment(this, R.id.realTabContent, stockFragment);
                    date.setText(selectedItem);
                    headerText.setText(selectedItem);
                    findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
                } else if (MainFragmentActivity.sabcat.equals("Market News")) {
                    Fragment marktNewsFragmnt;
                    headerText.setText("Market News");
                    marktNewsFragmnt = new MarketNewsFragment();
                    FragmentHelper.replaceContentFragment(this, R.id.realTabContent, marktNewsFragmnt);
                    // date.setText(selectedItem);
                    // headerText.setText(selectedItem);
                    findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
                    // finish();
                } else if (MainFragmentActivity.sabcat.equals("Indices")) {
                    Fragment indicesFragmnt;
                    headerText.setText("Indices");
                    indicesFragmnt = new IndicesFragment();
                    FragmentHelper.replaceContentFragment(this, R.id.realTabContent, indicesFragmnt);
                    // date.setText(selectedItem);
                    // headerText.setText(selectedItem);
                    findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
                    // finish();
                } else if (MainFragmentActivity.sabcat.equals("Commodities")) {
                    Fragment commoditiesFragmt;
                    headerText.setText("Commodities");
                    commoditiesFragmt = new CommoditiesFragment();
                    FragmentHelper.replaceContentFragment(this, R.id.realTabContent, commoditiesFragmt);
                    date.setText(selectedItem);
                    headerText.setText(selectedItem);
                    findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
                    // finish();
                }
                break;
            case R.id.todaysPaper:
                mSectionType = Sections.TODAYS;
                showCatScrollView();
                onTodaysPaperTabClicked();
                // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
                // lvMenuItems = getResources().getStringArray(
                // R.array.todaynews_menu_items);
                // lvMenu.setAdapter(new ArrayAdapter<String>(mContext,
                // android.R.layout.simple_list_item_1, lvMenuItems));
                break;
            case R.id.settings:
                if (Utility.isInternetOn(BaseActivity.this)) {
                    hideCatScrollView();
                    hideTickers();
                    onSettingsTabClicked();
                } else {
                    Utility.displayAlert(BaseActivity.this, getResources().getString(R.string.app_name), getResources().getString(R.string.no_connection), android.R.string.ok,
                            Utility.getOkButtonListener(BaseActivity.this));
                }
                break;

            default:
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.search_button:
                // setting.setVisibility(View.GONE);
                // findViewById(R.id.refresh_btn).setVisibility(View.GONE);
                if (Utility.isInternetOn(this)) {
                    BaseActivity.numAdCount = 2;
                    if (mFeedItem != null && mFeedItem.root != null && mFeedItem.root.getmStockSearch() != null) {
                        String stockSearchUrl = mFeedItem.root.getmStockSearch().feedUrl;
                        Intent searchIntent = new Intent(this, SearchCompanyStockActivity.class);
                        searchIntent.putExtra(SearchStock.SEARCH_STOCK_URL, stockSearchUrl);
                        searchIntent.putExtra(MarketKeys.MARKET_ACTIVITY, false);
                        startActivity(searchIntent);
                    } else {
                        BaseActivity.numAdCount = 2;
                        Utility.displayAlert(this, getResources().getString(R.string.app_name), getResources().getString(R.string.no_connection), android.R.string.ok, Utility.getOkButtonListener(this));
                        BaseFragment.numCount = 2;
                    }
                    BaseFragment.numCount = 2;
                } else {
                    Utility.displayAlert(BaseActivity.this, getResources().getString(R.string.app_name), getResources().getString(R.string.no_connection), android.R.string.ok,
                            Utility.getOkButtonListener(BaseActivity.this));
                }
                break;

            case R.id.refresh_btn:
                if (mFeedItem != null && mFeedItem.root != null) {
                    checkCurrentFragment();
                } else if (Utility.isInternetOn(getApplicationContext())) {
                    HomeManager managr = new HomeManager(this);
                    managr.downloadData(new CatgyDloadCmpltListener() {

                        @Override
                        public void onFailure() {
                            Utility.hideProgressDialog();
                            Utility.showToast(getResources().getString(R.string.no_data), getApplicationContext());
                        }

                        @Override
                        public void onFeedsDloadComplete(SectionNewsRootFeedItem result) {
                            mRadioGroup.setEnabled(false);
                            Utility.setDataToActvty(result);
                            mFeedItem = result;

                            if (mFeedItem.root != null) {
                                Utility.hideProgressDialog();
                                Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.realTabContent);
                                if (currentFragment == null) {
                                    mHomeBtn.setChecked(true);
                                } else {
                                    checkCurrentFragment();
                                }
                            }
                        }
                    });
                } else {
                    Utility.displayAlert(BaseActivity.this, getResources().getString(R.string.app_name), getResources().getString(R.string.no_connection), android.R.string.ok,
                            Utility.getOkButtonListener(BaseActivity.this));
                }
                break;
            case R.id.header_txt:
                if (Utility.isInternetOn(this)) {
                    if (mHomeBtn.isChecked()) {
                        if (Utility.isInternetOn(this)) {
                            mSectionType = Sections.HOME;
                            mSelectedCatName = mSubCategoryList.get(0);
                            hideTickers();
                            showCatScrollView();
                            addSubCategory(mSubCategoryList.get(0));
                            onHomeTabClicked();
                        }
                    } else {
                        mHomeBtn.setChecked(true);
                    }
                } else {
                    Utility.displayAlert(BaseActivity.this, getResources().getString(R.string.app_name), getResources().getString(R.string.no_connection), android.R.string.ok, Utility.getOkButtonListener(BaseActivity.this));
                }
                break;
            case R.id.menu:
                SaveSharedPref prefUtility = SaveSharedPref.getInstance(this);
                if (!prefUtility.getMenu().equals("") && prefUtility.getMenu() != null) {
                    lvMenu.setVisibility(View.VISIBLE);
                    Intent animActivity = new Intent(this, MenuActivity.class);
                    animActivity.putExtra("TAGNAME", "null");
                    findViewById(R.id.refresh_btn).setVisibility(View.GONE);
                    findViewById(R.id.setting_button).setVisibility(View.GONE);
                    findViewById(R.id.search_button).setVisibility(View.GONE);
                    startActivity(animActivity);
                } else {
                    new MenuCall(BaseActivity.this, this);
                }
/*                if (Utility.isInternetOn(this)) {
                    lvMenu.setVisibility(View.VISIBLE);
                    Intent animActivity = new Intent(this, MenuLIst.class);
                    animActivity.putExtra("TAGNAME", "null");
                    findViewById(R.id.refresh_btn).setVisibility(View.GONE);
                    findViewById(R.id.setting_button).setVisibility(View.GONE);
                    findViewById(R.id.search_button).setVisibility(View.GONE);
                    startActivityForResult(animActivity, 1);
                } else {
                    Utility.displayAlert(BaseActivity.this, getResources().getString(R.string.app_name), getResources().getString(R.string.no_connection), android.R.string.ok, Utility.getOkButtonListener(BaseActivity.this));
                }*/

                break;
            case R.id.header_date:
                // toggleMenu(v);
                if (Utility.isInternetOn(this)) {
                    lvMenu.setVisibility(View.VISIBLE);
                    //Intent animActivitynew = new Intent(this, MenuLIst.class);
                    Intent animActivitynew = new Intent(this, MenuActivity.class);
                    animActivitynew.putExtra("TAGNAME", "null");
                    findViewById(R.id.refresh_btn).setVisibility(View.GONE);
                    findViewById(R.id.setting_button).setVisibility(View.GONE);
                    findViewById(R.id.search_button).setVisibility(View.GONE);
                    startActivityForResult(animActivitynew, 1);
                } else {
                    Utility.displayAlert(BaseActivity.this, getResources().getString(R.string.app_name), getResources().getString(R.string.no_connection), android.R.string.ok, Utility.getOkButtonListener(BaseActivity.this));
                }
                break;
            case R.id.menunew:
                lvMenunew.setVisibility(View.VISIBLE);
                break;
        }
    }

    /*
     * private void initCommonAds() { AdManager mAdManager = new AdManager();
     * mCommonAd = (BonzaiAdView) findViewById(R.id.common_ad_banner_layout);
     * mAdManager.displayBannerAdOnMainPage(mCommonAd, BonzaiZoneIds.COMMON); }
     */
    protected void onHomeTabClicked() {
        sSelected = false;
        Fragment fragment;
        headerText.setText(MainFragmentActivity.sabcat);
        if (mRadioGroup != null) {
            mRadioGroup.setVisibility(View.GONE);
        }
        fragment = new HomeFragment();
        Bundle bundle = new Bundle();
        bundle.putString(SelectedCat.CATEGORY, MainFragmentActivity.sabcat);
        bundle.putString("feedURL", MainFragmentActivity.feedURL);
        fragment.setArguments(bundle);
        FragmentHelper.replaceContentFragment(this, R.id.realTabContent, fragment);
        intermercialAds();
        numAdCount = 2;
    }

    protected void onMarketsTabClicked() {
        // System.out.println(" Ashish 25->>>>");
        if (!sSelected) {
            // finish();
            Intent marketIntetn = new Intent(this, MarketActivity.class);
            marketIntetn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            sSelected = true;
            overridePendingTransition(0, 0);
            startActivity(marketIntetn);
            numAdCount = 2;
            finish();
            // System.out.println("Markets Tab Clicked-->>");
        }

    }

    protected void onTodaysPaperTabClicked() {
        // System.out.println(" Ashish 26->>>>");
        sSelected = false;
        headerText.setText(MainFragmentActivity.sabcat);
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.realTabContent);
        fragment = new TodaysPaperFragment();
        Bundle bundle = new Bundle();
        // String jdjfdbf=SelectedCat.CATEGORY;
        bundle.putString(SelectedCat.CATEGORY, MainFragmentActivity.sabcat);
        fragment.setArguments(bundle);
        try {
            FragmentHelper.replaceContentFragment(this, R.id.realTabContent, fragment);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void onSettingsTabClicked() {
        // System.out.println(" Ashish 27->>>>");
        sSelected = false;
        findViewById(R.id.refresh_btn).setVisibility(View.INVISIBLE);
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.realTabContent);
        fragment = new SettingsFragment();
        FragmentHelper.replaceSettingsFragment(this, R.id.realTabContent, fragment);
        // System.out.println("On settings Tab-->>");
        BaseFragment.numCount = 2;
        BaseActivity.numAdCount = 2;
    }

    @Override
    public void onSettingsItemClick(int position, String item) {
        // System.out.println(" Ashish 28->>>>"+item);
        if (item.equalsIgnoreCase("Favourites") || item.equalsIgnoreCase("Favorites")) {
            hideCatScrollView();
            loadFavouritesActivity(item, position);
            // System.out.println(" Ashish  fav 29->>>>");
        } else if (item.equalsIgnoreCase("Gallery")) {
            hideCatScrollView();
            loadGalleryFragment(item, position);
        } else if (item.equalsIgnoreCase("Account Settings")) {
            loadAccountSettingsActivity(item, position);
            // System.out.println(" Ashish acct sett 30->>>>");
        } else if (item.equalsIgnoreCase("Offers & Promotions")) {
            loadOffersPromotionsActivity(item, position);
        } else if (item.equalsIgnoreCase("Notification Settings")) {
            loadNotificationSettingsContentActivity(item, position);
        } else if (item.equalsIgnoreCase("Send Feedback")) {
            if (Utility.isInternetOn(mContext)) {
                loadSendfeedbackActivity(item, position);
            } else {
                Utility.showToast("Please check your interent  connection", mContext);
            }
        } else if (item.equalsIgnoreCase("Share This App")) {
       /*     if (Utility.isInternetOn(mContext)) {
                SubNewsItem newsItem = new SubNewsItem();
                newsItem.short_url = "https://play.google.com/store/apps/details?id=com.businessstandard";
                newsItem.imageUrl = "";
                newsItem.newsUrl = "";
                newsItem.briefDescription = "";
                newsItem.title = getResources().getString(R.string.titleforshare);
                ShareDialogFragment frgmt = new ShareDialogFragment(newsItem);
                frgmt.show(getSupportFragmentManager(), "share");
                //
            } else {
                Utility.showToast("Please check your interent  connection", mContext);
            }*/
            ShareUtility.getInstance().shareApp(this, "", getString(R.string.app_share_subject));
        } else if (item.equalsIgnoreCase("Rate This App")) {
            if (Utility.isInternetOn(mContext)) {
                rateThisAppdilaog();
                //
            } else {
                Utility.showToast("Please check your internet connection", mContext);
            }
        } else if (item.equalsIgnoreCase("Logout")) {
            showdilaog();
        } else {
            loadSettingsContentActivity(item, position);
        }

    }

    private void launchMarket() {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            startActivity(myAppLinkToMarket);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "unable to find market app", Toast.LENGTH_LONG).show();
        }
    }

    private void loadGalleryFragment(String item, int position) {
        hideCatScrollView();
        headerText.setText("Gallery");
        date.setText("Gallery");
        GalleryFragment galleryFragment = new GalleryFragment();
        FragmentHelper.replaceAndAddContentFragment(this, R.id.realTabContent, galleryFragment);
    }

    private void loadSendfeedbackActivity(String item, int position) {
        // System.out.println(" Ashish 36->>>>");
        Intent newIntent = new Intent(this, SendFeedbakActivity.class);
        newIntent.putExtra(SettingsKeys.CLICKED_ITEM, item);
        newIntent.putExtra(SettingsKeys.POSITION, position);
        startActivity(newIntent);
        // System.out.println("On Account settings Tab-->>");
    }

    private void loadOffersPromotionsActivity(String item, int position) {
        // System.out.println(" Ashish 36->>>>");
        Intent newIntent = new Intent(this, OffersPromotionsActivity.class);
        newIntent.putExtra(SettingsKeys.CLICKED_ITEM, item);
        newIntent.putExtra(SettingsKeys.POSITION, position);
        startActivity(newIntent);
        // System.out.println("On Account settings Tab-->>");
    }

    private void loadAccountSettingsActivity(String item, int position) {
        // System.out.println(" Ashish 36->>>>");
        Intent newIntent = new Intent(this, AccountSettingsActivity.class);
        newIntent.putExtra(SettingsKeys.CLICKED_ITEM, item);
        newIntent.putExtra(SettingsKeys.POSITION, position);
        startActivity(newIntent);
        // System.out.println("On Account settings Tab-->>");
    }

    private void loadFavouritesActivity(String item, int position) {
        // System.out.println(" Ashish 37->>>>");
        hideCatScrollView();
        headerText.setText("Favorites");
        date.setText("Favorites");
        FavouritesFragment favFragment = new FavouritesFragment();
        FragmentHelper.replaceAndAddContentFragment(this, R.id.realTabContent, favFragment);
        // System.out.println("On Fav Tab-->>");
    }

    private void loadSettingsContentActivity(String item, int position) {
        // System.out.println(" Ashish 38->>>>");
        Intent newIntent = new Intent(this, SettingsContentActivity.class);
        newIntent.putExtra(SettingsKeys.CLICKED_ITEM, item);
        newIntent.putExtra(SettingsKeys.POSITION, position);
        startActivity(newIntent);
    }

    private void loadNotificationSettingsContentActivity(String item, int position) {
        // System.out.println(" Ashish 38->>>>");
        Intent newIntent = new Intent(this, NotificationSettingsActivity.class);
        newIntent.putExtra(SettingsKeys.CLICKED_ITEM, item);
        newIntent.putExtra(SettingsKeys.POSITION, position);
        startActivity(newIntent);
    }

    public void onStart() {
        try {
            super.onStart();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onResume() {
        try {
            comScore.onEnterForeground();
            BaseFragment.numCount = 0;
            super.onResume();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onDestroy() {
        try {
            super.onDestroy();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onStop() {
        try {
            super.onStop();
            BaseFragment.numCount = 1;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.support.v4.app.FragmentActivity#onPause()
     */
    @Override
    protected void onPause() {
        try {
            comScore.onExitForeground();
            super.onPause();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onBackPressed() {
        // super.onBackPressed();
        // if (mainLayout.isMenuShown()) {
        // mainLayout.toggleMenu();
        // counter = 0;
        // } else {
        // counter = 1;
        // date.setVisibility(View.VISIBLE);
        // super.onBackPressed();
        // }
        // // else{
        // // date.setVisibility(View.VISIBLE);
        // // mRefreshBtn.setVisibility(View.VISIBLE);
        // // super.onBackPressed();
        // // }
        // if (counter == 1) {

/*
        if (headerText != null) {
            headerText.setText("Top Stories");
        }
*/

        super.onBackPressed();

        Fragment frg = getSupportFragmentManager().findFragmentById(R.id.realTabContent);

        // if (doubleBackToExitPressedOnce) {
        // super.onBackPressed();
        // return;
        // }
        //
        // this.doubleBackToExitPressedOnce = true;
        // Toast.makeText(this, "Please click BACK again to exit",
        // Toast.LENGTH_SHORT).show();
        //
        // new Handler().postDelayed(new Runnable() {
        //
        // @Override
        // public void run() {
        // doubleBackToExitPressedOnce = false;
        // }
        // }, 2000);
        // System.out.println(" Ashish 41->>>>");

        /**
         * @author poojarani
         */

        if ((frg instanceof HomeFragment || frg instanceof TodaysPaperFragment || frg instanceof MarketNewsFragment)) {
            if (headerText != null) {
                headerText.setText("Top Stories");
            }
            // mCommonAd.setVisibility(View.VISIBLE);
            // mCommonAd_up.setVisibility(View.VISIBLE);
            // onHomeTabClicked();
            adViewStatus();
            // initCommonAds();
            mRadioGroup.setVisibility(View.GONE);
            mDivider.setVisibility(View.VISIBLE);
            mRefreshBtn.setVisibility(View.VISIBLE);

            // showTickers();
            // System.out.println(" Ashish 42->>>>");

        }
        // else{
        //
        // }

        if (frg instanceof SettingsFragment) {
            if (headerText != null) {
                headerText.setText("Settings");
            }
            // mCommonAd.setVisibility(View.VISIBLE);
            // mCommonAd_up.setVisibility(View.VISIBLE);
            adViewStatus();
            // initCommonAds();
            mRadioGroup.setVisibility(View.GONE);
            mDivider.setVisibility(View.VISIBLE);
            mRefreshBtn.setVisibility(View.INVISIBLE);
            // System.out.println(" Ashish 43->>>>");

        }

        if ((frg instanceof MarketNewsFragment)) {
            showTickers();
            // System.out.println(" Ashish 44->>>>");
        }

    }

    // }

    /**
     *
     */
    // private void backbutton() {
    // // TODO Auto-generated method stub
    // if (doubleBackToExitPressedOnce) {
    // super.onBackPressed();
    // return;
    // }
    //
    // this.doubleBackToExitPressedOnce = true;
    // Toast.makeText(this, "Please click BACK again to exit",
    // Toast.LENGTH_SHORT).show();
    //
    // new Handler().postDelayed(new Runnable() {
    //
    // @Override
    // public void run() {
    // doubleBackToExitPressedOnce = false;
    // }
    // }, 2000);
    // }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == TwitterShare.TWITTER_REQUESTCODE) {
            TwitterHelper.tweetMessage(data);
        }
        try {
            Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);
        } catch (Exception e) {
            // TODO: handle exception
        }
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                selectedItem = data.getStringExtra("result");
                // if (result.compareTo("Current affairs") == 0) {
                // FragmentManager fm =
                // BaseActivity.this.getSupportFragmentManager();
                // FragmentTransaction ft = fm.beginTransaction();
                // ft.commitAllowingStateLoss();
                // mSelectedCatName = result;
                // loadFragment(result);
                // addSubCategory(result);
                // date.setText(result);
                // // date.setText(selectedItem);
            }
            if (resultCode == RESULT_CANCELED) {
                // Write your code if there's no result
                // selectedItem = "book";
            }
        }
    }

    @Override
    public SectionNewsRootFeedItem getDataFromActivity() {
        return mFeedItem;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.businessstandard.common.ui.BaseFragment.FragmentListner#
     * getSelectedCategory()
     */
    @Override
    public String getSelectedCategory() {
        return mSelectedCategory;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.businessstandard.home.ui.ArticleDetailFragment.
     * OnNewslistAvailabelListener#onNewsListAvail()
     */
    @Override
    public ArrayList<SubNewsItem> onNewsListAvail() {

        return null;
    }

    @Override
    public void onNewsListDownloaded(ArrayList<SubNewsItem> newsList) {

    }

    @Override
    public void onNewsItemClick(SubNewsItem subNewsitemClicked, int position, String mSelectedCatName, String newscategory) {

    }

    protected void checkCurrentFragment() {

        Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.realTabContent);
        if (currentFragment != null) {
            if (currentFragment instanceof StocksFragment) {
                StocksFragment stockFrag = (StocksFragment) currentFragment;
                stockFrag.refreshContent();
            } else if (currentFragment instanceof CommoditiesFragment) {
                CommoditiesFragment commodFrag = (CommoditiesFragment) currentFragment;
                commodFrag.refreshContent();

            } else if (currentFragment instanceof IndicesFragment) {
                IndicesFragment indiFrag = (IndicesFragment) currentFragment;
                indiFrag.refreshContent();
            } else if (currentFragment instanceof MarketNewsFragment) {
                MarketNewsFragment marktFrag = (MarketNewsFragment) currentFragment;
                marktFrag.refreshContent();
            } else if (currentFragment instanceof HomeFragment) {
                HomeFragment homeFrag = (HomeFragment) currentFragment;
                homeFrag.refreshContent();
            } else if (currentFragment instanceof TodaysPaperFragment) {
                TodaysPaperFragment todfrag = (TodaysPaperFragment) currentFragment;
                todfrag.refreshContent();
            }
        }
    }

    public void setCatgeroes(List<String> cats, HashMap<String, String> CatsMap, String selectedCat) {

        adViewStatus();
        mSubCategoryList.clear();
        mSubCatgryMap.clear();
        mSubCatgryMap.putAll(CatsMap);
        mSubCategoryList.addAll(cats);
        addSubCategory(selectedCat);
    }

    public void setTopStoriesCatgeroes(List<String> cats, HashMap<String, String> CatsMap, String subCategory) {
        mSubCategoryList.clear();
        mSubCatgryMap.clear();
        String selectedCat = null;
        mSubCatgryMap.putAll(CatsMap);
        mSubCategoryList.addAll(cats);
        if (subCategory == null) {
            selectedCat = mSubCategoryList.get(0);
        } else {
            if (mSubCatgryMap.containsKey(subCategory)) {
                selectedCat = subCategory;
            } else {
                selectedCat = mSubCategoryList.get(0);
            }
        }
        addSubCategory(selectedCat);
    }

    public void homeCategories(List<SectionNewsItem> listofFeeds) {
        String selectedCat = null;
        if (listofFeeds != null && listofFeeds.size() > 0) {

            for (SectionNewsItem item : listofFeeds) {
                mSubCatgryMap.put(item.categoryName, item.feedUrl);
                mSubCategoryList.add(item.categoryName);
            }
            selectedCat = mSubCategoryList.get(0);
            addSubCategory(selectedCat);
        }
    }

    /**
     * @param selectedCat
     */
    public void addSubCategory(String selectedCat) {
        adViewStatus();
        mCategoryScroll.addCategory(mSubCategoryList, selectedCat);
        BaseFragment.numCount = 1;

    }

    public void cleardata() {
        mSubCatgryMap.clear();
        mSubCategoryList.clear();
    }

    public void showCatScrollView() {
        if (Utility.isInternetOn(this) && MainFragmentActivity.sabcat.equals("Market Data") || MainFragmentActivity.sabcat.equals("Commodities"))
            mCategoryScroll.setVisibility(View.VISIBLE);
        else {
            hideCatScrollView();
        }
    }

    public void hideCatScrollView() {
        mCategoryScroll.setVisibility(View.GONE);
    }

    public void marketCatOnClick(String catgory, int index) {
        showTickers();
        switch (index) {
            case MarketKeys.STOCKS:
                Fragment stockFragment;
                stockFragment = new StocksFragment();
                FragmentHelper.replaceContentFragment(this, R.id.realTabContent, stockFragment);
                break;
            case MarketKeys.COMMODITIES:
	/*		Fragment commoditiesFragmt;
			commoditiesFragmt = new CommoditiesFragment();
			FragmentHelper.replaceContentFragment(this, R.id.realTabContent, commoditiesFragmt);*/
                break;
            case MarketKeys.MARKET_NEWS:
		/*	Fragment marktNewsFragmnt;
			marktNewsFragmnt = new MarketNewsFragment();
			FragmentHelper.replaceContentFragment(this, R.id.realTabContent, marktNewsFragmnt);*/
                Fragment indicesFragmnt;
                indicesFragmnt = new IndicesFragment();
                FragmentHelper.replaceContentFragment(this, R.id.realTabContent, indicesFragmnt);
                break;
            case MarketKeys.INDICES:
		/*	Fragment indicesFragmnt;
			indicesFragmnt = new IndicesFragment();
			FragmentHelper.replaceContentFragment(this, R.id.realTabContent, indicesFragmnt);*/
                Fragment commoditiesFragmt;
                commoditiesFragmt = new CommoditiesFragment();
                FragmentHelper.replaceContentFragment(this, R.id.realTabContent, commoditiesFragmt);
                break;

            default:
                break;
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see com.businessstandard.common.customviews.CategoryScrollView.
     * OnCategorySelectedListener#onCategorySelected(java.lang.String)
     */
    @Override
    public void onCategorySelected(String category) {
        mSelectedCatName = category;
        loadFragment(category);
        addSubCategory(category);
    }

    public void hideadView() {
        mCommonAd.setVisibility(View.GONE);
        mCommonAd_up.setVisibility(View.GONE);
    }

    public void hideRadiogroup() {
        mRadioGroup.setVisibility(View.GONE);
    }

    public void alertBox(String title, String mymessage) {
        new AlertDialog.Builder(mContext).setMessage(mymessage).setTitle(title).setCancelable(true).setNeutralButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        }).show();
    }

    @Override
    public void onSelectResult(String value) {
        SaveSharedPref prefUtility = SaveSharedPref.getInstance(this);
        prefUtility.saveMenu(value);
        lvMenu.setVisibility(View.VISIBLE);
        Intent animActivity = new Intent(this, MenuActivity.class);
        animActivity.putExtra("TAGNAME", "null");
        findViewById(R.id.refresh_btn).setVisibility(View.GONE);
        findViewById(R.id.setting_button).setVisibility(View.GONE);
        findViewById(R.id.search_button).setVisibility(View.GONE);
        startActivity(animActivity);
    }

    /**
     * Background Async Task to download file
     */
    class DownloadImageFromURL extends AsyncTask<String, String, String> {

        /**
         * Before starting background thread Show Progress Bar Dialog
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // showDialog(progress_bar_type);
        }

        /**
         * Downloading file in background thread
         */
        @Override
        protected String doInBackground(String... args) {
            int count;
            try {

                // String strUrl
                // ="http://180.151.100.58:81/splash_screen_bg.png";

                String strUrl = "http://images.business-standard.com/ads/ipad_ads/important/splash_screen_bg.png";

                URL url = new URL(strUrl);
                URLConnection conection = url.openConnection();
                conection.connect();
                // this will be useful so that you can show a tipical 0-100%
                // progress bar
                int lenghtOfFile = conection.getContentLength();

                // Date(conection.getExpiration()));
                // download the file
                DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
                Date lastModifiedUrl = new Date(conection.getLastModified());
                String lastModUrl = df.format(lastModifiedUrl);


                String imgPath = mContext.getFilesDir().toString().trim();
                File file = new File(imgPath + "/" + "splashscreen.png");
                DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
                String lastModImg = sdf.format(file.lastModified());


                Date date1 = sdf.parse(lastModUrl);
                Date date2 = sdf.parse(lastModImg);

                if (date1.compareTo(date2) > 0) {
                    InputStream input = new BufferedInputStream(url.openStream(), 8192);
                    // Output stream
                    OutputStream output = new FileOutputStream(imgPath + "/" + "splashscreen.png");
                    // OutputStream output = new
                    // FileOutputStream("/sdcard/downloadedfile.jpg");

                    byte data[] = new byte[1024];

                    long total = 0;

                    while ((count = input.read(data)) != -1) {
                        total += count;
                        // publishing the progress....
                        // After this onProgressUpdate will be called
                        publishProgress("" + (int) ((total * 100) / lenghtOfFile));

                        // writing data to file
                        output.write(data, 0, count);
                    }

                    // flushing output
                    output.flush();
                    // closing streams
                    output.close();
                    input.close();
                }

            } catch (Exception e) {
                // Log.e("Error: ", e.getMessage());
                e.printStackTrace();
            }

            return null;
        }

        /**
         * Updating progress bar
         */
        protected void onProgressUpdate(String... progress) {
            // setting progress percentage
            // pDialog.setProgress(Integer.parseInt(progress[0]));
        }

        /**
         * After completing background task Dismiss the progress dialog
         **/
        @Override
        protected void onPostExecute(String file_url) {

            String imagePath = mContext.getFilesDir().toString().trim() + "/splashscreen.png";
            // relLayout = (RelativeLayout) findViewById(R.id.rellayout);
            // Drawable drawable =Drawable.createFromPath(imagePath); //new
            // Image that was added to the res folder
            // relLayout.setBackgroundDrawable(drawable);
            new BsAdsCheck().execute();
        }

    }

    private class BsAdsCheck extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // showDialog(DIALOG_DOWNLOAD_PROGRESS);
        }

        @Override
        protected String doInBackground(String... args) {
            // System.out.println(" Ashish 70->>>>");
            String strResult = "";
            try {

                try {
                    // String
                    // strUrl="http://180.151.100.58:81/bsandroidApp.txt";
                    String strUrl = "http://images.business-standard.com//ads/ipad_ads/important//bsandroidApp.txt";

                    URL url = new URL(strUrl);
                    URLConnection urlCon = (HttpURLConnection) url.openConnection();
                    ((HttpURLConnection) urlCon).setRequestMethod("GET");
                    urlCon.setDoInput(true);

                    if (urlCon.getConnectTimeout() != 0) {
                        urlCon.setUseCaches(false);
                    } else {
                        urlCon.setUseCaches(true);
                    }

                    StringBuffer sb = new StringBuffer();
                    BufferedReader in = new BufferedReader(new InputStreamReader(urlCon.getInputStream()));
                    if (in != null) {
                        String strLine = null;
                        // while ((strLine = in.readLine()) != null) {
                        while ((strLine = in.readLine()) != null) {
                            sb.append(strLine);
                        }
                        in.close();
                    }
                    strResult = sb.toString();

                    // System.out.println("strResult-->>"+strResult);

                } catch (java.net.MalformedURLException urlex) {
                    urlex.printStackTrace();
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                }

                upAds = "false";
                lwrAds = "false";
                popUpAds = "false";

                if (strResult.length() > 0) {

                    String[] arrAds = strResult.split("@@@");

                    if (arrAds.length == 3) {
                        // //System.out.println("blnResult--->>>>>>>"+strResult);
                        // //System.out.println("upperAd-->>>"+arrAds[0]+"\nlowerAd-->>"+arrAds[1]);
                        String[] upperAds = arrAds[0].split("=");
                        if (upperAds.length == 2) {
                            if (upperAds[1].equalsIgnoreCase("true") || upperAds[1].equalsIgnoreCase("false")) {
                                upAds = upperAds[1];
                            } else {
                                upAds = "false";
                            }
                        } else {
                            upAds = "false";
                        }
                        // //System.out.println("upperAd status--->>>>>>>"+upperAds[1]);

                        String[] lowerAds = arrAds[1].split("=");
                        if (lowerAds.length == 2) {
                            if (lowerAds[1].equalsIgnoreCase("true") || lowerAds[1].equalsIgnoreCase("false")) {
                                lwrAds = lowerAds[1];
                            } else {
                                lwrAds = "false";
                            }

                        } else {
                            lwrAds = "false";
                        }
                        String[] intermercialAds = arrAds[2].split("=");
                        if (intermercialAds.length == 2) {
                            if (intermercialAds[1].equalsIgnoreCase("true") || intermercialAds[1].equalsIgnoreCase("false")) {
                                popUpAds = intermercialAds[1];
                            } else {
                                popUpAds = "false";
                            }

                        } else {
                            popUpAds = "false";
                        }

                        // //System.out.println("lowerAd status--->>>>>>>"+lowerAds[1]);

                        // System.out.println("Adds Status--->>>>>>>"+upAds+"\nlwr adds--->>"+lwrAds+"\npop up adds--->>"+popUpAds);
                        strResult = upperAds[1] + "@@@" + lowerAds[1] + "@@@" + intermercialAds[1];
                        // System.out.println("blnResult--->>>>>>>"+strResult);
                    } else {
                        upAds = "false";
                        lwrAds = "false";
                        popUpAds = "false";
                        strResult = upAds + lwrAds + popUpAds;
                        // System.out.println("strResult--->>>"+strResult);

                    }

                }

            } catch (Exception expx) {
                expx.printStackTrace();
            }
            return strResult;

        }

        protected void onProgressUpdate(String... progress) {
            super.onProgressUpdate(progress);

        }

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            adViewStatus();
            if (result.indexOf("true") > -1) {
                // intermercialAds();
            }

        }

    }

    // protected void onProgressUpdate(String... progress) {
    // super.onProgressUpdate(progress);
    //
    // }

    /**
     * Registers the application with GCM servers asynchronously.
     * <p>
     * Stores the registration ID and app versionCode in the application's
     * shared preferences.
     */
    // private void registerInBackground() {
    // new AsyncTask() {
    // @Override
    // protected String doInBackground(Void... params) {
    // String msg = "";
    // try {
    // if (gcm == null) {
    // gcm = GoogleCloudMessaging.getInstance(mContext);
    // }
    // regid = gcm.register(SENDER_ID);
    // msg = "Device registered, registration ID=" + regid;
    //
    // // You should send the registration ID to your server over
    // // HTTP,
    // // so it can use GCM/HTTP or CCS to send messages to your
    // // app.
    // // The request to your server should be authenticated if
    // // your app
    // // is using accounts.
    // sendRegistrationIdToBackend();
    //
    // // For this demo: we don't need to send it because the
    // // device
    // // will send upstream messages to a server that echo back
    // // the
    // // message using the 'from' address in the message.
    //
    // // Persist the regID - no need to register again.
    // storeRegistrationId(mContext, regid);
    // } catch (IOException ex) {
    // msg = "Error :" + ex.getMessage();
    // // If there is an error, don't just keep trying to register.
    // // Require the user to click a button again, or perform
    // // exponential back-off.
    // }
    // return msg;
    // }
    //
    // @Override
    // protected void onPostExecute(String msg) {
    // // mDisplay.append(msg + "\n");
    // }
    // }.execute(null, null, null);
    //
    // }
    private void rateThisAppdilaog() {
        // TODO Auto-generated method stub
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(BaseActivity.this);

        // Setting Dialog Title
        alertDialog.setTitle("Rate this app");

        // Setting Dialog Message
        alertDialog.setMessage("You will be redirected to Google Play store for rating the app.");

        // Setting Positive "Yes" Button
        alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                //launchMarket();
                ShareUtility.getInstance().jumpToPlayStore(BaseActivity.this);
            }
        });
        // Setting Negative "NO" Button
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // Write your code here to execute after dialog
                dialog.cancel();
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }

    private void showdilaog() {
        // TODO Auto-generated method stub
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(BaseActivity.this);

        // Setting Dialog Title
        alertDialog.setTitle("\tBS");

        // Setting Dialog Message
        alertDialog.setMessage("Are you sure you wish to logout? ");

        // Setting Positive "Yes" Button
        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                String fileDirPath = getApplicationContext().getFilesDir() + "/userinfo.json";
                File f1 = new File(fileDirPath);
                if (f1.exists()) {
                    final boolean blnStatus = f1.delete();
                    SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    SharedPreferences.Editor edit = preferences.edit();
                    edit.clear().commit();
                    Toast.makeText(BaseActivity.this, "LOGOUT SUCCESSFUL", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(BaseActivity.this, MainFragmentActivity.class);
                    startActivity(i);
                    finish();

                    if (blnStatus) {

                        // getApplicationContext().startActivity(iMainAct);
                    }
                } else {
                    dialog.cancel();
                    // mContext.startActivity(iMainAct);
                }
            }
        });
        // Setting Negative "NO" Button
        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // Write your code here to execute after dialog
                dialog.cancel();
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }

    // private void onMenuItemClick(AdapterView<?> parent, View view,
    // int position, long id) {
    // // String selectedItem = lvMenuItems[position];
    // // String currentItem = tvTitle.getText().toString();
    //
    // // Do nothing if selectedItem is currentItem
    // // if(selectedItem.compareTo(currentItem) == 0) {
    // // mainLayout.toggleMenu();
    // // return;
    // // }
    //
    // FragmentManager fm = BaseActivity.this.getSupportFragmentManager();
    // FragmentTransaction ft = fm.beginTransaction();
    // Fragment fragment = null;
    //
    // if (selectedItem.compareTo("Home") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = mSubCategoryList.get(0);
    // hideTickers();
    // showCatScrollView();
    // addSubCategory(mSubCategoryList.get(0));
    // onHomeTabClicked();
    //
    // lvMenunew.setVisibility(View.VISIBLE);
    // lvMenuItemsNew = getResources().getStringArray(
    // R.array.home_menu_items);
    // lvMenunew.setAdapter(new ArrayAdapter<String>(mContext,
    // R.layout.sab_item_list, lvMenuItemsNew));
    // // mButton.setTextColor(Color.parseColor("#FF0000"))
    // } else if (selectedItem.compareTo("Market") == 0) {
    //
    // lvMenunew.setVisibility(View.VISIBLE);
    // lvMenuItemsNew = getResources().getStringArray(
    // R.array.market_menu_items);
    //
    // lvMenunew.setAdapter(new ArrayAdapter<String>(mContext,
    // R.layout.sab_item_list, lvMenuItemsNew));
    //
    // } else if (selectedItem.compareTo("Todays Newspaper") == 0) {
    // // sSelected = false;
    // mSectionType = Sections.TODAYS;
    // showCatScrollView();
    // onTodaysPaperTabClicked();
    // lvMenunew.setVisibility(View.VISIBLE);
    // lvMenuItemsNew = getResources().getStringArray(
    // R.array.todaynews_menu_items);
    // lvMenunew.setAdapter(new ArrayAdapter<String>(mContext,
    // R.layout.sab_item_list, lvMenuItemsNew));
    // } else if (selectedItem.compareTo("Settings") == 0) {
    // lvMenunew.setVisibility(View.VISIBLE);
    // lvMenuItemsNew = getResources().getStringArray(
    // R.array.setting_items);
    // lvMenunew.setAdapter(new ArrayAdapter<String>(mContext,
    // R.layout.sab_item_list, lvMenuItemsNew));
    //
    // }
    //
    // }

    // private void onMenuItemClickView(AdapterView<?> parent, View view,
    // int position, long id) {
    // String selectedItem = lvMenuItemsNew[position];
    // // String currentItem = tvTitle.getText().toString();
    //
    // // Do nothing if selectedItem is currentItem
    // // if(selectedItem.compareTo(currentItem) == 0) {
    // // mainLayout.toggleMenu();
    // // return;
    // // }
    //
    // FragmentManager fm = BaseActivity.this.getSupportFragmentManager();
    // FragmentTransaction ft = fm.beginTransaction();
    // Fragment fragment = null;
    //
    // if (selectedItem.compareTo("Top Stories") == 0) {
    //
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Current affairs") == 0) {
    // mSelectedCatName = selectedItem;
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Economy") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("International") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Companies") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Opinion") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Technologies") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = "Technology";
    // showCatScrollView();
    // addSubCategory("Technology");
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Personal Finance") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Specials") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Stock") == 0) {
    // Fragment stockFragment;
    //
    // stockFragment = new StocksFragment();
    // FragmentHelper.replaceContentFragment(this, R.id.realTabContent,
    // stockFragment);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Market News") == 0) {
    // Fragment marktNewsFragmnt;
    // marktNewsFragmnt = new MarketNewsFragment();
    // FragmentHelper.replaceContentFragment(this, R.id.realTabContent,
    // marktNewsFragmnt);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Indices") == 0) {
    // Fragment indicesFragmnt;
    // indicesFragmnt = new IndicesFragment();
    // FragmentHelper.replaceContentFragment(this, R.id.realTabContent,
    // indicesFragmnt);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Commodities") == 0) {
    // Fragment commoditiesFragmt;
    // commoditiesFragmt = new CommoditiesFragment();
    // FragmentHelper.replaceContentFragment(this, R.id.realTabContent,
    // commoditiesFragmt);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Favorites") == 0) {
    // hideCatScrollView();
    // loadFavouritesActivity(selectedItem, 0);
    // date.setVisibility(View.GONE);
    // // mRefreshBtn.setVisibility(View.GONE);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Account Setting") == 0) {
    // loadAccountSettingsActivity(selectedItem, 1);
    // } else if (selectedItem.compareTo("About Us") == 0) {
    // loadSettingsContentActivity(selectedItem, 2);
    // } else if (selectedItem.compareTo("Contact Us") == 0) {
    // loadSettingsContentActivity(selectedItem, 3);
    // } else if (selectedItem.compareTo("Disclaimer") == 0) {
    // loadSettingsContentActivity(selectedItem, 4);
    // } else if (selectedItem.compareTo("Advertise With Us") == 0) {
    // loadSettingsContentActivity(selectedItem, 5);
    // } else if (selectedItem.compareTo("Privacy Policy") == 0) {
    // loadSettingsContentActivity(selectedItem, 6);
    // } else if (selectedItem.compareTo("Front Page") == 0) {
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Companies & Industry") == 0) {
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Economy & Policy") == 0) {
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Banking & Finance") == 0) {
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Life & Leisure") == 0) {
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Opinion & Analysis") == 0) {
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("The smart Investor") == 0) {
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("The Strategist") == 0) {
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Technology") == 0) {
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Internationals") == 0) {
    // mSelectedCatName = "International";
    // onTodaysPaperTabClicked();
    // loadFragment("International");
    // addSubCategory("International");
    // date.setText(selectedItem);
    // } else if (selectedItem.compareTo("Politics") == 0) {
    // onCategorySelected(selectedItem);
    // date.setText(selectedItem);
    // }
    //
    //
    // mainLayout.toggleMenu();
    // }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("WORKAROUND_FOR_BUG_19917_KEY", "WORKAROUND_FOR_BUG_19917_VALUE");
        super.onSaveInstanceState(outState);
    }

    /*
     * (non-Javadoc)
     *
     * @see android.support.v4.app.FragmentActivity#onResumeFragments()
     */
    @Override
    protected void onPostResume() {
        // TODO Auto-generated method stub
        super.onPostResume();
        findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
        setting.setVisibility(View.VISIBLE);
        findViewById(R.id.search_button).setVisibility(View.VISIBLE);
    }

    // @Override
    // protected void onPostResume() {
    // super.onPostResume();
    // // Commit your transactions here.
    // FragmentManager fm = BaseActivity.this.getSupportFragmentManager();
    // FragmentTransaction ft = fm.beginTransaction();
    // ft.commitAllowingStateLoss();
    // // Fragment stockFragment;
    //
    // if (selectedItem.compareTo("Top Stories") == 0) {
    //
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Current affairs") == 0) {
    // mSelectedCatName = selectedItem;
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Economy") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("International") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Companies") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Opinion") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Technologies") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = "Technology";
    // showCatScrollView();
    // addSubCategory("Technology");
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Personal Finance") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // headerText.setText(MainFragmentActivity.sabcat);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Specials") == 0) {
    // mSectionType = Sections.HOME;
    // mSelectedCatName = selectedItem;
    // showCatScrollView();
    // addSubCategory(selectedItem);
    // onHomeTabClicked();
    // date.setText(selectedItem);
    // headerText.setText(MainFragmentActivity.sabcat);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Stock") == 0) {
    // Fragment stockFragment;
    //
    // stockFragment = new StocksFragment();
    // FragmentHelper.replaceContentFragment(this, R.id.realTabContent,
    // stockFragment);
    // date.setText(selectedItem);
    // headerText.setText(MainFragmentActivity.sabcat);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Market News") == 0) {
    // Fragment marktNewsFragmnt;
    // marktNewsFragmnt = new MarketNewsFragment();
    // FragmentHelper.replaceContentFragment(this, R.id.realTabContent,
    // marktNewsFragmnt);
    // date.setText(selectedItem);
    // headerText.setText(MainFragmentActivity.sabcat);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Indices") == 0) {
    // Fragment indicesFragmnt;
    // indicesFragmnt = new IndicesFragment();
    // FragmentHelper.replaceContentFragment(this, R.id.realTabContent,
    // indicesFragmnt);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Commodities") == 0) {
    // Fragment commoditiesFragmt;
    // commoditiesFragmt = new CommoditiesFragment();
    // FragmentHelper.replaceContentFragment(this, R.id.realTabContent,
    // commoditiesFragmt);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Favorites") == 0) {
    // hideCatScrollView();
    // loadFavouritesActivity(selectedItem, 0);
    // date.setVisibility(View.GONE);
    // // mRefreshBtn.setVisibility(View.GONE);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // // } else if (selectedItem.compareTo("Account Setting") == 0) {
    // // loadAccountSettingsActivity(selectedItem, 1);
    // // } else if (selectedItem.compareTo("About Us") == 0) {
    // // loadSettingsContentActivity(selectedItem, 2);
    // // } else if (selectedItem.compareTo("Contact Us") == 0) {
    // // loadSettingsContentActivity(selectedItem, 3);
    // // } else if (selectedItem.compareTo("Disclaimer") == 0) {
    // // loadSettingsContentActivity(selectedItem, 4);
    // // } else if (selectedItem.compareTo("Advertise With Us") == 0) {
    // // loadSettingsContentActivity(selectedItem, 5);
    // // } else if (selectedItem.compareTo("Privacy Policy") == 0) {
    // // loadSettingsContentActivity(selectedItem, 6);
    // } else if (selectedItem.compareTo("Front Page") == 0) {
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Companies & Industry") == 0) {
    // mSectionType = Sections.TODAYS;
    // showCatScrollView();
    // onTodaysPaperTabClicked();
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Economy & Policy") == 0) {
    // mSectionType = Sections.TODAYS;
    // showCatScrollView();
    // onTodaysPaperTabClicked();
    // mSelectedCatName = selectedItem;
    //
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Banking & Finance") == 0) {
    // mSectionType = Sections.TODAYS;
    // showCatScrollView();
    // onTodaysPaperTabClicked();
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Life & Leisure") == 0) {
    // mSectionType = Sections.TODAYS;
    // showCatScrollView();
    // onTodaysPaperTabClicked();
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Opinion & Analysis") == 0) {
    // mSectionType = Sections.TODAYS;
    // showCatScrollView();
    // onTodaysPaperTabClicked();
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("The smart Investor") == 0) {
    // mSectionType = Sections.TODAYS;
    // showCatScrollView();
    // onTodaysPaperTabClicked();
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("The Strategist") == 0) {
    // mSectionType = Sections.TODAYS;
    // showCatScrollView();
    // onTodaysPaperTabClicked();
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Technology") == 0) {
    // mSectionType = Sections.TODAYS;
    // showCatScrollView();
    // onTodaysPaperTabClicked();
    // mSelectedCatName = selectedItem;
    // onTodaysPaperTabClicked();
    // loadFragment(selectedItem);
    // addSubCategory(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Internationals") == 0) {
    // mSectionType = Sections.TODAYS;
    // showCatScrollView();
    // onTodaysPaperTabClicked();
    // mSelectedCatName = "International";
    // onTodaysPaperTabClicked();
    // loadFragment("International");
    // addSubCategory("International");
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Politics") == 0) {
    // mSectionType = Sections.TODAYS;
    // showCatScrollView();
    // onTodaysPaperTabClicked();
    // onCategorySelected(selectedItem);
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Setting") == 0) {
    // hideCatScrollView();
    // hideTickers();
    // onSettingsTabClicked();
    // date.setText(selectedItem);
    // headerText.setText(selectedItem);
    // // findViewById(R.id.refresh_btn).setVisibility(View.VISIBLE);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("Search") == 0) {
    // BaseActivity.numAdCount = 2;
    // // selectedItem="book";
    // if (mFeedItem != null && mFeedItem.root != null
    // && mFeedItem.root.getmStockSearch() != null) {
    // String stockSearchUrl = mFeedItem.root.getmStockSearch().feedUrl;
    // Intent searchIntent = new Intent(this,
    // SearchCompanyStockActivity.class);
    // searchIntent.putExtra(SearchStock.SEARCH_STOCK_URL,
    // stockSearchUrl);
    // searchIntent.putExtra(MarketKeys.MARKET_ACTIVITY, false);
    // startActivity(searchIntent);
    // } else {
    //
    // BaseActivity.numAdCount = 2;
    // Utility.displayAlert(this,
    // getResources().getString(R.string.app_name),
    // getResources().getString(R.string.no_connection),
    // android.R.string.ok, Utility.getOkButtonListener(this));
    // BaseFragment.numCount = 2;
    // }
    // // date.setText(selectedItem);
    // // selectedItem = "book";
    // } else if (selectedItem.compareTo("refresh") == 0) {
    //
    // if (mFeedItem != null && mFeedItem.root != null) {
    // checkCurrentFragment();
    // } else if (Utility.isInternetOn(getApplicationContext())) {
    // HomeManager managr = new HomeManager(this);
    // managr.downloadData(new CatgyDloadCmpltListener() {
    //
    // @Override
    // public void onFailure() {
    // Utility.hideProgressDialog();
    // Utility.showToast(
    // getResources().getString(R.string.no_data),
    // getApplicationContext());
    //
    // }
    //
    // @Override
    // public void onFeedsDloadComplete(
    // SectionNewsRootFeedItem result) {
    // mRadioGroup.setEnabled(true);
    // Utility.setDataToActvty(result);
    // mFeedItem = result;
    // selectedItem = "book";
    // if (mFeedItem.root != null) {
    // Utility.hideProgressDialog();
    // Fragment currentFragment = getSupportFragmentManager()
    // .findFragmentById(R.id.realTabContent);
    // if (currentFragment == null) {
    // mHomeBtn.setChecked(true);
    // // onHomeTabClicked();
    // } else {
    // checkCurrentFragment();
    // }
    // }
    //
    // }
    //
    // });
    // }
    //
    // else
    // Utility.displayAlert(BaseActivity.this, getResources()
    // .getString(R.string.app_name), getResources()
    // .getString(R.string.no_connection),
    // android.R.string.ok, Utility
    // .getOkButtonListener(BaseActivity.this));
    // selectedItem = "book";
    //
    // }
    //
    // }
}
