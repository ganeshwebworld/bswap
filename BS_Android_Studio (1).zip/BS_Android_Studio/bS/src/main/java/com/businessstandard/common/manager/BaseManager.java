/**
   Project      : Economist
   Filename     : BaseManager.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */

package com.businessstandard.common.manager;

import java.util.ArrayList;
import java.util.HashMap;

import android.support.v4.app.FragmentActivity;

import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.market.dto.TickerNewsFeedRootObject;
import com.businessstandard.todayspaper.dto.TodaysPaperNewsRootItem;

/**
 * @author lenesha
 * 
 */
public class BaseManager {

	public BaseManager(FragmentActivity activity) {
		
	}

	public static interface CallbackListener {
		void onFailure();
	}

	public static interface CatgyDloadCmpltListener extends CallbackListener {
		void onFeedsDloadComplete(SectionNewsRootFeedItem result);
	}

	public static interface SubNewsDloadCmpltListener extends CallbackListener {
		void onSubNewsDloadComplete(ArrayList<SubNewsItem> result);

		/**
		 * @param result
		 */
		
	}
//	public static interface SubNewsDloadCmpltListenerNew extends CallbackListener {
//		void onSubNewsDloadComplete(HashMap<String, ArrayList<SubNewsItem>> result);
//	}
	

	public static interface TickerDloadCmpltListener extends CallbackListener {
		void onTickerDloadCmplt(TickerNewsFeedRootObject result);
	}

	public static interface TodaysPaperCatgryDownldListner extends CallbackListener {
		void onSubNewsDloadComplete(TodaysPaperNewsRootItem result);
	}
}
