package com.businessstandard.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class GalleryResponseModel implements Serializable {

    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("GalleryVideoslist")
    @Expose
    private List<GalleryVideoslist> galleryVideoslist = null;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<GalleryVideoslist> getGalleryVideoslist() {
        return galleryVideoslist;
    }

    public void setGalleryVideoslist(List<GalleryVideoslist> galleryVideoslist) {
        this.galleryVideoslist = galleryVideoslist;
    }
    
}