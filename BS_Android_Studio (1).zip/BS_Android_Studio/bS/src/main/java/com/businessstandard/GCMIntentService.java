///*
// * Copyright 2012 Google Inc.
// *
// * Licensed under the Apache License, Version 2.0 (the "License");
// * you may not use this file except in compliance with the License.
// * You may obtain a copy of the License at
// *
// *   http://www.apache.org/licenses/LICENSE-2.0
// *
// * Unless required by applicable law or agreed to in writing, software
// * distributed under the License is distributed on an "AS IS" BASIS,
// * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// * See the License for the specific language governing permissions and
// * limitations under the License.
// */
//package com.businessstandard;
//
//import static com.businessstandard.CommonUtilities.SENDER_ID;
//import static com.businessstandard.CommonUtilities.displayMessage;
//import android.app.Notification;
//import android.app.NotificationManager;
//import android.app.PendingIntent;
//import android.content.Context;
//import android.content.Intent;
//import android.content.pm.PackageManager.NameNotFoundException;
//import android.media.RingtoneManager;
//import android.os.Build;
//import android.support.v4.app.NotificationCompat;
//import android.util.Log;
//import android.view.View;
//import android.widget.Toast;
//
//import com.businessstandard.R;
//import com.businessstandard.common.ui.MainFragmentActivity;
//import com.businessstandard.common.ui.MainFragmentActivity.AutoLogin;
//import com.businessstandard.home.ui.ArticleWebView;
//import com.businessstandard.settings.ui.NotificationSettingsActivity;
//import com.businessstandard.ServerUtilities;
//import com.google.android.gcm.GCMBaseIntentService;
//import com.google.android.gcm.GCMRegistrar;
//
///**
// * IntentService responsible for handling GCM messages.
// */
//public class GCMIntentService extends GCMBaseIntentService {
//	String devicename = "android";
//	public static String api_key = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
//	@SuppressWarnings("hiding")
//	private static final String TAG = "GCMIntentService";
//
//	public GCMIntentService() {
//		super(
// );
//	}
//
//	@Override
//	protected void onRegistered(Context context, String registrationId) {
//		Log.i(TAG, "Device registered: regId = " + registrationId);
//		Toast.makeText(context, "Msg Recived", 0);
//
//		// displayMessage(context, getString(R.string.gcm_registered));
//		TelephonyManager tManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
//		String uuid = tManager.getDeviceId();
//		String appversion;
//
//		try {
//			appversion = Integer.toString(getPackageManager().getPackageInfo(getPackageName(), 0).versionCode);
//		} catch (NameNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		String osversion = android.os.Build.VERSION.RELEASE; // e.g. myVersion := "1.6"
//		int sdkVersion = android.os.Build.VERSION.SDK_INT; // e.g. sdkVersion :=
//															// 8;
//
//		try {
//			String versionName = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
//
//			String devicemodel = getDeviceName();
//
//			appversion = Integer.toString(getPackageManager().getPackageInfo(getPackageName(), 0).versionCode);
//			AutoLogin signuptasknew = new MainFragmentActivity.AutoLogin(context,
//					GCMRegistrar.getRegistrationId(context));
//			signuptasknew.execute(api_key, uuid, "Email@example.com", "android", devicename, devicemodel, osversion,
//					appversion);
//		} catch (NameNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//	@Override
//	protected void onUnregistered(Context context, String registrationId) {
//		Log.i(TAG, "Device unregistered");
//		// displayMessage(context, getString(R.string.gcm_unregistered));
//		if (GCMRegistrar.isRegisteredOnServer(context)) {
//			ServerUtilities.unregister(context, registrationId);
//		} else {
//			// This callback results from the call to unregister made on
//			// ServerUtilities when the registration to the server failed.
//			Log.i(TAG, "Ignoring unregister callback");
//		}
//	}
//
//	@Override
//	protected void onMessage(Context context, Intent intent) {
//	protected void onMessage(Context context, Intent intent) {
//		Log.i(TAG, "GCM PUSH RECIVED : " + intent.getExtras().toString());
//		String message = intent.getExtras().getString("message");
//		String articalId = intent.getExtras().getString("articleId");
//		/*
//		 * String sound= intent.getExtras().getString("sound"); String vibration=
//		 * intent.getExtras().getString("vibration");
//		 */
//		Log.d("PUSHRECIVE", "PUSHRECIVE");
//		Log.i(TAG, message + "MAYANK :" + articalId);
//		if (articalId != null) {
//			GenrateNotificaionArtical(context, message, articalId, NotificationSettingsActivity.isSound(context),
//					NotificationSettingsActivity.isVibration(context));
//		} else {
//			displayMessage(context, message);
//			// notifies user
//			generateNotification(context, message);
//		}
//
//	}
//
//	@Override
//	protected void onDeletedMessages(Context context, int total) {
//		Log.i(TAG, "Received deleted messages notification");
//		String message = getString(R.string.gcm_deleted, total);
//		// displayMessage(context, message);
//		// notifies user
//		generateNotification(context, message);
//	}
//
//	@Override
//	public void onError(Context context, String errorId) {
//		Log.i(TAG, "Received error: " + errorId);
//		// displayMessage(context, getString(R.string.gcm_error, errorId));
//	}
//
//	@Override
//	protected boolean onRecoverableError(Context context, String errorId) {
//		// log message
//		Log.i(TAG, "Received recoverable error: " + errorId);
//		// displayMessage(context, getString(R.string.gcm_recoverable_error,
//		// errorId));
//		return super.onRecoverableError(context, errorId);
//	}
//
//	/**
//	 * Issues a notification to inform the user that server has sent a message.
//	 */
//	// @SuppressWarnings("deprecation")
//	// private static void generateNotification(Context context, String message) {
//	// int icon = R.drawable.app_icon_xhdpi;
//	// long when = System.currentTimeMillis();
//	// NotificationManager notificationManager = (NotificationManager)
//	// context.getSystemService(Context.NOTIFICATION_SERVICE);
//	// Notification notification = new Notification(icon, message, when);
//	//
//	// String title = context.getString(R.string.app_name);
//	//
//	// Intent notificationIntent = new Intent(context, MainFragmentActivity.class);
//	// // set intent so it does not start a new activity
//	// notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
//	// Intent.FLAG_ACTIVITY_SINGLE_TOP);
//	// PendingIntent intent =
//	// PendingIntent.getActivity(context, 0, notificationIntent, 0);
//	// notification.setLatestEventInfo(context, title, message, intent);
//	// notification.flags |= Notification.FLAG_AUTO_CANCEL;
//	//
//	// // Play default notification sound
//	// notification.defaults |= Notification.DEFAULT_SOUND;
//	//
//	// //notification.sound = Uri.parse("android.resource://" +
//	// context.getPackageName() + "your_sound_file_name.mp3");
//	//
//	// // Vibrate if vibrate is enabled
//	// notification.defaults |= Notification.DEFAULT_VIBRATE;
//	// notificationManager.notify(0, notification);
//	//
//	//
//	// }
//
//	public void generateNotification(Context context, String Message) {
//		String title = context.getString(R.string.app_name);
//		NotificationCompat.Builder mBuilder = null;
//
//		mBuilder = new NotificationCompat.Builder(this).setSmallIcon(R.drawable.app_icon_xhdpi)
//				// notification icon
//				.setContentTitle(title) // title for notification
//				.setContentText(Message) // message for notification
//				.setAutoCancel(true).setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
//				.setVibrate(new long[] { 1000, 1000, 1000, 1000, 1000 });
//
//		// clear notification after click
//		Intent intent = new Intent(this, MainFragmentActivity.class);
//		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
//		PendingIntent pi = PendingIntent.getActivity(this, 0, intent, Intent.FLAG_ACTIVITY_NEW_TASK);
//		mBuilder.setContentIntent(pi);
//		NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//		mNotificationManager.notify(0, mBuilder.build());
//
//	}
//
//	public void GenrateNotificaionArtical(Context context, String Message, String articalId, Boolean isSound,
//			Boolean isVibrate) {
//		String title = context.getString(R.string.app_name);
//		NotificationCompat.Builder mBuilder = null;
//		if (!isSound && isVibrate) {
//			mBuilder = new NotificationCompat.Builder(this).setSmallIcon(R.drawable.app_icon_xhdpi)
//					// notification icon
//					.setContentTitle(title) // title for notification
//					.setContentText(Message) // message for notification
//					.setAutoCancel(true).setSound(null).setVibrate(new long[] { 1000, 1000, 1000, 1000, 1000 });
//		} else if (!isVibrate && isSound) {
//			mBuilder = new NotificationCompat.Builder(this).setSmallIcon(R.drawable.app_icon_xhdpi)
//					// notification icon
//					.setContentTitle(title) // title for notification
//					.setContentText(Message) // message for notification
//					.setAutoCancel(true).setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
//					.setVibrate(new long[] { 0, 0 });
//		} else if (!isVibrate && !isSound) {
//			mBuilder = new NotificationCompat.Builder(this).setSmallIcon(R.drawable.app_icon_xhdpi)
//					// notification icon
//					.setContentTitle(title) // title for notification
//					.setContentText(Message) // message for notification
//					.setAutoCancel(true).setSound(null).setVibrate(new long[] { 0, 0 });
//		} else if (isSound && isVibrate) {
//			mBuilder = new NotificationCompat.Builder(this).setSmallIcon(R.drawable.app_icon_xhdpi)
//					// notification icon
//					.setContentTitle(title) // title for notification
//					.setContentText(Message) // message for notification
//					.setAutoCancel(true).setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
//					.setVibrate(new long[] { 1000, 1000, 1000, 1000, 1000 });
//		}
//
//		// clear notification after click
//		Intent intent = new Intent(this, ArticleWebView.class);
//		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
//		intent.putExtra("ArticleId", articalId);
//		PendingIntent pi = PendingIntent.getActivity(this, 0, intent, Intent.FLAG_ACTIVITY_NEW_TASK);
//		mBuilder.setContentIntent(pi);
//		NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//		mNotificationManager.notify(0, mBuilder.build());
//
//	}
//
//	/**
//	 * Issues a notification to inform the user that server has sent a message.
//	 */
//	// @SuppressWarnings("deprecation")
//	// private static void generateNotification(Context context, String
//	// message,String ArticleId) {
//	// int icon = R.drawable.app_icon_xhdpi;
//	// long when = System.currentTimeMillis();
//	// NotificationManager notificationManager = (NotificationManager)
//	// context.getSystemService(Context.NOTIFICATION_SERVICE);
//	// Notification notification = new Notification(icon, message, when);
//	//
//	// String title = context.getString(R.string.app_name);
//	//
//	// Intent notificationIntent = new Intent(context, ArticleWebView.class);
//	// notificationIntent.putExtra("ArticleId", ArticleId);
//	// // set intent so it does not start a new activity
//	// notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
//	// Intent.FLAG_ACTIVITY_SINGLE_TOP);
//	// PendingIntent intent =
//	// PendingIntent.getActivity(context, 0, notificationIntent, 0);
//	// notification.setLatestEventInfo(context, title, message, intent);
//	// notification.flags |= Notification.FLAG_AUTO_CANCEL;
//	//
//	// // Play default notification sound
//	// notification.defaults |= Notification.DEFAULT_SOUND;
//	//
//	// //notification.sound = Uri.parse("android.resource://" +
//	// context.getPackageName() + "your_sound_file_name.mp3");
//	//
//	// // Vibrate if vibrate is enabled
//	// notification.defaults |= Notification.DEFAULT_VIBRATE;
//	// notificationManager.notify(0, notification);
//	//
//	// }
//
//	public String getDeviceName() {
//		String manufacturer = Build.MANUFACTURER;
//		String model = Build.MODEL;
//		if (model.startsWith(manufacturer)) {
//			return capitalize(model);
//		} else {
//			return capitalize(manufacturer) + " " + model;
//		}
//	}
//
//	private String capitalize(String s) {
//		if (s == null || s.length() == 0) {
//			return "";
//		}
//		char first = s.charAt(0);
//		if (Character.isUpperCase(first)) {
//			return s;
//		} else {
//			return Character.toUpperCase(first) + s.substring(1);
//		}
//
//	}
//}