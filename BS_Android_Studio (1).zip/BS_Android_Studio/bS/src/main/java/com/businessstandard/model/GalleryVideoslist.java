package com.businessstandard.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class GalleryVideoslist implements Serializable {

    @SerializedName("gallery_id")
    @Expose
    private String galleryId;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("gallery_url")
    @Expose
    private String galleryUrl;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("creation_date")
    @Expose
    private String creationDate;
    @SerializedName("total_views")
    @Expose
    private String totalViews;
    @SerializedName("cover_image")
    @Expose
    private String coverImage;
    @SerializedName("cover_image_relpath")
    @Expose
    private String coverImageRelpath;
    @SerializedName("modification_date")
    @Expose
    private String modificationDate;

    public String getGalleryId() {
        return galleryId;
    }

    public void setGalleryId(String galleryId) {
        this.galleryId = galleryId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGalleryUrl() {
        return galleryUrl;
    }

    public void setGalleryUrl(String galleryUrl) {
        this.galleryUrl = galleryUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getTotalViews() {
        return totalViews;
    }

    public void setTotalViews(String totalViews) {
        this.totalViews = totalViews;
    }

    public String getCoverImage() {
        return coverImage;
    }

    public void setCoverImage(String coverImage) {
        this.coverImage = coverImage;
    }

    public String getCoverImageRelpath() {
        return coverImageRelpath;
    }

    public void setCoverImageRelpath(String coverImageRelpath) {
        this.coverImageRelpath = coverImageRelpath;
    }

    public String getModificationDate() {
        return modificationDate;
    }

    public void setModificationDate(String modificationDate) {
        this.modificationDate = modificationDate;
    }

}
