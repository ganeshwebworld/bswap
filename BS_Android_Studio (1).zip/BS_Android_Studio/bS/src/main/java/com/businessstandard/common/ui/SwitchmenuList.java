/**
 * Project      : Economist
 * Filename     : SwitchmenuList.java
 * Author       : android
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.common.ui;

import android.app.ActivityOptions;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.todayspaper.ui.TodaysPaperFragment;

import java.util.ArrayList;

public class SwitchmenuList extends FragmentActivity {

    ListView list;
    private ArrayList<String> lvMenuItemsNew;
    TextView date;
    String TAG;
    LinearLayout mainlayout;
    String TAGheader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menulist);
        list = (ListView) findViewById(R.id.menulistview);
        TAG = getIntent().getStringExtra("Tag");
        TAGheader = getIntent().getStringExtra("newTag");
        date = (TextView) findViewById(R.id.header_name);
        date.setText(TAG);
        mainlayout = (LinearLayout) findViewById(R.id.mainlayout);

        mainlayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        if (TAG.compareTo("Home") == 0) {
            Menulsitadaper adapert = new Menulsitadaper(getApplicationContext(), lvMenuItemsNew);
            list.setAdapter(adapert);
        } else if (TAG.compareTo("Market") == 0) {
            Menulsitadaper adapert = new Menulsitadaper(getApplicationContext(), lvMenuItemsNew);
            list.setAdapter(adapert);
        } else if (TAG.compareTo("Today's Paper") == 0) {
            lvMenuItemsNew = TodaysPaperFragment.mSubCategoryList;
            if (lvMenuItemsNew != null) {
                Menulsitadaper adapert = new Menulsitadaper(getApplicationContext(), lvMenuItemsNew);
                list.setAdapter(adapert);
            } else {
                Toast.makeText(getApplicationContext(), "Downloading issue", Toast.LENGTH_SHORT).show();
            }
        } else if (TAG.compareTo("Settings") == 0) {
            Menulsitadaper adapert = new Menulsitadaper(getApplicationContext(), lvMenuItemsNew);
            list.setAdapter(adapert);
        }

        list.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent animActivity = new Intent(SwitchmenuList.this, MenuLIst.class);
                    Bundle bndlanimation = ActivityOptions.makeCustomAnimation(getApplicationContext(), R.anim.leftright, R.anim.rightleft).toBundle();
                    MainFragmentActivity.maincat = "Back";
                    startActivity(animActivity, bndlanimation);
                    finish();
                } else {
                    onMenuItemClickView(parent, view, position, id);
                }
            }

        });
    }

    private void onMenuItemClickView(AdapterView<?> parent, View view, int position, long id) {

        for (int a = 0; a < parent.getChildCount(); a++) {
            parent.getChildAt(a).setBackgroundColor(Color.parseColor("#F6E3CE"));
        }

        view.setBackgroundColor(Color.parseColor("#ffffff"));

        String selectedItem = lvMenuItemsNew.get(position);

        Intent i = new Intent(SwitchmenuList.this, MainFragmentActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.putExtra("MainCat", "Todays paper");
        i.putExtra("SabCat", selectedItem);
        startActivity(i);
        finish();
    }
}
