package com.businessstandard.network;

import com.businessstandard.model.ConfigResponseModel;
import com.businessstandard.model.GalleryDetailResponseModel;
import com.businessstandard.model.GalleryResponseModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;

/**
 * Created by mayank.paryani on 08-10-2018.
 */

public interface NetworkInterface {

    @POST("bs-android-config-api")
    @FormUrlEncoded
    Call<ConfigResponseModel> getConfigData(@Field("api_token") String apiToken, @Field("apiVersion") String apiVersion);

    @POST
    @FormUrlEncoded
    Call<GalleryResponseModel> getVideosListingData(@Url String url, @Field("api_token") String apiToken, @Field("pageNo") String pageNumber, @Field("itemsPerPage") String itemsPerPage);

    @POST
    @FormUrlEncoded
    Call<GalleryDetailResponseModel> getVideosDetailsData(@Url String detailUrl, @Field("api_token") String apiToken, @Field("gallery_id") String galleryId);
}
