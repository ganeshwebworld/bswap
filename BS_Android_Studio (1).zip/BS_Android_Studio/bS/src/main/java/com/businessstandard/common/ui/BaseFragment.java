/**
   Project      : Economist
   Filename     : BaseFragment.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */

package com.businessstandard.common.ui;

import java.util.HashMap;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.market.dto.CompanyStockNewsFeed;

/**
 * @author lenesha
 * 
 */
public class BaseFragment extends Fragment {

	protected ListView mNewsListView;
	protected OnClickListener mNonTickerNseBsebtnClickListnr;
	protected OnClickListener mTickerNseBsebtnClickListnr;
	protected TextView mBseText, mNseText;
	protected ImageView mBseImg, mNseImg;
	public static int numCount=0;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		ViewGroup viewGroup = (ViewGroup) inflater.inflate(R.layout.common_header_bar, container, false);
		return viewGroup;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.support.v4.app.Fragment#onActivityCreated(android.os.Bundle)
	 */
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		System.out.println("NumCount Base fragment--"+numCount);
		numCount++;
		System.out.println("numCount++ fragment--"+numCount);
		BaseActivity.numAdCount=numCount;
	}

	public interface NewsItemClickListner {
		public void onNewsItemClick(SubNewsItem subNewsitemClicked, int position, String mSelectedCatName, String  newscategory);
	}

	public interface MarketCatgegoryClickListner {
		public void onMarketCatgegoryClickListner(String catgory, int index);
	}

	public interface FragmentListner {
		public SectionNewsRootFeedItem getDataFromActivity();
		public String getSelectedCategory();
		public void setCatgeroes(List<String> cats, HashMap<String, String> CatsMap,String selectedCat);
		public void setTopStoriesCatgeroes(List<String> cats, HashMap<String, String> CatsMap, String mSelectedCategory);
	}

	public interface CompanyDataListner {
		public CompanyStockNewsFeed onCompanySelectListner();
	}

	/**
	 * @param keyCode
	 * @param event
	 * @return
	 */
}
