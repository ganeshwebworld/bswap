/**
 * Project      : Economist
 * Filename     : Forgotpass.java
 * Author       : android-ubantu
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.home.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author android-ubantu
 */
public class Forgotpass extends Activity {

    EditText forgotEmail;
    Button submit;
    String email;
    String apiToken;
    TextView txtErrorMessage;
    Context mContext;
    private SaveSharedPref mSharedPreferenceManager;
    private com.businessstandard.model.Constants mConstants = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_forgot_pass);
        mSharedPreferenceManager = SaveSharedPref.getInstance(this);
        if (mSharedPreferenceManager.exists(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA)) {
            if (mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class) != null) {
                mConstants = mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class);
            }
        }
        forgotEmail = (EditText) findViewById(R.id.email);
//		forgotEmail.getText().insert(forgotEmail.getSelectionStart(), "  ");
        submit = (Button) findViewById(R.id.submit);
        mContext = this;
        apiToken = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
        txtErrorMessage = (TextView) findViewById(R.id.error);
        submit.setOnClickListener(new View.OnClickListener() {
            //gaurav-submit button click and email validation!!
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                email = forgotEmail.getText().toString();
                if (email.length() == 0) {

                    txtErrorMessage.setText("Please enter Email Id");
                } else if (isValidEmail(email)) {
                    Forgot signuptask = new Forgot(mContext);
                    signuptask
                            .execute(apiToken, email);
                } else {
                    txtErrorMessage.setText("Please enter valid Email Id");
                }
            }
        });
    }

    //gaurav-calling post api of forget pass!!
    private class Forgot extends AsyncTask<String, String, JSONObject> {

        private final ProgressDialog progressDialog;
        Context ctx;
        String response;

        String errorMessage;

        public Forgot(Context context) {
            ctx = context;
            progressDialog = new ProgressDialog(context);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setTitle("Validating..");

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
            // showDialog(DIALOG_DOWNLOAD_PROGRESS);
        }

        @Override
        protected JSONObject doInBackground(String... args) {
            //String strUrl = ctx.getString(R.string.api_base_url) + Constants.FORGOT_PASSWORD_API;
            String forgetPasswordApiUrl = "";
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getForgotPasswordApi())) {
                forgetPasswordApiUrl = mConstants.getForgotPasswordApi();
            }

/*			InputStream is = null;

			JSONParser jsonParser = new JSONParser();
//			List<NameValuePair> params = new ArrayList<NameValuePair>();
//			params.add(new BasicNameValuePair("api_token", args[0]));
//			params.add(new BasicNameValuePair("forget_email", args[1]));
		
			org.apache.commons.httpclient.NameValuePair[] request = {
					new org.apache.commons.httpclient.NameValuePair(
							"api_token", args[0]),
					new org.apache.commons.httpclient.NameValuePair("forget_email",
							args[1])};
			JSONObject json = null;
			try {
				json = new JSONObject(jsonParser.callWebservice(request, strUrl));
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/


            OkHttpClient client = new OkHttpClient();
            JSONObject json = null;

            RequestBody formBody = new FormBody.Builder()
                    .add("api_token", args[0])
                    .add("forget_email", args[1])
                    .build();

            Request request = new Request.Builder()
                    .url(forgetPasswordApiUrl)
                    .post(formBody)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String jsonStr = response.body().string();
                    json = new JSONObject(jsonStr);
                    return json;
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;

        }

        protected void onProgressUpdate(String... progress) {
            super.onProgressUpdate(progress);

        }

        protected void onPostExecute(JSONObject json) {
            progressDialog.cancel();

            StringBuilder sb = new StringBuilder();
            String status = null;
            JSONObject id = null;
            String userId;
            try {
//				id = json.getJSONObject("message");

                try {
//					subscription = id.getString("is_unsubscribed");
//					subscription_enddate = id.getString("end_date");
                } catch (Exception e) {
                    // TODO: handle exception
//					subscription = "1";
                }
//				userId = id.getString("user_id");
                status = json.getString("status");

                if (!status.equals("success")) {
                    String message;
                    message = json.getString("message");
                    errorMessage = message;
                    Forgotpass.this.txtErrorMessage.setText(message);

                } else {

                    String fileDirPath = Forgotpass.this.getFilesDir()
                            + "/forgotpass.json";
                    String fileContent = json.toString();
                    File file = new File(fileDirPath);
                    try {
                        if (!file.exists()) {
                            file.createNewFile();
                        }

                        FileWriter fw = new FileWriter(file);
                        BufferedWriter bw = new BufferedWriter(fw);
                        bw.write(fileContent);
                        bw.close();
                    } catch (IOException io) {
                        io.printStackTrace();
                    }

                    // Toast toast = Toast.makeText(LoginNowActivity.this,
                    // "Login Successfull.", Toast.LENGTH_SHORT);
//					sharedpreferences = PreferenceManager
//					.getDefaultSharedPreferences(mContext);
//					SharedPreferences.Editor editor = sharedpreferences.edit();
//					editor.putString("value", subscription);
//					editor.putString("newvalue", userId);
//					editor.putString("user_email", usernameStr);
//					editor.putString("pass", passwordStr);
////					editor.putString("Enddate", subscription_enddate);
//					editor.commit();

                    Toast.makeText(getApplicationContext(), "Password send to your mail id", Toast.LENGTH_LONG).show();
                    finish();
                    // ArticleDetailFragment.mLoginNow.setVisibility(View.GONE);
                }
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                try {
                    status = json.getString("status");

                    if (!status.equals("success")) {
                        String message;
                        message = json.getString("message");
                        errorMessage = message;
                        Forgotpass.this.txtErrorMessage.setText(message);
                    }
                } catch (JSONException e1) {
                }
            }

        }
    }

    public final static boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }
}
