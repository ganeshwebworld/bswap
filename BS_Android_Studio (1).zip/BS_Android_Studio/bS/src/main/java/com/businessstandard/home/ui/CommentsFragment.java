/**
   Project      : Economist
   Filename     : ArticleDetailFragment.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */
package com.businessstandard.home.ui;

import java.text.MessageFormat;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.CommentItem;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.util.Constants.BundleKeys;
import com.businessstandard.common.util.FacebookHelper;
import com.businessstandard.common.util.FacebookHelper.UserInfoRecivedListener;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.HomeManager;
import com.businessstandard.home.HomeManager.CommentsDloadCmpltListener;
import com.businessstandard.home.HomeManager.CommentsPostingCmpltListener;
import com.businessstandard.home.adapters.CommentsListAdapter;
import com.facebook.FacebookAuthorizationException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.model.GraphObject;
import com.facebook.model.GraphUser;

public class CommentsFragment extends BaseFragment implements OnClickListener {

	private ListView mcomments_listviwe;
	private String mNewsItemPos;
	private FragmentListner listner;
	private View view;
	private EditText mCommentsEditText;
	private Button mPostCommentBtn;
	private FacebookHelper fbHelper;
	private Session.StatusCallback statusCallback = new SessionStatusCallback();
	private final String PENDING_ACTION_BUNDLE_KEY = "com.facebook:PendingAction";
	private PendingAction pendingAction = PendingAction.NONE;
	private HomeManager mHomeManager;
	private String commentUrl, mCommentTxt;
	private boolean mIsLoginChecked = false;
	String postCommenturl;

	private enum PendingAction {
		NONE, POST_COMMENT_UPDATE
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.comments_layout, container, false);
		mCommentsEditText = (EditText) view.findViewById(R.id.comments_text);
		mcomments_listviwe = (ListView) view.findViewById(R.id.comments_list);
		mPostCommentBtn = (Button) view.findViewById(R.id.post_comment);
		mPostCommentBtn.setOnClickListener(this);
		mNewsItemPos = getArguments().getString(BundleKeys.NEWS_ID);
		Log.d("POS", " " + mNewsItemPos);

		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		mHomeManager = new HomeManager(getActivity());

		fbHelper = FacebookHelper.getInstance();
		fbHelper.initFBHelper(getActivity(), savedInstanceState, statusCallback);

		if (listner != null && listner.getDataFromActivity() != null
				&& listner.getDataFromActivity().root != null)
			showComments(listner.getDataFromActivity());
		else
			Utility.displayAlert(getActivity(),
					getActivity().getString(R.string.app_name), getActivity()
							.getString(R.string.no_connection),
					android.R.string.ok, Utility
							.getOkButtonListener(getActivity()));

	}

//	/**
//	 * @param dataFromActivity
//	 */
	private void showComments(SectionNewsRootFeedItem rootItem) {
		try {
			commentUrl = MessageFormat.format("{0}?autono={1}",
					rootItem.root.getmNewsComment().feedUrl, mNewsItemPos);
		} catch (Exception e) {
			e.printStackTrace();
		}
		downloadComments(commentUrl);
	}

	/**
	 * @param commentUrl
	 */
	private void downloadComments(String commentUrl) {
		mHomeManager.downloadCommentsData(new CommentsDloadCmpltListener() {

			@Override
			public void onFailure() {
				Utility.hideProgressDialog();
				Utility.showToast(getString(R.string.no_comments),
						getActivity());
				if (!fbHelper.isLoggedIn() && !mIsLoginChecked) {
					showFacebookAlert();
					mIsLoginChecked = true;
				}
			}

			@Override
			public void CommentsDloadCmplistner(List<CommentItem> result) {
				Utility.hideProgressDialog();
				displayComments(result);
				if (!fbHelper.isLoggedIn() && !mIsLoginChecked) {
					showFacebookAlert();
					mIsLoginChecked = true;
				}
			}

		}, commentUrl);

	}

	/**
	 * @param result
	 */
	protected void displayComments(List<CommentItem> result) {
		TextView emptyView = (TextView) view.findViewById(R.id.empty_text);

		if (result.size() > 0) {
			mcomments_listviwe.setVisibility(View.VISIBLE);
			emptyView.setVisibility(View.INVISIBLE);

			CommentsListAdapter adapter = new CommentsListAdapter(getActivity()
					.getApplicationContext(), R.layout.comments_list_item,
					result);
			mcomments_listviwe.setAdapter(adapter);
		} else {
			mcomments_listviwe.setVisibility(View.INVISIBLE);
			emptyView.setVisibility(View.VISIBLE);
		}
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		listner = (FragmentListner) activity;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.view.View.OnClickListener#onClick(android.view.View)
	 */
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.post_comment:
			mCommentTxt = mCommentsEditText.getText().toString();
			if (mCommentTxt.length() > 0) {
				pendingAction = PendingAction.POST_COMMENT_UPDATE;
				if (fbHelper.isLoggedIn()) {
					getUserInfo();
				} else {
					if (getActivity() != null) {
						fbHelper.login(getActivity());
					}

				}

			} else {
				if (getActivity() != null)

					Utility.displayAlert(getActivity(), getResources()
							.getString(R.string.app_name), getResources()
							.getString(R.string.comments_empty),
							android.R.string.ok, Utility
									.getOkButtonListener(getActivity()));
			}
			break;

		default:
			break;
		}
	}

	/**
	 * 
	 */
	private void getUserInfo() {

		Utility.displayProgressDailog(getActivity(), R.string.loading);
		fbHelper.fetchUserInfo((new UserInfoRecivedListener() {

			@Override
			public void onRecivedUserInfo(GraphUser user, Response response) {
				Utility.hideProgressDialog();
				GraphObject object = response.getGraphObject();
				String email = (String) object.getProperty("email");

				pendingAction = PendingAction.NONE;

				if (user != null) {
					postComment(user, email);
				}
			}
		}), getActivity());
	}

	/**
	 * @param user
	 * @param email
	 * 
	 */
	protected void postComment(GraphUser user, String email) {
		SectionNewsRootFeedItem data = listner.getDataFromActivity();
		try {
			// System.out.println(data.root.getmComment().feedUrl);
			postCommenturl = data.root.getmComment().feedUrl;
		} catch (Exception e) {
			e.printStackTrace();
		}
		String username = user.getName();
		String id = email;

		mHomeManager.postCommentForNews(mNewsItemPos, username, id,
				mCommentTxt, postCommenturl,
				new CommentsPostingCmpltListener() {

					@Override
					public void onFailure() {
						pendingAction = PendingAction.NONE;
						Utility.hideProgressDialog();

					}

					@Override
					public void commentsPostingCmplistner() {
						pendingAction = PendingAction.NONE;
						mCommentsEditText.setText("");
						Utility.hideProgressDialog();
						if (getActivity() != null)

							Utility.showToast(
									getString(R.string.commnt_post_success),
									getActivity());
						downloadComments(commentUrl);
					}
				});

	}

	private class SessionStatusCallback implements Session.StatusCallback {
		@Override
		public void call(Session session, SessionState state,
				Exception exception) {
			Log.i("", "SessionStatusCallback:: Sesssion Updated:" + exception);
			Log.i("", " Active permission:" + session.getPermissions());
			if (pendingAction != PendingAction.NONE
					&& (exception instanceof FacebookOperationCanceledException || exception instanceof FacebookAuthorizationException)) {
				new AlertDialog.Builder(getActivity())
						.setTitle(R.string.cancelled)
						.setMessage(R.string.permission_not_granted)
						.setPositiveButton(R.string.ok, null).show();
				pendingAction = PendingAction.NONE;
			}

			if (fbHelper.isLoggedIn()) {
				handlePendingAction();

			}

		}

		private void handlePendingAction() {
			switch (pendingAction) {
			case POST_COMMENT_UPDATE:
				getUserInfo();

			}

		}

	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		Session session = Session.getActiveSession();
		Session.saveSession(session, outState);
		outState.putString(PENDING_ACTION_BUNDLE_KEY, pendingAction.name());
	}

	@Override
	public void onStart() {
		super.onStart();
		Session.getActiveSession().addCallback(statusCallback);
	}

	@Override
	public void onStop() {
		super.onStop();
		Session.getActiveSession().removeCallback(statusCallback);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		Session.getActiveSession().onActivityResult(getActivity(), requestCode,
				resultCode, data);
	}

	private void showFacebookAlert() {

		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
		builder.setMessage(getString(R.string.comment_fbook_login_alert))
				.setCancelable(false)
				.setPositiveButton(R.string.login_msg,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								fbHelper.login(getActivity());
							}

						})
				.setNegativeButton(R.string.cancel_msg,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								dialog.cancel();
							}
						});
		AlertDialog alert = builder.create();
		alert.show();

	}
}
