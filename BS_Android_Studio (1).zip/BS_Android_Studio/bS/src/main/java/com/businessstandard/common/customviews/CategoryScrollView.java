/**
   Project      : Economist
   Filename     : CategoryScrollView.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */
package com.businessstandard.common.customviews;

import java.util.ArrayList;
import java.util.List;
import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.businessstandard.R;

//TODO REVIEW: Consider using a RadioGroup instead of buttons to achieve the functionality.
//TODO REVIEW: Consider using <selector> for switching button backgrounds based on state.
/**
 * @author lenesha
 * */
public class CategoryScrollView extends HorizontalScrollView {

	LinearLayout mCategoryWrapper = null;
	//	Button mPreviousPressed = null;
	TextView mPreviousPressed = null;

	/**
	 * Interface definition for a callback to be invoked when a category
	 * sSelected.

	 * 
	 */
	public interface OnCategorySelectedListener {
		public void onCategorySelected(String category);
	}

	public interface OnIndicatorsChangesListener {
		public void onIndicatorsChanged(boolean showLeft, boolean showRight);
	}

	/**
	 * @param context
	 * @param attrs
	 */
	public CategoryScrollView(Context context, AttributeSet attrs) {
		super(context, attrs);
		mCategoryWrapper = new LinearLayout(context);
		mCategoryWrapper.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
		mCategoryWrapper.setOrientation(LinearLayout.HORIZONTAL);
		setHorizontalFadingEdgeEnabled(true);
		setFadingEdgeLength(50);
		addView(mCategoryWrapper);
		setHorizontalScrollBarEnabled(false);
	}


	//	public void addCategory(ArrayList<String> categories, String pressed) {
	//		mCategoryWrapper.removeAllViews();
	//		Button tab = null;
	//		for (int i = 0; i < categories.size(); i++) {
	//			String name = categories.get(i);
	//			tab = (Button) View.inflate(getContext(),
	//					R.layout.category_item_layout, null);
	//			tab.setText(name);
	//			tab.setOnClickListener(listenerbtn);
	//			mCategoryWrapper.addView(tab);
	//			if (name.equals(pressed)) {
	//				tab.setBackgroundResource(R.drawable.category_selected_bg);
	//				mPreviousPressed = tab;
	//			}
	//		}
	//		setIndicators();
	//	}


	public void addCategory(List<String> categories, String pressed) {
		mCategoryWrapper.removeAllViews();
		//		Button tab = null;
		TextView tab = null;

		for (int i = 0; i < categories.size(); i++) {
			String name = categories.get(i);
			//			tab = (Button) View.inflate(getContext(),
			//					R.layout.category_item_layout, null);
			tab = (TextView) View.inflate(getContext(),R.layout.category_item_layout, null);



			tab.setText(name);
			tab.setOnClickListener(listenerbtn);
			mCategoryWrapper.addView(tab);
			if (name.equals(pressed)) {
				tab.setTextColor(getResources().getColor(R.color.selected_sub_cat));
				mPreviousPressed = tab;
			}
		}
		setIndicators();
	}

	/*
	 * returns the category.
	 * Helps to scroll the horizontalscrollview when page in viewpager is scrolled and also categories
	 * in Home and Todays paper tabs.
	 */
	public TextView getCategory(String catName) {
		for(int pos = 0; pos < mCategoryWrapper.getChildCount(); pos++) {
			TextView textview = (TextView) mCategoryWrapper.getChildAt(pos);
			String a = (String) textview.getText();
			Log.d("Scroll", " " + pos + a);

			if(textview.getText().equals(catName)) {
				return textview;
			}
		}
		return null;

	}

	//	OnClickListener listenerbtn = new OnClickListener() {
	//		@Override
	//		public void onClick(View v) {
	//			if (!((Button) v).getText().equals(mPreviousPressed.getText())) {
	//				mPreviousPressed
	//						.setBackgroundResource(android.R.color.transparent);
	//				mPreviousPressed = (Button) v;
	//				mPreviousPressed
	//						.setBackgroundResource(R.drawable.category_selected_bg);
	//				listener.onCategorySelected(mPreviousPressed.getText()
	//						.toString());
	//			}
	//		}
	//	};

	//	OnClickListener listenerbtn = new OnClickListener() {
	//		@Override
	//		public void onClick(View v) {
	//			if (!((Button) v).getText().equals(mPreviousPressed.getText())) {
	//				mPreviousPressed
	//						.setBackgroundResource(android.R.color.transparent);
	//				//mPreviousPressed = (Button) v;
	//				mPreviousPressed = (TextView) v;
	//
	////				mPreviousPressed
	////						.setBackgroundResource(R.drawable.category_selected_bg);
	//				listener.onCategorySelected(mPreviousPressed.getText()
	//						.toString());
	//			}
	//		}
	//	};

	OnClickListener listenerbtn = new OnClickListener() {
		@Override
		public void onClick(View v) {
			//if (!((TextView) v).getText().equals(mPreviousPressed.getText())) {
				mPreviousPressed.setBackgroundResource(android.R.color.white);
				//mPreviousPressed = (Button) v;
				mPreviousPressed = (TextView) v;

				//				mPreviousPressed
				//						.setBackgroundResource(R.drawable.category_selected_bg);
				listener.onCategorySelected(mPreviousPressed.getText().toString());
			//}
		}
	};


	private OnCategorySelectedListener listener;

	public void setOnCategorySelectedListener(OnCategorySelectedListener listener) {
		this.listener = listener;
	}

	private OnIndicatorsChangesListener indicatorsListener;

	public void setOnIndicatorsChangedListener(OnIndicatorsChangesListener listener) 
	{
		indicatorsListener = listener;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.view.View#onScrollChanged(int, int, int, int)
	 */
	@Override
	protected void onScrollChanged(int l, int t, int oldl, int oldt) {
		Log.d("CAT", "OnScrollChanged.");
		setIndicators();
		super.onScrollChanged(l, t, oldl, oldt);
	}

	/**
	 * 
	 */
	private void setIndicators() {
		Log.d("CAT", "leftFading: " + getLeftFadingEdgeStrength());
		Log.d("CAT", "rightFading: " + getRightFadingEdgeStrength());
		boolean showLeft = (getLeftFadingEdgeStrength() > 0.0) ? true : false;
		boolean showRight = (getRightFadingEdgeStrength() > 0.0 || getRightFadingEdgeStrength() < 0.0) ? true
				: false;
	//	indicatorsListener.onIndicatorsChanged(showLeft, showRight);
	}


	
}
