/**
   Project      : Economist
   Filename     : TwitterShare.java
   Author       : poojarani
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.common.util;

import oauth.signpost.OAuth;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.auth.AccessToken;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import com.businessstandard.R;
import com.twitter.android.Constants;
import com.twitter.android.TWLoginActivity;
import com.twitter.android.Twitter;


/**
 * @author poojarani
 *
 */
public class TwitterShare {

	private static final String TAG = "NEWTWEET";
	private Twitter mTwitter;
	private Activity mcallingActivity;          
	public static final String CONSUMER_KEY = "Rxs8UEF0ntqwPojKUVBMg"; //g3ak7Qh96sDZ7wSzOwMcMw";
	public static final String CONSUMER_SECRET = "j3e1FZHYoEmeuBgm5T0wEs1fsIZ4y5tdjYypsIIKGU"; //0dcibsYCtJIvaHuQQ1XmucbZSxx4kAnrKd6h6H1rhfo";
	public static final int TWITTER_REQUESTCODE = 500;
	public static final String POST = "Post";
	public static final String REGISTER = "Register";
	public static String mMode;

	public static final int MSG_SHOW_TWEETMSG = 555;
	public static final int ARG_SUCCESS = 0;
	public static final int ARG_FAILURE = 1;
	public static final int ARG_OVERLOAD = 2;
	public static final int ARG_ERROR = 3;

	private String mAccessToken = null;
	private String mAccessSecret = null;
	private Handler H;
	Boolean tweet=false;

	private SharedPreferences twitterPrefs;
	private OnMessagePostedListener mOnMessagePostedListener;

	public interface OnMessagePostedListener {
		public void onMessagePostFinish(int status);
	}

	/**
	 * 
	 */
	public TwitterShare(Activity activity) {
		mcallingActivity = activity;
		twitterPrefs = PreferenceManager
				.getDefaultSharedPreferences(mcallingActivity
						.getApplicationContext());
		if(mcallingActivity instanceof OnMessagePostedListener ) {
			mOnMessagePostedListener = (OnMessagePostedListener) activity;
		}
	}

	public void prepareToRegister(String Mode, String msg,String url, Handler H) {
		this.H = H;

		prepareToRegister(Mode, msg);
	}

	public void prepareToRegister(String Mode, String msg) {
		Log.d(TAG, "signInToTwitter");
		mMode = Mode;
		mTwitter = new Twitter(R.drawable.icn_twt, CONSUMER_KEY, CONSUMER_SECRET);
		Intent twIntent = new Intent(mcallingActivity, TWLoginActivity.class);
		if (Mode.equals(POST)) {
			if (twitterPrefs.contains(TWLoginActivity.LOGEDIN) && twitterPrefs.getBoolean(TWLoginActivity.LOGEDIN, false)) {
				mAccessToken = twitterPrefs.getString(Constants.ACCESS_TOKEN, "");
				mAccessSecret = twitterPrefs.getString(Constants.SECRET_TOKEN, "");
				Log.d(TAG, mAccessSecret + " " + mAccessToken);
				mTwitter.setAccessToken(mAccessToken);
				mTwitter.setSecretToken(mAccessSecret);
				postToTwitter(msg);
			} else {
				mcallingActivity.startActivityForResult(twIntent, TWITTER_REQUESTCODE);
			}
		} else {
			mcallingActivity.startActivityForResult(twIntent, TWITTER_REQUESTCODE);
		}
	}

	public void tweetMessage(Intent data, String message) {
		if (data != null) {
			Log.d(TAG, "onActivityResult");
			if (data.hasExtra("result")) {
				boolean bRet = data.getBooleanExtra("result", true);
				if (bRet) {
					Bundle values = data.getBundleExtra("values");
					mAccessToken = values
							.getString(Constants.ACCESS_TOKEN);
					mAccessSecret = values
							.getString(Constants.SECRET_TOKEN);
					if (mTwitter != null) {
						mTwitter.setAccessToken(mAccessToken);
						mTwitter.setSecretToken(mAccessSecret);
						Log.d("NEWTWEET", " onActivityResult UIHelper");
						postToTwitter(message);
					} else {
						Log.d(TAG, "Could not sign-in to Twitter");
					}
				}
			}
		}
	}

	/**
	 * 
	 */
	@SuppressWarnings("deprecation")
	private void postToTwitter(final String message) {

		final twitter4j.Twitter twitter = new TwitterFactory().getInstance();
		twitter.setOAuthConsumer(CONSUMER_KEY, CONSUMER_SECRET);
		twitter.setOAuthAccessToken(new AccessToken(twitterPrefs.getString(Constants.ACCESS_TOKEN, ""),
				twitterPrefs.getString(Constants.SECRET_TOKEN, "")));
		
		new AsyncTask<Void, Void, Integer>() {

			@Override
			protected Integer doInBackground(Void... params) {
				int tweetStatus;
				try {
					Log.d(TAG, "updating status Twitter");
					twitter.updateStatus(message);
					Log.d(TAG, "status updated");
					tweetStatus = ARG_SUCCESS;
					
				} catch (TwitterException e) {
					if (e.getStatusCode() == 403) {
						
						tweetStatus = ARG_OVERLOAD;
						Log.d("Tweet", "ARG_OVERLOAD " + e.getMessage());
//						tweet=true;
//						Toast.makeText(mcallingActivity, "Character limit is exceeding", Toast.LENGTH_SHORT).show();
					} else {
						
						tweetStatus = ARG_ERROR;
						Log.d("Tweet", "ARG_ERROR" + e.getMessage());
					}
				}

				return tweetStatus;
			}

			/* (non-Javadoc)
			 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
			 */
			@Override
			protected void onPostExecute(Integer result) {
				super.onPostExecute(result);
				mOnMessagePostedListener.onMessagePostFinish(result);
//				if(tweet==true){
//				Toast.makeText(mcallingActivity, "Twitter Character limit is exceeding", Toast.LENGTH_SHORT).show();
//				}
			}
		}.execute();
		
	}

	/**
	 * @return
	 */
	public boolean isLogedIn() {
		return (twitterPrefs.contains(TWLoginActivity.LOGEDIN) && twitterPrefs
				.getBoolean(TWLoginActivity.LOGEDIN, false));
	}

	/**
	 * 
	 */
	public void signOutTwitter() {

		final Editor edit = twitterPrefs.edit();
		edit.remove(TWLoginActivity.LOGEDIN);
		edit.remove(OAuth.OAUTH_TOKEN);
		edit.commit();
	}

	@SuppressWarnings("deprecation")
	public User getUserInfoAtTwitter() {

		mAccessToken = twitterPrefs.getString(Constants.ACCESS_TOKEN, "");
		mAccessSecret = twitterPrefs.getString(Constants.SECRET_TOKEN, "");

		twitter4j.Twitter twitter = new TwitterFactory().getInstance();
		twitter.setOAuthConsumer(CONSUMER_KEY, CONSUMER_SECRET);
		twitter.setOAuthAccessToken(new AccessToken(twitterPrefs.getString(Constants.ACCESS_TOKEN, ""),
				twitterPrefs.getString(Constants.SECRET_TOKEN, "")));
		try {
			User current_user = twitter.showUser(twitter.getId());
			return current_user;
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (TwitterException e) {
			e.printStackTrace();
		}
		return null;
	}

	public String getTwitterAccessToken() {
		return twitterPrefs.getString(Constants.ACCESS_TOKEN, "");
	}
}
