/**
   Project      : Economist
   Filename     : PopupAdsActivity.java
   Author       : amishra
   Comments     : 
   Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
				  Modified under contract by Robosoft Technologies Pvt. Ltd.
   History      : NA
*/

package com.businessstandard.common.ui;

import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebView.HitTestResult;
import android.webkit.WebViewClient;
import android.webkit.WebSettings.PluginState;
import android.widget.ImageView;
import com.businessstandard.R;

/**
 * @author amishra
 *
 */
public class PopupAdsActivity extends Activity {
	
	private MyWebView mainview;
	private ImageView closeAds;
	
	
	
	@SuppressLint("SetJavaScriptEnabled")
	@SuppressWarnings("deprecation")
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.popup_ads);
        
        this.closeAds=(ImageView)findViewById(R.id.closeAds);
        this.closeAds.setVisibility(View.INVISIBLE);
        this.closeAds.setClickable(true);
        this.closeAds.setOnClickListener(new OnClickListener() {
            
       	 public void onClick(View v) {
       		 	finish();
                }
          });
        
           
        
        this.mainview=(MyWebView)findViewById(R.id.adsView);
        
        //mainview.setWebViewClient(new AdsWebViewClient());
        mainview.setWebViewClient(new AdsWebViewClient() {
        	  @Override
        	  public void onPageFinished(WebView view, String url) {
        	    super.onPageFinished(view, url);
        	    closeAds.setVisibility(View.VISIBLE);
        	    System.out.println("Fully Page loaded in Webview --->>>>and set timer called");
        	    setTimer();
        	  }
        	});

        mainview.getSettings().setLoadWithOverviewMode(false);
        mainview.getSettings().setUseWideViewPort(false);
        mainview.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        mainview.getSettings().setBuiltInZoomControls(false);
        mainview.getSettings().setJavaScriptEnabled(true);
       
        //mainview.clearCache(true);
       // mainview.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
//        mainview.getSettings().setPluginsEnabled(true);
        mainview.getSettings().setDomStorageEnabled(true);
        mainview.getSettings().setPluginState(PluginState.ON);
        mainview.getSettings().setAllowFileAccess(true);        
        mainview.getSettings().setLoadsImagesAutomatically(true); 
        mainview.setVerticalScrollBarEnabled(false);
        mainview.setHorizontalScrollBarEnabled(false);       
        //mainview.getSettings().setSavePassword(false);
        //mainview.getSettings().setSaveFormData(true);
        mainview. setInitialScale(72);
        mainview.getSettings().setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.36 (KHTML, like Gecko) Chrome/13.0.766.0 Safari/534.36");
        //mainview.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        mainview.loadUrl("file:///android_asset/popupads.html");      
        
	}
	private class AdsWebViewClient extends WebViewClient {
	    @Override
	    public boolean shouldOverrideUrlLoading(WebView view, String url)
	    {	    	
	    	Log.d("Web View client", "shouldOverrideUrlLoading : " + url);	    	
	    	Intent i = new Intent();	    	
	    	i.setAction(Intent.ACTION_VIEW);
	    	i.addCategory(Intent.CATEGORY_BROWSABLE);
	    	i.setData(Uri.parse(url));
	    	startActivity(i);	    		    	
	        return true;
	    }	
	  
	    @Override
	    public void onLoadResource (WebView view, String url)
	    {
	        if (url.contains("googleads")||url.contains("http")||url.contains("https"))
	        {
	            if(view.getHitTestResult() != null && (view.getHitTestResult().getType() == HitTestResult.SRC_ANCHOR_TYPE ||
	                    view.getHitTestResult().getType() == HitTestResult.SRC_IMAGE_ANCHOR_TYPE))
	            {
	                view.getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
	                view.stopLoading();
	            }
	        }
	    }
	    
	    
}
	private void setTimer()
	{
	
	TimerTask task = new TimerTask() {
		@Override
        public void run() {
                      
            finish();
        }
    };
    Timer t = new Timer();
    t.schedule(task, 10000);
    
	}
	

}
