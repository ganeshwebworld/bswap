package com.businessstandard.network;

/**
 * Created by mayank.paryani on 08-10-2018.
 */

public interface NetworkUrl {
    String BASE_URL = "https://betabs.business-standard.com/user/process-api/";
}
