/**
   Project      : Economist
   Filename     : StockData.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.market.dto;

/**
 * @author lenesha
 *
 */
public class StockData {
	 public BseStockDataItem[] nseTopGainers;
	 public BseStockDataItem[] bseTopGainers;
	 public BseStockDataItem[] nseTopLoosers;
	 public BseStockDataItem[] bseTopLoosers;
	 public BseStockDataItem[] bse52WeekHigh;
	 public BseStockDataItem[] nse52WeekHigh;
	 public BseStockDataItem[] bse52WeekLow;
	 public BseStockDataItem[] nse52WeekLow;
	 public TickerNewsItemFeed tickerFeed;
}
