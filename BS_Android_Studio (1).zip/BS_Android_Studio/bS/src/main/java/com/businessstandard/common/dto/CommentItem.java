/**
   Project      : Economist
   Filename     : CommentItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.common.dto;

import org.json.JSONException;
import org.json.JSONObject;

import com.businessstandard.common.util.Constants.CommentsKeys;

/**
 * @author lenesha
 *
 */
public class CommentItem {
	public String commentId;
	public	String autoNo;
	public String userName;
	public	String comments;
	public	String nType;
	public	String publish, ip;
	public	String creationDate;
	
	
	public void init(JSONObject object){
		try {
			if(object.has(CommentsKeys.COMMENT_ID)){
				commentId = object.getString(CommentsKeys.COMMENT_ID);
			}
			if(object.has(CommentsKeys.AUTO_NO)){
				autoNo = object.getString(CommentsKeys.AUTO_NO);
			}
			if(object.has(CommentsKeys.USER_NAME)){
				userName = object.getString(CommentsKeys.USER_NAME);
			}
			if(object.has(CommentsKeys.COMMENTS)){
				comments = object.getString(CommentsKeys.COMMENTS);
			}
			if(object.has(CommentsKeys.PUBLISH)){
				publish = object.getString(CommentsKeys.PUBLISH);
			}
			if(object.has(CommentsKeys.CDATE)){
				creationDate = object.getString(CommentsKeys.CDATE);
			}
			if(object.has(CommentsKeys.NTYPE)){
				nType = object.getString(CommentsKeys.NTYPE);
			}
			if(object.has(CommentsKeys.IP)){
				ip = object.getString(CommentsKeys.IP);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
}
