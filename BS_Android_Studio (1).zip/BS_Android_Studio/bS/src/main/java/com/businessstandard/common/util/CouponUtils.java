/**
   Project      : Economist
   Filename     : CouponUtils.java
   Author       : android
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
				  Modified under contract by Robosoft Technologies Pvt. Ltd.
   History      : NA
*/

package com.businessstandard.common.util;

import android.graphics.Bitmap;

/**
 * @author android
 *
 */
public class CouponUtils {

	String offerid;
	String offerdesc;
	String couponcode;
	String validtill;
	String showfirsttime;
	String source;
	String logourl;
	Bitmap bitmap;
	/**
	 * @return the offerid
	 */
	public String getOfferid() {
		return offerid;
	}
	/**
	 * @param offerid the offerid to set
	 */
	public void setOfferid(String offerid) {
		this.offerid = offerid;
	}
	/**
	 * @return the offerdesc
	 */
	public String getOfferdesc() {
		return offerdesc;
	}
	/**
	 * @param offerdesc the offerdesc to set
	 */
	public void setOfferdesc(String offerdesc) {
		this.offerdesc = offerdesc;
	}
	/**
	 * @return the couponcode
	 */
	public String getCouponcode() {
		return couponcode;
	}
	/**
	 * @param couponcode the couponcode to set
	 */
	public void setCouponcode(String couponcode) {
		this.couponcode = couponcode;
	}
	/**
	 * @return the validtill
	 */
	public String getValidtill() {
		return validtill;
	}
	/**
	 * @param validtill the validtill to set
	 */
	public void setValidtill(String validtill) {
		this.validtill = validtill;
	}
	/**
	 * @return the showfirsttime
	 */
	public String getShowfirsttime() {
		return showfirsttime;
	}
	/**
	 * @param showfirsttime the showfirsttime to set
	 */
	public void setShowfirsttime(String showfirsttime) {
		this.showfirsttime = showfirsttime;
	}
	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}
	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}
	/**
	 * @return the logourl
	 */
	public String getLogourl() {
		return logourl;
	}
	/**
	 * @param logourl the logourl to set
	 */
	public void setLogourl(String logourl) {
		this.logourl = logourl;
	}
	/**
	 * @return the bitmap
	 */
	public Bitmap getBitmap() {
		return bitmap;
	}
	/**
	 * @param bitmap the bitmap to set
	 */
	public void setBitmap(Bitmap bitmap) {
		this.bitmap = bitmap;
	}
	
}
