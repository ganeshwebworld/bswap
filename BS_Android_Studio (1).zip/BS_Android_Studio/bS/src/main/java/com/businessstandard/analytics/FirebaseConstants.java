package com.businessstandard.analytics;

public interface FirebaseConstants {
    String FIREBASE_BUNDLE_ACTION_KEY = "Action";
    String FIREBASE_BUNDLE_LABEL_KEY = "Label";
}
