/**
 * Project      : Economist
 * Filename     : RegisterNowActivity.java
 * Author       : nchauhan
 * Comments     :
 * Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.home.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.ui.BaseFragment.NewsItemClickListner;
import com.businessstandard.analytics.FirebaseAnalyticsTracker;
import com.businessstandard.analytics.GAConstants;
import com.businessstandard.analytics.GoogleAnalytics;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author nchauhan
 */
public class LoginNowActivity extends Activity {

    private final String TAG = "RegisterNowActivity";
    final static String PREFERENCE_NAME = "login";
    private NewsItemClickListner mNewsClickListener;
    EditText username, password;
    TextView txtErrorMessage, forgottext;
    String apiToken;
    Context mContext;
    SharedPreferences sharedpreferences;
    String subscription;
    String subscription_enddate;
    String usernameStr;
    String passwordStr;
    private Button loginButton;
    private GoogleAnalytics mGoogleAnalytics;
    private FirebaseAnalyticsTracker mFirebaseAnalyticsTracker;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.signin_form);
        mContext = this;
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        mFirebaseAnalyticsTracker = FirebaseAnalyticsTracker.getInstance(this);
        apiToken = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
        username = (EditText) findViewById(R.id.username);
        // username.setSelection(2);
        // username.getText().insert(username.getSelectionStart(), "  ");

        username.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        password = (EditText) findViewById(R.id.password);
        // password.getText().insert(password.getSelectionStart(), "  ");
        loginButton = (Button) findViewById(R.id.login);
        txtErrorMessage = (TextView) findViewById(R.id.error);
        forgottext = (TextView) findViewById(R.id.forgot);

        loginButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                usernameStr = username.getText().toString();
                passwordStr = password.getText().toString();
                if (usernameStr.length() == 0) {
                    txtErrorMessage.setText("Please enter Email Id");
                } else if (isValidEmail(usernameStr)) {
                    RegisterUser signuptask = new RegisterUser(mContext);
                    signuptask.execute(apiToken, usernameStr, passwordStr);
                } else {
                    txtErrorMessage.setText("Please enter valid Email Id");
                }
            }
        });

        forgottext.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent i = new Intent(LoginNowActivity.this, Forgotpass.class);
                startActivity(i);
            }
        });
    }

    private class RegisterUser extends AsyncTask<String, String, JSONObject> {

        private final ProgressDialog progressDialog;
        Context ctx;
        String response;
        String errorMessage;

        RegisterUser(Context context) {
            ctx = context;
            progressDialog = new ProgressDialog(context);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setTitle("Validating..");
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
            // showDialog(DIALOG_DOWNLOAD_PROGRESS);
        }

        @Override
        protected JSONObject doInBackground(String... args) {
            //String strUrl = ctx.getString(R.string.api_base_url) + Constants.SIGN_IN_API;
            SaveSharedPref saveSharedPref = SaveSharedPref.getInstance(mContext);
            String strUrl = "";
            if (saveSharedPref != null && !TextUtils.isEmpty(saveSharedPref.getString(SharedPreferencesKey.KEY_SIGN_IN_API, ""))) {
                strUrl = saveSharedPref.getString(SharedPreferencesKey.KEY_SIGN_IN_API, "");
            }

            OkHttpClient client = new OkHttpClient();
            JSONObject json;

            RequestBody formBody = new FormBody.Builder()
                    .add("api_token", args[0])
                    .add("login_email", args[1])
                    .add("login_password", args[2])
                    .build();

            Request request = new Request.Builder()
                    .url(strUrl)
                    .post(formBody)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String jsonStr = response.body().string();
                    json = new JSONObject(jsonStr);
                    return json;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onProgressUpdate(String... progress) {
            super.onProgressUpdate(progress);
        }

        protected void onPostExecute(JSONObject json) {
            progressDialog.cancel();
            StringBuilder sb = new StringBuilder();
            String status = null;
            JSONObject id = null;
            String userId;
            try {
                id = json.getJSONObject("message");
                try {
                    subscription = id.getString("is_unsubscribed");
                    subscription_enddate = id.getString("subscription_end_date");
                } catch (Exception e) {
                    subscription = "Y";
                    // try{
                    // subscription_enddate =
                    // id.getString("subscription_end_date");
                    // }catch(Exception e1){
                    //
                    // }
                }
                userId = id.getString("user_id");
                status = json.getString("status");

                if (!status.equals("success")) {
                    String message;
                    message = json.getString("message");
                    errorMessage = message;
                    LoginNowActivity.this.txtErrorMessage.setText(message);
                } else {
                    String fileDirPath = LoginNowActivity.this.getFilesDir() + "/userinfo.json";
                    String fileContent = json.toString();
                    File file = new File(fileDirPath);
                    try {
                        if (!file.exists()) {
                            file.createNewFile();
                        }
                        FileWriter fw = new FileWriter(file);
                        BufferedWriter bw = new BufferedWriter(fw);
                        bw.write(fileContent);
                        bw.close();
                    } catch (Exception io) {
                        io.printStackTrace();
                    }
                    // Toast toast = Toast.makeText(LoginNowActivity.this,
                    // "Login Successfull.", Toast.LENGTH_SHORT);
                    sharedpreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("value", subscription);
                    editor.putString("newvalue", userId);
                    editor.putString("user_email", usernameStr);
                    editor.putString("pass", passwordStr);
                    editor.putString("Enddate", subscription_enddate);
                    editor.commit();

                    //Store User ID to Shared Preferences for Future GA Event Tracking
                    if (!TextUtils.isEmpty(userId)) {
                        SaveSharedPref.getInstance(LoginNowActivity.this).saveString(SharedPreferencesKey.KEY_USER_ID, userId);
                        trackLoginSuccessGAEvent(userId);
                    }

                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("result", status);
                    setResult(RESULT_OK, returnIntent);
                    finish();
                    // ArticleDetailFragment.mLoginNow.setVisibility(View.GONE);
                }
            } catch (Exception e) {
                e.printStackTrace();
                try {
                    status = json.getString("status");
                    if (!status.equals("success")) {
                        String message;
                        message = json.getString("message");
                        errorMessage = message;
                        LoginNowActivity.this.txtErrorMessage.setText(message);
                    }
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    private void trackLoginSuccessGAEvent(String userID) {
        mGoogleAnalytics.trackEvent(GAConstants.LOGIN_SUCCESS_EVENT_CATEGORY, userID, "");

        mFirebaseAnalyticsTracker.trackEvent(GAConstants.LOGIN_SUCCESS_EVENT_CATEGORY, userID, "");
    }

    public final static boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }
}
