/**
   Project      : Economist
   Filename     : McxNcdexGainersLoosersItems.java
   Author       : user
   Comments     : 
   Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.market.dto;

import java.util.List;

/**
 * @author lenesha
 *
 */
public class McxNcdexGainersLoosersItems extends StockHolder {

public 	List<McxAndNcdexNewsItem> mcxOrNcdex;
public boolean isMcxGainer= false;
public boolean isMcxLooser = false;
public boolean isNcdexGainer = false;
public boolean isNcdexLooser = false;

}
