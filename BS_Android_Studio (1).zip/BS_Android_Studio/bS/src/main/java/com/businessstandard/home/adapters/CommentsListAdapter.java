/**
   Project      : Economist
   Filename     : CommentsListAdapter.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */

package com.businessstandard.home.adapters;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.CommentItem;
import com.businessstandard.common.util.Utility;

/**
 * @author lenesha
 * 
 */
public class CommentsListAdapter extends ArrayAdapter<CommentItem> {

	private LayoutInflater mInflater;

	/**
	 * @param applicationContext
	 * @param commentsListItem
	 * @param result
	 */
	public CommentsListAdapter(Context applicationContext,
			int commentsListItem, List<CommentItem> result) {
		super(applicationContext, commentsListItem, result);
		mInflater = LayoutInflater.from(applicationContext);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.widget.ArrayAdapter#getView(int, android.view.View,
	 * android.view.ViewGroup)
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.comments_list_item, null);
			holder = new ViewHolder();
			holder.commentAuthor = (TextView) convertView
					.findViewById(R.id.commentAuthor);
			holder.commentTime = (TextView) convertView
					.findViewById(R.id.commentTime);
			holder.commentTitle = (TextView) convertView
					.findViewById(R.id.commentTitle);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		CommentItem item = getItem(position);
		holder.commentAuthor.setText(item.userName);
		String date = Utility.getPublishedTime(item.creationDate);
		holder.commentTime.setText(date);
		holder.commentTitle.setText(item.comments);
		return convertView;
	}

	class ViewHolder {

		TextView commentAuthor;
		TextView commentTime;
		TextView commentTitle;

	}
}
