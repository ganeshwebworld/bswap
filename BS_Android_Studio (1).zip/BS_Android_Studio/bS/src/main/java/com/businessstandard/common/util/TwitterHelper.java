/**
   Project      : Economist
   Filename     : TwitterHelper.java
   Author       : poojarani
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.common.util;

import android.content.Intent;
import android.support.v4.app.FragmentActivity;

/**
 * @author poojarani
 *
 */
public class TwitterHelper {
	
	private static TwitterShare sTwitterInstance;
	public static String tweetMsg =null;
	public static void instantiateTwitter(FragmentActivity activity) {
	if(sTwitterInstance == null) 
			sTwitterInstance = new TwitterShare(activity);
		
	}
	
	public static boolean checkLoginStatus() {
		return(sTwitterInstance.isLogedIn());
	}
	
	public static void twitterSignOut() {
		sTwitterInstance.signOutTwitter();

	}
	
	public static void twitterSignIn() {
		sTwitterInstance.prepareToRegister(TwitterShare.REGISTER, null);		
	}
	
	public static void sendTweet(String tweetMsg) {
		sTwitterInstance.prepareToRegister(TwitterShare.POST, tweetMsg);		

		
	}
	public static void twitterSignInAndPost(String tweetMsg) {
		TwitterHelper.tweetMsg = tweetMsg;
		sTwitterInstance.prepareToRegister(TwitterShare.REGISTER, tweetMsg);		
	}

	/**
	 * @param data
	 */
	public static void tweetMessage(Intent data) {
		sTwitterInstance.tweetMessage(data, TwitterHelper.tweetMsg);
	}

}
