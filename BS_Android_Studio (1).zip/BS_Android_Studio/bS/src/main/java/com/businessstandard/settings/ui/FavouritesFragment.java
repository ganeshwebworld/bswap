/**
   Project      : Economist
   Filename     : FavouritesFragment.java
   Author       : poojarani
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */

package com.businessstandard.settings.ui;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.util.EconomistDatabaseHelper;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.ui.HomeFragment.OnNewsListDwnloadedListener;
import com.businessstandard.home.ui.NewsListAdapter;

public class FavouritesFragment extends BaseFragment implements OnItemClickListener{

	private List<SubNewsItem> mFavNewsItemsList;
	private NewsListAdapter mFavNewslistAdapter;
	private NewsItemClickListner mNewsClickListener;
	private OnNewsListDwnloadedListener mOnFavNewsListAvailListener;
	private TextView mEmptyView;
	String tgpref;
	ArrayList<SubNewsItem> ListToUpdate;



	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fav_list, container,
				false);
		SharedPreferences preferences = PreferenceManager
				.getDefaultSharedPreferences(getActivity());
		tgpref = preferences.getString("value", "-1");
		mNewsListView = (ListView) view.findViewById(R.id.fav_listview);
		mFavNewsItemsList = new ArrayList<SubNewsItem>();
		mEmptyView = (TextView) view.findViewById(R.id.empty_text);
		ListToUpdate=new ArrayList<SubNewsItem>();


		return view;
	}
	@Override
	public void onAttach(Activity activity) {
		// TODO Auto-generated method stub
		super.onAttach(activity);
		mNewsClickListener = (NewsItemClickListner) activity;
		mOnFavNewsListAvailListener = (OnNewsListDwnloadedListener) activity;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		mNewsListView.setOnItemClickListener(this);
		load();

	}

	private void load() {

		EconomistDatabaseHelper dbhelper = EconomistDatabaseHelper
				.getInstance(getActivity());
		Cursor favourites = dbhelper.getFavouriteNewsItems();
		if (favourites != null && favourites.moveToFirst()) {
			do {
				
				final SubNewsItem item = new SubNewsItem();
				if(tgpref.equals("N")&&(favourites.getString(EconomistDatabaseHelper.COL_PAID).equals("Y")))
				{
					
						ListToUpdate.add(item);
					//dbhelper.addFavouritNewsItem1(item,true);
				
						/*if (dbhelper.isInFavorites(item.title)) {

						} else {
							
							// eDataBaseHelper.addFavouritNewsItem1(item,true);
								
						}
					*/
					
				}
				item.title = favourites.getString(
						EconomistDatabaseHelper.COL_TITLE).replace('\"', '"');
				item.newsUrl = favourites
						.getString(EconomistDatabaseHelper.COL_NEWS_LINK);
				item.author = favourites
						.getString(EconomistDatabaseHelper.COL_AUTHOR);
				item.imageUrl = favourites
						.getString(EconomistDatabaseHelper.COL_STORYIMAGEURL);
				item.newscontent = favourites
						.getString(EconomistDatabaseHelper.COL_DESC);
				item.dateTime =favourites
						.getString(EconomistDatabaseHelper.COL_DATE);
				item.newsId = favourites
						.getString(EconomistDatabaseHelper.COL_GUID);
				item.ispaid = favourites
				.getString(EconomistDatabaseHelper.COL_PAID);
				item.briefDescription = favourites
						.getString(EconomistDatabaseHelper.COL_DES);
				mFavNewsItemsList.add(item);
			} while (favourites.moveToNext());

			favourites.close();
			/*EconomistDatabaseHelper eDataBaseHelper = EconomistDatabaseHelper
					.getInstance(getActivity().getApplicationContext());
			Boolean isLoad=false;
			for(int i=0;i<mFavNewsItemsList.size();i++)
			{
				if(tgpref.equals("N")&&(mFavNewsItemsList.get(i).ispaid.equals("Y")))
				{
					
					long s=eDataBaseHelper.addFavouritNewsItem1(mFavNewsItemsList.get(i),true);
					if(s!=-1)
					{
						isLoad=true;
					}
					
				}
				
			}
			eDataBaseHelper.close();*/
			/*if(isLoad)
			{
				load();	
				return;
			}*/
			
			
			if(mFavNewsItemsList != null && mFavNewsItemsList.size() > 0) {
				mOnFavNewsListAvailListener.onNewsListDownloaded((ArrayList<SubNewsItem>) mFavNewsItemsList);
				mFavNewslistAdapter = new NewsListAdapter(getActivity().getApplicationContext(), mFavNewsItemsList);
				mNewsListView.setAdapter(mFavNewslistAdapter);
			}

		} else {
			mNewsListView.setVisibility(View.GONE);
			mEmptyView.setVisibility(View.VISIBLE);
			if(getActivity() != null)
				Utility.showToast(getString(R.string.alert_no_fav), getActivity());
		}

	}
	/* (non-Javadoc)
	 * @see android.widget.AdapterView.OnItemClickListener#onItemClick(android.widget.AdapterView, android.view.View, int, long)
	 */
	@Override
	public void onItemClick(AdapterView<?> arg0, View view, int position, long id) {
		// TODO Auto-generated method stub

		SubNewsItem subNewsitemClicked = mFavNewslistAdapter.getItem(position);
		mNewsClickListener.onNewsItemClick(subNewsitemClicked, position, getString(R.string.cat_fav), null);


	}






}
