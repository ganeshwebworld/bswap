package com.businessstandard.utils;

/**
 * Created by mayank.paryani on 08-10-2018.
 */

public interface AppConstants {
    long SPLASH_SCREEN_HANDLER_DELAY = 2000;
    String API_VERSION = "1.1";
    String CONFIG_API_KEY = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
    String STATUS_SUCCESS = "success";
    String GALLERY_ID = "gellery_id";
    String GALLERY_VIDEO_TITLE = "gallery_video_title";
}
