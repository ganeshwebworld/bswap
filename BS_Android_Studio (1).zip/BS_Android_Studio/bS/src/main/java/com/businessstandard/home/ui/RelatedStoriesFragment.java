/**
   Project      : Economist
   Filename     : RelatedStoriesFragment.java
   Author       : poojarani
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */

package com.businessstandard.home.ui;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.SectionNewsItem;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.manager.BaseManager.SubNewsDloadCmpltListener;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.util.Constants.BundleKeys;
import com.businessstandard.common.util.Constants.RootFragment;
import com.businessstandard.common.util.FragmentHelper;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.HomeManager;
import com.businessstandard.home.ui.HomeFragment.OnNewsListDwnloadedListener;

/**
 * 
 * @author poojarani
 *
 */

public class RelatedStoriesFragment extends BaseFragment implements OnItemClickListener {

	private NewsListAdapter mNewsAdapter;
	private List<SubNewsItem> mRelatedNewsList;
	private FragmentListner listner;
	private String mNewsItemPos;
	private OnNewsListDwnloadedListener mOnRelNewsListDwnloadedListener;
	private TextView mEmptyText;

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		listner = (FragmentListner) activity;
		mOnRelNewsListDwnloadedListener = (OnNewsListDwnloadedListener) activity;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.related_stories_layout, container,
				false);
		mNewsListView = (ListView) view.findViewById(R.id.related_list);
		mEmptyText = (TextView) view.findViewById(R.id.empty_text);
		mNewsItemPos = getArguments().getString(BundleKeys.NEWS_ID);
		Log.d("POS"," " + mNewsItemPos);
		return view;

	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		mRelatedNewsList = new ArrayList<SubNewsItem>();
		mNewsAdapter = new  NewsListAdapter(getActivity(), mRelatedNewsList);
		mNewsListView.setAdapter(mNewsAdapter);
		mNewsListView.setOnItemClickListener(this);
		if(listner != null && listner.getDataFromActivity() != null 
				&& listner.getDataFromActivity().root != null)
			showRelatedStories(listner.getDataFromActivity());
		else 
			Utility.displayAlert(getActivity(), getActivity()
					.getString(R.string.app_name) , getActivity()
					.getString(R.string.no_data), android.R.string.ok,
					Utility.getOkButtonListener(getActivity()));
	}



	private void showRelatedStories(SectionNewsRootFeedItem rootItem) {
		//URL setup
		ArrayList<SectionNewsItem> item = rootItem.root.getmNewsSearch();
		if(item==null) return;
		
		String feedUrl = item.get(0).feedUrl;
		System.out.println(feedUrl+">>>>>>>>>>>>>>>>>>>>>");
		
		String url = MessageFormat.format("{0}{1}", feedUrl, ("?autono=" + mNewsItemPos));
		Log.d("URL", " " + url);
		downloadRelatedStories(url);
	}

	private void downloadRelatedStories(String url) {
		HomeManager homeManager = new HomeManager(getActivity());
		homeManager.downloadNewsFeedData(true, new SubNewsDloadCmpltListener() {

			@Override
			public void onFailure() {
				Utility.hideProgressDialog();
				displayEmptytext();
			}

			

			@Override
			public void onSubNewsDloadComplete(ArrayList<SubNewsItem> result) {
				Utility.hideProgressDialog();
				mOnRelNewsListDwnloadedListener.onNewsListDownloaded(result);		
				displayNews(result);
			}

		}, url);

	}
	
	private void displayEmptytext() {
		mEmptyText.setVisibility(View.VISIBLE);	
		mNewsListView.setVisibility(View.INVISIBLE);
	}

	private void displayNews(ArrayList<SubNewsItem> result) {
		if (result != null) {
			mNewsListView.setVisibility(View.VISIBLE);
			mEmptyText.setVisibility(View.INVISIBLE);	

			mRelatedNewsList = result;
			mNewsAdapter.clear();
			for (SubNewsItem item : result) {
				mNewsAdapter.add(item);
				mNewsAdapter.setNotifyOnChange(false);
			}
			mNewsAdapter.notifyDataSetChanged();

		}

	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
		Bundle bundle = new Bundle();
		bundle.putInt(BundleKeys.NEWS_ITEM_POSITION, position);				
		bundle.putInt(BundleKeys.NEWS_ITEM_POS_TAG, RootFragment.RELATED_ARTICLES);
		ArticleDetailFragment fragment = new ArticleDetailFragment();
		fragment.setArguments(bundle);
		FragmentHelper.replaceAndAddContentFragment(getActivity(), R.id.realTabContent, fragment);
	}



}
