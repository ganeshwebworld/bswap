/**
 * Project      : Economist
 * Filename     : MarketActivity.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */

package com.businessstandard.market.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.manager.BaseManager.CatgyDloadCmpltListener;
import com.businessstandard.common.manager.BaseManager.TickerDloadCmpltListener;
import com.businessstandard.common.ui.BaseActivity;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.ui.BaseFragment.FragmentListner;
import com.businessstandard.common.ui.MainFragmentActivity;
import com.businessstandard.common.ui.MenuActivity;
import com.businessstandard.common.ui.MenuLIst;
import com.businessstandard.common.ui.SearchCompanyStockActivity;
import com.businessstandard.common.util.Constants.BundleKeys;
import com.businessstandard.common.util.Constants.MarketKeys;
import com.businessstandard.common.util.Constants.RootFragment;
import com.businessstandard.common.util.Constants.SearchStock;
import com.businessstandard.common.util.Constants.Sections;
import com.businessstandard.common.util.FragmentHelper;
import com.businessstandard.common.util.TwitterShare;
import com.businessstandard.common.util.TwitterShare.OnMessagePostedListener;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.HomeManager;
import com.businessstandard.home.ui.ArticleDetailFragment;
import com.businessstandard.market.dto.TickerNewsFeedRootObject;
import com.businessstandard.market.dto.TickerNewsItemFeed;
import com.businessstandard.settings.ui.FavouritesFragment;

import java.util.ArrayList;
import java.util.Collections;

/**
 * @author lenesha
 *
 */
public class MarketActivity extends BaseActivity implements FragmentListner, OnMessagePostedListener, OnClickListener {

    private TickerNewsItemFeed mTickernewsFeed = null;
    private ArrayList<String> mCatgryList = new ArrayList<String>();
    private TextView mBseLabel;
    private TextView mNseLabel;
    private TextView mBseText;
    private TextView mNseText;
    private ImageView mNseImg;
    private ImageView mBseImg;
    private ArrayList<SubNewsItem> mNewsList;
    public static String activity_name = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        numAdCount = 2;
        BaseFragment.numCount = 2;
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            boolean flag = bundle.getBoolean(MarketKeys.LAUNCH_MARKET);
            if (flag) {
                startActivity(new Intent(this, MainFragmentActivity.class));
//				this.finish();
            }
        } else {
            showTickers();
            setLayout(R.layout.activity_home_screen);
            mBseLabel = (TextView) findViewById(R.id.bselabel);
            mBseText = (TextView) findViewById(R.id.bseValue);
            mNseLabel = (TextView) findViewById(R.id.nselabel);
            mNseText = (TextView) findViewById(R.id.nseValue);
            mBseImg = (ImageView) findViewById(R.id.bseimg);
            mNseImg = (ImageView) findViewById(R.id.nseimg);
            mRadioGroup.check(R.id.markets);
            mFeedItem = HomeManager.feedObjct;
            marketCategories();
            marketCatOnClick(mSubCategoryList.get(0), mSubCategoryList.indexOf(mSubCategoryList.get(0)));
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.search_button:
                if (mFeedItem != null && mFeedItem.root != null && mFeedItem.root.getmStockSearch() != null) {
                    String stockSearchUrl = mFeedItem.root.getmStockSearch().feedUrl;
                    Intent searchIntent = new Intent(this, SearchCompanyStockActivity.class);
                    searchIntent.putExtra(SearchStock.SEARCH_STOCK_URL, stockSearchUrl);
                    searchIntent.putExtra(MarketKeys.MARKET_ACTIVITY, true);
                    startActivity(searchIntent);
                } else {
                    Utility.displayAlert(this,
                            getResources().getString(R.string.app_name),
                            getResources().getString(R.string.no_connection),
                            android.R.string.ok,
                            Utility.getOkButtonListener(this));

                }
                break;

            case R.id.refresh_btn:
                if (mFeedItem != null && mFeedItem.root != null) {
                    checkCurrentFragment();
                } else if (Utility.isInternetOn(getApplicationContext())) {
                    HomeManager managr = new HomeManager(this);
                    managr.downloadData(new CatgyDloadCmpltListener() {

                        @Override
                        public void onFailure() {
                            Utility.hideProgressDialog();
                            Utility.showToast(getResources().getString(R.string.no_data), getApplicationContext());
                        }

                        @Override
                        public void onFeedsDloadComplete(SectionNewsRootFeedItem result) {
                            mRadioGroup.setEnabled(false);
                            Utility.setDataToActvty(result);
                            mFeedItem = result;

                            if (mFeedItem.root != null) {
                                Utility.hideProgressDialog();
                                Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.realTabContent);
                                if (currentFragment == null) {
                                    mHomeBtn.setChecked(true);
                                } else {
                                    checkCurrentFragment();
                                }
                            }

                        }

                    });
                } else {
                    Utility.displayAlert(this, getResources()
                                    .getString(R.string.app_name), getResources()
                                    .getString(R.string.no_connection),
                            android.R.string.ok, Utility
                                    .getOkButtonListener(this));
                }
                break;

            case R.id.header_txt:
                if (mHomeBtn.isChecked()) {
                    numAdCount = 2;
                    if (Utility.isInternetOn(this)) {
                        mSectionType = Sections.HOME;
                        mSelectedCategory = mSubCategoryList.get(0);
                        hideTickers();
                        showCatScrollView();
                        addSubCategory(mSubCategoryList.get(0));
                        onHomeTabClicked();

                    }
                } else {
                    mSelectedCatName = null;
                    mHomeBtn.setChecked(true);
                    mSectionType = Sections.HOME;

                }
                break;

            case R.id.menu:
                lvMenu.setVisibility(View.VISIBLE);
                //Intent animActivity = new Intent(this, MenuLIst.class);
                Intent animActivity = new Intent(this, MenuActivity.class);
                activity_name = "Market Data";
                animActivity.putExtra("TAGNAME", "Market Data");
                findViewById(R.id.refresh_btn).setVisibility(View.GONE);
                findViewById(R.id.setting_button).setVisibility(View.GONE);
                findViewById(R.id.search_button).setVisibility(View.GONE);
                startActivityForResult(animActivity, 1);

                break;
            case R.id.header_date:
                lvMenu.setVisibility(View.VISIBLE);
                //Intent animActivitynew = new Intent(this, MenuLIst.class);
                Intent animActivitynew = new Intent(this, MenuActivity.class);
                animActivitynew.putExtra("TAGNAME", "Market Data");
                activity_name = "Market Data";
                findViewById(R.id.refresh_btn).setVisibility(View.GONE);
                findViewById(R.id.setting_button).setVisibility(View.GONE);
                findViewById(R.id.search_button).setVisibility(View.GONE);
                startActivityForResult(animActivitynew, 1);
                break;
        }
    }

    private void dipslayTicker() {
        if (mTickernewsFeed.bsestock.changePercent != null) {
            try {
                Float bseVal = Float.valueOf(mTickernewsFeed.bsestock.changePercent);
                if (bseVal >= 0) {
                    mBseLabel.setText(mBseLabel.getText() + " " + mTickernewsFeed.bsestock.price + " ");
                    mBseText.setText(mTickernewsFeed.bsestock.changeValue);
                    mBseText.setTextColor(getResources().getColor(R.color.ticker_green));
                    mBseImg.setBackgroundResource(R.drawable.arrow_green);
                } else {
                    mBseLabel.setText(mBseLabel.getText() + " " + mTickernewsFeed.bsestock.price + " ");
                    mBseText.setText(mTickernewsFeed.bsestock.changeValue);
                    mBseImg.setBackgroundResource(R.drawable.arrow_red);
                    mBseText.setTextColor(getResources().getColor(R.color.ticker_red));

                }
            } catch (NumberFormatException exception) {
                mBseLabel.setText(mBseLabel.getText() + " " + 0.0 + " ");
                mBseText.setText("0.0");
                mBseImg.setBackgroundResource(R.drawable.arrow_green);
                mBseText.setTextColor(getResources().getColor(R.color.black));
            }

        }

        if (mTickernewsFeed.nsestock.changePercent != null) {

            try {
                Float nseVal = Float.valueOf(mTickernewsFeed.nsestock.changePercent);
                if (nseVal >= 0) {
                    mNseLabel.setText(mNseLabel.getText() + " " + mTickernewsFeed.nsestock.price + " ");
                    mNseText.setText(mTickernewsFeed.nsestock.changeValue);
                    mNseImg.setBackgroundResource(R.drawable.arrow_green);
                    mNseText.setTextColor(getResources().getColor(R.color.ticker_green));

                } else {
                    mNseLabel.setText(mNseLabel.getText() + " " + mTickernewsFeed.nsestock.price + " ");
                    mNseText.setText(mTickernewsFeed.nsestock.changeValue);
                    mNseImg.setBackgroundResource(R.drawable.arrow_red);
                    mNseText.setTextColor(getResources().getColor(R.color.ticker_red));
                }

            } catch (NumberFormatException exception) {
                mNseLabel.setText(mNseLabel.getText() + " " + 0.0 + " ");
                mNseText.setText("0.0");
                mNseImg.setBackgroundResource(R.drawable.arrow_green);
                mNseText.setTextColor(getResources().getColor(R.color.black));
            }

        }

    }

    private void marketCategories() {
        cleardata();
        String[] catgryArray = getResources().getStringArray(R.array.marketArray);
        Collections.addAll(mSubCategoryList, catgryArray);
        addSubCategory(mSubCategoryList.get(0));
    }


    protected void getTickerFeeds() {
        HomeManager homeManager = new HomeManager(this);
        homeManager.donwloadTickerValues(new TickerDloadCmpltListener() {

            @Override
            public void onFailure() {
                mBseLabel.setText(mBseLabel.getText() + " " + 0.0 + " ");
                mBseText.setText("0.0");
                mBseImg.setBackgroundResource(R.drawable.arrow_green);
                mBseText.setTextColor(getResources().getColor(R.color.black));

                mNseLabel.setText(mNseLabel.getText() + " " + 0.0 + " ");
                mNseText.setText("0.0");
                mNseImg.setBackgroundResource(R.drawable.arrow_green);
                mNseText.setTextColor(getResources().getColor(R.color.black));
            }

            @Override
            public void onTickerDloadCmplt(TickerNewsFeedRootObject result) {
                TickerNewsItemFeed tickerFeed = result.root;
                if (tickerFeed != null && tickerFeed.bsestock != null && tickerFeed.nsestock != null) {
                    mTickernewsFeed = tickerFeed;
                    dipslayTicker();
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        mBseLabel.setText("BSE");
        mNseLabel.setText("NSE");
        mBseText.setText("");
        mNseText.setText("");
        getTickerFeeds();
    }


    @Override
    public void onPause() {
        super.onPause();
        mBseLabel.setText("BSE");
        mNseLabel.setText("NSE");
        mBseText.setText("");
        mNseText.setText("");
    }

    public void onDestroy() {
        System.out.println(" onDestroy numcount set->>>>");
        super.onDestroy();
        //alertBox("On Start", "On Start");
        //BaseFragment.numCount=0;
    }

    public void onStop() {
        System.out.println(" onDestroy numcount set->>>>");
        super.onStop();
        //alertBox("On Start", "On Start");
        //BaseFragment.numCount=0;
    }

    @Override
    public void onNewsListDownloaded(ArrayList<SubNewsItem> newsList) {
        mNewsList = newsList;
    }

    /*
     * (non-Javadoc)
     *
     * @see com.businessstandard.common.ui.BaseFragment.NewsItemClickListner#
     * onNewsItemClick(com.businessstandard.dto.SubNewsItem, int,
     * java.lang.String, java.lang.String)
     */
    @Override
    public void onNewsItemClick(SubNewsItem subNewsitemClicked, int position, String selectedCategory, String category) {
        hideTickers();
        mSelectedCategory = category;
        mCommonAd.setVisibility(View.GONE);
        Fragment visibleFrag = getSupportFragmentManager().findFragmentById(R.id.realTabContent);
        mRadioGroup.setVisibility(View.GONE);
        mDivider.setVisibility(View.GONE);
        mRefreshBtn.setVisibility(View.INVISIBLE);
        Bundle bundle = new Bundle();

        if (visibleFrag instanceof FavouritesFragment) {
            bundle.putBoolean(BundleKeys.IS_FAV_FRAGMENT, true);
            mCategoryScroll.setVisibility(View.VISIBLE);
        } else {
            bundle.putBoolean(BundleKeys.IS_FAV_FRAGMENT, false);
            mCategoryScroll.setVisibility(View.VISIBLE);
        }

        bundle.putInt(BundleKeys.NEWS_ITEM_POSITION, position);
        bundle.putInt(BundleKeys.NEWS_ITEM_POS_TAG, RootFragment.HOME);
        bundle.putString(BundleKeys.SELECTED_CAT_NAME, selectedCategory);
        ArticleDetailFragment fragment = new ArticleDetailFragment();
        fragment.setArguments(bundle);
        FragmentHelper.replaceAndAddContentFragment(this, R.id.realTabContent, fragment);

    }


    @Override
    public ArrayList<SubNewsItem> onNewsListAvail() {
        return (ArrayList<SubNewsItem>) mNewsList;
    }

    @Override
    public void onMessagePostFinish(int status) {
        switch (status) {
            case TwitterShare.ARG_SUCCESS:
                Utility.showToast(getString(R.string.twitter_post_success), this);
                break;

            case TwitterShare.ARG_ERROR:
                Utility.showToast(getString(R.string.twitter_post_error), this);
                break;

            case TwitterShare.ARG_OVERLOAD:
                Utility.showToast(getString(R.string.twitter_post_duplicate), this);
                break;
        }
    }

    /* (non-Javadoc)
     * @see com.businessstandard.common.ui.BaseActivity#onBackPressed()
     */
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        activity_name = null;
    }
}
