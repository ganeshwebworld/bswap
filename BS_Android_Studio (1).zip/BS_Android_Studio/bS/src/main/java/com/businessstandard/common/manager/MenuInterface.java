package com.businessstandard.common.manager;

public interface MenuInterface {

    void onSelectResult(String value);
}
