/**
 * Project      : Economist
 * Filename     : LoadPaymentGateway.java
 * Author       : android-ubantu
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.common.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.businessstandard.R;
import com.businessstandard.analytics.FirebaseAnalyticsTracker;
import com.businessstandard.analytics.GAConstants;
import com.businessstandard.analytics.GoogleAnalytics;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.apache.http.util.EncodingUtils;

/**
 * @author android-ubantu
 */
public class LoadPaymentGateway extends Activity {
    /*
     * (non-Javadoc)
     *
     * @see android.app.Activity#onCreate(android.os.Bundle)
     */
    public static WebView web;
    private GoogleAnalytics mGoogleAnalytics;
    private SaveSharedPref saveSharedPref;
    private String userID = "";
    private FirebaseAnalyticsTracker mFirebaseAnalyticsTracker;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment_webview);
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        mFirebaseAnalyticsTracker = FirebaseAnalyticsTracker.getInstance(this);
        saveSharedPref = SaveSharedPref.getInstance(LoadPaymentGateway.this);
        if (!TextUtils.isEmpty(saveSharedPref.getString(SharedPreferencesKey.KEY_USER_ID, ""))) {
            userID = saveSharedPref.getString(SharedPreferencesKey.KEY_USER_ID, "");
        }
        web = (WebView) findViewById(R.id.webviewnew);
        web.getSettings().setJavaScriptEnabled(true); // enable javascript
        web.getSettings().setAppCacheEnabled(false);
        web.getSettings().setLoadWithOverviewMode(true);
        web.getSettings().setUseWideViewPort(true);
        web.getSettings().setBuiltInZoomControls(true);
        web.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.clearCache(true);
        web.addJavascriptInterface(this, "HTMLOUT");
        Intent i = getIntent();
        String ids = i.getStringExtra("value");
        int d = i.getIntExtra("package", 0);
        //String url = "http://waprevamp.business-standard.com/payment-api.php";
        String url = "https://wap.business-standard.com/payment-api.php";
        String postData = "user_id=" + ids + "&amount=" + d;

        web.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }
        });

        web.postUrl(url, EncodingUtils.getBytes(postData, "UTF-8"));

    }

    @Override
    public void onBackPressed() {
        // TODO Auto-generated method stub
        showdilaog();
    }

    @SuppressLint("CommitPrefEdits")
    @SuppressWarnings("deprecation")
    @JavascriptInterface
    public void gotResponseFromPGI(final boolean blsuccess, String msg) {

        AlertDialog alertDialog = new AlertDialog.Builder(LoadPaymentGateway.this).create();

        alertDialog.setTitle("\tBS");
        alertDialog.setCancelable(false);
        if (blsuccess) {
            String subscription = "N";
            SharedPreferences sharedpreferences = PreferenceManager.getDefaultSharedPreferences(LoadPaymentGateway.this);
            SharedPreferences.Editor editor = sharedpreferences.edit();
            // editor.putString("value", subscription);
//			editor.putString("value", null);
            editor.commit();
            // SharedPreferences.Editor editor = sharedpreferences.edit();
            // editor.putString("value", subscription);
            editor.putString("value", subscription);
            String tillDate = null;
            editor.putString("tillDate", tillDate);
            editor.commit();
            alertDialog.setMessage("Thank you for the payment!");

            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("result", blsuccess);
                    trackGAOrderSuccessEvent();
                    setResult(RESULT_OK, returnIntent);
                    finish();
                }
            });

            alertDialog.show();
        } else {

            alertDialog.setMessage("Payment Failed!");

            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("result", blsuccess);
                    trackGAOrdeFailedEvent(msg);
                    setResult(RESULT_OK, returnIntent);
                    finish();
                }
            });

            alertDialog.show();
        }
    }

    private void trackGAOrdeFailedEvent(String msg) {
        if (mGoogleAnalytics != null && !TextUtils.isEmpty(userID)) {
            mGoogleAnalytics.trackEvent(GAConstants.ORDER_FAILURE_EVENT_CATEGORY, userID, msg);
        }

        mFirebaseAnalyticsTracker.trackEvent(GAConstants.ORDER_FAILURE_EVENT_CATEGORY, userID, msg);
    }

    private void trackGAOrderSuccessEvent() {
        if (!TextUtils.isEmpty(userID) && !TextUtils.isEmpty(saveSharedPref.getString(SharedPreferencesKey.SUBSCRIPTION_AMOUNT_SELECTED, ""))) {
            mGoogleAnalytics.trackEvent(GAConstants.ORDER_SUCCESS_EVENT_CATEGORY,
                    userID,
                    "Value :" + SaveSharedPref.getInstance(LoadPaymentGateway.this).getString(SharedPreferencesKey.SUBSCRIPTION_AMOUNT_SELECTED, "")
                            + "Quantity :1" + "Item Price :" + SaveSharedPref.getInstance(LoadPaymentGateway.this).getString(SharedPreferencesKey.SUBSCRIPTION_AMOUNT_SELECTED, "")
                            + "Currency :INR" + "Content Type :Product");
        }

        mFirebaseAnalyticsTracker.trackEvent(GAConstants.ORDER_SUCCESS_EVENT_CATEGORY, userID, "Value :" + SaveSharedPref.getInstance(LoadPaymentGateway.this).getString(SharedPreferencesKey.SUBSCRIPTION_AMOUNT_SELECTED, "")
                + "Quantity :1" + "Item Price :" + SaveSharedPref.getInstance(LoadPaymentGateway.this).getString(SharedPreferencesKey.SUBSCRIPTION_AMOUNT_SELECTED, "")
                + "Currency :INR" + "Content Type :Product");
    }

    private void showdilaog() {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(LoadPaymentGateway.this);

        // Setting Dialog Title
        alertDialog.setTitle("\tBS");
        alertDialog.setCancelable(false);
        // Setting Dialog Message
        alertDialog.setMessage("Are you sure you want to cancel this payment? ");

        // Setting Positive "Yes" Button
        alertDialog.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        trackGAOrdeFailedEvent("user pressed back button and cancels the payment");
                        finish();
                    }
                });

        // Setting Negative "NO" Button
        alertDialog.setNegativeButton("NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to execute after dialog
                        dialog.cancel();
                    }
                });

        // Showing Alert Message
        alertDialog.show();
    }
}
