/**
 * Project      : Economist
 * Filename     : SendFeedbakActivity.java
 * Author       : DevStringx
 * Comments     :
 * Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.settings.ui;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.ui.MainFragmentActivity;
import com.businessstandard.common.util.Constants.SettingsKeys;
import com.businessstandard.common.util.Utility;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author DevStringx
 */
public class SendFeedbakActivity extends FragmentActivity implements OnClickListener {
    private ImageView mHeaderTxt;
    Button menu, send_btn;
    private EditText email_edt, desc_edt;
    private String uuid;
    private com.businessstandard.model.Constants mConstants = null;

    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        int positionId;
        BaseFragment.numCount = 1;
        setContentView(R.layout.sendfeedback_activity);
        SaveSharedPref mSharedPreferenceManager = SaveSharedPref.getInstance(this);
        if (mSharedPreferenceManager.exists(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA)) {
            if (mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class) != null) {
                mConstants = mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class);
            }
        }
        // menu=(Button)findViewById(R.id.menu);
        // menu.setVisibility(View.GONE);

	/*	TelephonyManager tManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		uuid = tManager.getDeviceId();*/

        //Secure Id added in place of telephony id
        uuid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        Intent intent = getIntent();
        mHeaderTxt = (ImageView) findViewById(R.id.header_txt);
        String item = intent.getStringExtra(SettingsKeys.CLICKED_ITEM);
        positionId = intent.getIntExtra(SettingsKeys.POSITION, 0);
        TextView title_item = (TextView) findViewById(R.id.page_title);
        TextView date = (TextView) findViewById(R.id.header_date);
        email_edt = (EditText) findViewById(R.id.email_edt);
        desc_edt = (EditText) findViewById(R.id.desc_edt);
        send_btn = (Button) findViewById(R.id.send_btn);
        date.setText(Utility.getTodaysData());
        findViewById(R.id.search_button).setVisibility(View.GONE);
        findViewById(R.id.refresh_btn).setVisibility(View.GONE);
        title_item.setText(item);
        initListeners();

    }

    private void initListeners() {
        mHeaderTxt.setOnClickListener(this);
        send_btn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.header_txt:
                launchHome();
                break;
            case R.id.send_btn:
                if (!email_edt.getText().toString().trim().equalsIgnoreCase("") && isValidEmail(email_edt.getText().toString().trim())) {
                    new sendFeedback(SendFeedbakActivity.this).execute(MainFragmentActivity.api_key, email_edt.getText().toString().trim(), desc_edt.getText().toString());
                } else {
                    Toast.makeText(this, "Please enter a vaild email address.", Toast.LENGTH_LONG).show();
                }
                break;

        }

    }

    public final static boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    private void launchHome() {
        Intent intent = new Intent(this, MainFragmentActivity.class);
        intent.setFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }

    @Override
    public void onStop() {
        super.onStop();
        BaseFragment.numCount = 1;
    }

    @Override
    public void onResume() {
        super.onResume();
        BaseFragment.numCount = 1;
    }

    private class sendFeedback extends AsyncTask<String, String, JSONObject> {

        /**
         * @param mContext
         */
        ProgressDialog dialog;
        Context context;

        public sendFeedback(Context mContext) {
            // TODO Auto-generated constructor stub
            context = mContext;

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //
            dialog = ProgressDialog.show(SendFeedbakActivity.this, "", "Please wait...");
        }

        @Override
        protected JSONObject doInBackground(String... args) {
            Context ctx = getApplicationContext();
            String strUrl = "";
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getSendFeedback())) {
                strUrl = mConstants.getSendFeedback();
            }
            //strUrl = ctx.getString(R.string.api_base_url) + Constants.SEND_FEEDBACK;
/*
            InputStream is = null;

            JSONParser jsonParser = new JSONParser();
//			List<NameValuePair> params = new ArrayList<NameValuePair>();
//			params.add(new BasicNameValuePair("api_token", args[0]));
//			params.add(new BasicNameValuePair("user_email", args[1]));
//			params.add(new BasicNameValuePair("user_message", args[2]));

            org.apache.commons.httpclient.NameValuePair[] request = {
                    new org.apache.commons.httpclient.NameValuePair(
                            "api_token", args[0]),
                    new org.apache.commons.httpclient.NameValuePair("user_email",
                            args[1]),
                    new org.apache.commons.httpclient.NameValuePair("user_message",
                            args[2])};

//			JSONObject json = jsonParser.getJSONFromUrl(strUrl
//					+ Constants.SEND_FEEDBACK, params);
            JSONObject json = null;
            try {
                json = new JSONObject(jsonParser.callWebservice(request, strUrl
                        + Constants.SEND_FEEDBACK));
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            System.out.println("=======json==" + json);*/

            OkHttpClient client = new OkHttpClient();
            JSONObject json = null;

            RequestBody formBody = new FormBody.Builder()
                    .add("api_token", args[0])
                    .add("user_email", args[1])
                    .add("user_message", args[2])
                    .build();

            Request request = new Request.Builder()
                    .url(strUrl)
                    .post(formBody)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String jsonStr = response.body().string();
                    json = new JSONObject(jsonStr);
                    return json;
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(JSONObject json) {
            if (dialog != null) {
                dialog.dismiss();
            }
            String msg = "";
            try {
                if (json.getString("status").equalsIgnoreCase("success")) {

                }
                msg = json.getString("message");

            } catch (JSONException e) {
                e.printStackTrace();
            }
            Toast.makeText(SendFeedbakActivity.this, msg, Toast.LENGTH_LONG).show();

        }
    }
}
