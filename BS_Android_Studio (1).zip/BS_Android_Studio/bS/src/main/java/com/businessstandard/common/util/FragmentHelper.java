/**
 * Project      : Economist
 * Filename     : FragmentHelper.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.common.util;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.util.Log;

/**
 * @author lenesha
 */
public class FragmentHelper {

    private static final String TAG = FragmentHelper.class.getSimpleName();
    public static final String DIALOG_FRAGMENT_TAG = "dialog";

    public static void replaceContentFragment(final FragmentActivity activity, final int containerId, final Fragment frgmt) {
        if (activity != null) {
            try {
                FragmentManager manager = activity.getSupportFragmentManager();
                manager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                manager.beginTransaction().replace(containerId, frgmt).commitAllowingStateLoss();
            } catch (IllegalStateException exception) {
                exception.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void replaceSettingsFragment(final FragmentActivity activity, final int containerId, final Fragment frgmt) {
        if (activity != null) {
            try {
                FragmentManager manager = activity.getSupportFragmentManager();
                manager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                manager.beginTransaction().replace(containerId, frgmt, "settings_fragment").addToBackStack(null).commit();
            } catch (IllegalStateException exception) {
                exception.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void replaceMarketFragment(FragmentActivity activity, final int containerId, Fragment frgmt) {
        if (activity != null) {
            FragmentManager manager = activity.getSupportFragmentManager();
            manager.popBackStackImmediate(null,
                    FragmentManager.POP_BACK_STACK_INCLUSIVE);
            manager.beginTransaction().replace(containerId, frgmt)
                    .commitAllowingStateLoss();
        }
    }

    // this method will add fragment to backstack
    public static void replaceAndAddContentFragment(FragmentActivity activity, final int containerId, final Fragment fragment) {
        try {
            activity.getSupportFragmentManager().beginTransaction()
                    .replace(containerId, fragment, "content_fragment").addToBackStack(null)
                    .commitAllowingStateLoss();
        } catch (IllegalStateException exception) {
            exception.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // this method won't add fragment to backstack
    public static void replaceFragment(final FragmentActivity activity, final int containerId, final Fragment fragment) {
        activity.getSupportFragmentManager().beginTransaction().replace(containerId, fragment).commitAllowingStateLoss();
    }

    public static void popBackStackInclusive(FragmentManager fragMgr) {
        if (fragMgr != null) {
            try {
                for (int i = 0; i < fragMgr.getBackStackEntryCount(); ++i) {
                    fragMgr.popBackStack();
                }
            } catch (IllegalStateException e) {
                // ignore
                Log.w(TAG, e);
            }
        }
    }
}
