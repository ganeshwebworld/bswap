/**
   Project      : Economist
   Filename     : McxAndNcdexSpotItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.market.dto;

import com.google.gson.annotations.SerializedName;

/**
 * @author lenesha
 *
 */
public class McxAndNcdexSpotItem {
	@SerializedName("Symbol")
	private String mSymbol;
	
	public String getmSymbol() {
		return mSymbol;
	}

	public String getmTradeDate() {
		return mTradeDate;
	}

	public String getmPrice() {
		return mPrice;
	}

	public String getmUnits() {
		return mUnits;
	}

	public String getmMarketPlace() {
		return mMarketPlace;
	}

	public String getmPreviousClose() {
		return mPreviousClose;
	}

	@SerializedName("Trade Date")
	private String mTradeDate;
	
	@SerializedName("Price")
	private String mPrice;
	
	@SerializedName("Units")
	private String mUnits;
	
	@SerializedName("Market Place")
	private String mMarketPlace;
	
	@SerializedName("Previous Close")
	private String mPreviousClose;
	


}