package com.businessstandard.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class DynamicSplash implements Serializable {

    @SerializedName("isDynamicSplash")
    @Expose
    private Boolean isDynamicSplash;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("logo")
    @Expose
    private String logo;
    @SerializedName("bg_color")
    @Expose
    private String bgColor;
    @SerializedName("title_color")
    @Expose
    private String titleColor;
    @SerializedName("progressIndicatorColor")
    @Expose
    private String progressIndicatorColor;

    public Boolean getIsDynamicSplash() {
        return isDynamicSplash;
    }

    public void setIsDynamicSplash(Boolean isDynamicSplash) {
        this.isDynamicSplash = isDynamicSplash;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public String getBgColor() {
        return bgColor;
    }

    public void setBgColor(String bgColor) {
        this.bgColor = bgColor;
    }

    public String getTitleColor() {
        return titleColor;
    }

    public void setTitleColor(String titleColor) {
        this.titleColor = titleColor;
    }

    public Boolean getDynamicSplash() {
        return isDynamicSplash;
    }

    public void setDynamicSplash(Boolean dynamicSplash) {
        isDynamicSplash = dynamicSplash;
    }

    public String getProgressIndicatorColor() {
        return progressIndicatorColor;
    }

    public void setProgressIndicatorColor(String progressIndicatorColor) {
        this.progressIndicatorColor = progressIndicatorColor;
    }
}