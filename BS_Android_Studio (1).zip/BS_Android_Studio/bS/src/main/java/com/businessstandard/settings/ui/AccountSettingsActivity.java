/**
 * Project      : Economist
 * Filename     : AccountSettingsActivity.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2013, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.settings.ui;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.webkit.WebSettings.ZoomDensity;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.common.ui.BaseActivity;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.ui.MainFragmentActivity;
import com.businessstandard.common.util.FacebookHelper;
import com.businessstandard.common.util.TwitterHelper;
import com.businessstandard.common.util.TwitterShare;
import com.businessstandard.common.util.TwitterShare.OnMessagePostedListener;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.ui.ShareDialogFragment;
import com.businessstandard.linkedin.Config;
import com.businessstandard.linkedin.LinkedinDialog;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;
import com.facebook.FacebookAuthorizationException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.Session;
import com.facebook.SessionState;
import com.google.code.linkedinapi.client.LinkedInApiClient;
import com.google.code.linkedinapi.client.LinkedInApiClientFactory;
import com.google.code.linkedinapi.client.oauth.LinkedInAccessToken;
import com.google.code.linkedinapi.client.oauth.LinkedInOAuthService;
import com.google.code.linkedinapi.client.oauth.LinkedInOAuthServiceFactory;
import com.google.code.linkedinapi.client.oauth.LinkedInRequestToken;
import com.twitter.sdk.android.core.Callback;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.TwitterCore;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.TwitterSession;
import com.twitter.sdk.android.core.identity.TwitterAuthClient;

/**
 * @author lenesha
 */
public class AccountSettingsActivity extends FragmentActivity implements OnClickListener, OnMessagePostedListener {

    private String TAG = AccountSettingsActivity.class.getSimpleName();
    private Session.StatusCallback mStatusCallback = new SessionStatusCallback();
    private final String PENDING_ACTION_BUNDLE_KEY = "com.facebook:PendingAction";
    private PendingAction mPendingAction = PendingAction.NONE;
    private Button mFbLogin;
    private FacebookHelper mFbHelper;
    private FragmentActivity mContext;
    private Button mTwitterLoginBtn;
    //private BonzaiAdView mAdView;
    private RelativeLayout mAdView;
    private RelativeLayout mAdView_Up;
    private ImageView mHeaderTxt;
    private boolean mIsTwitterLogIn = false;
    Boolean linkedlogin = false;
    private String strAdDown;
    Button menu;
    private String strAdUp;
    private WebView webview;
    Button linkedin_login;
    private WebView webview_Down;
    LinkedInAccessToken accessToken = null;
    private boolean mIntentInProgress;
    private static final int RC_SIGN_IN = 0;
    LinkedInRequestToken liToken;
    LinkedInApiClient client;
    SharedPreferences preferences;
    String token_secret;
    String token;
    final LinkedInOAuthService oAuthService = LinkedInOAuthServiceFactory
            .getInstance().createLinkedInOAuthService(
                    Config.LINKEDIN_CONSUMER_KEY,
                    Config.LINKEDIN_CONSUMER_SECRET);
    final LinkedInApiClientFactory factory = LinkedInApiClientFactory
            .newInstance(Config.LINKEDIN_CONSUMER_KEY,
                    Config.LINKEDIN_CONSUMER_SECRET);

    private enum PendingAction {
        NONE, POST_STATUS_UPDATE
    }

    //twitter auth client required for custom login
    private TwitterAuthClient twitterAuthClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acc_settings);
        twitterAuthClient = new TwitterAuthClient();
        preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

//		menu=(Button)findViewById(R.id.menu);
//		menu.setVisibility(View.GONE);
        TextView date = (TextView) findViewById(R.id.header_date);
        date.setText(Utility.getTodaysData());
        mHeaderTxt = (ImageView) findViewById(R.id.header_txt);
        mFbLogin = (Button) findViewById(R.id.fbLogin);
        mTwitterLoginBtn = (Button) findViewById(R.id.twitterLogin);
        linkedin_login = (Button) findViewById(R.id.linkedin);
        linkedin_login.setOnClickListener(this);
        findViewById(R.id.search_button).setVisibility(View.GONE);
        findViewById(R.id.refresh_btn).setVisibility(View.GONE);
        mAdView = (RelativeLayout) findViewById(R.id.common_ad_banner_layout);
        mAdView_Up = (RelativeLayout) findViewById(R.id.common_ad_banner_layout_up);

        webview = (WebView) findViewById(R.id.webView);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webview.getSettings().setLoadWithOverviewMode(true);
        webview.getSettings().setUseWideViewPort(false);
        webview.getSettings().setBuiltInZoomControls(false);
        webview.setHorizontalScrollBarEnabled(false);
        webview.getSettings().setDomStorageEnabled(true);
        webview.getSettings().setAllowFileAccess(true);
        webview.getSettings().setLoadsImagesAutomatically(true);
        webview.getSettings().setSupportZoom(false);
        webview.setInitialScale(100);
        webview.getSettings().setDefaultZoom(ZoomDensity.FAR);
        webview.getSettings().setUserAgentString("Safari/534.30 Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 ");
        webview.getSettings().setSaveFormData(true);
        //webview.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);

        webview_Down = (WebView) findViewById(R.id.webView1);
        webview_Down.getSettings().setJavaScriptEnabled(true);
        webview_Down.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webview_Down.getSettings().setLoadWithOverviewMode(true);
        webview_Down.getSettings().setUseWideViewPort(false);
        webview_Down.getSettings().setBuiltInZoomControls(false);
        webview_Down.setHorizontalScrollBarEnabled(false);
        webview_Down.getSettings().setDomStorageEnabled(true);
        webview_Down.getSettings().setAllowFileAccess(true);
        webview_Down.getSettings().setLoadsImagesAutomatically(true);
        webview_Down.getSettings().setSupportZoom(false);
        webview_Down.setInitialScale(100);
        webview_Down.getSettings().setDefaultZoom(ZoomDensity.FAR);
        webview_Down.getSettings().setUserAgentString("Safari/534.30 Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 ");
        webview_Down.getSettings().setSaveFormData(true);
        //webview_Down.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);

        //initAds();
        mFbLogin.setOnClickListener(this);
        mFbHelper = FacebookHelper.getInstance();
        TwitterHelper.instantiateTwitter(this);
        mContext = this;
        mFbHelper.initFBHelper(this, savedInstanceState, mStatusCallback);
        updateFbUi();
        updateInUi();
        initialiseTwitterBtn();
        initListener();
        @SuppressWarnings("static-access")
        Display d = ((WindowManager) getSystemService(this.WINDOW_SERVICE)).getDefaultDisplay();
        @SuppressWarnings("deprecation")
        int width = d.getWidth();
        @SuppressWarnings("deprecation")
        int height = d.getHeight();
        System.out.println("Device Width-->>" + width);
        System.out.println("Device Height-->>" + height);
        if (width >= 220 && width < 260) {
            mAdView.removeAllViews();
            mAdView_Up.removeAllViews();
            webview_Down.loadUrl("file:///android_asset/Ads_down240.html");
            mAdView.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up240.html");
            mAdView_Up.addView(webview);
        } else if (width >= 300 && width < 340) {
            mAdView.removeAllViews();
            mAdView_Up.removeAllViews();
            webview_Down.loadUrl("file:///android_asset/Ads_down320.html");
            mAdView.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up320.html");
            mAdView_Up.addView(webview);
        } else if (width >= 450 && width < 490) {
            mAdView.removeAllViews();
            mAdView_Up.removeAllViews();
            webview_Down.loadUrl("file:///android_asset/Ads_down468.html");
            mAdView.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up468.html");
            mAdView_Up.addView(webview);
        } else if (width >= 590 && width < 700) {
            mAdView.removeAllViews();
            mAdView_Up.removeAllViews();
            webview_Down.loadUrl("file:///android_asset/Ads_down600.html");
            mAdView.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up600.html");
            mAdView_Up.addView(webview);
        } else if (width >= 700 && width < 730) {
            mAdView.removeAllViews();
            mAdView_Up.removeAllViews();
            webview_Down.loadUrl("file:///android_asset/Ads_down720.html");
            mAdView.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up720.html");
            mAdView_Up.addView(webview);
        } else if (width >= 730 && width < 770) {
            mAdView.removeAllViews();
            mAdView_Up.removeAllViews();
            webview_Down.loadUrl("file:///android_asset/Ads_down768.html");
            mAdView.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up768.html");
            mAdView_Up.addView(webview);
        } else if (width >= 770 && width <= 800) {
            mAdView.removeAllViews();
            mAdView_Up.removeAllViews();
            webview_Down.loadUrl("file:///android_asset/Ads_down800.html");
            mAdView.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up800.html");
            mAdView_Up.addView(webview);
        } else if (width >= 1000) {
            mAdView.removeAllViews();
            mAdView_Up.removeAllViews();
            webview_Down.loadUrl("file:///android_asset/Ads_down1024.html");
            mAdView.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up1024.html");
            mAdView_Up.addView(webview);
        } else {
            mAdView.removeAllViews();
            mAdView_Up.removeAllViews();
            webview_Down.loadUrl("file:///android_asset/Ads_down468.html");
            mAdView.addView(webview_Down);
            webview.loadUrl("file:///android_asset/Ads_up468.html");
            mAdView_Up.addView(webview);
        }
        this.strAdUp = BaseActivity.upAds;
        this.strAdDown = BaseActivity.lwrAds;
        if (strAdUp.equalsIgnoreCase("true")) {
            mAdView_Up.setVisibility(View.VISIBLE);
        } else {
            mAdView_Up.setVisibility(View.GONE);
        }
        if (strAdDown.equalsIgnoreCase("true")) {
            mAdView.setVisibility(View.VISIBLE);
        } else {
            mAdView.setVisibility(View.GONE);
        }

    }

    private void initListener() {
        mHeaderTxt.setOnClickListener(this);
    }

    /**
     *
     */
    private void initAds() {
        //AdManager adManager = new AdManager();
        //adManager.displayBannerAdOnMainPage(mAdView, BonzaiZoneIds.COMMON);
    }

    /**
     *
     */
    private void initialiseTwitterBtn() {
        //mIsTwitterLogIn = TwitterHelper.checkLoginStatus();
        if (mIsTwitterLogIn) {
            mTwitterLoginBtn.setBackgroundResource(R.drawable.btn_twt_sigout);
            setResult(RESULT_OK);
        } else {
            mTwitterLoginBtn.setBackgroundResource(R.drawable.btn_twt_sigin);
        }
        mTwitterLoginBtn.setOnClickListener(this);
    }

    /**
     *
     */
    private void updateFbUi() {
        if (mFbHelper.isLoggedIn()) {
            mFbLogin.setBackgroundResource(R.drawable.btn_fb_logout);

        } else {
            mFbLogin.setBackgroundResource(R.drawable.btn_fb_login);

        }
    }

    private class SessionStatusCallback implements Session.StatusCallback {
        @Override
        public void call(Session session, SessionState state, Exception exception) {
            Log.i(TAG, "SessionStatusCallback:: Sesssion Updated:" + exception);
            Log.i(TAG, " Active permission:" + session.getPermissions());
            if (mPendingAction != PendingAction.NONE && (exception instanceof FacebookOperationCanceledException || exception instanceof FacebookAuthorizationException)) {
                new AlertDialog.Builder(AccountSettingsActivity.this)
                        .setTitle(R.string.cancelled)
                        .setMessage(R.string.permission_not_granted)
                        .setPositiveButton(R.string.ok, null).show();
                mPendingAction = PendingAction.NONE;
            }
            handlePendingAction();
            updateFbUi();
        }

        private void handlePendingAction() {
            switch (mPendingAction) {
                case POST_STATUS_UPDATE:
                    // perfomPublish();
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Session session = Session.getActiveSession();
        Session.saveSession(session, outState);
        outState.putString(PENDING_ACTION_BUNDLE_KEY, mPendingAction.name());
    }

    @Override
    public void onStart() {
        super.onStart();
        Session.getActiveSession().addCallback(mStatusCallback);
    }

    @Override
    public void onStop() {
        super.onStop();
        Session.getActiveSession().removeCallback(mStatusCallback);
        BaseFragment.numCount = 1;
    }

    @Override
    public void onResume() {
        super.onResume();
        BaseFragment.numCount = 1;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);
        if (requestCode == TwitterShare.TWITTER_REQUESTCODE) {
            initialiseTwitterBtn();
        }
        if (twitterAuthClient != null) {
            twitterAuthClient.onActivityResult(requestCode, resultCode, data);
        }
        // Pass the activity result to the twitterAuthClient.

    }
	/*public void onBackPressed(){
		
	}*/

    /*
     * (non-Javadoc)
     *
     * @see android.view.View.OnClickListener#onClick(android.view.View)
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fbLogin:
                if (mFbHelper.isLoggedIn()) {
                    mFbHelper.logout();
                } else {
                    mFbHelper.login(mContext);
                }
                break;
            case R.id.twitterLogin:
              /*  if (!Utility.isInternetOn(getApplicationContext())) {
                    Utility.displayAlert(AccountSettingsActivity.this,
                            getResources().getString(R.string.app_name),
                            getResources().getString(R.string.no_connection),
                            android.R.string.ok,
                            Utility.getOkButtonListener(this));
                    return;
                }
                if (mIsTwitterLogIn) {
                    TwitterHelper.twitterSignOut();
                    mIsTwitterLogIn = false;
                    initialiseTwitterBtn();
                } else {
                    TwitterHelper.twitterSignIn();
                    initialiseTwitterBtn();
                }*/
                customLoginTwitter();
                break;
            case R.id.linkedin:
                token = preferences.getString("AccessToken", "null");
                token_secret = preferences.getString("TokenSecret", "null");
                if (token.equals("null") && token_secret.equals("null"))
                    sharebylinkedin();
                else {
                    SharedPreferences.Editor edit = preferences.edit();
                    edit.putString("AccessToken", null);
                    edit.putString("TokenSecret", null);
                    edit.commit();
                    ShareDialogFragment.linkedinlogin_status = false;
                    linkedin_login.setBackgroundResource(R.drawable.btn_ln_login);
                }
                break;
            case R.id.header_txt:
                launchHome();
                break;
            default:
                break;
        }
    }

    private void launchHome() {
        Intent intent = new Intent(this, MainFragmentActivity.class);
        intent.setFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * com.businessstandard.common.util.TwitterShare.OnMessagePostedListener
     * #onMessagePostFinish(int)
     */
    @Override
    public void onMessagePostFinish(int status) {
        switch (status) {
            case TwitterShare.ARG_SUCCESS:
                Utility.showToast(getString(R.string.twitter_post_success), this);
                break;

            case TwitterShare.ARG_ERROR:
                Utility.showToast(getString(R.string.twitter_post_error), this);
                break;

            case TwitterShare.ARG_OVERLOAD:
                Utility.showToast(getString(R.string.twitter_post_duplicate), this);
                break;
        }
    }

    public void sharebylinkedin() {
        // TODO Auto-generated method stub

        final ProgressDialog progressDialog = new ProgressDialog(this);

        final LinkedinDialog d = new LinkedinDialog(this, progressDialog);
        d.show();
        // set call back listener to get oauth_verifier value
        d.setVerifierListener(new com.businessstandard.linkedin.LinkedinDialog.OnVerifyListener() {
            @Override
            public void onVerify(final String verifier) {
                try {
                    new AsyncTask<Void, Void, Void>() {
                        @Override
                        protected Void doInBackground(Void... voids) {
                            try {
                                accessToken = LinkedinDialog.oAuthService.getOAuthAccessToken(LinkedinDialog.liToken, verifier);

                                LinkedinDialog.factory.createLinkedInApiClient(accessToken);
                                client = factory.createLinkedInApiClient(accessToken);
                                client = factory.createLinkedInApiClient(accessToken);

                                SharedPreferences.Editor edit = preferences.edit();
                                edit.putString("AccessToken", accessToken.getToken());
                                edit.putString("TokenSecret", accessToken.getTokenSecret());
                                edit.commit();
                                ShareDialogFragment.linkedinlogin_status = true;
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            return null;
                        }

                        @Override
                        protected void onPostExecute(Void aVoid) {
                            try {
                                super.onPostExecute(aVoid);
                                updateInUi();
                                progressDialog.setMessage("Loading...");
                                progressDialog.setCancelable(true);
                                progressDialog.dismiss();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }.execute();

                } catch (Exception e) {
                    Log.i("LinkedinSample", "error to get verifier");
                    e.printStackTrace();
                }
            }

        });
    }

    private void updateInUi() {
        token = preferences.getString("AccessToken", "null");
        token_secret = preferences.getString("TokenSecret", "null");
        if (token.equals("null") && token_secret.equals("null")) {
            linkedin_login.setBackgroundResource(R.drawable.btn_ln_login);
        } else
            linkedin_login.setBackgroundResource(R.drawable.btn_ln_logout);
    }


    public void customLoginTwitter() {
        //check if user is already authenticated or not
        if (getTwitterSession() == null) {

            //if user is not authenticated start authenticating
            twitterAuthClient.authorize(this, new Callback<TwitterSession>() {
                @Override
                public void success(Result<TwitterSession> result) {
                    // Do something with result, which provides a TwitterSession for making API calls
                    TwitterSession twitterSession = result.data;
                    //call fetch email only when permission is granted
                    if (twitterSession != null) {
                        mIsTwitterLogIn = true;
                        initialiseTwitterBtn();
                        fetchTwitterEmail(twitterSession);
                    }
                }

                @Override
                public void failure(TwitterException e) {
                    // Do something on failure
                    Toast.makeText(AccountSettingsActivity.this, "Failed to authenticate. Please try again.", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            //if user is already authenticated direct call fetch twitter email api
            Toast.makeText(this, "User already authenticated", Toast.LENGTH_SHORT).show();
            if (getTwitterSession() != null) {
                fetchTwitterEmail(getTwitterSession());
            }
        }
    }

    /**
     * Saving user information, after user is authenticated for the first time.
     * You don't need to show user to login, until user has a valid access toen
     */
    private void saveTwitterInfo(TwitterSession twitterSession, String email) {

        SaveSharedPref saveSharedPref = SaveSharedPref.getInstance(this);

        try {
            /* Storing oAuth tokens to shared preferences */
            saveSharedPref.saveString(SharedPreferencesKey.TWITTER_AUTH_TOKEN, twitterSession.getAuthToken().token);
            saveSharedPref.saveString(SharedPreferencesKey.TWITTER_AUTH_SECRET, twitterSession.getAuthToken().secret);
            saveSharedPref.saveBoolean(SharedPreferencesKey.KEY_TWITTER_LOGIN, true);
            saveSharedPref.saveString(SharedPreferencesKey.TWITTER_USER_NAME, twitterSession.getUserName());
            saveSharedPref.saveLong(SharedPreferencesKey.TWITTER_USER_ID, twitterSession.getUserId());
            saveSharedPref.saveString(SharedPreferencesKey.TWITTER_USER_EMAIL, email);
        } catch (TwitterException e1) {
            e1.printStackTrace();
        }
    }


    /**
     * Before using this feature, ensure that “Request email addresses from users” is checked for your Twitter app.
     *
     * @param twitterSession user logged in twitter session
     */


    public void fetchTwitterEmail(final TwitterSession twitterSession) {
        twitterAuthClient.requestEmail(twitterSession, new Callback<String>() {
            @Override
            public void success(Result<String> result) {
                //here it will give u only email and rest of other information u can get from TwitterSession
                if (!TextUtils.isEmpty(result.data)) {
                    saveTwitterInfo(twitterSession, result.data);
                }
                //userDetailsLabel.setText("User Id : " + twitterSession.getUserId() + "\nScreen Name : " + twitterSession.getUserName() + "\nEmail Id : " + result.data);
            }

            @Override
            public void failure(TwitterException exception) {
                Toast.makeText(AccountSettingsActivity.this, "Failed to authenticate. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * get authenticates user session
     *
     * @return twitter session
     */
    private TwitterSession getTwitterSession() {
        TwitterSession session = TwitterCore.getInstance().getSessionManager().getActiveSession();
        //NOTE : if you want to get token and secret too use uncomment the below code
        /*TwitterAuthToken authToken = session.getAuthToken();
        String token = authToken.token;
        String secret = authToken.secret;*/
        return session;
    }
}
