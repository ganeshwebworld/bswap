/**
   Project      : Economist
   Filename     : ParserManager.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */

package com.businessstandard.common.io;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.businessstandard.common.dto.CommentItem;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.util.Constants;
import com.businessstandard.common.util.Constants.CommentsKeys;

/**
 * @author lenesha
 *
 */
public class ParserManager {
	public ArrayList<SubNewsItem> getListOfnewsItem(String sectionNewsItem) {
		ArrayList<SubNewsItem> subnewsItemList = new ArrayList<SubNewsItem>();
		try {

			JSONObject jsonObject = new JSONObject(sectionNewsItem);

			JSONObject jsonSubObject = jsonObject.getJSONObject(Constants.ROOT_TAG);
			
			if(jsonSubObject.get(Constants.ITEM_TAG) instanceof JSONObject) {
				
				SubNewsItem newsItem = new SubNewsItem();

				newsItem.init(jsonSubObject);

				subnewsItemList.add(newsItem);
			}

			if(jsonSubObject.get(Constants.ITEM_TAG) instanceof JSONArray){

				JSONArray jsonArray = jsonSubObject.getJSONArray(Constants.ITEM_TAG);

				for (int i = 0;i <= jsonArray.length();i++) {

					JSONObject newsObject = jsonArray.getJSONObject(i);

					SubNewsItem newsItem = new SubNewsItem();

					newsItem.init(newsObject);

					subnewsItemList.add(newsItem);


					Log.i("", "newslist size"+subnewsItemList.size());
				}

			}

		} catch (JSONException e) {

			e.printStackTrace();

		}
		return subnewsItemList;
	}
	public List<CommentItem> parseCommentFeeds(String document) {

		List<CommentItem>  mCommentList =  new ArrayList<CommentItem>();
		try {
			JSONObject jsonObject = new JSONObject(document);

			JSONObject jsonSubObject = null;
			JSONArray jsonArray = null;

			if(jsonObject.get(CommentsKeys.COMM_TAG) instanceof JSONObject){
				jsonSubObject = jsonObject.getJSONObject(CommentsKeys.COMM_TAG);

				CommentItem commentItem = new CommentItem();
				commentItem.init(jsonSubObject);
				mCommentList.add(commentItem);
			}
			else if(jsonObject.get(CommentsKeys.COMM_TAG) instanceof JSONArray){
				jsonArray = jsonObject.getJSONArray(CommentsKeys.COMM_TAG);

				int count = jsonArray.length();
				for(int i = 0;i < count;i++){
					JSONObject commentObject = jsonArray.getJSONObject(i);
					CommentItem commentItem = new CommentItem();
					commentItem.init(commentObject);
					mCommentList.add(commentItem);
				}
			}

		} catch (JSONException e) {
			e.printStackTrace();
		}
		return mCommentList;
	}

}
