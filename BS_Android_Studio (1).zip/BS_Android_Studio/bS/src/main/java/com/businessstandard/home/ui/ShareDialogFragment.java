/**
 * Project      : Economist
 * Filename     : ShareDialogFragment.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */

package com.businessstandard.home.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.Signature;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.DialogFragment;
import android.text.Html;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.util.FacebookHelper;
import com.businessstandard.common.util.FacebookHelper.FeedPostListener;
import com.businessstandard.common.util.TwitterHelper;
import com.businessstandard.common.util.TwitterShare;
import com.businessstandard.common.util.Utility;
import com.businessstandard.linkedin.Config;
import com.businessstandard.linkedin.LinkedinDialog;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.ShareUtility;
import com.businessstandard.utils.SharedPreferencesKey;
import com.facebook.FacebookAuthorizationException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.Session;
import com.facebook.SessionState;
import com.google.code.linkedinapi.client.LinkedInApiClient;
import com.google.code.linkedinapi.client.LinkedInApiClientFactory;
import com.google.code.linkedinapi.client.oauth.LinkedInAccessToken;
import com.google.code.linkedinapi.client.oauth.LinkedInOAuthService;
import com.google.code.linkedinapi.client.oauth.LinkedInOAuthServiceFactory;
import com.google.code.linkedinapi.client.oauth.LinkedInRequestToken;
import com.google.code.linkedinapi.schema.Person;
import com.twitter.sdk.android.core.TwitterException;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import twitter4j.StatusUpdate;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;
import twitter4j.conf.ConfigurationBuilder;

public class ShareDialogFragment extends DialogFragment implements OnClickListener {

    private SubNewsItem newsItem;
    private FacebookHelper facebookHelper;
    private TwitterShare mTwitterManager;
    private Session.StatusCallback statusCallback = new SessionStatusCallback();
    private final String PENDING_ACTION_BUNDLE_KEY = "com.facebook:PendingAction";
    private PendingAction pendingAction = PendingAction.NONE;
    private Dialog dialog;
    //	private GoogleApiClient mGoogleApiClient;
    LinkedInRequestToken liToken;
    LinkedInApiClient client;
    private boolean mSignInClicked;
    public static boolean linkedinlogin_status = false;
    //	private ConnectionResult mConnectionResult;
    LinkedInAccessToken accessToken = null;
    private boolean mIntentInProgress;
    private static final int RC_SIGN_IN = 0;
    public final static LinkedInOAuthService oAuthService = LinkedInOAuthServiceFactory
            .getInstance().createLinkedInOAuthService(
                    Config.LINKEDIN_CONSUMER_KEY,
                    Config.LINKEDIN_CONSUMER_SECRET);
    final static LinkedInApiClientFactory factory = LinkedInApiClientFactory
            .newInstance(Config.LINKEDIN_CONSUMER_KEY,
                    Config.LINKEDIN_CONSUMER_SECRET);

    SharedPreferences preferences;
    String token_secret;
    String token;


    private enum PendingAction {
        NONE, POST_STATUS_UPDATE
    }

    public ShareDialogFragment(SubNewsItem item) {
        newsItem = item;
    }

    public ShareDialogFragment() {

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        preferences = PreferenceManager
                .getDefaultSharedPreferences(activity);
//		 mGoogleApiClient = new GoogleApiClient.Builder(activity)
//			.addConnectionCallbacks((ConnectionCallbacks) getActivity())
//			.addOnConnectionFailedListener((OnConnectionFailedListener) activity).addApi(Plus.API)
//			.addScope(Plus.SCOPE_PLUS_LOGIN).build();
        try {
            PackageInfo info = activity.getPackageManager().getPackageInfo(
                    "com.businessstandard",
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }

    }

    /*
     * (non-Javadoc)
     *
     * @see
     * android.support.v4.app.Fragment#onCreateView(android.view.LayoutInflater,
     * android.view.ViewGroup, android.os.Bundle)
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        Dialog dialog = getDialog();
        getDialog().setTitle(R.string.share_hdr);
        WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();

        dialog.getWindow().setAttributes(lp);
        dialog.getWindow().setFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND,
                WindowManager.LayoutParams.FLAG_DIM_BEHIND);

        View view = inflater.inflate(R.layout.share_layout, container, false);

        initViews(view);

        return view;
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * android.support.v4.app.DialogFragment#onActivityCreated(android.os.Bundle
     * )
     */
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        facebookHelper = FacebookHelper.getInstance();
        mTwitterManager = new TwitterShare(getActivity());
        facebookHelper.initFBHelper(getActivity(), savedInstanceState, statusCallback);
        if (savedInstanceState != null) {
            String name = savedInstanceState.getString(PENDING_ACTION_BUNDLE_KEY);
            pendingAction = PendingAction.valueOf(name);
        }
    }

    /**
     * @param view
     */
    private void initViews(View view) {

        TextView facebook = (TextView) view.findViewById(R.id.fbook);
        TextView twitter = (TextView) view.findViewById(R.id.twit);
        TextView email = (TextView) view.findViewById(R.id.mail);
        TextView whats_app = (TextView) view.findViewById(R.id.whats_app);
        TextView linked_in = (TextView) view.findViewById(R.id.linkedin);
        TextView google_plus = (TextView) view.findViewById(R.id.google_plus);
        google_plus.setVisibility(View.GONE);
        facebook.setOnClickListener(this);
        twitter.setOnClickListener(this);
        email.setOnClickListener(this);
        whats_app.setOnClickListener(this);
        linked_in.setOnClickListener(this);
        google_plus.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.linkedin:
/*                SharedPreferences.Editor edit = preferences.edit();
                token = preferences.getString("AccessToken", "null");
                token_secret = preferences.getString("TokenSecret", "null");
                if (token.equals("null") && token_secret.equals("null"))
                    sharebylinkedin();
                else
                    sharelinkedindata();*/
                if (!TextUtils.isEmpty(Html.fromHtml(newsItem.title) + " " + newsItem.short_url)) {
                    ShareUtility.getInstance().shareOnLinkedIn(getContext(), Html.fromHtml(newsItem.title) + " " + newsItem.short_url);
                }
                dismiss();
                break;
            case R.id.fbook:
//			ShareDialogOthers frgmt = new ShareDialogOthers(newsItem);
//			frgmt.show(getActivity().getSupportFragmentManager(), "share");
//			signInWithGplus();
                sharebyFb();
                break;
            case R.id.twit:
                if (!TextUtils.isEmpty(Html.fromHtml(newsItem.title) + " " + newsItem.short_url)) {
                    //new updateTwitterStatus().execute(Html.fromHtml(newsItem.title) + " " + newsItem.short_url);
                    ShareUtility.getInstance().shareOnTwitter(getContext(), Html.fromHtml(newsItem.title) + " " + newsItem.short_url);
                }
                //shareByTwitter();
                dismiss();
                break;
            case R.id.whats_app:
                /*try {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, Html.fromHtml(newsItem.title) + "\n" + newsItem.short_url + "\n" + "Sent from BS App");
                    sendIntent.setType("text/plain");
                    sendIntent.setPackage("com.whatsapp");
                    startActivity(Intent.createChooser(sendIntent, "- shared via Business Standard Android App"));
                } catch (Exception e) {
                    // TODO: handle exception
                    Toast.makeText(getActivity(), "Whats app not installed", Toast.LENGTH_SHORT).show();
                }*/
                if (!TextUtils.isEmpty(Html.fromHtml(newsItem.title) + " " + newsItem.short_url)) {
                    ShareUtility.getInstance().shareOnWhatsapp(getContext(), Html.fromHtml(newsItem.title) + "\n" + newsItem.short_url);
                }
                dismiss();
                break;
            case R.id.google_plus:
                try {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, Html.fromHtml(newsItem.title) + "\n" + newsItem.short_url + "\n" + "Sent from BS App");
                    sendIntent.setType("text/plain");
                    sendIntent.setPackage("com.google.android.apps.plus");
                    startActivity(Intent.createChooser(sendIntent, "- shared via Business Standard Android App"));
                } catch (Exception e) {
                    // TODO: handle exception
                    Toast.makeText(getActivity(), "Google+ not installed", Toast.LENGTH_SHORT).show();
                }
                dismiss();
                break;
            case R.id.mail:
                shareByEmail();

        }
    }

    private ProgressDialog pDialog;

    class updateTwitterStatus extends AsyncTask<String, String, Void> {

        private SaveSharedPref mSharedPreferences = SaveSharedPref.getInstance(getContext());

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (getContext() != null) {
                pDialog = new ProgressDialog(getContext());
                pDialog.setMessage("Posting to twitter...");
                pDialog.setIndeterminate(false);
                pDialog.setCancelable(false);
                pDialog.show();
            }
        }

        protected Void doInBackground(String... args) {

            String status = args[0];
            try {
                ConfigurationBuilder builder = new ConfigurationBuilder();
                builder.setOAuthConsumerKey(getString(R.string.twitter_consumer_key));
                builder.setOAuthConsumerSecret(getString(R.string.twitter_consumer_key));

                // Access Token
                String access_token = mSharedPreferences.getString(SharedPreferencesKey.TWITTER_AUTH_TOKEN, "");
                // Access Token Secret
                String access_token_secret = mSharedPreferences.getString(SharedPreferencesKey.TWITTER_AUTH_SECRET, "");

                AccessToken accessToken = new AccessToken(access_token, access_token_secret);
                Twitter twitter = new TwitterFactory(builder.build()).getInstance(accessToken);

                // Update status
                StatusUpdate statusUpdate = new StatusUpdate(status);

                twitter4j.Status response = twitter.updateStatus(statusUpdate);

                Log.d("Status", response.getText());

            } catch (TwitterException e) {
                Log.d("Failed to post!", e.getMessage());
            } catch (twitter4j.TwitterException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {

            /* Dismiss the progress dialog after sharing */
            pDialog.dismiss();
            if (getContext() != null) {
                Toast.makeText(getContext(), "Posted to Twitter!", Toast.LENGTH_SHORT).show();
            }
        }

    }

    /**
     *
     */

//	public  void sharebylinkedin() {
////		LISessionManager.getInstance(getActivity()).init(getActivity(), buildScope(), new AuthListener() {
////            public void onAuthSuccess() {
//////                setUpdateState();
////                Toast.makeText(getActivity(), "success" + LISessionManager.getInstance(getActivity()).getSession().getAccessToken().toString(), Toast.LENGTH_LONG).show();
////            }
////            public void onAuthError(LIAuthError error) {
//////                setUpdateState();
//////                ((TextView) findViewById(R.id.at)).setText(error.toString());
////                Toast.makeText(getActivity(), "failed " + error.toString(), Toast.LENGTH_LONG).show();
////            }
////        }, true);
//		
//		String url = "https://api.linkedin.com/v1/people/~/shares";
//
//		JSONObject body=null;
//		try {
//			body = new JSONObject("{" +
//			    "\"comment\": \"Sample share\"," +
//			    "\"visibility\": { \"code\": \"anyone\" }," +
//			    "\"content\": { " +
//			        "\"title\": \"Sample share\"," +
//			        "\"description\": \"Testing the mobile SDK call wrapper!\"," +
//			        "\"submitted-url\": \"http://www.example.com/\"," +
//			        "\"submitted-image-url\": \"http://www.example.com/pic.jpg\"" +
//			    "}" +
//			"}");
//		} catch (JSONException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		               
//		APIHelper apiHelper = APIHelper.getInstance(getActivity()); 
//		apiHelper.postRequest(getActivity(), url, body, new ApiListener() {
//		    @Override
//		    public void onApiSuccess(ApiResponse apiResponse) {
//		        // Success!
//		    	Toast.makeText(getActivity(), apiResponse.getStatusCode(), Toast.LENGTH_LONG).show();
//		    }
//
//		    @Override
//		    public void onApiError(LIApiError liApiError) {
//		        // Error making POST request!
//		    	Toast.makeText(getActivity(), "Error", Toast.LENGTH_LONG).show();
//		    }
//
//			
//		});
//	}

//	 private void setUpdateState() {
//	        LISessionManager sessionManager = LISessionManager.getInstance(getApplicationContext());
//	        LISession session = sessionManager.getSession();
//	        boolean accessTokenValid = session.isValid();
//
//	        ((TextView) findViewById(R.id.at)).setText(
//	                accessTokenValid ? session.getAccessToken().toString() : "Sync with LinkedIn to enable these buttons");
//	        ((Button) findViewById(R.id.apiCall)).setEnabled(accessTokenValid);
//	        ((Button) findViewById(R.id.deeplink)).setEnabled(accessTokenValid);
//	    }

//	    private static Scope buildScope() {
//	        return Scope.build(Scope.R_BASICPROFILE, Scope.W_SHARE);
//	    }
    public void sharebylinkedin() {
        // TODO Auto-generated method stub

        ProgressDialog progressDialog = new ProgressDialog(getActivity());

        final LinkedinDialog d = new LinkedinDialog(getActivity(),
                progressDialog);
        d.show();

        // set call back listener to get oauth_verifier value
        d.setVerifierListener(new com.businessstandard.linkedin.LinkedinDialog.OnVerifyListener() {
            @Override
            public void onVerify(String verifier) {
                try {
                    Log.i("LinkedinSample", "verifier: " + verifier);

                    accessToken = LinkedinDialog.oAuthService.getOAuthAccessToken(LinkedinDialog.liToken, verifier);
                    LinkedinDialog.factory.createLinkedInApiClient(accessToken);
                    client = factory.createLinkedInApiClient(accessToken);
                    client = factory.createLinkedInApiClient(accessToken);
                    // client.postNetworkUpdate("LinkedIn Android app test");
                    // Person profile = client.getProfileForCurrentUser();
//					com.google.code.linkedinapi.schema.Person profile = null;
//					try {
//						profile = client.getProfileForCurrentUser(EnumSet.of(
//								ProfileField.ID, ProfileField.FIRST_NAME,
//								ProfileField.EMAIL_ADDRESS,
//								ProfileField.LAST_NAME, ProfileField.HEADLINE,
//								ProfileField.INDUSTRY,
//								ProfileField.PICTURE_URL,
//								ProfileField.DATE_OF_BIRTH,
//								ProfileField.LOCATION_NAME,
//								ProfileField.MAIN_ADDRESS,
//								ProfileField.LOCATION_COUNTRY));
//						Log.e("create access token secret", client
//								.getAccessToken().getTokenSecret());
//					} catch (NullPointerException e) {
//						// TODO: handle exception
//					}
                    Log.i("LinkedinSample", "ln_access_token: " + accessToken.getToken());
                    Log.i("LinkedinSample", "ln_access_token: " + accessToken.getTokenSecret());
                    Person p = client.getProfileForCurrentUser();
                    System.out.println("Welcome " + p.getFirstName() + " " + p.getLastName());
                    SharedPreferences.Editor edit = preferences.edit();
                    edit.putString("AccessToken", accessToken.getToken());
                    edit.putString("TokenSecret", accessToken.getTokenSecret());
                    edit.commit();
                    linkedinlogin_status = true;
                    //sharelinkedindata();
//					d.dismiss();
                } catch (Exception e) {
                    Log.i("LinkedinSample", "error to get verifier");
                    e.printStackTrace();
                }
            }


        });

        // set progress dialog
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(true);
        progressDialog.show();
    }

    /**
     *
     */
    private void shareByTwitter() {
        if (getActivity() != null) {
            TwitterHelper.instantiateTwitter(getActivity());
        }
        if (TwitterHelper.checkLoginStatus()) {

            TwitterHelper.sendTweet(Html.fromHtml(newsItem.title) + " " + newsItem.short_url);
        } else {
            TwitterHelper.twitterSignInAndPost(Html.fromHtml(newsItem.title) + " " + newsItem.short_url);

        }

    }

    /**
     *
     */
    private void sharebyFb() {
        if (facebookHelper.isLoggedIn()) {
            perfomPublish();
        } else {
            pendingAction = PendingAction.POST_STATUS_UPDATE;
            facebookHelper.login(getActivity());
        }
    }

    private void shareByEmail() {
        Intent intent = new Intent(android.content.Intent.ACTION_SEND);
        intent.setType("message/rfc822");
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
        if (newsItem != null && newsItem.newsUrl != null && newsItem.title != null) {
            intent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{""});
            intent.putExtra(android.content.Intent.EXTRA_SUBJECT, newsItem.title);
            intent.putExtra(android.content.Intent.EXTRA_TEXT, newsItem.title + Utility.NEWLINE_CHARACTER + newsItem.briefDescription + Utility.NEWLINE_CHARACTER
                    + newsItem.short_url + Utility.NEWLINE_CHARACTER);
            startActivity(Intent.createChooser(intent, getString(R.string.how_share)));
        } else {
            Utility.showToast(getString(R.string.something_went_wrong), getActivity());
        }
        dismiss();
    }

    private class SessionStatusCallback implements Session.StatusCallback {
        @Override
        public void call(Session session, SessionState state, Exception exception) {
            Log.i("", "SessionStatusCallback:: Sesssion Updated:" + exception);
            Log.i("", " Active permission:" + session.getPermissions());
            if (pendingAction != PendingAction.NONE
                    && (exception instanceof FacebookOperationCanceledException || exception instanceof FacebookAuthorizationException)) {
                new AlertDialog.Builder(getActivity()).setTitle(R.string.cancelled)
                        .setMessage(R.string.permission_not_granted).setPositiveButton(R.string.ok, null).show();
                pendingAction = PendingAction.NONE;
            }

            if (facebookHelper.isLoggedIn())
                handlePendingAction();

        }

        private void handlePendingAction() {
            switch (pendingAction) {
                case POST_STATUS_UPDATE:
                    perfomPublish();

            }

        }

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Session session = Session.getActiveSession();
        Session.saveSession(session, outState);
        outState.putString(PENDING_ACTION_BUNDLE_KEY, pendingAction.name());
    }

    /**
     *
     */
    public void perfomPublish() {
        Log.i("", "Post Request");
        pendingAction = PendingAction.POST_STATUS_UPDATE;
        facebookHelper.publishFeed(getActivity(), newsItem, new FeedPostListener() {
            @Override
            public void onCompletePost(String postId) {
                pendingAction = PendingAction.NONE;
                Log.i("", "Posting Done");
                if (getActivity() != null)
                    Utility.showToast(getString(R.string.fb_post_success), getActivity());
                dismiss();
            }

            @Override
            public void onFailedPost(Exception exception) {
                pendingAction = PendingAction.NONE;
                Log.i("", "Posting Failed");
                dismiss();
            }

        });

    }

    @Override
    public void onStart() {
        super.onStart();
        Session.getActiveSession().addCallback(statusCallback);
//		mGoogleApiClient.connect();
    }

    @Override
    public void onStop() {
        super.onStop();
        Session.getActiveSession().removeCallback(statusCallback);
//		if (mGoogleApiClient.isConnected()) {
//			mGoogleApiClient.disconnect();
//		}
    }
//	private void signInWithGplus() {
//		if (!mGoogleApiClient.isConnecting()) {
//			mSignInClicked = true;
//			resolveSignInError();
//		}
//	}
//
//	private void resolveSignInError() {
//		if (mConnectionResult.hasResolution()) {
//			try {
//				mIntentInProgress = true;
//				mConnectionResult.startResolutionForResult(getActivity(), RC_SIGN_IN);
//			} catch (SendIntentException e) {
//				mIntentInProgress = false;
//				mGoogleApiClient.connect();
//			}
//		}
//	
//}

    /* (non-Javadoc)
     * @see com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks#onConnected(android.os.Bundle)
     */
//	@Override
//	public void onConnected(Bundle connectionHint) {
//		// TODO Auto-generated method stub
//		mSignInClicked = false;
//		Toast.makeText(getActivity(), "User is connected!", Toast.LENGTH_LONG).show();
//
//		// Get user's information
////		getProfileInformation();
//
//		// Update the UI after signin
//		updateUI(true);	
//	}

    /* (non-Javadoc)
     * @see com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks#onConnectionSuspended(int)
     */
//	@Override
//	public void onConnectionSuspended(int cause) {
//		// TODO Auto-generated method stub
//		mGoogleApiClient.connect();
//		updateUI(false);
//	}
//	private void updateUI(boolean isSignedIn) {
//		if (isSignedIn) {
//			// btnSignIn.setVisibility(View.GONE);
//			// btnSignOut.setVisibility(View.VISIBLE);
//			// btnRevokeAccess.setVisibility(View.VISIBLE);
//			// llProfileLayout.setVisibility(View.VISIBLE);
//		} else {
//			// btnSignIn.setVisibility(View.VISIBLE);
//			// btnSignOut.setVisibility(View.GONE);
//			// btnRevokeAccess.setVisibility(View.GONE);
    // llProfileLayout.setVisibility(View.GONE);
//		}
//	}
}
