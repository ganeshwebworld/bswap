package com.businessstandard.deeplinking;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.businessstandard.common.ui.BaseActivity;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.ui.ArticleWebView;

public class ArticleDeepLinkActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getIntent() != null) {
            String action = getIntent().getAction();
            String scheme = getIntent().getScheme();
            Uri data = getIntent().getData();

            if (Intent.ACTION_VIEW.equals(action) && scheme != null && data != null) {
                String finalDataUrl = data.toString();
                String parts[] = finalDataUrl.split("_");
                String result = parts[parts.length - 2];
                result = extractArticleIDFromResult(result);

                if (Utility.isInternetOn(this)) {
                    Intent intent = new Intent(this, ArticleWebView.class);
                    intent.putExtra("ArticleId", result);
                    startActivity(intent);
                    finish();
                } else {
                    Utility.showToast("Please check your internet connection", this);
                    finish();
                }
            }
        }
    }

    private String extractArticleIDFromResult(String result) {
        if (result.length() == 12) {
            return result;
        } else if (result.length() > 12) {
            return result.substring(result.length() - 12);
        } else {
            throw new IllegalArgumentException("result has less than 12 characters!");
        }
    }
}
