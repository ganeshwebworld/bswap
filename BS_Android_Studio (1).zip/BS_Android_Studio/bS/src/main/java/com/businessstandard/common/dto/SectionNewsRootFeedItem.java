/**
   Project      : Economist
   Filename     : SectionNewsRootFeedItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.common.dto;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

/**
 * @author lenesha
 *
 */
public class SectionNewsRootFeedItem {

	public SectionNewsFeedObject root;
	
	@SerializedName("settings")
	private ArrayList<SectionMainItem> mSettings;

	public ArrayList<SectionMainItem> getSettings() {
		return mSettings;
	}
}