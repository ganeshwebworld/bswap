/**
   Project      : Economist
   Filename     : TodaysPaperManager.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.todayspaper;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;

import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.util.Log;

import com.businessstandard.R;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.manager.BaseManager;
import com.businessstandard.common.util.Constants.FeedUrl;
import com.businessstandard.common.util.Utility;
import com.businessstandard.todayspaper.dto.TodaysPaperNewsRootItem;
import com.businessstandard.todayspaper.io.TodaysPaperConnectionManager;
import com.businessstandard.todayspaper.ui.TodaysPaperFragment;

/**
 * @author lenesha
 *
 */
public class TodaysPaperManager extends BaseManager {

	private static TodaysPaperManager sManager;
	private TodaysPaperConnectionManager mConnectionManager;
	private WeakReference<FragmentActivity> mActivity;
	public ArrayList<SubNewsItem> newsItemList;
	
	public ArrayList<SubNewsItem> newsItemListnew;
	ArrayList<String> feed;
	public static int counter;

	public TodaysPaperManager(FragmentActivity activity) {
		super(activity);
		mConnectionManager = new TodaysPaperConnectionManager(
				activity.getApplicationContext());
		mActivity = new WeakReference<FragmentActivity>(activity);
		ArrayList<String> feed=new ArrayList<String>();
		
		
		
	}

	public static void setManager(TodaysPaperManager managr) {
		sManager = managr;
	}

	public static TodaysPaperManager getManager() {
		return sManager;
	}

	public void DonwloadCategories(
			TodaysPaperCatgryDownldListner catgyDloadCmpltListener,
			String feedUrl) {

		CategorynDownloaderAsyncTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new CategorynDownloaderAsyncTask(catgyDloadCmpltListener);
			task.execute(feedUrl);
		} else {
			Utility.displayAlert(mActivity.get(), mActivity.get()
					.getString(R.string.app_name), mActivity.get()
					.getString(R.string.no_connection), android.R.string.ok,
					Utility.getOkButtonListener(mActivity.get()));
		}

	}

	public class CategorynDownloaderAsyncTask extends
			AsyncTask<String, String, TodaysPaperNewsRootItem> {
		TodaysPaperCatgryDownldListner catgyDloadCmpltListener;

		public CategorynDownloaderAsyncTask(
				TodaysPaperCatgryDownldListner catgyDloadCmpltListener) {
			this.catgyDloadCmpltListener = catgyDloadCmpltListener;
		}

		@Override
		protected TodaysPaperNewsRootItem doInBackground(String... params) {
			String url = params[0];
			
			TodaysPaperNewsRootItem sectionNewsItem = mConnectionManager
					.getCatgryFeeds(url);
			return sectionNewsItem;
		}

		@Override
		protected void onPostExecute(TodaysPaperNewsRootItem result) {
			super.onPostExecute(result);
			if (result != null)
				catgyDloadCmpltListener.onSubNewsDloadComplete(result);
			else {
				catgyDloadCmpltListener.onFailure();
			}
		}
	}

	public void downloadNewsFeedData(
			SubNewsDloadCmpltListener subNewsDloadCmpltListener, String feedUrl) {
		NewsFeedDownloaderTask task;
//		feed=feedUrl;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new NewsFeedDownloaderTask(subNewsDloadCmpltListener);
			task.execute(feedUrl);
		} 
	}

	public class NewsFeedDownloaderTask extends
			AsyncTask<String, String, ArrayList<SubNewsItem>> {
		SubNewsDloadCmpltListener subNewsDloadCmpltListener;

		public NewsFeedDownloaderTask(
				SubNewsDloadCmpltListener subNewsDloadCmpltListener) {
			this.subNewsDloadCmpltListener = subNewsDloadCmpltListener;
		}

		@Override
		protected ArrayList<SubNewsItem> doInBackground(String... params) {
//			HashMap<String, ArrayList<SubNewsItem>> map = new HashMap<String, ArrayList<SubNewsItem>>();
//			ArrayList<SubNewsItem> newsItemListnew=new ArrayList<SubNewsItem>();
//			for(int i=0;i<=feed.size()-1;i++){
//			String url = params[0];
//			String sectionNewsItem = mConnectionManager.getSubNewsFeeds(url);
//
//			if (sectionNewsItem != null){
//				counter=i;
//				newsItemList = mConnectionManager
//						.getListOfnewsItem(sectionNewsItem);
//				
//				
//				newsItemListnew.addAll(newsItemList);
//				map.put(TodaysPaperFragment.mSubCategoryList.get(i), newsItemList);
//			
//			}
//			newsItemListnew.addAll(i, newsItemList);
//			}
		
			String url = params[0];
			String sectionNewsItem = mConnectionManager.getSubNewsFeeds(url);
			if (sectionNewsItem != null)
				newsItemList = mConnectionManager
						.getListOfnewsItem(sectionNewsItem);
			return newsItemList;
		
		}

		@Override
		protected void onPostExecute(ArrayList<SubNewsItem> result) {
			super.onPostExecute(result);
			Log.i("", "" + result);

			if (result != null)
				subNewsDloadCmpltListener.onSubNewsDloadComplete(result);
			else {
				subNewsDloadCmpltListener.onFailure();
			}
		}
	}

}
