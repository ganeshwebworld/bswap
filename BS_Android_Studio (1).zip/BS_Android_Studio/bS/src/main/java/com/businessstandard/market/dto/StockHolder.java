/**
   Project      : Economist
   Filename     : StockHolder.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.market.dto;

/**
 * @author lenesha
 *
 */
public class StockHolder {

}
