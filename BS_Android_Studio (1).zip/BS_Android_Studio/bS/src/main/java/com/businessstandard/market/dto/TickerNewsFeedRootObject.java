/**
   Project      : Economist
   Filename     : TickerNewsFeedRootObject.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.market.dto;

import com.google.gson.annotations.SerializedName;

/**
 * @author lenesha
 *
 */
public class TickerNewsFeedRootObject {

	@SerializedName("")
	public TickerNewsItemFeed root;

}
