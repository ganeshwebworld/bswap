/**
   Project      : Economist
   Filename     : FacebookHelper.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */

package com.businessstandard.common.util;

/**
 * @author lenesha
 *
 */
import java.util.Arrays;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.Html;
import android.util.Log;
import android.widget.Toast;

import com.businessstandard.common.dto.SubNewsItem;
import com.facebook.FacebookException;
import com.facebook.LoggingBehavior;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.Settings;
import com.facebook.model.GraphUser;
import com.facebook.widget.WebDialog;
import com.facebook.widget.WebDialog.OnCompleteListener;
public class FacebookHelper {

	private String TAG = FacebookHelper.class.getSimpleName();
	private Session.StatusCallback mStatusCallback;
	private static FacebookHelper instance;
	private static final List<String> PERMISSIONS = Arrays
			.asList("publish_actions,email");

	public interface FBkey {
		String NAME = "name";
		String LINK = "link";
		String CAPTION = "caption";
		String PICTURE = "picture";
		String DESCRIPTION = "description";
	}

	public interface UserInfoRecivedListener {
		public void onRecivedUserInfo(GraphUser user, Response response);
	}

	public interface FeedPostListener {
		public void onCompletePost(String postId);

		public void onFailedPost(Exception exception);
	}

	private FacebookHelper() {

	}

	public static FacebookHelper getInstance() {
		if (instance == null) {
			instance = new FacebookHelper();
		}
		return instance;
	}

	private void setStatusCallback(Session.StatusCallback statusCallback) {
		if (statusCallback != null) {
			mStatusCallback = statusCallback;

		}
	}

	public void initFBHelper(Activity activity, Bundle savedInstanceState,
			Session.StatusCallback statusCallback) {
		Settings.addLoggingBehavior(LoggingBehavior.INCLUDE_ACCESS_TOKENS);
		setStatusCallback(statusCallback);
		Session session = Session.getActiveSession();
		if (session == null) {
			if (savedInstanceState != null) {
				session = Session.restoreSession(activity, null,
						mStatusCallback, savedInstanceState);
			}
			if (session == null) {
				session = new Session(activity);
			}
			Session.setActiveSession(session);
			if (session.getState().equals(SessionState.CREATED_TOKEN_LOADED)) {
				session.openForRead(new Session.OpenRequest(activity)
				.setCallback(mStatusCallback));
			}
		}

	}

	public void login(Activity context) {
		Session session = Session.getActiveSession();
		if (!session.isOpened() && !session.isClosed()) {
			session.openForRead(new Session.OpenRequest(context).setCallback(mStatusCallback).setPermissions(Arrays.asList("email")));
		} else {
			Session.openActiveSession(context, true, mStatusCallback);
		}

	}

	public void logout() {
		Session session = Session.getActiveSession();
		if (!session.isClosed()) {
			session.closeAndClearTokenInformation();
		}
	}

	public void fetchUserInfo(final UserInfoRecivedListener infoListener,final Activity fragment) {
		final Session session = Session.getActiveSession();
		if (session != null && session.isOpened()) {
			
			Request request = Request.newMeRequest(session,
					new Request.GraphUserCallback() {
				@Override
				public void onCompleted(GraphUser me, Response response) {
					if (response.getRequest().getSession() == session) {
						infoListener.onRecivedUserInfo(me,response);
						
					}
				}
			});
			request.executeAsync();
		}
	}

	public void publishFeed(final Activity context,
			FeedPostListener actionListener) {
		Session session = Session.getActiveSession();
		if (session != null) {
			if (hasPublishPermission()) {
				// We can do the action right away.
				performPublish(context, actionListener);
			} else {
				// We need to get new permissions, then complete the action when
				// we get called back.
				try {
					Log.i(TAG, "Requesting Permission");
					session.requestNewPublishPermissions(new Session.NewPermissionsRequest(
							context, PERMISSIONS));
				} catch (UnsupportedOperationException e) {
					e.printStackTrace();
					actionListener.onFailedPost(e);
					Log.i(TAG, "Requesting Permission Failed");
				}
			}
		}

	}

	private void performPublish(final Activity context,
			final FeedPostListener actionListener) {

		// ToDo: Test case post value need to be changed
		Bundle params = new Bundle();
		params.putString(FBkey.NAME, "Facebook SDK for Android");
		params.putString(FBkey.CAPTION,
				"Build great social apps and get more installs.");
		params.putString(
				FBkey.DESCRIPTION,
				"The Facebook SDK for Android makes it easier and faster to develop Facebook integrated Android apps.");
		params.putString(FBkey.LINK, "https://developers.facebook.com/android");
		params.putString(FBkey.PICTURE,
				"https://raw.github.com/fbsamples/ios-3.x-howtos/master/Images/iossdk_logo.png");

		WebDialog feedDialog = (new WebDialog.FeedDialogBuilder(context,
				Session.getActiveSession(), params)).setOnCompleteListener(
						new OnCompleteListener() {
							@Override
							public void onComplete(Bundle values,
									FacebookException error) {
								// When the story is posted, echo the success
								// and the post Id.
								if (error == null) {
									final String postId = values.getString("post_id");
									if (postId != null) {
//										Toast.makeText(context,
//												"Posted story, id: " + postId,
//												Toast.LENGTH_SHORT).show();
										actionListener.onCompletePost(postId);
									}
								} else {
									actionListener.onFailedPost(error);
								}

							}

						}).build();
		feedDialog.show();
	}

	public boolean isLoggedIn() {
		Session session = Session.getActiveSession();
		if (session != null && session.isOpened()) {
			return true;
		}
		return false;
	}

	private boolean hasPublishPermission() {
		Session session = Session.getActiveSession();
		return session != null;
	}

	/**
	 * @param activity
	 * @param newsItem
	 * @param feedPostListener
	 */
	public void publishFeed(FragmentActivity activity, SubNewsItem newsItem,
			FeedPostListener feedPostListener) {
		Session session = Session.getActiveSession();
		if (session != null) {
			if (hasPublishPermission()) {
				// We can do the action right away.
				performPublish(activity, feedPostListener,newsItem);
			} else {
				// We need to get new permissions, then complete the action when
				// we get called back.
				try {
					Log.i(TAG, "Requesting Permission");
					session.requestNewPublishPermissions(new Session.NewPermissionsRequest(
							activity, PERMISSIONS));
				} catch (UnsupportedOperationException e) {
					e.printStackTrace();
					feedPostListener.onFailedPost(e);
					Log.i(TAG, "Requesting Permission Failed");
				}
			}
		}

	}

	/**
	 * @param activity
	 * @param feedPostListener
	 * @param newsItem
	 */
	private void performPublish(final FragmentActivity activity,
			final FeedPostListener feedPostListener, SubNewsItem newsItem) {
		Bundle params = new Bundle();
//		String URl="http://"+newsItem.newsUrl;
		params.putString(FBkey.NAME,newsItem.title );
//		params.putString(FBkey.CAPTION,newsItem.newsUrl);
		params.putString(
				FBkey.DESCRIPTION,
				newsItem.briefDescription);
		params.putString(FBkey.LINK, newsItem.short_url);
		params.putString(FBkey.PICTURE,newsItem.imageUrl);
		
		WebDialog feedDialog = (new WebDialog.FeedDialogBuilder(activity,
				Session.getActiveSession(), params)).setOnCompleteListener(
						new OnCompleteListener() {
							@Override
							public void onComplete(Bundle values,
									FacebookException error) {
								// When the story is posted, echo the success
								// and the post Id.
								if (error == null) {
									final String postId = values.getString("post_id");
//									if (postId != null) {

										feedPostListener.onCompletePost(postId);
//									}
								} else {
									feedPostListener.onFailedPost(error);
								}

							}

						}).build();
		feedDialog.show();
	}
	
}