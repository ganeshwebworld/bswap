/**
 * Project      : Economist
 * Filename     : HomeManager.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.home;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.util.Log;

import com.businessstandard.R;
import com.businessstandard.common.dto.CommentItem;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.io.ParserManager;
import com.businessstandard.common.manager.BaseManager;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.io.HomeConnectionManager;
import com.businessstandard.market.dto.CompanyStockNewsFeed;
import com.businessstandard.market.dto.TickerNewsFeedRootObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * @author lenesha
 */
public class HomeManager extends BaseManager {

    public static HomeManager sManager;
    private HomeConnectionManager mConnectionManager;
    private WeakReference<FragmentActivity> mActivity;
    public ArrayList<SubNewsItem> newsItemList;
    public ParserManager mParserManager;
    public static SectionNewsRootFeedItem feedObjct;
    public static String sSearchUrl;
    public static String sStock_graph;
    public static SectionNewsRootFeedItem sectionNewsItemnew = null;
    private Context mContext;

    public HomeManager(FragmentActivity activity) {
        super(activity);
        mConnectionManager = new HomeConnectionManager(activity.getApplicationContext());
        mActivity = new WeakReference<FragmentActivity>(activity);
        mContext = activity;
        mParserManager = new ParserManager();
    }

    public void downloadData(CatgyDloadCmpltListener catgyDloadCmpltListener) {

        SectionNewsCollectorAsyncTask task;

        if (Utility.isInternetOn(mActivity.get())) {
            Utility.displayProgressDailog(mActivity.get(), R.string.loading);
            task = new SectionNewsCollectorAsyncTask(catgyDloadCmpltListener);
            task.execute();
        } else {
            Utility.displayAlert(mActivity.get(), mActivity.get()
                    .getString(R.string.app_name), mActivity.get()
                    .getString(R.string.no_connection), android.R.string.ok, Utility.getOkButtonListener(mActivity.get()));
        }

    }

    public class SectionNewsCollectorAsyncTask extends AsyncTask<Void, Void, SectionNewsRootFeedItem> {

        CatgyDloadCmpltListener catgyDloadCmpltListener;

        public SectionNewsCollectorAsyncTask(CatgyDloadCmpltListener catgyDloadCmpltListener) {
            this.catgyDloadCmpltListener = catgyDloadCmpltListener;
        }

        @Override
        protected SectionNewsRootFeedItem doInBackground(Void... params) {
            SectionNewsRootFeedItem sectionNewsItem = null;
            if (sectionNewsItemnew == null) {
                sectionNewsItem = mConnectionManager.getSectionNewsCategories(mContext);
                return sectionNewsItem;
            } else {
                sectionNewsItem = sectionNewsItemnew;
                return sectionNewsItem;
            }
        }

        @Override
        protected void onPostExecute(SectionNewsRootFeedItem result) {
            super.onPostExecute(result);
            if (catgyDloadCmpltListener != null) {
                if (result != null && result.root != null) {
                    if (!TextUtils.isEmpty(result.root.getmStockSearch().feedUrl)) {
                        sSearchUrl = result.root.getmStockSearch().feedUrl;
                    }
                    if (!TextUtils.isEmpty(result.root.getmStockGraph().feedUrl)) {
                        sStock_graph = result.root.getmStockGraph().feedUrl;
                    }
                    feedObjct = result;
                    catgyDloadCmpltListener.onFeedsDloadComplete(result);
                    sectionNewsItemnew = result;
                } else {
                    catgyDloadCmpltListener.onFailure();
                }
            }

        }
    }

    public void downloadNewsFeedData(boolean isShowProgress, SubNewsDloadCmpltListener subNewsDloadCmpltListener, String feedUrl) {
        NewsFeedDownloaderTask task;
        if (Utility.isInternetOn(mActivity.get())) {
            if (isShowProgress) {
                Utility.displayProgressDailog(mActivity.get(), R.string.loading);
            }
            task = new NewsFeedDownloaderTask(subNewsDloadCmpltListener);
            task.execute(feedUrl);
        } else {
            Utility.hideProgressDialog();
            Utility.displayAlert(mActivity.get(), mActivity.get()
                    .getString(R.string.app_name), mActivity.get()
                    .getString(R.string.no_connection), android.R.string.ok, Utility.getOkButtonListener(mActivity.get()));
        }
    }

    public class NewsFeedDownloaderTask extends AsyncTask<String, String, ArrayList<SubNewsItem>> {

        SubNewsDloadCmpltListener subNewsDloadCmpltListener;

        public NewsFeedDownloaderTask(SubNewsDloadCmpltListener subNewsDloadCmpltListener) {
            this.subNewsDloadCmpltListener = subNewsDloadCmpltListener;
        }

        @Override
        protected ArrayList<SubNewsItem> doInBackground(String... params) {
            String url = params[0];
            String sectionNewsItem = mConnectionManager.getSubNewsFeeds(url);
            if (sectionNewsItem != null)
                newsItemList = mParserManager.getListOfnewsItem(sectionNewsItem);
            return newsItemList;
        }

        @Override
        protected void onPostExecute(ArrayList<SubNewsItem> result) {
            super.onPostExecute(result);
            Log.i("", "" + result);
            if (result != null)
                subNewsDloadCmpltListener.onSubNewsDloadComplete(result);
            else {
                subNewsDloadCmpltListener.onFailure();
            }
        }
    }

    public void donwloadTickerValues(TickerDloadCmpltListener tickerdnloadlistener) {
        TickerFeedDownloaderTask task;
        if (Utility.isInternetOn(mActivity.get())) {
            task = new TickerFeedDownloaderTask(tickerdnloadlistener);
            task.execute();
        }
    }

    public class TickerFeedDownloaderTask extends AsyncTask<Void, Void, TickerNewsFeedRootObject> {

        TickerDloadCmpltListener tickerdnloadlistener;

        public TickerFeedDownloaderTask(TickerDloadCmpltListener tickerdnloadlistener) {
            this.tickerdnloadlistener = tickerdnloadlistener;
        }

        @Override
        protected TickerNewsFeedRootObject doInBackground(Void... params) {
            TickerNewsFeedRootObject tickerFeed = mConnectionManager.getTickerFeeds();
            return tickerFeed;
        }

        @Override
        protected void onPostExecute(TickerNewsFeedRootObject result) {
            super.onPostExecute(result);
            if (tickerdnloadlistener != null) {
                if (result != null && result.root != null)
                    tickerdnloadlistener.onTickerDloadCmplt(result);
                else
                    tickerdnloadlistener.onFailure();
            }
        }
    }

    public interface CompanySearchDloadCmpltListener extends CallbackListener {
        void OnCompanySearchDloadCmplt(CompanyStockNewsFeed[] result);
    }

    /**
     * @param companySearchDloadCmpltListener
     * @param url
     */
    public void downloadCompanyData(CompanySearchDloadCmpltListener companySearchDloadCmpltListener, String url) {

        StockFeedDownloaderTask task;
        if (Utility.isInternetOn(mActivity.get())) {
            Utility.displayProgressDailog(mActivity.get(), R.string.loading);
            task = new StockFeedDownloaderTask(companySearchDloadCmpltListener);
            task.execute(url);
        } else {
            Utility.displayAlert(mActivity.get(), mActivity.get()
                            .getString(R.string.app_name), mActivity.get()
                            .getString(R.string.no_connection), android.R.string.ok,
                    Utility.getOkButtonListener(mActivity.get()));
        }
    }

    public class StockFeedDownloaderTask extends AsyncTask<String, String, CompanyStockNewsFeed[]> {

        CompanySearchDloadCmpltListener companySearchDloadCmpltListener;

        /**
         * @param companySearchDloadCmpltListener
         */
        public StockFeedDownloaderTask(CompanySearchDloadCmpltListener companySearchDloadCmpltListener) {
            this.companySearchDloadCmpltListener = companySearchDloadCmpltListener;
        }

        /* (non-Javadoc)
         * @see android.os.AsyncTask#doInBackground(Params[])
         */
        @Override
        protected CompanyStockNewsFeed[] doInBackground(String... params) {
            String url = params[0];
            CompanyStockNewsFeed[] newsFeed = mConnectionManager.getStockFeeds(url);
            return newsFeed;
        }

        @Override
        protected void onPostExecute(CompanyStockNewsFeed[] result) {
            super.onPostExecute(result);
            if (companySearchDloadCmpltListener != null) {
                if (result != null && result.length > 0)
                    companySearchDloadCmpltListener.OnCompanySearchDloadCmplt(result);
                else
                    companySearchDloadCmpltListener.onFailure();
            }
        }
    }

    public void downloadCommentsData(CommentsDloadCmpltListener commentsDloadLIstner, String url) {
        CommentsDownloaderTask task;
        if (Utility.isInternetOn(mActivity.get())) {
            Utility.displayProgressDailog(mActivity.get(), R.string.loading);
            task = new CommentsDownloaderTask(commentsDloadLIstner);
            task.execute(url);
        } else {
            Utility.displayAlert(mActivity.get(), mActivity.get()
                    .getString(R.string.app_name), mActivity.get()
                    .getString(R.string.no_connection), android.R.string.ok, Utility.getOkButtonListener(mActivity.get()));
        }
    }

    public class CommentsDownloaderTask extends AsyncTask<String, String, List<CommentItem>> {

        CommentsDloadCmpltListener commentsDloadLIstner;

        /**
         * @param commentsDloadLIstner
         */
        public CommentsDownloaderTask(
                CommentsDloadCmpltListener commentsDloadLIstner) {
            this.commentsDloadLIstner = commentsDloadLIstner;
        }

        /* (non-Javadoc)
         * @see android.os.AsyncTask#doInBackground(Params[])
         */
        @Override
        protected List<CommentItem> doInBackground(String... params) {
            String url = params[0];
            String sectionNewsItem = mConnectionManager.getCommentFeeds(url);

            List<CommentItem> commentsItemList = null;
            if (sectionNewsItem != null)
                commentsItemList = mParserManager.parseCommentFeeds(sectionNewsItem);
            return commentsItemList;
        }

        /* (non-Javadoc)
         * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
         */
        @Override
        protected void onPostExecute(List<CommentItem> result) {
            super.onPostExecute(result);
            if (commentsDloadLIstner != null) {
                if (result != null && !(result.isEmpty()))
                    commentsDloadLIstner.CommentsDloadCmplistner(result);
                else
                    commentsDloadLIstner.onFailure();
            }
        }
    }

    public interface CommentsDloadCmpltListener extends CallbackListener {
        void CommentsDloadCmplistner(List<CommentItem> result);
    }

    public interface CommentsPostingCmpltListener extends CallbackListener {
        void commentsPostingCmplistner();
    }

    /**
     * @param mNewsItemPos
     * @param username
     * @param id
     * @param comment
     * @param postCommenturl
     * @param commentsPostingCmpltListener
     */
    public void postCommentForNews(String mNewsItemPos, String username,
                                   String id, String comment,
                                   String postCommenturl, CommentsPostingCmpltListener commentsPostingCmpltListener) {
        CommentsPostingTask task;
        if (Utility.isInternetOn(mActivity.get())) {
            task = new CommentsPostingTask(commentsPostingCmpltListener, mNewsItemPos, username, id, comment, postCommenturl);
            task.execute();
        } else {
            Utility.displayAlert(mActivity.get(), mActivity.get()
                            .getString(R.string.app_name), mActivity.get()
                            .getString(R.string.no_connection), android.R.string.ok,
                    Utility.getOkButtonListener(mActivity.get()));
        }
    }

    public class CommentsPostingTask extends AsyncTask<String, String, String> {

        CommentsPostingCmpltListener commentsPostingCmpltListener;
        String mNewsItemPos;
        String username;
        String id;
        String comment;
        String postCommenturl;

        /**
         * @param commentsPostingCmpltListener
         * @param comment
         * @param id
         * @param username
         * @param mNewsItemPos
         * @param postCommenturl
         */
        public CommentsPostingTask(CommentsPostingCmpltListener commentsPostingCmpltListener,
                                   String mNewsItemPos, String username, String id,
                                   String comment, String postCommenturl) {

            this.commentsPostingCmpltListener = commentsPostingCmpltListener;
            this.username = username;
            this.id = id;
            this.comment = comment;
            this.postCommenturl = postCommenturl;
            this.mNewsItemPos = mNewsItemPos;
        }

        /* (non-Javadoc)
         * @see android.os.AsyncTask#doInBackground(Params[])
         */
        @Override
        protected String doInBackground(String... params) {
            String status = mConnectionManager.postcomments(mNewsItemPos, id, username, comment, postCommenturl);
            return status;
        }

        /* (non-Javadoc)
         * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
         */
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result != null)
                commentsPostingCmpltListener.commentsPostingCmplistner();
            else {
                commentsPostingCmpltListener.onFailure();
            }
        }
    }

}