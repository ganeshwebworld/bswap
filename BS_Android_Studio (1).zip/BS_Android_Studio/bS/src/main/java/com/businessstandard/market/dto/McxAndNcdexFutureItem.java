/**
   Project      : Economist
   Filename     : McxAndNcdexFutureItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.market.dto;

import com.google.gson.annotations.SerializedName;

/**
 * @author lenesha
 *
 */
public class McxAndNcdexFutureItem {
	@SerializedName("Symbol")
	private String mSymbol;
	
	@SerializedName("Expiry Date")
	private String mExpiryDate;
	
	@SerializedName("ltp")
	private String mLtp;
	
	@SerializedName("pq_unit")
	private String mPq_Unit;
	
	@SerializedName("open")
	private String mOpen;
	
	public String getmSymbol() {
		return mSymbol;
	}

	public String getmExpiryDate() {
		return mExpiryDate;
	}

	public String getmLtp() {
		return mLtp;
	}

	public String getmPq_Unit() {
		return mPq_Unit;
	}

	public String getmOpen() {
		return mOpen;
	}

	public String getmHigh() {
		return mHigh;
	}

	public String getmLow() {
		return mLow;
	}

	public String getmPreviousClose() {
		return mPreviousClose;
	}

	public String getmChange() {
		return mChange;
	}

	public String getmChangePercentage() {
		return mChangePercentage;
	}

	@SerializedName("high")
	String mHigh;
	
	@SerializedName("low")
	String mLow;
	
	@SerializedName("previous close")
	String mPreviousClose;
	
	@SerializedName("change")
	String mChange;
	
	@SerializedName("change percentage")
	String mChangePercentage;
	
}