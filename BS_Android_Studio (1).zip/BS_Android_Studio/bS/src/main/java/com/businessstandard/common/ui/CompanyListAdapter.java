/**
   Project      : Economist
   Filename     : NewsListAdapter.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */
package com.businessstandard.common.ui;

import java.util.ArrayList;

import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.market.dto.CompanyStockNewsFeed;

/**
 * @author lenesha
 *
 */
public class CompanyListAdapter extends ArrayAdapter<CompanyStockNewsFeed> {
	private LayoutInflater mInflater;

	public CompanyListAdapter(FragmentActivity mcontext, int newsListitem,
			ArrayList<CompanyStockNewsFeed> itemList) {
		super(mcontext, newsListitem, itemList);
		mInflater = LayoutInflater.from(mcontext);
	}

	public CompanyListAdapter(FragmentActivity mcontext, int newsListitem) {
		super(mcontext, newsListitem);
		mInflater = LayoutInflater.from(mcontext);

	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder holder;
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.company_list_item, null);
			holder = new ViewHolder();

			holder.cmpnyName = (TextView) convertView
					.findViewById(R.id.company_name);
			holder.cmpnyBse = (TextView) convertView
					.findViewById(R.id.compny_bse);
			holder.cmpnyNse = (TextView) convertView
					.findViewById(R.id.compny_nse);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		CompanyStockNewsFeed newsItem = getItem(position);
	
			if(newsItem.bsestock.coName!=null)
				holder.cmpnyName.setText(newsItem.bsestock.coName);
			else if(newsItem.nsestock.coName!=null)
				holder.cmpnyName.setText(newsItem.nsestock.coName);

			if(newsItem.bsestock.price!=null)
				holder.cmpnyBse.setText(newsItem.bsestock.price);
			else
				holder.cmpnyBse.setText(getContext().getResources().getString(R.string.hipen));
		
			if(newsItem.nsestock!=null && newsItem.nsestock.price!=null)
				holder.cmpnyNse.setText(newsItem.nsestock.price);
			else
				holder.cmpnyNse.setText(getContext().getResources().getString(R.string.hipen));

		
		return convertView;
	}

	private class ViewHolder {

		TextView cmpnyName;
		TextView cmpnyBse;
		TextView cmpnyNse;

	}
}
