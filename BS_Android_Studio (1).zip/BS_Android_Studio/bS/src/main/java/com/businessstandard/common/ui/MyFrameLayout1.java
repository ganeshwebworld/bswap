package com.businessstandard.common.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class MyFrameLayout1 extends FrameLayout {

	/**
	 * @param context
	 */
	public MyFrameLayout1(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public MyFrameLayout1(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyFrameLayout1(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

	@Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    	 super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    	 int width = MeasureSpec.getSize(widthMeasureSpec)/2;
    	 int height = 40;
    	 if(width < 360)
    	 {
    		 width = 280;
    		 height = 40;
    	 }
    	 else if(width < 250)
    	 {
    		 width = 200;
    		 height = 40;
    	 }
    	 
    	
    	  //setMeasuredDimension(250,300);
    	 setMeasuredDimension(width, height);
    }
}
