/**
   Project      : Economist
   Filename     : TodaysPaperConnectionManager.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.todayspaper.io;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import android.content.Context;
import android.util.Log;

import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.util.ConnectionUtility;
import com.businessstandard.common.util.Constants;
import com.businessstandard.common.util.RestTemplateContainer;
import com.businessstandard.todayspaper.TodaysPaperManager;
import com.businessstandard.todayspaper.dto.TodaysPaperNewsRootItem;
import com.businessstandard.todayspaper.ui.TodaysPaperFragment;
import com.google.gson.JsonObject;

/**
 * @author lenesha
 *
 */
public class TodaysPaperConnectionManager {
	private WeakReference<Context> mContext;

	public TodaysPaperConnectionManager(Context context) {
		mContext = new WeakReference<Context>(context);
	}
	public TodaysPaperConnectionManager() {
	}

	public TodaysPaperNewsRootItem getCatgryFeeds(String url) {
		MultiValueMap<String, String> param = new LinkedMultiValueMap<String, String>();
		RestTemplateContainer restTemplateContainer = ConnectionUtility
				.createRestTemplate(param);
		ResponseEntity<TodaysPaperNewsRootItem> responseEntity = null;

		try {
			responseEntity = restTemplateContainer.restTemplate.exchange(url,
					HttpMethod.GET, restTemplateContainer.httpEntity,
					TodaysPaperNewsRootItem.class);
			if (responseEntity.getStatusCode() == HttpStatus.OK)
				return responseEntity.getBody();
			else
				return null;
		} catch (Exception e) {
			Log.i("EXCEPTION", e.getMessage());
			return null;
		}
	}

	public String getSubNewsFeeds(String url) {
		MultiValueMap<String, String> param = new LinkedMultiValueMap<String, String>();
		RestTemplateContainer restTemplateContainer = ConnectionUtility
				.createRestTemplate(param);
		ResponseEntity<String> responseEntity = null;

		try {
			responseEntity = restTemplateContainer.restTemplate.exchange(url,
					HttpMethod.GET, restTemplateContainer.httpEntity,
					String.class);
			if (responseEntity.getStatusCode() == HttpStatus.OK)
				return responseEntity.getBody();
			else
				return null;
		} catch (Exception e) {
			Log.i("EXCEPTION", e.getMessage());
			return null;
		}
	}

	public ArrayList<SubNewsItem> getListOfnewsItem(String sectionNewsItem) {
		ArrayList<SubNewsItem> subnewsItemList = new ArrayList<SubNewsItem>();
		int counter=0;

		try {

			JSONObject jsonObject = new JSONObject(sectionNewsItem);

			JSONObject jsonSubObject = jsonObject
					.getJSONObject(Constants.ROOT_TAG);

			if (jsonSubObject.get(Constants.ITEM_TAG) instanceof JSONArray) {

				JSONArray jsonArray = jsonSubObject
						.getJSONArray(Constants.ITEM_TAG);

				for (int i = 0; i < jsonArray.length(); i++) {
					

					JSONObject newsObject = jsonArray.getJSONObject(i);
					if(counter==0){
//					for(int z=i;z==i;z++){
						newsObject.put("key", TodaysPaperFragment.mSubCategoryList.get(TodaysPaperManager.counter));
						counter++;
					}
//					}
					

					SubNewsItem newsItem = new SubNewsItem();

					newsItem.init(newsObject);

					subnewsItemList.add(newsItem);

				}

			}

		} catch (JSONException e) {

			e.printStackTrace();

		}
		return subnewsItemList;
	}
}
