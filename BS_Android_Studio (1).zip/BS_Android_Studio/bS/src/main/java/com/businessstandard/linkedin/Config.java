package com.businessstandard.linkedin;

public class Config {
	public static String LINKEDIN_CONSUMER_KEY = "81f2s39rdgrouh";//"77sq2bm0dzx3k0"; // "75aigvox6h9b62";
	public static String LINKEDIN_CONSUMER_SECRET = "Bv2pO9UjGd7vqED0";// "RlsNlUngEE0iFWxb"; // "QjzZtZBVKovdhdbe";
	public static String scopeParams = "rw_nus+r_basicprofile";

	public static String OAUTH_CALLBACK_SCHEME = "x-oauthflow-linkedin";
	public static String OAUTH_CALLBACK_HOST = "callback";
	public static String OAUTH_CALLBACK_URL = "https://com.businessstandard/auth/callback";//OAUTH_CALLBACK_SCHEME + "://" + OAUTH_CALLBACK_HOST;
}
