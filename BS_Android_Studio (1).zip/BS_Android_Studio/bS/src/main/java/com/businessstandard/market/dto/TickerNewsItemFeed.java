/**
   Project      : Economist
   Filename     : TickerNewsItemFeed.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.market.dto;

/**
 * @author lenesha
 *
 */
public class TickerNewsItemFeed  extends StockHolder {

	public BseNseNewsItem bsestock;
	public BseNseNewsItem nsestock;
	public boolean isNse = true;
}
