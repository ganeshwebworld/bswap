/**
 * Project      : Economist
 * Filename     : MainFragmentActivity.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.common.ui;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.coupon.database.CouponDataBase;
import com.businessstandard.R;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.manager.BaseManager.CatgyDloadCmpltListener;
import com.businessstandard.common.ui.BaseFragment.FragmentListner;
import com.businessstandard.common.util.Constants.BundleKeys;
import com.businessstandard.common.util.Constants.RootFragment;
import com.businessstandard.common.util.CouponUtils;
import com.businessstandard.common.util.FragmentHelper;
import com.businessstandard.common.util.TwitterShare;
import com.businessstandard.common.util.TwitterShare.OnMessagePostedListener;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.HomeManager;
import com.businessstandard.home.ui.ArticleDetailFragment;
import com.businessstandard.settings.ui.CouponDetailsActivity;
import com.businessstandard.settings.ui.FavouritesFragment;
import com.businessstandard.settings.ui.SettingsFragment;
import com.businessstandard.utils.AlertDialogUtility;
import com.businessstandard.utils.DialogButtonListener;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.FormBody;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static com.businessstandard.CommonUtilities.DISPLAY_MESSAGE_ACTION;
//import com.google.android.gcm.GCMRegistrar;

/**
 * @author lenesha
 */
public class MainFragmentActivity extends BaseActivity implements OnMessagePostedListener {

    private HomeManager mManger;
    Context context;
    String devicename = "android";
    String devicemodel;
    String osversion;
    public static String appversion;
    public static String maincat;
    public static String sabcat = "Top Stories";
    public static String feedURL = "";
    public static String DEVICE_TOKEN = "APA91bETMGJsritBkpGDlF9xq-UcW6JyrSmqdZIUcHQn8gIjJoHoQRk12HOdm6S-bDFXoOUEBEpIPrNFqTFrtorEf7TApG2ax4xPWkJxbC10SlRQ7P5QuMlFBpiRacTfCRmPLR3JivzQ";
    public static String api_key = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
    public static String newMessage = null;
    int flag = 0;
    int counter = 0;
    Handler handler;
    private String isopen = "error";
    private List<SubNewsItem> mNewsList, mRelatdNewsList, mFavoritesNewsList;
    public FragmentListner mFragmentListener;
    public static SharedPreferences mPreferences;
    PackageInfo pinfo = null;
    public static ArrayList<CouponUtils> arrayList = new ArrayList<CouponUtils>();
    private CouponDataBase dataBase;
    private String uuid;
    private SaveSharedPref mSharedPreferenceManager;
    private com.businessstandard.model.Constants mConstants = null;

    @SuppressLint("MissingPermission")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mSharedPreferenceManager = SaveSharedPref.getInstance(this);
        if (mSharedPreferenceManager.exists(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA)) {
            if (mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class) != null) {
                mConstants = mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class);
            }
        }
        // if (savedInstanceState != null) {
        // context = this;
        // // Restore the fragment's instance
        // // mContent = getSupportFragmentManager().getFragment(
        // // savedInstanceState, "mContent");
        // //
        // }
        try {
            pinfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (NameNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        appversion = Integer.toString(pinfo.versionCode);
        // // notifiyme signuptasknew1 = new notifiyme(context);
        // // signuptasknew1.execute(api_key, regId, "hello");

		/*		TelephonyManager tManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		uuid = tManager.getDeviceId();*/

        //Secure Id added in place of telephony id
        uuid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        // for push notification
//		GCMRegistrar.checkDevice(this);
//		GCMRegistrar.checkManifest(this);
        registerReceiver(mHandleMessageReceiver, new IntentFilter(DISPLAY_MESSAGE_ACTION));
//		final String regId = GCMRegistrar.getRegistrationId(this);
//		System.out.println("=====regId====="+regId);
//		if (regId.equals("")) {
//			// // Automatically registers application on startup.
//			flag = 1;
//			GCMRegistrar.register(this, SENDER_ID);
//		} else {
//			// Device is already registered on GCM, check server.
//			if (GCMRegistrar.isRegisteredOnServer(this)) {
//				// // Skips registration.
//				// // Toast.makeText(this, "Already register",
//				// Toast.LENGTH_SHORT)
//				// // .show();
//				// // mDisplay.append(getString(R.string.already_registered) +
//				// // "\n");
//			} else {
//				// Try to register again, but not in the UI thread.
//				// It's also necessary to cancel the thread onDestroy(),
//				// hence the use of AsyncTask instead of a raw thread.
//				// final Context context = this;
//				mRegisterTask = new AsyncTask<Void, Void, Void>() {
//					//
//					@Override
//					protected Void doInBackground(Void... params) {
//						boolean registered = ServerUtilities.register(context,
//								regId,uuid);
//						// // At this point all attempts to register with the
//						// app
//						// // server failed, so we need to unregister the device
//						// // from GCM - the app will try to register again when
//						// // it is restarted. Note that GCM will send an
//						// // unregistered callback upon completion, but
//						// // GCMIntentService.onUnregistered() will ignore it.
//						if (!registered) {
//							GCMRegistrar.unregister(context);
//						}
//						return null;
//					}
//
//					//
//					@Override
//					protected void onPostExecute(Void result) {
//						mRegisterTask = null;
//					}
//					//
//				};
//				// mRegisterTask.execute(null, null, null);
//			}

//		}
        if (SaveSharedPref.getInstance(this).getBoolean(SharedPreferencesKey.FRESH_LAUNCH, true)) {
            SaveSharedPref.getInstance(this).saveBoolean(SharedPreferencesKey.FRESH_LAUNCH, false);
            if (Utility.isInternetOn(MainFragmentActivity.this)) {
                AppUpgrade appUpgrade = new AppUpgrade(MainFragmentActivity.this);
                appUpgrade.execute(api_key, "android");
            } else {
                getCouponCode();
            }
        } else {
            LoadUI();
        }
    }

    /**
     *
     */
    private void getCouponCode() {
        mPreferences = getSharedPreferences("isopen", MODE_PRIVATE);
        isopen = mPreferences.getString("success", "error");
        dataBase = new CouponDataBase(MainFragmentActivity.this);
        // if (isopen.equalsIgnoreCase("error")) {

        CouponCode signuptasknew = new CouponCode(MainFragmentActivity.this);
        signuptasknew.execute(api_key, uuid, "android", "send", appversion);
        // }
    }

    /**
     *
     */

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // getSupportFragmentManager().putFragment(outState, "mContent",
        // mContent);
    }

    private void LoadUI() {
        maincat = getIntent().getStringExtra("MainCat");
        sabcat = getIntent().getStringExtra("SabCat");
        feedURL = getIntent().getStringExtra("feedURL");
        if (maincat == null) {
            maincat = "Home";
            sabcat = "Top Stories";
            counter = 1;
        }
        setLayout(R.layout.activity_home_screen);

        mNewsList = new ArrayList<SubNewsItem>();

        mManger = new HomeManager(this);
        String source = getIntent().getStringExtra("Source");
        if (source != null) {
            if (source.equals("from service")) {
                String message = getIntent().getStringExtra(EXTRA_MESSAGE);
                AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

                LinearLayout layout = new LinearLayout(this);
                TextView tvMessage = new TextView(this);

                tvMessage.setText("   " + message);

                layout.setOrientation(LinearLayout.VERTICAL);
                layout.addView(tvMessage);

                builder1.setTitle("Latest News");
                builder1.setView(layout);

                builder1.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });

                // builder1.setTitle("Latests News");
                // builder1.setMessage("I am here!!!!!!!!!!!!");
                // builder1.setCancelable(true);
                // builder1.setPositiveButton("Yes",
                // new DialogInterface.OnClickListener() {
                // public void onClick(DialogInterface dialog, int id) {
                // dialog.cancel();
                // }
                // });

                AlertDialog alert11 = builder1.create();
                alert11.show();
            }
        }
        getFeeds();
        hideTickers();
        osversion = android.os.Build.VERSION.RELEASE; // e.g. myVersion := "1.6"
        int sdkVersion = android.os.Build.VERSION.SDK_INT; // e.g. sdkVersion :=
        // 8;

        String versionName = pinfo.versionName;
        devicemodel = getDeviceName();

//		if (!mPreferences.getString("savedevice", "").equalsIgnoreCase(
//				"Device info saved successfully.")) {
//			AutoLogin signuptasknew = new AutoLogin(MainFragmentActivity.this,GCMRegistrar.getRegistrationId(MainFragmentActivity.this));
//			signuptasknew.execute(api_key, uuid, "Email@example.com",
//					"android", devicename, devicemodel, osversion, appversion);
//		}
    }

    private void getFeeds() {

        if (!Utility.isInternetOn(this)) {
            RadioButton home_btn = (RadioButton) mRadioGroup.findViewById(R.id.home);
            home_btn.setChecked(true);
            return;
        }

        mManger.downloadData(new CatgyDloadCmpltListener() {

            @Override
            public void onFailure() {
                Utility.hideProgressDialog();
                Utility.displayAlert(MainFragmentActivity.this, getResources()
                        .getString(R.string.app_name), getResources()
                        .getString(R.string.no_data), android.R.string.ok, Utility.getOkButtonListener(MainFragmentActivity.this));
            }

            @Override
            public void onFeedsDloadComplete(SectionNewsRootFeedItem result) {
                mRadioGroup.setEnabled(true);
                Utility.setDataToActvty(result);
                mFeedItem = result;
                if (mFeedItem.root != null) {
                    if (maincat.equals("Home")) {
                        if (counter == 1) {
                            RadioButton news_btn = (RadioButton) mRadioGroup.findViewById(R.id.todaysPaper);
                            news_btn.setChecked(true);
                        }
                        RadioButton home_btn = (RadioButton) mRadioGroup.findViewById(R.id.home);
                        home_btn.setChecked(true);
                    } else if (maincat.equals("Market")) {
                        RadioButton market_btn = (RadioButton) mRadioGroup.findViewById(R.id.markets);
                        market_btn.setChecked(true);
                    } else if (maincat.equals("Todays paper")) {
                        RadioButton news_btn = (RadioButton) mRadioGroup.findViewById(R.id.todaysPaper);
                        news_btn.setChecked(true);
                    }
                }
            }
        });
    }

    @Override
    public void onNewsItemClick(SubNewsItem subNewsitemClicked, int position, String selectedCategory, String category) {
        mSelectedCategory = category;
        mCommonAd.setVisibility(View.GONE);
        Fragment visibleFrag = getSupportFragmentManager().findFragmentById(R.id.realTabContent);
        mRadioGroup.setVisibility(View.GONE);
        mDivider.setVisibility(View.GONE);
        mRefreshBtn.setVisibility(View.INVISIBLE);
        Bundle bundle = new Bundle();

        if (visibleFrag instanceof FavouritesFragment) {
            bundle.putBoolean(BundleKeys.IS_FAV_FRAGMENT, true);
            mCategoryScroll.setVisibility(View.GONE);
        } else {
            bundle.putBoolean(BundleKeys.IS_FAV_FRAGMENT, false);
            mCategoryScroll.setVisibility(View.GONE);
        }

        bundle.putInt(BundleKeys.NEWS_ITEM_POSITION, position);
        bundle.putInt(BundleKeys.NEWS_ITEM_POS_TAG, RootFragment.HOME);
        bundle.putString(BundleKeys.SELECTED_CAT_NAME, selectedCategory);
        ArticleDetailFragment fragment = new ArticleDetailFragment();
        fragment.setArguments(bundle);
        FragmentHelper.replaceAndAddContentFragment(this, R.id.realTabContent, fragment);
    }

    @Override
    public void onBackPressed() {
        ArticleDetailFragment articleDetailFragment = null;
        SettingsFragment settingsFragment = null;
        if (getSupportFragmentManager().findFragmentByTag("content_fragment") instanceof ArticleDetailFragment) {
            articleDetailFragment = (ArticleDetailFragment) getSupportFragmentManager().findFragmentByTag("content_fragment");
        }
        if (getSupportFragmentManager().findFragmentByTag("settings_fragment") instanceof SettingsFragment) {
            settingsFragment = (SettingsFragment) getSupportFragmentManager().findFragmentByTag("settings_fragment");
        }
        if (articleDetailFragment != null || settingsFragment != null) {
            super.onBackPressed();
        } else {
            exitDialog();
        }
    }

    @Override
    public void onNewsListDownloaded(ArrayList<SubNewsItem> newsList) {
        mNewsList = newsList;
    }

    @Override
    public ArrayList<SubNewsItem> onNewsListAvail() {
        return (ArrayList<SubNewsItem>) mNewsList;
    }

    @Override
    public void onMessagePostFinish(int status) {
        switch (status) {
            case TwitterShare.ARG_SUCCESS:
                Utility.showToast(getString(R.string.twitter_post_success), this);
                break;

            case TwitterShare.ARG_ERROR:
                Utility.showToast(getString(R.string.twitter_post_error), this);
                break;

            case TwitterShare.ARG_OVERLOAD:
                Utility.showToast(getString(R.string.twitter_post_duplicate), this);
                break;
        }
    }

    // for push notification
    private final BroadcastReceiver mHandleMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            newMessage = intent.getExtras().getString(EXTRA_MESSAGE);
            if (flag == 1)
                newMessage = intent.getExtras().getString(EXTRA_MESSAGE);
        }
    };

    public class AutoLogin extends AsyncTask<String, String, JSONObject> {

        /**
         * @param mContext
         */
        Context mContext;
        String RegID;

        public AutoLogin(Context mContext, String RegID) {
            // TODO Auto-generated constructor stub
            this.mContext = mContext;
            this.RegID = RegID;

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //
        }

        @Override
        protected JSONObject doInBackground(String... args) {

            String strUrl = "";
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getSaveDataApiV2())) {
                strUrl = mConstants.getSaveDataApiV2();
            }
            //strUrl = Constants.BaseUrl_V2 + Constants.SAVE_DATA_API_V2;

            //String strUrl="http://betabs.business-standard.com/user/process-api/save-device-info";
/*            InputStream is = null;

            JSONParser jsonParser = new JSONParser();
			org.apache.commons.httpclient.NameValuePair[] pairs = {
					new org.apache.commons.httpclient.NameValuePair(
							"api_token", args[0]),
					new org.apache.commons.httpclient.NameValuePair(
							"device_token",GCMRegistrar.getRegistrationId(MainFragmentActivity.this)),
					new org.apache.commons.httpclient.NameValuePair(
							"user_email", args[2]),
					new org.apache.commons.httpclient.NameValuePair(
							"device_type", args[3]),
					new org.apache.commons.httpclient.NameValuePair(
							"device_name", args[4]),
					new org.apache.commons.httpclient.NameValuePair(
							"device_model", args[5]),
					new org.apache.commons.httpclient.NameValuePair(
							"os_version", args[6]),
					new org.apache.commons.httpclient.NameValuePair(
							"app_version", args[7]),
					new org.apache.commons.httpclient.NameValuePair(
							"device_uniqueid", args[1] )};*/
            // System.out.println("=======id=="+mPreferences.getString("device_token",
            // DEVICE_TOKEN));


            //String json = jsonParser.callWebservice(pairs, strUrl);


/*            JSONObject object = null;
            try {
                String Postparams = "api_token=" + args[0] + "&" + "device_token=" + RegID + "&" + "user_email=" + args[2] + "&" + "device_type=" + args[3] + "&" + "device_name=" + args[4] + "&" + "device_model=" + args[5] + "&" + "os_version=" + args[6] + "&" + "app_version=" + args[7] + "&" + "device_uniqueid=" + args[1];
                String json = jsonParser.sendHTTPRequestUsingPost(strUrl, Postparams);
                Log.d("AutoLogin", json);
                Log.d("AutoLogin_PARM", Postparams);
                object = new JSONObject(json);
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return object;*/

            OkHttpClient client = new OkHttpClient();
            JSONObject json = null;

            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("api_token", args[0])
                    .addFormDataPart("device_token", RegID)
                    .addFormDataPart("user_email", args[2])
                    .addFormDataPart("device_type", args[3])
                    .addFormDataPart("device_name", args[4])
                    .addFormDataPart("device_model", args[5])
                    .addFormDataPart("os_version", args[6])
                    .addFormDataPart("app_version", args[7])
                    .addFormDataPart("device_uniqueid", args[1])
                    .build();

            Request request = new Request.Builder()
                    .url(strUrl)
                    .post(requestBody)
                    .build();

            try (Response response = client.newCall(request).execute()) {

                try {
                    assert response.body() != null;
                    json = new JSONObject(response.body().string());
                    return json;
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;

        }

        protected void onPostExecute(JSONObject json) {
            // progressDialognew.cancel();

            if (json != null) {
                StringBuilder sb = new StringBuilder();
                String status = null;
                JSONObject id = null;
                try {
                    Editor editor = mPreferences.edit();
                    editor.putString("success", json.getString("status"));
                    if (json.getString("status").equalsIgnoreCase("success")) {
                        editor.putString("savedevice",
                                json.optString("message", ""));

                        editor.commit();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class CouponCode extends AsyncTask<String, String, JSONObject> {
        ProgressDialog dialog;
        Context context;

        CouponCode(Context mContext) {
            context = mContext;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(context, "", "Loading...");
        }

        @Override
        protected JSONObject doInBackground(String... args) {

            Context ctx = getApplicationContext();
            String strUrl = "";
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getGetCouponsApi())) {
                strUrl = mConstants.getGetCouponsApi();
            }
            //strUrl = ctx.getString(R.string.api_base_url) + Constants.GET_COUPONS_API;

            // InputStream is = null;

            /*JSONParser jsonParser = new JSONParser();
            org.apache.commons.httpclient.NameValuePair[] request = {new org.apache.commons.httpclient.NameValuePair(
                    "api_token", args[0]),
                    new org.apache.commons.httpclient.NameValuePair(
                            "device_udid", args[1]),
                    new org.apache.commons.httpclient.NameValuePair(
                            "device_type", args[2]),
                    new org.apache.commons.httpclient.NameValuePair(
                            "paytm_coupon_status", args[3]),
                    new org.apache.commons.httpclient.NameValuePair(
                            "app_version", args[4])};
            String res = jsonParser.callWebservice(request, strUrl);
            System.out.println("===json==" + res);
            JSONObject json = null;
            try {
                json = new JSONObject(res);
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return json;*/

            OkHttpClient client = new OkHttpClient();
            JSONObject json = null;

            RequestBody formBody = new FormBody.Builder()
                    .add("api_token", args[0])
                    .add("device_udid", args[1])
                    .add("device_type", args[2])
                    .add("paytm_coupon_status", args[3])
                    .add("app_version", args[4])
                    .build();

            Request request = new Request.Builder()
                    .url(strUrl)
                    .post(formBody)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String jsonStr = response.body().string();
                    json = new JSONObject(jsonStr);
                    return json;
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(JSONObject json) {
            try {
                if (json.getString("status").equalsIgnoreCase("success")) {
                    arrayList.clear();
                    JSONArray array = json.getJSONArray("message");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        CouponUtils couponUtils = new CouponUtils();
                        couponUtils.setCouponcode(jsonObject.optString("couponcode", ""));
                        couponUtils.setLogourl(jsonObject.optString("logourl", ""));
                        couponUtils.setOfferdesc(jsonObject.optString("offerdesc", ""));
                        couponUtils.setOfferid(jsonObject.optString("offerid", ""));
                        couponUtils.setShowfirsttime(jsonObject.optString("showfirsttime", ""));
                        couponUtils.setSource(jsonObject.optString("source", ""));
                        couponUtils.setValidtill(jsonObject.optString("validtill", ""));
                        arrayList.add(couponUtils);
                    }
                    dataBase.deleteAll();
                    dataBase.insertCoupon(arrayList);
                }
            } catch (Exception e1) {
                e1.printStackTrace();
            }
            CouponUtils couponUtils = null;
            // progressDialognew.cancel();
            for (int i = 0; i < arrayList.size(); i++) {
                if (arrayList.get(i).getShowfirsttime().equalsIgnoreCase("true")) {
                    couponUtils = arrayList.get(i);
                    break;
                }
            }

            if (dialog != null) {
                dialog.dismiss();
            }

            if (couponUtils != null) {
                CouponDialog(couponUtils);
            }
            /*
             * try { Editor editor = mPreferences.edit();
             * editor.putString("success", json.getString("status")); if
             * (json.getString("status").equalsIgnoreCase("success")) { json =
             * json.optJSONObject("message"); if (json != null) {
             * editor.putString("deviceudidexist",
             * json.optString("deviceudidexist", ""));
             * editor.putString("couponcode", json.optString("paytm_coupon"));
             * editor.commit();
             *
             * if (json.optString("deviceudidexist", "") .equalsIgnoreCase("")
             * && !json.optString("paytm_coupon", "") .equalsIgnoreCase("")) {
             * CouponDialog(); } } } } catch (JSONException e) {
             * e.printStackTrace(); }
             */
            LoadUI();
        }
    }

    private class AppUpgrade extends AsyncTask<String, String, String> {
        ProgressDialog dialog;
        Context context;

        AppUpgrade(Context mContext) {
            context = mContext;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(context, "", "Loading...");
        }

        @Override
        protected String doInBackground(String... args) {
            try {
                Context ctx = getApplicationContext();
                String strUrl = "";
                if (mConstants != null && !TextUtils.isEmpty(mConstants.getAppUpdate())) {
                    strUrl = mConstants.getAppUpdate();
                }
                //strUrl = ctx.getString(R.string.api_base_url) + Constants.APP_UPDATE;

                OkHttpClient client = new OkHttpClient();

                RequestBody formBody = new FormBody.Builder()
                        .add("api_token", args[0])
                        .add("device", args[1])
                        .build();

                Request request = new Request.Builder()
                        .url(strUrl)
                        .post(formBody)
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    if (response.isSuccessful()) {
                        assert response.body() != null;
                        String jsonStr = response.body().string();
                        return jsonStr;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(String json) {
            if (dialog != null) {
                dialog.dismiss();
            }
            try {
                JSONObject jsonObject = new JSONObject(json);
                jsonObject = jsonObject.getJSONObject("message");
                String isupdate = jsonObject.optString("status", "0");
                if (isupdate.equalsIgnoreCase("1")) {
                    String apiAppVersion = jsonObject.optString("app_version", "0");
                    try {
                        String appVersion = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
                        if (Double.parseDouble(apiAppVersion) > Double.parseDouble(appVersion)) {
                            AppUpgrade();
                        } else {
                            getCouponCode();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        getCouponCode();
                    }
                } else {
                    getCouponCode();
                }
            } catch (Exception e) {
                e.printStackTrace();
                getCouponCode();
            }
        }
    }

    private void AppUpgrade() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainFragmentActivity.this);
        alertDialogBuilder.setMessage(getString(R.string.app_update_alert_message));
        alertDialogBuilder.setTitle(getString(R.string.app_update_alert_title));
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton(getString(R.string.app_update_alert_positive_text),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        Uri uri = Uri.parse("market://details?id=" + getPackageName());
                        Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                        try {
                            startActivity(myAppLinkToMarket);
                        } catch (ActivityNotFoundException e) {
                            Toast.makeText(MainFragmentActivity.this, " unable to find market app", Toast.LENGTH_LONG).show();
                        }
                        finish();
                    }
                });

        alertDialogBuilder.setNegativeButton(getString(R.string.app_update_alert_negative_text),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void exitDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainFragmentActivity.this);
        alertDialogBuilder.setMessage(getString(R.string.exit_alert_message));
        alertDialogBuilder.setTitle(getString(R.string.exit_alert_title));
        alertDialogBuilder.setCancelable(true);
        alertDialogBuilder.setPositiveButton(getString(R.string.exit_alert_positive_text),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        finishAffinity();
                    }
                });

        alertDialogBuilder.setNegativeButton(getString(R.string.exit_alert_negative_text),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void CouponDialog(final CouponUtils couponUtils) {

        TextView coupon_txt, termcondition_txt;
        Button viewdetail_btn, close;

        final Dialog dialog = new Dialog(MainFragmentActivity.this, R.style.mydialogstyle);
        dialog.setContentView(R.layout.coupon);
        coupon_txt = (TextView) dialog.findViewById(R.id.coupon_txt);
        termcondition_txt = (TextView) dialog.findViewById(R.id.termscondition_txt);
        viewdetail_btn = (Button) dialog.findViewById(R.id.viewdetail_btn);
        String next = "<font color='#05C1FF'> Terms &amp; Conditions </font>";
        termcondition_txt.setText(Html.fromHtml(getResources().getString(
                R.string.coupon_dialog_coupon_term_condition_first)
                + next
                + getResources().getString(
                R.string.coupon_dialog_coupon_term_condition_last)));
        close = (Button) dialog.findViewById(R.id.close);
        coupon_txt.setText(couponUtils.getCouponcode());
        close.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        viewdetail_btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainFragmentActivity.this, CouponDetailsActivity.class);
                intent.putExtra("couponcode", couponUtils.getCouponcode());
                startActivity(intent);
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return capitalize(model);
        } else {
            return capitalize(manufacturer) + " " + model;
        }
    }

    private String capitalize(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        char first = s.charAt(0);
        if (Character.isUpperCase(first)) {
            return s;
        } else {
            return Character.toUpperCase(first) + s.substring(1);
        }

    }

    // private class notifiyme extends AsyncTask<String, String, JSONObject> {
    //
    // private ProgressDialog progressDialognew; Context ctx; String response;
    //
    // String errorMessage;
    // /**
    // * @param mContext
    // */
    //
    // public notifiyme(Context mContext) { // TODO Auto-generated constructor
    // // stub ctx = mContext; // progressDialognew = new
    // ProgressDialog(mContext);
    // // progressDialognew.setProgressStyle(ProgressDialog.STYLE_SPINNER); //
    // // progressDialognew.setTitle("Validating..");
    // }
    //
    // @Override protected void onPreExecute() {
    // super.onPreExecute(); //
    // }
    // // progressDialognew.show(); // showDialog(DIALOG_DOWNLOAD_PROGRESS); }
    //
    // @Override protected JSONObject doInBackground(String... args) { String
    // strUrl =
    // "http://cmstest.webdunia.net/user/process-api/send-push-notification";
    //
    // InputStream is = null;
    //
    // JSONParser jsonParser = new JSONParser(); List<NameValuePair> params =
    // new ArrayList<NameValuePair>(); params.add(new
    // BasicNameValuePair("api_token", args[0])); params.add(new
    // BasicNameValuePair("registatoin_ids", args[1])); params.add(new
    // BasicNameValuePair("message", args[2]));
    //
    //
    //
    // JSONObject json = jsonParser.getJSONFromUrl(strUrl, params);
    //
    // return json;
    //
    // }
    //
    // // protected void onProgressUpdate(String... progress) {
    // // super.onProgressUpdate(progress);
    // //
    // // }
    //
    // protected void onPostExecute(JSONObject json) { //
    // // progressDialognew.cancel();
    //
    // StringBuilder sb = new StringBuilder(); String status = null; JSONObject
    // id = null;
    //
    // } }

    /*
     * (non-Javadoc)
     *
     * @see com.businessstandard.common.ui.BaseActivity#onPostResume()
     */
    @Override
    public void onPostResume() {
        // TODO Auto-generated method stub
        super.onPostResume();

        if (newMessage != null) {
            // if (source.equals("from service")) {
            String ns = Context.NOTIFICATION_SERVICE;
            NotificationManager nMgr = (NotificationManager) getApplicationContext().getSystemService(ns);
            assert nMgr != null;
            nMgr.cancel(0);
            // String message = getIntent().getStringExtra(EXTRA_MESSAGE);
            AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

            LinearLayout layout = new LinearLayout(this);
            TextView tvMessage = new TextView(this);

            tvMessage.setText("  " + newMessage);
            newMessage = "null";
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.addView(tvMessage);

            builder1.setTitle("Latest News");
            builder1.setView(layout);

            builder1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    newMessage = "null";
                    dialog.cancel();
                }
            });

            AlertDialog alert11 = builder1.create();
            if (!(alert11.isShowing()))
                alert11.show();
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see com.businessstandard.common.ui.BaseActivity#onPause()
     */
    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(mHandleMessageReceiver);
            super.onDestroy();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see com.businessstandard.common.ui.BaseActivity#onResume()
     */
    @Override
    public void onResume() {
        try {
            registerReceiver(mHandleMessageReceiver, new IntentFilter(DISPLAY_MESSAGE_ACTION));
            super.onResume();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

/*
    public String getUserEmail() {
        String email = "example@example.com";
        Pattern emailPattern = Patterns.EMAIL_ADDRESS; // API level 8+
        Account[] accounts = AccountManager.get(context).getAccounts();
        for (Account account : accounts) {
            if (emailPattern.matcher(account.name).matches()) {
                email = account.name;

            }
        }
        return email;
    }
*/

    private void showExitDialog() {
        DialogButtonListener dialogButtonListener = new DialogButtonListener() {
            @Override
            public void onPositiveButtonClick() {
                finishAffinity();
            }

            @Override
            public void onNegativeButtonClick() {

            }

            @Override
            public void onNeutralButtonClick() {

            }
        };
        AlertDialogUtility.getInstance().showAlertDialog(this, getString(R.string.app_name), getString(R.string.exit_alert_message), getString(R.string.exit_alert_positive_text), getString(R.string.exit_alert_negative_text), dialogButtonListener, true);
    }

}