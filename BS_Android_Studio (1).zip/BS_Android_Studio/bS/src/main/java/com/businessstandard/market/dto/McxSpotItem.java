/**
   Project      : Economist
   Filename     : McxSpotItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.market.dto;

import java.util.List;

import com.google.gson.annotations.SerializedName;

/**
 * @author lenesha
 *
 */
public class McxSpotItem {
	@SerializedName("MCX Spot")
	public List<McxAndNcdexSpotItem> mcxSpot;
}
