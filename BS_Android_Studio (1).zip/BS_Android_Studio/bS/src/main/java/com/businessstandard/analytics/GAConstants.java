package com.businessstandard.analytics;

public interface GAConstants {
    String TandC_EVENT_CATEGORY = "TermsAndCondition";
    String TandC_EVENT_LABEL = "TermsAndCondition:Agreed";
    String LOGIN_SUCCESS_EVENT_CATEGORY = "LoginIntoAccount";
    String ADD_TO_CART_EVENT_CATEGORY = "AddToCart";
    String SELECT_PRODUCT_EVENT_CATEGORY = "SubmitApplication";
    String SELECT_PRODUCT_EVENT_LABEL = "PackageSelectionProceed";
    String ORDER_SUCCESS_EVENT_CATEGORY = "Subscribe";
    String ORDER_FAILURE_EVENT_CATEGORY = "CanceledSubscription";
    String COMPLETE_REGISTRATION_EVENT_CATEGORY = "CompleteRegistration";
    String CREATE_ACCOUNT_EVENT_CATEGORY = "CreateAccount";
    String COMPLETE_REGISTRATION_EVENT_LABEL = "Registration";

    String PAID_ARTICLE_NO_LOGIN_EVENT_CATEGORY = "ViewPaywall";

    String PAID_ARTICLE_PAID_LOGIN_EVENT_CATEGORY = "ViewContent";
    String PAID_ARTICLE_PAID_LOGIN_EVENT_ACTION = "article_content_tier:'locked' ";
    String PAID_ARTICLE_PAID_LOGIN_EVENT_LABEL = "is_subscriber:true";

    String FREE_ARTICLE_EVENT_CATEGORY = "ViewContent";
    String FREE_ARTICLE_EVENT_ACTION = "article_content_tier:'free'";
}
