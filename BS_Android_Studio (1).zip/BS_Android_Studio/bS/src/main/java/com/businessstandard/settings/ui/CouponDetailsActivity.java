/**
   Project      : Economist
   Filename     : CouponDetailsActivity.java
   Author       : android
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
				  Modified under contract by Robosoft Technologies Pvt. Ltd.
   History      : NA
*/

package com.businessstandard.settings.ui;

import android.app.Activity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.ui.MainFragmentActivity;

/**
 * @author android
 *
 */
public class CouponDetailsActivity extends Activity{
	private Button close;
	TextView moredetail,couponcode;
	/* (non-Javadoc)
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.coupondeatils);
		close=(Button)findViewById(R.id.close);
		couponcode=(TextView)findViewById(R.id.couponcode);
		couponcode.setText("Your PayTM Coupon Code is : "+getIntent().getStringExtra("couponcode"));
		moredetail=(TextView)findViewById(R.id.moredetail_txt);
		String next = "<font color='#05C1FF'> wwww.business-standard.com/paytmoffer </font>";
		moredetail.setText(Html.fromHtml(getResources().getString(R.string.more_detail)+ "<br />" + next));
		close.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				finish();
			}
		});
	}

}
