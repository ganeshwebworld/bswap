package com.businessstandard.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class GalleryVideo implements Serializable {

    @SerializedName("video_id")
    @Expose
    private String videoId;
    @SerializedName("gallery_id")
    @Expose
    private String galleryId;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("english_title")
    @Expose
    private String englishTitle;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("tags")
    @Expose
    private String tags;
    @SerializedName("thumbnail_name")
    @Expose
    private String thumbnailName;
    @SerializedName("video_type")
    @Expose
    private String videoType;
    @SerializedName("video_name")
    @Expose
    private String videoName;
    @SerializedName("video_name_mp4")
    @Expose
    private Object videoNameMp4;
    @SerializedName("video_format")
    @Expose
    private String videoFormat;
    @SerializedName("thumbnail_relpath")
    @Expose
    private String thumbnailRelpath;
    @SerializedName("video_relpath")
    @Expose
    private String videoRelpath;
    @SerializedName("video_url")
    @Expose
    private String videoUrl;
    @SerializedName("video_width")
    @Expose
    private String videoWidth;
    @SerializedName("video_height")
    @Expose
    private String videoHeight;
    @SerializedName("video_width_mp4")
    @Expose
    private Object videoWidthMp4;
    @SerializedName("video_height_mp4")
    @Expose
    private Object videoHeightMp4;
    @SerializedName("video_source_id")
    @Expose
    private String videoSourceId;
    @SerializedName("video_source_name")
    @Expose
    private String videoSourceName;
    @SerializedName("source_options")
    @Expose
    private String sourceOptions;
    @SerializedName("video_checksum")
    @Expose
    private String videoChecksum;
    @SerializedName("video_checksum_mp4")
    @Expose
    private Object videoChecksumMp4;
    @SerializedName("expiry_date")
    @Expose
    private String expiryDate;
    @SerializedName("display_order")
    @Expose
    private String displayOrder;
    @SerializedName("total_views")
    @Expose
    private String totalViews;
    @SerializedName("total_downloads")
    @Expose
    private String totalDownloads;
    @SerializedName("total_comments")
    @Expose
    private String totalComments;
    @SerializedName("total_likes")
    @Expose
    private String totalLikes;
    @SerializedName("total_dislikes")
    @Expose
    private String totalDislikes;
    @SerializedName("total_rating")
    @Expose
    private String totalRating;
    @SerializedName("average_rating")
    @Expose
    private String averageRating;
    @SerializedName("send_to_mobile")
    @Expose
    private String sendToMobile;
    @SerializedName("is_gallery_cover")
    @Expose
    private String isGalleryCover;
    @SerializedName("is_active")
    @Expose
    private String isActive;
    @SerializedName("created_by")
    @Expose
    private String createdBy;
    @SerializedName("creation_date")
    @Expose
    private String creationDate;
    @SerializedName("modified_by")
    @Expose
    private String modifiedBy;
    @SerializedName("modification_date")
    @Expose
    private String modificationDate;

    public String getVideoId() {
        return videoId;
    }

    public void setVideoId(String videoId) {
        this.videoId = videoId;
    }

    public String getGalleryId() {
        return galleryId;
    }

    public void setGalleryId(String galleryId) {
        this.galleryId = galleryId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getEnglishTitle() {
        return englishTitle;
    }

    public void setEnglishTitle(String englishTitle) {
        this.englishTitle = englishTitle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getThumbnailName() {
        return thumbnailName;
    }

    public void setThumbnailName(String thumbnailName) {
        this.thumbnailName = thumbnailName;
    }

    public String getVideoType() {
        return videoType;
    }

    public void setVideoType(String videoType) {
        this.videoType = videoType;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public Object getVideoNameMp4() {
        return videoNameMp4;
    }

    public void setVideoNameMp4(Object videoNameMp4) {
        this.videoNameMp4 = videoNameMp4;
    }

    public String getVideoFormat() {
        return videoFormat;
    }

    public void setVideoFormat(String videoFormat) {
        this.videoFormat = videoFormat;
    }

    public String getThumbnailRelpath() {
        return thumbnailRelpath;
    }

    public void setThumbnailRelpath(String thumbnailRelpath) {
        this.thumbnailRelpath = thumbnailRelpath;
    }

    public String getVideoRelpath() {
        return videoRelpath;
    }

    public void setVideoRelpath(String videoRelpath) {
        this.videoRelpath = videoRelpath;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getVideoWidth() {
        return videoWidth;
    }

    public void setVideoWidth(String videoWidth) {
        this.videoWidth = videoWidth;
    }

    public String getVideoHeight() {
        return videoHeight;
    }

    public void setVideoHeight(String videoHeight) {
        this.videoHeight = videoHeight;
    }

    public Object getVideoWidthMp4() {
        return videoWidthMp4;
    }

    public void setVideoWidthMp4(Object videoWidthMp4) {
        this.videoWidthMp4 = videoWidthMp4;
    }

    public Object getVideoHeightMp4() {
        return videoHeightMp4;
    }

    public void setVideoHeightMp4(Object videoHeightMp4) {
        this.videoHeightMp4 = videoHeightMp4;
    }

    public String getVideoSourceId() {
        return videoSourceId;
    }

    public void setVideoSourceId(String videoSourceId) {
        this.videoSourceId = videoSourceId;
    }

    public String getVideoSourceName() {
        return videoSourceName;
    }

    public void setVideoSourceName(String videoSourceName) {
        this.videoSourceName = videoSourceName;
    }

    public String getSourceOptions() {
        return sourceOptions;
    }

    public void setSourceOptions(String sourceOptions) {
        this.sourceOptions = sourceOptions;
    }

    public String getVideoChecksum() {
        return videoChecksum;
    }

    public void setVideoChecksum(String videoChecksum) {
        this.videoChecksum = videoChecksum;
    }

    public Object getVideoChecksumMp4() {
        return videoChecksumMp4;
    }

    public void setVideoChecksumMp4(Object videoChecksumMp4) {
        this.videoChecksumMp4 = videoChecksumMp4;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(String displayOrder) {
        this.displayOrder = displayOrder;
    }

    public String getTotalViews() {
        return totalViews;
    }

    public void setTotalViews(String totalViews) {
        this.totalViews = totalViews;
    }

    public String getTotalDownloads() {
        return totalDownloads;
    }

    public void setTotalDownloads(String totalDownloads) {
        this.totalDownloads = totalDownloads;
    }

    public String getTotalComments() {
        return totalComments;
    }

    public void setTotalComments(String totalComments) {
        this.totalComments = totalComments;
    }

    public String getTotalLikes() {
        return totalLikes;
    }

    public void setTotalLikes(String totalLikes) {
        this.totalLikes = totalLikes;
    }

    public String getTotalDislikes() {
        return totalDislikes;
    }

    public void setTotalDislikes(String totalDislikes) {
        this.totalDislikes = totalDislikes;
    }

    public String getTotalRating() {
        return totalRating;
    }

    public void setTotalRating(String totalRating) {
        this.totalRating = totalRating;
    }

    public String getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(String averageRating) {
        this.averageRating = averageRating;
    }

    public String getSendToMobile() {
        return sendToMobile;
    }

    public void setSendToMobile(String sendToMobile) {
        this.sendToMobile = sendToMobile;
    }

    public String getIsGalleryCover() {
        return isGalleryCover;
    }

    public void setIsGalleryCover(String isGalleryCover) {
        this.isGalleryCover = isGalleryCover;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getModificationDate() {
        return modificationDate;
    }

    public void setModificationDate(String modificationDate) {
        this.modificationDate = modificationDate;
    }

}
