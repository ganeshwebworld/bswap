package com.businessstandard.utils;

public interface SharedPreferencesKey {

    String TWITTER_AUTH_TOKEN = "TWITTER_AUTH_TOKEN";
    String TWITTER_AUTH_SECRET = "TWITTER_AUTH_SECRET";
    String KEY_TWITTER_LOGIN = "KEY_TWITTER_LOGIN";
    String TWITTER_USER_NAME = "TWITTER_USER_NAME";
    String TWITTER_USER_ID = "TWITTER_USER_ID";
    String TWITTER_USER_EMAIL = "TWITTER_USER_EMAIL";
    String FIRST_LAUNCH = "first_launch";
    String FRESH_LAUNCH = "fresh_launch";
    String KEY_CONFIG_CONSTANTS_DATA = "config_data";
    String KEY_SIGN_IN_API = "key_sign_in_api";
    String KEY_COMMON_JSON_API = "key_common_json_api";
    String KEY_USER_ID = "user_id";
    String KEY_DEVICE_ID = "device_id";
    String SUBSCRIPTION_AMOUNT_SELECTED = "subscription_amount_selected";
    String KEY_CONFIG_SPLASH_DATA = "key_config_splash_data";
}
