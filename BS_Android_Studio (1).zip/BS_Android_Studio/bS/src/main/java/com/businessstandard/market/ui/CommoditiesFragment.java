/**
 * Project      : Economist
 * Filename     : CommoditiesFragment.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.market.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.util.Utility;
import com.businessstandard.market.MarketsManager;
import com.businessstandard.market.MarketsManager.McxFutureDloadCmpltListener;
import com.businessstandard.market.MarketsManager.McxGainersDloadCmpltListener;
import com.businessstandard.market.MarketsManager.McxLoosersDloadCmpltListener;
import com.businessstandard.market.MarketsManager.McxSpotDloadCmpltListener;
import com.businessstandard.market.MarketsManager.NcdexFutureDloadCmpltListener;
import com.businessstandard.market.MarketsManager.NcdexGainersDloadCmpltListener;
import com.businessstandard.market.MarketsManager.NcdexLoosersDloadCmpltListener;
import com.businessstandard.market.MarketsManager.NcdexSpotDloadCmpltListener;
import com.businessstandard.market.dto.McxAndNcdexFutureItem;
import com.businessstandard.market.dto.McxAndNcdexNewsItem;
import com.businessstandard.market.dto.McxAndNcdexRootFeedItem;
import com.businessstandard.market.dto.McxAndNcdexSpotItem;
import com.businessstandard.market.dto.McxFutureRootFeedItem;
import com.businessstandard.market.dto.McxLoosersRootFeedItem;
import com.businessstandard.market.dto.McxNcdexFutureItems;
import com.businessstandard.market.dto.McxNcdexGainersLoosersItems;
import com.businessstandard.market.dto.McxNcdexSpotItems;
import com.businessstandard.market.dto.McxSpotRootFeedItem;
import com.businessstandard.market.dto.NcdexFutureRootFeedItem;
import com.businessstandard.market.dto.NcdexGainersRootFeedItem;
import com.businessstandard.market.dto.NcdexLoosersRootFeedItem;
import com.businessstandard.market.dto.NcdexSpotRootFeedItem;
import com.businessstandard.market.dto.StockHolder;
import com.businessstandard.analytics.GoogleAnalytics;

import java.util.List;

/**
 * @author lenesha
 *
 */
public class CommoditiesFragment extends BaseFragment {

    private FragmentActivity mcontext;
    private FragmentListner mListner;
    private ListView mCommoditiesListview;
    StockHolder mstockArray[] = new StockHolder[8];
    private CommoditiesAdapter mAdapter;
    private TextView mEmptyListTxt;
    private GoogleAnalytics mGoogleAnalytics;

    /* (non-Javadoc)
     * @see android.support.v4.app.Fragment#onAttach(android.app.Activity)
     */

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mcontext = getActivity();
        mListner = (FragmentListner) mcontext;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.commodities, container, false);
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        mCommoditiesListview = (ListView) view.findViewById(R.id.commodities_list);
        mEmptyListTxt = (TextView) view.findViewById(R.id.empty_text);
        return view;
    }

    /* (non-Javadoc)
     * @see android.support.v4.app.Fragment#onActivityCreated(android.os.Bundle)
     */
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mAdapter = new CommoditiesAdapter(mcontext, R.layout.stock_list, mstockArray);
        mCommoditiesListview.setVerticalFadingEdgeEnabled(false);
        mCommoditiesListview.setAdapter(mAdapter);
        //AnalyticsUtils.getInstAnalyticsUtils(getActivity()).trackPageView(getString(R.string.tab_market) + getString(R.string.cat_commodities));
        if (mGoogleAnalytics != null && getActivity() != null) {
            mGoogleAnalytics.trackScreenView(getString(R.string.tab_market) + getString(R.string.cat_commodities), getActivity());
        }
        getData();
    }

    private void displayEmptylist() {
        mEmptyListTxt.setVisibility(View.VISIBLE);
        mCommoditiesListview.setVisibility(View.INVISIBLE);
    }

    /**
     *
     */
    private void getData() {

        SectionNewsRootFeedItem dataFeed = mListner.getDataFromActivity();
        if (getActivity() != null && Utility.isInternetOn(getActivity())) {


            if (dataFeed != null && dataFeed.root != null) {
                mCommoditiesListview.setVisibility(View.VISIBLE);
                mEmptyListTxt.setVisibility(View.INVISIBLE);


                String mcxGainersUrl = dataFeed.root.getmMCXGainers().feedUrl;
                String mcxLoosersUrl = dataFeed.root.getmMCXLoosers().feedUrl;

                String ncdexGainersUrl = dataFeed.root.getmNCDEXGainers().feedUrl;
                String ncdexLoosersUrl = dataFeed.root.getmNCDEXLoosers().feedUrl;


                String mcxSpotUrl = dataFeed.root.getmMCXSpot().feedUrl;
                String ncdexSpotUrl = dataFeed.root.getmNCDEXSpot().feedUrl;

                String mcxFutureUrl = dataFeed.root.getmMCXFuture().feedUrl;
                String ncdexFutureUrl = dataFeed.root.getmNCDEXFuture().feedUrl;

                MarketsManager manager = new MarketsManager(getActivity());
                manager.mcxGainersDownload(new McxGainersDloadCmpltListener() {

                    @Override
                    public void onFailure() {
                        Utility.hideProgressDialog();

                    }

                    @Override
                    public void onCompanySearchDloadCmplt(McxAndNcdexRootFeedItem result) {

                        Utility.hideProgressDialog();
                        McxAndNcdexRootFeedItem res = result;
                        List<McxAndNcdexNewsItem> mcxGainersList = res.root.mcxGainers;

                        McxNcdexGainersLoosersItems mcxGainersItems = new McxNcdexGainersLoosersItems();
                        mcxGainersItems.mcxOrNcdex = mcxGainersList;
                        mcxGainersItems.isMcxGainer = true;
                        mstockArray[0] = mcxGainersItems;
                        mAdapter.notifyDataSetChanged();

                        Log.i("market", "" + res.root);
                    }
                }, mcxGainersUrl);


                manager.mcxLoosersDownload(new McxLoosersDloadCmpltListener() {

                    @Override
                    public void onFailure() {
                        Utility.hideProgressDialog();
                    }

                    @Override
                    public void onCompanySearchDloadCmplt(McxLoosersRootFeedItem result) {
                        Utility.hideProgressDialog();

                        McxLoosersRootFeedItem res = result;

                        List<McxAndNcdexNewsItem> mcxLoosersList = res.root.mcxLoosers;
                        McxNcdexGainersLoosersItems mcxLoosersItems = new McxNcdexGainersLoosersItems();
                        mcxLoosersItems.mcxOrNcdex = mcxLoosersList;
                        mcxLoosersItems.isMcxLooser = true;

                        mstockArray[2] = mcxLoosersItems;

                        mAdapter.notifyDataSetChanged();


                    }
                }, mcxLoosersUrl);


                manager.NcdexGainersDownload(new NcdexGainersDloadCmpltListener() {

                    @Override
                    public void onFailure() {
                        Utility.hideProgressDialog();

                    }

                    @Override
                    public void onCompanySearchDloadCmplt(NcdexGainersRootFeedItem result) {
                        Utility.hideProgressDialog();

                        NcdexGainersRootFeedItem res = result;

                        List<McxAndNcdexNewsItem> ncdexGainers = res.root.ncdexGainers;

                        McxNcdexGainersLoosersItems ncdexGainersItems = new McxNcdexGainersLoosersItems();
                        ncdexGainersItems.mcxOrNcdex = ncdexGainers;
                        ncdexGainersItems.isNcdexGainer = true;
                        mstockArray[1] = ncdexGainersItems;

                        mAdapter.notifyDataSetChanged();

                        Log.i("market", "" + res.root);


                    }
                }, ncdexGainersUrl);

                manager.NcdexLoosersDownload(new NcdexLoosersDloadCmpltListener() {

                    @Override
                    public void onFailure() {
                        Utility.hideProgressDialog();
                    }

                    @Override
                    public void onCompanySearchDloadCmplt(NcdexLoosersRootFeedItem result) {
                        Utility.hideProgressDialog();

                        NcdexLoosersRootFeedItem res = result;

                        List<McxAndNcdexNewsItem> ncdexLoosers = res.root.ncdexLoosers;
                        McxNcdexGainersLoosersItems ncdexLoosersItems = new McxNcdexGainersLoosersItems();
                        ncdexLoosersItems.mcxOrNcdex = ncdexLoosers;
                        ncdexLoosersItems.isNcdexLooser = true;
                        mstockArray[3] = ncdexLoosersItems;

                        mAdapter.notifyDataSetChanged();

                        Log.i("market", "" + res.root);


                    }
                }, ncdexLoosersUrl);

                manager.mcxSpotDownload(new McxSpotDloadCmpltListener() {

                    @Override
                    public void onFailure() {
                        Utility.hideProgressDialog();

                    }

                    @Override
                    public void onCompanySearchDloadCmplt(McxSpotRootFeedItem result) {
                        Utility.hideProgressDialog();

                        McxSpotRootFeedItem res = result;

                        List<McxAndNcdexSpotItem> mcxSpot = res.root.mcxSpot;

                        McxNcdexSpotItems mcxSpotItems = new McxNcdexSpotItems();
                        mcxSpotItems.mcxOrNcdexSpot = mcxSpot;
                        mcxSpotItems.isMcxSpot = true;
                        mstockArray[4] = mcxSpotItems;
                        mAdapter.notifyDataSetChanged();
                        Log.i("market", "" + res.root);


                    }
                }, mcxSpotUrl);

                manager.NcdexSpotDownload(new NcdexSpotDloadCmpltListener() {

                    @Override
                    public void onFailure() {
                        Utility.hideProgressDialog();
                    }

                    @Override
                    public void onCompanySearchDloadCmplt(NcdexSpotRootFeedItem result) {
                        Utility.hideProgressDialog();

                        NcdexSpotRootFeedItem res = result;
                        List<McxAndNcdexSpotItem> ncdexSpot = res.root.ncdexSpot;

                        McxNcdexSpotItems ncdexSpotItems = new McxNcdexSpotItems();
                        ncdexSpotItems.mcxOrNcdexSpot = ncdexSpot;
                        ncdexSpotItems.isNcdexSpot = true;
                        mstockArray[5] = ncdexSpotItems;

                        mAdapter.notifyDataSetChanged();


                    }
                }, ncdexSpotUrl);

                manager.mcxFutureDownload(new McxFutureDloadCmpltListener() {

                    @Override
                    public void onFailure() {
                        Utility.hideProgressDialog();

                    }

                    @Override
                    public void onCompanySearchDloadCmplt(McxFutureRootFeedItem result) {
                        Utility.hideProgressDialog();

                        McxFutureRootFeedItem res = result;

                        List<McxAndNcdexFutureItem> mcxFuture = res.root.mcxFuture;

                        McxNcdexFutureItems mcxFutureItems = new McxNcdexFutureItems();
                        mcxFutureItems.mcxOrNcdexFutureItems = mcxFuture;
                        mcxFutureItems.isMcxFuture = true;
                        mstockArray[6] = mcxFutureItems;
                        mAdapter.notifyDataSetChanged();
                        Log.i("market", "" + res.root);


                    }
                }, mcxFutureUrl);


                manager.NcdexFutureDownload(new NcdexFutureDloadCmpltListener() {

                    @Override
                    public void onFailure() {
                        Utility.hideProgressDialog();

                    }

                    @Override
                    public void onCompanySearchDloadCmplt(NcdexFutureRootFeedItem result) {
                        Utility.hideProgressDialog();

                        NcdexFutureRootFeedItem res = result;

                        List<McxAndNcdexFutureItem> ncdexFuture = res.root.ncdexFuture;
                        McxNcdexFutureItems ncdexFutureItems = new McxNcdexFutureItems();
                        ncdexFutureItems.mcxOrNcdexFutureItems = ncdexFuture;
                        ncdexFutureItems.isNcdexFuture = true;
                        mstockArray[7] = ncdexFutureItems;

                        mAdapter.notifyDataSetChanged();


                    }
                }, ncdexFutureUrl);
            } else {
                displayEmptylist();
                if (getActivity() != null)
                    Utility.displayAlert(getActivity(), getActivity()
                                    .getString(R.string.app_name), getActivity()
                                    .getString(R.string.unable_to_fetch_data), android.R.string.ok,
                            Utility.getOkButtonListener(getActivity()));
            }
        } else {
            Utility.hideProgressDialog();
            if (getActivity() != null)
                Utility.displayAlert(getActivity(), getActivity()
                                .getString(R.string.app_name), getActivity()
                                .getString(R.string.no_connection), android.R.string.ok,
                        Utility.getOkButtonListener(getActivity()));
            displayEmptylist();
        }
    }

    public void refreshContent() {
        getData();

    }
}
