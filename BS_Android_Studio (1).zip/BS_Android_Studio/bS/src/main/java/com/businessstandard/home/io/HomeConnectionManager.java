/**
 * Project      : Economist
 * Filename     : HomeConnectionManager.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.home.io;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.util.ConnectionUtility;
import com.businessstandard.common.util.RestTemplateContainer;
import com.businessstandard.home.HomeManager;
import com.businessstandard.market.dto.CompanyStockNewsFeed;
import com.businessstandard.market.dto.TickerNewsFeedRootObject;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;

import java.lang.ref.WeakReference;

/**
 * @author lenesha
 */
public class HomeConnectionManager {

    private WeakReference<Context> mContext;

    public HomeConnectionManager(Context context) {
        mContext = new WeakReference<Context>(context);
    }

    public SectionNewsRootFeedItem getSectionNewsCategories(Context context) {
        try {
            //String finalUrl = mContext.get().getString(R.string.base_url);
            SaveSharedPref saveSharedPref = SaveSharedPref.getInstance(context);
            String finalUrl = "";
            if (saveSharedPref != null && !TextUtils.isEmpty(saveSharedPref.getString(SharedPreferencesKey.KEY_COMMON_JSON_API, ""))) {
                finalUrl = saveSharedPref.getString(SharedPreferencesKey.KEY_COMMON_JSON_API, "");
            }

            MultiValueMap<String, String> param = new LinkedMultiValueMap<String, String>();

            RestTemplateContainer restTemplateContainer = ConnectionUtility.createRestTemplate(param);

            ResponseEntity<SectionNewsRootFeedItem> responseEntity;

            responseEntity = restTemplateContainer.restTemplate.exchange(
                    finalUrl, HttpMethod.GET, restTemplateContainer.httpEntity,
                    SectionNewsRootFeedItem.class);
            if (responseEntity.getStatusCode() == HttpStatus.OK)
                return responseEntity.getBody();
            else
                return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getSubNewsFeeds(String url) {

        MultiValueMap<String, String> param = new LinkedMultiValueMap<String, String>();
        RestTemplateContainer restTemplateContainer = ConnectionUtility.createRestTemplate(param);
        ResponseEntity<String> responseEntity = null;
        try {
            responseEntity = restTemplateContainer.restTemplate.exchange(url,
                    HttpMethod.GET, restTemplateContainer.httpEntity,
                    String.class);
            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                Log.d("SUCC", " " + responseEntity.getBody());
                return responseEntity.getBody();

            } else {
                Log.d("SUCC", " " + responseEntity.getBody());
                return null;

            }
        } catch (Exception e) {
            Log.i("EXCEPTION", e.getMessage());
            return null;
        }
    }

    public TickerNewsFeedRootObject getTickerFeeds() {
        try {
            MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
            RestTemplateContainer restTemplateContainer = ConnectionUtility.createRestTemplate(params, mContext.get());
            ResponseEntity<TickerNewsFeedRootObject> responseEntity;

            String finalUrl = HomeManager.sStock_graph;

            responseEntity = restTemplateContainer.restTemplate.exchange(
                    finalUrl, HttpMethod.GET, restTemplateContainer.httpEntity,
                    TickerNewsFeedRootObject.class);

            if (responseEntity.getStatusCode() == HttpStatus.OK)
                return responseEntity.getBody();
            else
                return null;

        } catch (Exception e) {
            Log.i("EXCEPTION", e.getMessage());

            return null;

        }

    }

    /**
     * @param url
     */
    public CompanyStockNewsFeed[] getStockFeeds(String url) {
        try {
            MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
            RestTemplateContainer restTemplateContainer = ConnectionUtility.createRestTemplate(params, mContext.get());
            ResponseEntity<CompanyStockNewsFeed[]> responseEntity;

            responseEntity = restTemplateContainer.restTemplate.exchange(url,
                    HttpMethod.GET, restTemplateContainer.httpEntity,
                    CompanyStockNewsFeed[].class);
            if (responseEntity.getStatusCode() == HttpStatus.OK)
                return responseEntity.getBody();
            else
                return null;

        } catch (Exception e) {
            Log.i("EXCEPTION", e.getMessage());
            return null;
        }
    }

    public String getCommentFeeds(String url) {

        MultiValueMap<String, String> param = new LinkedMultiValueMap<String, String>();
        RestTemplateContainer restTemplateContainer = ConnectionUtility.createRestTemplate(param, mContext.get());
        ResponseEntity<String> responseEntity = null;

        try {
            responseEntity = restTemplateContainer.restTemplate.exchange(url,
                    HttpMethod.GET, restTemplateContainer.httpEntity,
                    String.class);
            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                Log.d("SUCC", " " + responseEntity.getBody());
                return responseEntity.getBody();
            } else {
                Log.d("SUCC", " " + responseEntity.getBody());
                return null;
            }
        } catch (Exception e) {
            Log.i("EXCEPTION", e.getMessage());
            return null;
        }
    }

    /**
     * @param mNewsItemPos
     * @param id
     * @param username
     * @param comment
     * @param postCommenturl
     */
    public String postcomments(String mNewsItemPos, String id, String username, String comment, String postCommenturl) {
        try {
            MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
            ResponseEntity<String> responseEntity;
            params.add(CommentKeys.AUTONO, mNewsItemPos);
            params.add(CommentKeys.UNAME, username);
            params.add(CommentKeys.EMAIL, id);
            params.add(CommentKeys.COMMENT_BODY, comment);
            RestTemplateContainer restTemplateContainer = ConnectionUtility.createRestTemplate(params, mContext.get());

            responseEntity = restTemplateContainer.restTemplate.exchange(
                    postCommenturl, HttpMethod.POST,
                    restTemplateContainer.httpEntity, String.class);
            if (responseEntity.getStatusCode() == HttpStatus.OK) {
                return responseEntity.getBody();
            } else
                return null;
        } catch (ResourceAccessException e) {
            e.printStackTrace();
            return null;
        } catch (HttpStatusCodeException e) {
            return null;
        } catch (IllegalArgumentException e) {
            return null;
        } catch (RuntimeException e) {
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static interface CommentKeys {
        public String COMMENT_BODY = "comment";
        public String AUTONO = "autono";
        public String UNAME = "uname";
        public String EMAIL = "email";
    }
}
