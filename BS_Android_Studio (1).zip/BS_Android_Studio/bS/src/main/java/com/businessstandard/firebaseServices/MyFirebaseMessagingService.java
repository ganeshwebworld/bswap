package com.businessstandard.firebaseServices;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.text.TextUtils;

import com.businessstandard.R;
import com.businessstandard.home.ui.ArticleWebView;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.twitter.android.NotificationUtils;

import java.net.URL;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    String message = "";
    public static final String WITH_SOUND_WITH_VIBRATION_CHANNEL_ID = "BsChannelWithSoundWithVibration";
    public static final String WITH_SOUND_WITHOUT_VIBRATION_CHANNEL_ID = "BsChannelWithSoundWithoutVibration";
    public static final String WITHOUT_SOUND_WITH_VIBRATION_CHANNEL_ID = "BsChannelWithoutSoundWithVibration";
    public static final String WITHOUT_SOUND_WITHOUT_VIBRATION_CHANNEL_ID = "BsChannelWithoutSoundWithoutVibration";
    private String attachmentUrl;
    private NotificationChannel channel = null;
    private AudioAttributes att = null;
    private Uri sound = null;

    @Override
    public void onNewToken(String s) {
        if (!TextUtils.isEmpty(s)) {
            NotificationUtils.getInstance().sendDataToServer(this, s);
        }
        super.onNewToken(s);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        try {
            String articleId = "";
            if (remoteMessage.getData().size() > 0) {
                if (!TextUtils.isEmpty(remoteMessage.getData().get(getString(R.string.notification_message)))) {
                    message = remoteMessage.getData().get(getString(R.string.notification_message));
                }
                if (!TextUtils.isEmpty(remoteMessage.getData().get(getString(R.string.notification_article_id_key)))) {
                    articleId = remoteMessage.getData().get(getString(R.string.notification_article_id_key));
                }
            }
            sendNotification(message, articleId);
        } catch (Exception e) {
            e.printStackTrace();
        }

        super.onMessageReceived(remoteMessage);
    }

    private void sendNotification(String message, String articleId) {

        att = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();

        sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        String title = getString(R.string.app_name);

        boolean isSound = isSound(this);
        boolean isVibrate = isVibration(this);

        Intent intent = new Intent(this, ArticleWebView.class);
        intent.putExtra("ArticleId", articleId);
        intent.setAction(Long.toString(System.currentTimeMillis()));
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        int notifyID = getRandomNumber();

        NotificationCompat.Builder notificationBuilder = null;

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!isSound && isVibrate) {
                if (notificationManager != null && notificationManager.getNotificationChannel(WITHOUT_SOUND_WITH_VIBRATION_CHANNEL_ID) == null) {
                    createNotifChannelWithoutSoundWithVibration(notificationManager);
                }
            } else if (!isVibrate && !isSound) {
                if (notificationManager != null && notificationManager.getNotificationChannel(WITHOUT_SOUND_WITHOUT_VIBRATION_CHANNEL_ID) == null) {
                    createNotifChannelWithoutSoundWithoutVibration(notificationManager);
                }
            } else if (!isVibrate && isSound) {
                if (notificationManager != null && notificationManager.getNotificationChannel(WITH_SOUND_WITHOUT_VIBRATION_CHANNEL_ID) == null) {
                    createNotifChannelWithSoundWithoutVibration(notificationManager);
                }
            } else if (isSound && isVibrate) {
                if (notificationManager != null && notificationManager.getNotificationChannel(WITH_SOUND_WITH_VIBRATION_CHANNEL_ID) == null) {
                    createNotifChannelWithSoundWithVibration(notificationManager);
                }
            }
        }

        if (!isSound && isVibrate) {
            notificationBuilder = new NotificationCompat.Builder(this, WITHOUT_SOUND_WITH_VIBRATION_CHANNEL_ID)
                    .setContentTitle(title)
                    .setContentText(message)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                    .setSound(null)
                    .setContentIntent(pendingIntent)
                    .setAutoCancel(true)
                    .setVibrate(new long[]{1000, 1000, 1000, 1000, 1000})
                    .setSmallIcon(R.drawable.app_icon);

        } else if (!isVibrate && isSound) {
            notificationBuilder = new NotificationCompat.Builder(this, WITH_SOUND_WITHOUT_VIBRATION_CHANNEL_ID)
                    .setContentTitle(title)
                    .setContentText(message)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                    .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                    .setContentIntent(pendingIntent)
                    .setAutoCancel(true)
                    .setVibrate(new long[]{0, 0})
                    .setSmallIcon(R.drawable.app_icon);

        } else if (!isVibrate && !isSound) {
            notificationBuilder = new NotificationCompat.Builder(this, WITHOUT_SOUND_WITHOUT_VIBRATION_CHANNEL_ID)
                    .setContentTitle(title)
                    .setContentText(message)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                    .setSound(null)
                    .setContentIntent(pendingIntent)
                    .setAutoCancel(true)
                    .setVibrate(new long[]{0, 0})
                    .setSmallIcon(R.drawable.app_icon);
        } else if (isSound && isVibrate) {
            notificationBuilder = new NotificationCompat.Builder(this, WITH_SOUND_WITH_VIBRATION_CHANNEL_ID)
                    .setContentTitle(title)
                    .setContentText(message)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                    .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                    .setContentIntent(pendingIntent)
                    .setAutoCancel(true)
                    .setVibrate(new long[]{1000, 1000, 1000, 1000, 1000})
                    .setSmallIcon(R.drawable.app_icon);
        }

        if (notificationManager != null) {
            notificationManager.notify(notifyID, notificationBuilder.build());
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private void createNotifChannelWithSoundWithVibration(NotificationManager notificationManager) {
        channel = new NotificationChannel(WITH_SOUND_WITH_VIBRATION_CHANNEL_ID, "BS_WITH_SOUND_WITH_VIBRATION_CHANNEL", NotificationManager.IMPORTANCE_HIGH);
        channel.setSound(sound, att);
        channel.enableVibration(true);
        channel.setVibrationPattern(new long[]{1000, 1000, 1000, 1000, 1000});
        if (notificationManager != null) {
            notificationManager.createNotificationChannel(channel);
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private void createNotifChannelWithSoundWithoutVibration(NotificationManager notificationManager) {
        channel = new NotificationChannel(WITH_SOUND_WITHOUT_VIBRATION_CHANNEL_ID, "BS_WITH_SOUND_WITHOUT_VIBRATION_CHANNEL", NotificationManager.IMPORTANCE_HIGH);
        channel.setSound(sound, att);
        channel.enableVibration(false);
        channel.setVibrationPattern(new long[]{0, 0});
        if (notificationManager != null) {
            notificationManager.createNotificationChannel(channel);
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private void createNotifChannelWithoutSoundWithVibration(NotificationManager notificationManager) {
        channel = new NotificationChannel(WITHOUT_SOUND_WITH_VIBRATION_CHANNEL_ID, "BS_WITHOUT_SOUND_WITH_VIBRATION_CHANNEL", NotificationManager.IMPORTANCE_HIGH);
        channel.setSound(null, null);
        channel.enableVibration(true);
        channel.setVibrationPattern(new long[]{1000, 1000, 1000, 1000, 1000});
        if (notificationManager != null) {
            notificationManager.createNotificationChannel(channel);
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private void createNotifChannelWithoutSoundWithoutVibration(NotificationManager notificationManager) {
        channel = new NotificationChannel(WITHOUT_SOUND_WITHOUT_VIBRATION_CHANNEL_ID, "BS_WITHOUT_SOUND_WITHOUT_VIBRATION_CHANNEL", NotificationManager.IMPORTANCE_HIGH);
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setVibrationPattern(new long[]{0, 0});
        if (notificationManager != null) {
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Bitmap getBitmapFromURL(String attachmentUrl) {

        try {
            URL url = new URL(attachmentUrl);
            Bitmap image = BitmapFactory.decodeStream(url.openConnection().getInputStream());
            return image;
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    private int getRandomNumber() {
        try {
            int min = 1, max = 100;
            int range = (max - min) + 1;
            return (int) (Math.random() * range) + min;
        } catch (Exception e) {
            e.printStackTrace();
            try {
                return (int) (System.currentTimeMillis() / 10000);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
            return 88;
        }
    }

    public static Boolean isSound(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences("NotificationSettings", Context.MODE_PRIVATE);
        return sharedpreferences.getBoolean("isSound", true);
    }

    public static Boolean isVibration(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences("NotificationSettings", Context.MODE_PRIVATE);
        return sharedpreferences.getBoolean("isVibration", true);
    }
}
