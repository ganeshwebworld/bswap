/**
   Project      : Economist
   Filename     : Constants.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */
package com.businessstandard.common.util;

import java.util.ArrayList;

import com.businessstandard.market.dto.CompanyStockNewsFeed;

/**
 * @author lenesha
 * 
 */
public class Constants {

	public static final String BaseUrl_V2="http://api.business-standard.com";
    public static final String REGISTRATION_API = "/user/process-api/user-registration";
    public static final String SIGN_IN_API = "/user/process-api/login";
    public static final String SAVE_DATA_API_V2 = "/user/process-api/save-device-info-ver2";
    public static final String FORGOT_PASSWORD_API = "/user/process-api/forgot-password";
    public static final String DELETE_COUPON_API="/user/process-api/delete-offer-as-per-device-udid";
    public static final String GET_COUPONS_API="/user/process-api/save-device-udid-info";
    public static final String GET_DEVICE_NOTIFICATION_SETTING_V2="/user/process-api/get-notification-settings-by-device-token-ver2";
    public static final String POST_DEVICE_NOTIFICATION_SETTING_V2="/user/process-api/configure-notification-settings-ver2";
    public static final String ACTIVE_NOTIFICATION_FIELD_V2="/user/process-api/active-notifications";
    public static final String SEND_FEEDBACK="/user/process-api/save-user-feedback";
    public static final String APP_UPDATE="/user/process-api/get-app-store-version-by-device";

	public static final String POSITION = "position";
	public static final String USERNAME = "username";
	public static final String PASSWORD = "password";
	public static final String ROOT_TAG = "root";
	public static final String ITEM_TAG = "item";
	public static final int MAX_LINES = 2;
	public static final String IS_INDICES_FRAGMENT = "indices";
	public static final String MARKET_SUB_CAT = "subcat";
	public static final String AD_REFERER = "ArticleDetails";
	public static final String SEARCH_BTN_VISIBLE = "search";
     
	//demo only http://cmstest.webdunia.net
	// live url http://www.business-standard.com/

    public static final int START_NEW_ACTIVTY = 55;

	public static interface SettingsKeys {
		int FAVOURITES = 0;
		int ACCOUNT_SETTINGS = 1;
		int OFFERS_PROMOTIONS = 2;
		int LOGOUT = 3;
		String CLICKED_ITEM = "settingsItem";
		String POSITION = "position";

	}
	
	public static interface SelectedCat {
		String CATEGORY = "selectedCat";
	}

	public static interface NewsData {
		String NEWS_ID = "id";
		String NEWS_TITLE = "title";
		String NEWS_AUTHOR = "author";
		String NEWS_DATETIME = "datetime";
		String NEWS_URL = "newsurl";
		String NEWS_IMAGE_URL = "imageurl";
		String NEWS_BRIEF_DESCRIPTION = "shortDescription";
		String NEWS_DESCRIPTION = "newscontent";
		String IS_PAID = "ispaid";
		String SHORT_URL="shorturl";
		String Short_Disc="shortDescription";
		String Author_Thumb_Url="authorThumbUrl";
		String Author_Big_Image_Url="authorBigImgUrl";
		String Section="section";
		String Key ="key";
	}
	
	public static interface FeedUrl {
		String HOME_URL = "url";
		String TODAYS_PAPER_URL = "url";
	}
	
	public static interface SelectedCategory {
		String SELECTED_CATEGORY = "selectedCat"; 
	}

	public static interface MarketKeys {
		int STOCKS = 0;
		int MARKET_NEWS = 1;
		int INDICES = 2;
		int COMMODITIES = 3;
		String MARKETNEWS = "Market News";
		String MARKET_ACTIVITY = "MarketActivity";
		String LAUNCH_MARKET = "launch_market";
	}

	public static interface BundleKeys {
		String NEWS_ITEM_POSITION = "position";
		String NEWS_ID = "id";
		String NEWS_ITEM_POS_TAG = "itempos";
		String IS_FAV_FRAGMENT = "favorites";
		String SELECTED_CAT_NAME = "category";
	}
	
	public static interface Sections {
		int HOME = 1;
		int MARKET = 2;
		int TODAYS = 3;
	}

	public static interface RootFragment {
		int HOME = 1;
		int RELATED_ARTICLES = 2;
	}

	public static interface ChangePercentType {
		int POSITIVE = 1;
		int NEGATIVE = 2;
		int EXCEPTION = 3;
	}

	public static interface ViewpagerScrollType{
		int PREVIOUS = 1;
		int NEXT = 2;
	}

	public static interface SearchStock{
		String SEARCH_STOCK_URL ="stock_url";
	}
	private static ArrayList<CompanyStockNewsFeed> compny_list_items ;

	public static ArrayList<CompanyStockNewsFeed> getCompny_list_items() {
		return compny_list_items;
	}

	public static void setCompny_list_items(
			ArrayList<CompanyStockNewsFeed> compny_list_items) {
		Constants.compny_list_items = compny_list_items;
	}

	public interface CompanyKeys {
		String POSITION = "position";
	}
	public interface CommentsKeys{

		String COMMENT_ID = "commentid";
		String AUTO_NO ="autono";
		String	USER_NAME ="username";
		String	COMMENTS ="comments";
		String PUBLISH ="publish";
		String CDATE ="cdate";
		String	NTYPE ="ntype";
		String	IP ="ip";

		String COMM_TAG =	"comm";
	}
	public interface BonzaiZoneIds{
		int SPLASH_SCREEN = 1350;
		int MAST_HEAD =1351;
		int COMMON = 1349;
	}
	
	public interface AdType {
		String INTERSTIAL = "Ad.INTERSTIAL_AD";
		String BANNER = "Ad.BANNER_AD";
		String ASSORTED = "Ad.ASSORTED_AD";
	}

}
