/**
   Project      : Economist
   Filename     : TodaysPaperNewsFeedObject.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.todayspaper.dto;

import java.util.ArrayList;

/**
 * @author lenesha
 *
 */
public class TodaysPaperNewsFeedObject {
	public ArrayList<TodaysPaperItem> section;

}
