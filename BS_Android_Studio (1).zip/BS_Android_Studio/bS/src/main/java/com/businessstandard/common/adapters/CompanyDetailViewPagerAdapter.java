/**
   Project      : Economist
   Filename     : AccountSettingsActivity.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */
package com.businessstandard.common.adapters;

import java.lang.ref.WeakReference;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebView.FindListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.util.Constants.ChangePercentType;
import com.businessstandard.common.util.Utility;
import com.businessstandard.market.dto.CompanyStockNewsFeed;
/**
 * 
 * @author poojarani
 *
 */

public class CompanyDetailViewPagerAdapter extends PagerAdapter implements OnClickListener{

	private List<CompanyStockNewsFeed> mCompDetList;
	private OnNseNotAvailListener mOnNseNotAvailListener;
	private OnBseNotAvailListener mOnBseNotAvailListener;
	private boolean mIsIndices;
	private Context mContext; 
	private WeakReference<FragmentActivity> mActivity;

	public interface  OnNseNotAvailListener {
		public void onNseDataNotAvailable();
	}

	public interface OnBseNotAvailListener {
		public void onBseDataNotAvailable();
	}

	public CompanyDetailViewPagerAdapter(FragmentActivity activity, List<CompanyStockNewsFeed> mCompanyDetlist, boolean isIndicesFrag) {
		mCompDetList = mCompanyDetlist;
		mIsIndices = isIndicesFrag;
		mActivity = new WeakReference<FragmentActivity>(activity);
		mContext = activity;
		mOnNseNotAvailListener = (OnNseNotAvailListener) activity;
		mOnBseNotAvailListener = (OnBseNotAvailListener) activity;
	}

	@Override
	public int getCount() {
		return mCompDetList.size();
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == ((View) arg1);
	}

	class ViewHolder {
		TextView compnyNameView;
		TextView bseNseLabel;
		TextView time;
		TextView date;
		TextView price;
		ImageView img;
		TextView changePrcntg;
		TextView volume;
		TextView prevClose;
		TextView high;
		TextView fivetwoweekHigh;
		TextView open;
		TextView low;
		TextView fivetwoweekLow;
		TextView marketCapLabel;
		TextView marketCap;
		WebView cmpnyIntradayCsv;
		Button nseButton, bseButton;
		Button menu;

	}

	@Override
	public Object instantiateItem(ViewGroup container, int position) {
		android.view.LayoutInflater inflater = (android.view.LayoutInflater) container.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		View view = inflater.inflate(R.layout.companydetails_content, null);
		ViewHolder holder = new ViewHolder();
		holder.compnyNameView = (TextView)view.findViewById(R.id.company_name);
		holder.bseNseLabel = (TextView)view.findViewById(R.id.cmpny_bse_nse_label);
		holder.time = (TextView)view.findViewById(R.id.cmpny_time_sharemrkt);
		holder.date = (TextView)view.findViewById(R.id.cmpny_date_sharemrkt);

		holder.price = (TextView)view.findViewById(R.id.cmpny_price);
		holder.img = (ImageView)view.findViewById(R.id.cmpny_sensex_img);
		holder.changePrcntg = (TextView)view.findViewById(R.id.cmpny_changeperctg);
		holder.nseButton = (Button)view.findViewById(R.id.nse_button);
		holder.bseButton  = (Button)view.findViewById(R.id.bse_button);

		holder.volume = (TextView)view.findViewById(R.id.volume_data);
		holder.prevClose = (TextView)view.findViewById(R.id.per_cl_data);
		holder.high = (TextView)view.findViewById(R.id.high_data);
		holder.fivetwoweekHigh = (TextView)view.findViewById(R.id.fivetwoweek_high_data);
		holder.open = (TextView)view.findViewById(R.id.open_data);
		holder.low = (TextView)view.findViewById(R.id.low_data);
		holder.fivetwoweekLow = (TextView)view.findViewById(R.id.fivetwoweek_low_data);
//		holder.menu=(Button)view.findViewById(R.id.menu);
//		holder.menu.setVisibility(View.GONE);

		if(!mIsIndices) {
			holder.marketCapLabel = (TextView) view.findViewById(R.id.market_cap_label);
			holder.marketCapLabel.setVisibility(View.VISIBLE);
			holder.marketCap = (TextView)view.findViewById(R.id.market_cap_data);
			holder.marketCap.setVisibility(View.VISIBLE);
			holder.cmpnyIntradayCsv = (WebView)view.findViewById(R.id.cmpny_intradaycsv);
			holder.cmpnyIntradayCsv.setVisibility(View.VISIBLE);
		}

		holder.nseButton.setOnClickListener(this);
		holder.bseButton.setOnClickListener(this);
		holder.nseButton.setTag(position);
		holder.bseButton.setTag(position);
		holder.nseButton.setTag(R.string.sensex_position_tag, holder);
		holder.bseButton.setTag(R.string.sensex_position_tag,holder);

		showNSeDetails(holder, position);

		((ViewPager) container).addView(view,0);

		return view;
	}

	private void showNSeDetails(ViewHolder holder, int position) {

		holder.bseButton.setBackgroundResource(R.drawable.btn_toggle_bse_normal);

		if(mCompDetList.get(position).nsestock != null) {

			if(mCompDetList.get(position).nsestock.coName == null )
			{
				mOnNseNotAvailListener.onNseDataNotAvailable();
				showBSEDetails(holder, position);

			}
			else
			{
				holder.nseButton.setBackgroundResource(R.drawable.btn_toggle_nse_pressed);
				holder.compnyNameView.setText(mCompDetList.get(position).nsestock.coName);
				holder.bseNseLabel.setText("NSE");			

				String updated_time = mCompDetList.get(position).nsestock.updateTime;
				Date dateTime = Utility.getUpdatedDate(updated_time);
				holder.time.setText(Utility.getTimeFromDate(dateTime));
				holder.date.setText(Utility.getDate(dateTime));			

				int valueType = checkPercent(mCompDetList.get(position).nsestock.changePercent);


				try {
					Float priceValue = Float.valueOf(mCompDetList.get(position).nsestock.price);
					holder.price.setText(mContext.getResources().getString(R.string.rs)+ " " + mCompDetList.get(position).nsestock.price);

				} catch (NumberFormatException e) {
					holder.price.setText(mContext.getResources().getString(R.string.rs)+ " " + "0.0");

				}
				try {
					Float chngValue = Float.valueOf(mCompDetList.get(position).nsestock.changeValue);
					holder.changePrcntg.setText(mCompDetList.get(position).nsestock.changeValue);

				} catch (NumberFormatException e) {
					holder.changePrcntg.setText("0.0");

				}
				try {
					Float chngprcnt = Float.valueOf(mCompDetList.get(position).nsestock.changePercent);
					holder.changePrcntg.append("  "+mCompDetList.get(position).nsestock.changePercent+"%");

				} catch (NumberFormatException e) {
					holder.changePrcntg.append("  "+"0.0%");

				}
				setPercentvalue(valueType, holder);

				if(mCompDetList.get(position).nsestock.volume !=null && mCompDetList.get(position).nsestock.volume.length() >0)
					holder.volume.setText(":  " +mCompDetList.get(position).nsestock.volume);
				else
					holder.volume.setText(":  " +" -");	

				holder.prevClose.setText(":  " + mCompDetList.get(position).nsestock.prevClose);
				holder.high.setText(":  " +mCompDetList.get(position).nsestock.high);
				holder.fivetwoweekHigh.setText(":  " +mCompDetList.get(position).nsestock.prev52weekHigh);

				if(mCompDetList.get(position).nsestock.dayOpen != null && mCompDetList.get(position).nsestock.dayOpen.length() > 0)
					holder.open.setText(":  " +mCompDetList.get(position).nsestock.dayOpen);
				else
					holder.open.setText(":  " + " -");

				holder.low.setText(":  " +mCompDetList.get(position).nsestock.low);
				holder.fivetwoweekLow.setText(":  " +mCompDetList.get(position).nsestock.prev52weekLow);
				if(!mIsIndices) {
					holder.marketCap.setText(":  " +mCompDetList.get(position).nsestock.marketCap);
					holder.cmpnyIntradayCsv.loadUrl(mCompDetList.get(position).nsestock.intradayCSVPath);
				}
			}
		} else {
			mOnNseNotAvailListener.onNseDataNotAvailable();
			showBSEDetails(holder, position);

		}

	}

	/**
	 * @param valueType
	 * @param holder
	 */
	private void setPercentvalue(int valueType, ViewHolder holder) {
		switch(valueType) {
		case ChangePercentType.POSITIVE: 
			holder.price.setTextColor(mContext.getResources().getColor(R.color.ticker_green));
			holder.changePrcntg.setTextColor(mContext.getResources().getColor(R.color.ticker_green));
			holder.img.setBackgroundResource(R.drawable.arrow_green);
			break;

		case ChangePercentType.NEGATIVE:
			holder.price.setTextColor(mContext.getResources().getColor(R.color.ticker_red));
			holder.changePrcntg.setTextColor(mContext.getResources().getColor(R.color.ticker_red));
			holder.img.setBackgroundResource(R.drawable.arrow_red);
			break;

		case ChangePercentType.EXCEPTION:
			holder.price.setTextColor(mContext.getResources().getColor(R.color.black));
			holder.changePrcntg.setTextColor(mContext.getResources().getColor(R.color.black));
			holder.img.setBackgroundResource(R.drawable.arrow_green);

			break;
		}
	}

//	/**
//	 * @param position
//	 * @return
//	 */
	private int checkPercent(String changePercent) {
		try {
			float percentVal = Float.valueOf(changePercent);
			if(percentVal >= 0) {
				return ChangePercentType.POSITIVE;

			} else {
				return ChangePercentType.NEGATIVE;
			}
		} catch(NumberFormatException exception) {
			return ChangePercentType.EXCEPTION;
		}
	}

	private void showBSEDetails(final ViewHolder holder, int position) {

		holder.nseButton.setBackgroundResource(R.drawable.btn_toggle_nse_normal);
		holder.bseButton.setOnClickListener(this);

		if(mCompDetList.get(position).bsestock != null) {
			if(mCompDetList.get(position).bsestock.coName == null )
			{
				mOnBseNotAvailListener.onBseDataNotAvailable();
				showNSeDetails(holder, position);
			}
			else
			{
				holder.bseButton.setBackgroundResource(R.drawable.btn_toggle_bse_pressed);
				holder.compnyNameView.setText(mCompDetList.get(position).bsestock.coName);
				holder.bseNseLabel.setText("BSE");			 

				String updated_time = mCompDetList.get(position).bsestock.updateTime;
				Date dateTime = Utility.getUpdatedDate(updated_time);			
				holder.time.setText(Utility.getTimeFromDate(dateTime));
				holder.date.setText(Utility.getDate(dateTime));			

				int valueType = checkPercent(mCompDetList.get(position).bsestock.changePercent);

				try {
					Float priceValue = Float.valueOf(mCompDetList.get(position).bsestock.price);
					holder.price.setText(mContext.getResources().getString(R.string.rs)+ " " + mCompDetList.get(position).bsestock.price);

				} catch (NumberFormatException e) {
					holder.price.setText(mContext.getResources().getString(R.string.rs)+ " " + "0.0");

				}
				try {
					Float chngValue = Float.valueOf(mCompDetList.get(position).bsestock.changeValue);
					holder.changePrcntg.setText(mCompDetList.get(position).bsestock.changeValue);

				} catch (NumberFormatException e) {
					holder.changePrcntg.setText("0.0");

				}
				try {
					Float chngprcnt = Float.valueOf(mCompDetList.get(position).bsestock.changePercent);
					holder.changePrcntg.append("  "+mCompDetList.get(position).bsestock.changePercent+"%");

				} catch (NumberFormatException e) {
					holder.changePrcntg.append("  "+"0.0%");

				}
				setPercentvalue(valueType, holder);

				if(mCompDetList.get(position).bsestock.volume !=null && mCompDetList.get(position).bsestock.volume.length() >0)
					holder.volume.setText(":  " +mCompDetList.get(position).bsestock.volume);
				else
					holder.volume.setText(":  " +" -");	

				holder.prevClose.setText(":  " +mCompDetList.get(position).bsestock.prevClose);
				holder.high.setText(":  " +mCompDetList.get(position).bsestock.high);
				holder.fivetwoweekHigh.setText(":  " +mCompDetList.get(position).bsestock.prev52weekHigh);
				holder.open.setText(":  " +mCompDetList.get(position).bsestock.dayOpen);
				holder.low.setText(":  " +mCompDetList.get(position).bsestock.low);
				holder.fivetwoweekLow.setText(":  " +mCompDetList.get(position).bsestock.prev52weekLow);
				if(!mIsIndices) {
					holder.marketCap.setText(":  " +mCompDetList.get(position).bsestock.marketCap);	
					if(mCompDetList.get(position).bsestock.intradayCSVPath != null) {
//						
						holder.cmpnyIntradayCsv.loadUrl(mCompDetList.get(position).bsestock.intradayCSVPath);
						
					}
				}
			}
		} else {
			mOnBseNotAvailListener.onBseDataNotAvailable();
			showNSeDetails(holder, position);

		}

	}

	@Override
	public void destroyItem(View container, int position, Object object) {
		((ViewPager) container).removeView((View) object);
	}

	@Override
	public void onClick(View v) {
		int pos = (Integer) v.getTag();
		ViewHolder holder = (ViewHolder) v.getTag(R.string.sensex_position_tag);
		switch (v.getId()) {
		case R.id.nse_button:
			showNSeDetails(holder, pos);
			break;
		case R.id.bse_button:
			showBSEDetails(holder, pos);
			break;
		default:
			break;
		}		
	}


}
