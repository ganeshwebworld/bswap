/**
   Project      : Economist
   Filename     : BseNseNewsItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.market.dto;

import com.google.gson.annotations.SerializedName;

/**
 * @author lenesha
 *
 */
public class BseNseNewsItem extends StockHolder{

	@SerializedName("co_code")
	public int coCode;

	@SerializedName("co_name")
	public String coName;

	 @SerializedName("lname")
	 public String lastName;

	@SerializedName("price")
	public String price;

	 @SerializedName("open")
	 public String dayOpen;
	
	 @SerializedName("prev_close")
	 public String prevClose;

	@SerializedName("chnge")
	public String changeValue;

	@SerializedName("per_chnge")
	public String changePercent;

	 @SerializedName("high")
	 public String high;
	
	 @SerializedName("low")
	 public String low;
	
	 @SerializedName("updated_time")
	 public String updateTime;
	
	 @SerializedName("volume")
	 public String volume;
	
	 @SerializedName("52_wk_high")
	 public String prev52weekHigh;
	
	 @SerializedName("52_wk_low")
	 public String prev52weekLow;
	
	 @SerializedName("market_cap")
	 public String marketCap;
	
	@SerializedName("IntradayCSV")
	public String intradayCSVPath;

	 @SerializedName("archiveCSV")
	 public String archiveCSVPath;

}
