/**
 * Project      : Economist
 * Filename     : MenuLIst.java
 * Author       : android
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.common.ui;

import android.app.ActivityOptions;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.home.ui.HomeFragment;
import com.businessstandard.todayspaper.ui.TodaysPaperFragment;

import java.util.ArrayList;

/**
 * @author android
 */
public class MenuLIst extends BaseActivity {

    ListView list;
    private ArrayList<String> lvMenuItemsNew;
    TextView date;
    RelativeLayout layout;
    String TAG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menulist);
        //android O fix bug orientation
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }

        layout = (RelativeLayout) findViewById(R.id.layout);
        layout.setVisibility(View.GONE);

        list = (ListView) findViewById(R.id.menulistview);

        TAG = getIntent().getStringExtra("TAGNAME");

        if (MainFragmentActivity.maincat != null && MainFragmentActivity.maincat.equals("Todays paper")) {
            Intent animActivity = new Intent(MenuLIst.this, SwitchmenuList.class);
            animActivity.putExtra("Tag", "Today's Paper");
            animActivity.putExtra("newTag", TAG);
            animActivity.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            date = (TextView) findViewById(R.id.header_name);
            date.setText(selectedItem);
            startActivity(animActivity);
        }

        lvMenuItemsNew = HomeFragment.mSubCategoryList;

        if (lvMenuItemsNew != null) {
            Menulsitadaper adapert = new Menulsitadaper(getApplicationContext(), lvMenuItemsNew);
            list.setAdapter(adapert);
        } else {
            Toast.makeText(getApplicationContext(), "unable to download list ", Toast.LENGTH_SHORT).show();
        }

        list.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                onMenuItemClickView(parent, view, position, id);
            }
        });

    }

    private void onMenuItemClickView(AdapterView<?> parent, View view, int position, long id) {

        String selectedItem = lvMenuItemsNew.get(position);

        if (selectedItem.equals("Market Data")) {
            Intent i = new Intent(MenuLIst.this, MainFragmentActivity.class);
            if (selectedItem.equals("Home")){
                selectedItem = "Top Stories";
            }
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            i.putExtra("MainCat", "Market");
            i.putExtra("SabCat", selectedItem);
            startActivity(i);
            this.finish();
        } else if (!selectedItem.equals("Today's Paper") && !selectedItem.equals("Market Data")) {
            Intent i = new Intent(MenuLIst.this, MainFragmentActivity.class);
            if (selectedItem.equals("Home")){
                selectedItem = "Top Stories";
            }
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            i.putExtra("MainCat", "Home");
            i.putExtra("SabCat", selectedItem);
            startActivity(i);
            this.finish();
        } else {
            Intent animActivity = new Intent(MenuLIst.this, SwitchmenuList.class);
            animActivity.putExtra("Tag", selectedItem);
            animActivity.putExtra("newTag", TAG);
            animActivity.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            date = (TextView) findViewById(R.id.header_name);
            date.setText(selectedItem);
            Bundle bndlanimation = ActivityOptions.makeCustomAnimation(getApplicationContext(), R.anim.lefttoright, R.anim.righttoleft).toBundle();
            MenuLIst.this.overridePendingTransition(R.anim.leftright, R.anim.rightleft);
            if (TodaysPaperFragment.mSubCategoryList != null) {
                startActivityForResult(animActivity, 2, bndlanimation);
                finish();
            } else {
                Toast.makeText(getApplicationContext(), "unable to download list for todays paper", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
