/**
   Project      : Economist
   Filename     : EconomistDatabaseHelper.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.common.util;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.businessstandard.common.dto.SubNewsItem;
/**
 * @author lenesha
 *
 */
	public class EconomistDatabaseHelper extends SQLiteOpenHelper {

		private static String DATABASE_NAME = "Economist_Database";
		private static int DATABASE_VERSION = 1;

		public static int COL_TITLE = 0;
		public static int COL_NEWS_LINK = 1;
		public static int COL_AUTHOR = 2;
		public static int COL_STORYIMAGEURL = 3;
		public static int COL_DESC = 4;
		public static int COL_DATE = 5;
		public static int COL_GUID = 6;
		public static int COL_PAID = 7;
		public static int COL_DES = 8;

		public static int WEATHER_COL_CITY = 0;
		public static int WEATHER_COL_ISINDIAN = 1;

		private static String FAVOURITIES_TABLE_NAME = "FavouritiesTable";
		private static String F_NEWS_TITLE = "title";
		private static String F_NEWS_LINK = "link";
		private static String F_NEWS_AUTHOR = "author";
		private static String F_NEWS_STORYIMAGEURL = "storyimageurl";
		private static String F_NEWS_DESC = "desc";
		private static String F_NEWS_DATE = "date";
		private static String F_NEWS_ID = "newsId";
		private static String F_NEWS_Paid = "isPaid";
		private static String F_SHORT_DES = "short_des";

		

		private static EconomistDatabaseHelper mSelfInstance = null;

		private static final String CREATE_FAVOUTITES_TABLE = "CREATE TABLE " + FAVOURITIES_TABLE_NAME + " ( "
				+ F_NEWS_TITLE + " , " + F_NEWS_LINK + " , " + F_NEWS_AUTHOR + " , " + F_NEWS_STORYIMAGEURL + " , "
				+ F_NEWS_DESC + ", " + F_NEWS_DATE + " , "+ F_NEWS_ID + ", "+ F_NEWS_Paid+ " , " + F_SHORT_DES + " );";

		
		public EconomistDatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		public synchronized static EconomistDatabaseHelper getInstance(Context context) {
			if (mSelfInstance == null)
				mSelfInstance = new EconomistDatabaseHelper(context);
			Log.d("DB", " getInstance(Context context)");
			return mSelfInstance;
		}

		public synchronized static EconomistDatabaseHelper getInstance() {
			
			return mSelfInstance;
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			Log.d("DB", " onCreate");
			db.execSQL(CREATE_FAVOUTITES_TABLE);
		
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.d("DB", " onUpgrade");
			db.execSQL("DROP TABLE IF EXISTS " + FAVOURITIES_TABLE_NAME);
			
			onCreate(db);
		}

		public long addFavouritNewsItem1(SubNewsItem  favoritesItem) {
			String sql = "SELECT * FROM " + FAVOURITIES_TABLE_NAME + " WHERE " + F_NEWS_TITLE + " = ?";
			Cursor queryresult = getWritableDatabase().rawQuery(sql, new String[] { favoritesItem.title });
			if (queryresult.moveToFirst()) {
				queryresult.close();
			} else {
				queryresult.close();
				ContentValues newsItem = new ContentValues();
				newsItem.put(F_NEWS_TITLE, favoritesItem.title);
				newsItem.put(F_NEWS_LINK, favoritesItem.newsUrl);
				newsItem.put(F_NEWS_AUTHOR, favoritesItem.author);
				newsItem.put(F_NEWS_STORYIMAGEURL, favoritesItem.imageUrl);
				newsItem.put(F_NEWS_DESC, favoritesItem.newscontent);
				newsItem.put(F_NEWS_DATE, favoritesItem.dateTime);
				newsItem.put(F_NEWS_ID, favoritesItem.newsId);
				newsItem.put(F_NEWS_Paid, favoritesItem.ispaid);
				newsItem.put(F_SHORT_DES, favoritesItem.briefDescription);
				
				return getWritableDatabase().insert(FAVOURITIES_TABLE_NAME, null, newsItem);
			}
			return 0;
		}
		
/*		public long addFavouritNewsItem1(SubNewsItem  favoritesItem,Boolean isPaidUser) {
			String sql = "SELECT * FROM " + FAVOURITIES_TABLE_NAME + " WHERE " + F_NEWS_TITLE + " = ?";
			Cursor queryresult = getWritableDatabase().rawQuery(sql, new String[] { favoritesItem.title });
			if (queryresult.moveToFirst()) {
				queryresult.close();
				ContentValues newsItem = new ContentValues();
				newsItem.put(F_NEWS_LINK, favoritesItem.newsUrl);
				newsItem.put(F_NEWS_AUTHOR, favoritesItem.author);
				newsItem.put(F_NEWS_STORYIMAGEURL, favoritesItem.imageUrl);
				newsItem.put(F_NEWS_DESC, favoritesItem.newscontent);
				newsItem.put(F_NEWS_DATE, favoritesItem.dateTime);
				newsItem.put(F_NEWS_ID, favoritesItem.newsId);
				if(isPaidUser)
				{
					newsItem.put(F_NEWS_Paid, "N");
				}
				else
				{
					newsItem.put(F_NEWS_Paid, favoritesItem.ispaid);
				}
				
				newsItem.put(F_SHORT_DES, favoritesItem.briefDescription);
				return getWritableDatabase().update(FAVOURITIES_TABLE_NAME,newsItem,F_NEWS_TITLE+"=\'"+favoritesItem.title+"\'", null);
				
			} else {
				queryresult.close();
				ContentValues newsItem = new ContentValues();
				newsItem.put(F_NEWS_TITLE, favoritesItem.title);
				newsItem.put(F_NEWS_LINK, favoritesItem.newsUrl);
				newsItem.put(F_NEWS_AUTHOR, favoritesItem.author);
				newsItem.put(F_NEWS_STORYIMAGEURL, favoritesItem.imageUrl);
				newsItem.put(F_NEWS_DESC, favoritesItem.newscontent);
				newsItem.put(F_NEWS_DATE, favoritesItem.dateTime);
				newsItem.put(F_NEWS_ID, favoritesItem.newsId);
				if(isPaidUser)
				{
					newsItem.put(F_NEWS_Paid, "N");
				}
				else
				{
					newsItem.put(F_NEWS_Paid, favoritesItem.ispaid);
				}
				
				newsItem.put(F_SHORT_DES, favoritesItem.briefDescription);
				
				return getWritableDatabase().insert(FAVOURITIES_TABLE_NAME, null, newsItem);
			}
			
		}
*/

		public int removeFavouriteNewsItem(String title) {
			
			return getWritableDatabase().delete(FAVOURITIES_TABLE_NAME, F_NEWS_TITLE + " = ?", new String[] { title });
		}

		public Cursor getFavouriteNewsItems() {

			Cursor newsItemsCursor;
			newsItemsCursor = getReadableDatabase().query(FAVOURITIES_TABLE_NAME, null, null, null, null, null, null);

			if (newsItemsCursor == null) {
				return null;
			} else if (!newsItemsCursor.moveToFirst()) {
				newsItemsCursor.close();
				return null;
			}
			return newsItemsCursor;
		}

		
		public boolean isInFavorites(String title) {
			String s[] = new String[1];
			s[0] = title;
			String sql = "SELECT * FROM " + FAVOURITIES_TABLE_NAME + " WHERE " + F_NEWS_TITLE + " = ?";
			Cursor newsItem = getWritableDatabase().rawQuery(sql, s);
			if (newsItem == null) {
				return false;
			} else if (!newsItem.moveToFirst()) {
				newsItem.close();
				return false;
			}
			newsItem.close();
			return true;
		}

		
	}