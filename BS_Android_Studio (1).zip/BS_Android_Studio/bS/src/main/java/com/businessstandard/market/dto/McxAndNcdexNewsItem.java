/**
   Project      : Economist
   Filename     : McxAndNcdexNewsItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.market.dto;

import com.google.gson.annotations.SerializedName;

/**
 * @author lenesha
 *
 */
public class McxAndNcdexNewsItem {
	@SerializedName("Symbol")
	private String mSymbol;
	
	@SerializedName("Expiry Date")
	private String mExpiryDate;
	
	@SerializedName("Price")
	private String mPrice;
	
	@SerializedName("Change Percentage")
	private String mChangePercent;

	public String getmSymbol() {
		return mSymbol;
	}

	public String getmExpiryDate() {
		return mExpiryDate;
	}

	public String getmPrice() {
		return mPrice;
	}

	public String getmChangePercent() {
		return mChangePercent;
	}
}
