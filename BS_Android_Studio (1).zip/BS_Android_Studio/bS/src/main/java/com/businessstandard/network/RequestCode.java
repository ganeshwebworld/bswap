package com.businessstandard.network;

/**
 * Created by mayank.paryani on 08-10-2018.
 */

public interface RequestCode {
    int GET_CONFIG = 0;
    int GET_VIDEOS_TAB = 1;
    int GET_VIDEOS_DETAILS = 2;
}

