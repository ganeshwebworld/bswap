/**
   Project      : Economist
   Filename     : ButtonWidget.java
   Author       : nchauhan
   Comments     : 
   Copyright    : Copyright? 2011, Business Standard Ltd . All rights reserved
				  Modified under contract by Robosoft Technologies Pvt. Ltd.
   History      : NA
*/

package com.businessstandard.common.util;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Button;

/**
 * @author nchauhan
 *
 */
public class ButtonWidget extends Button {

	/**
	 * @param context
	 * @param attrs
	 * @param defStyle
	 */
	public ButtonWidget(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
	}

}
