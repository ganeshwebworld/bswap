/**
   Project      : Economist
   Filename     : BaseConnectionManager.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.common.io;

/**
 * @author lenesha
 *
 */
public class BaseConnectionManager {

}
