/**
   Project      : Economist
   Filename     : MarketsManager.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */
package com.businessstandard.market;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.util.Log;

import com.businessstandard.R;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.io.ParserManager;
import com.businessstandard.common.manager.BaseManager.CallbackListener;
import com.businessstandard.common.manager.BaseManager.SubNewsDloadCmpltListener;
import com.businessstandard.common.manager.BaseManager.TickerDloadCmpltListener;
import com.businessstandard.common.util.Utility;
import com.businessstandard.market.dto.BseStockDataItem;
import com.businessstandard.market.dto.McxAndNcdexRootFeedItem;
import com.businessstandard.market.dto.McxFutureRootFeedItem;
import com.businessstandard.market.dto.McxLoosersRootFeedItem;
import com.businessstandard.market.dto.McxSpotRootFeedItem;
import com.businessstandard.market.dto.NcdexFutureRootFeedItem;
import com.businessstandard.market.dto.NcdexGainersRootFeedItem;
import com.businessstandard.market.dto.NcdexLoosersRootFeedItem;
import com.businessstandard.market.dto.NcdexSpotRootFeedItem;
import com.businessstandard.market.dto.NseStockDataItem;
import com.businessstandard.market.dto.TickerNewsFeedRootObject;
import com.businessstandard.market.io.MarketsConnectionManager;

/**
 * @author lenesha
 *
 */
public class MarketsManager {

	private MarketsConnectionManager mConnectionManager;
	private WeakReference<FragmentActivity> mActivity;
	private ParserManager mParserManager;
	String sectionNewsItem;
	public static String newdataMarket=null;
	public static ArrayList<SubNewsItem> newsItemListNew = new ArrayList<SubNewsItem>();
	
	/**
	 * @param activity
	 */
	public MarketsManager(FragmentActivity activity) {
		mConnectionManager = new MarketsConnectionManager(
				activity.getApplicationContext());
		mActivity = new WeakReference<FragmentActivity>(activity);
		mParserManager = new ParserManager();
	}

	public void downloadNewsFeedData(
			SubNewsDloadCmpltListener subNewsDloadCmpltListener, String feedUrl) {
		NewsFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new NewsFeedDownloaderTask(subNewsDloadCmpltListener);
			task.execute(feedUrl);
		} else {
			Utility.displayAlert(mActivity.get(), R.string.app_name, R.string.no_connection, android.R.string.ok,
					Utility.getOkButtonListener(mActivity.get()));
		}
	}

	public class NewsFeedDownloaderTask extends
	AsyncTask<String, String, ArrayList<SubNewsItem>> {
		SubNewsDloadCmpltListener subNewsDloadCmpltListener;

		public NewsFeedDownloaderTask(
				SubNewsDloadCmpltListener subNewsDloadCmpltListener) {
			this.subNewsDloadCmpltListener = subNewsDloadCmpltListener;
		}

		@Override
		protected ArrayList<SubNewsItem> doInBackground(String... params) {
			String url = params[0];
			if(newdataMarket==null){
			sectionNewsItem = mConnectionManager.getSubNewsFeeds(url);
	        newdataMarket=sectionNewsItem;
			}else{
				sectionNewsItem=newdataMarket;
			}
			ArrayList<SubNewsItem> newsItemList = null;
			if (sectionNewsItem != null && newsItemListNew.size()<=0){
				newsItemList = mParserManager
				.getListOfnewsItem(sectionNewsItem);
			return newsItemList;
			}
			else{
				newsItemList=newsItemListNew;
				return newsItemList;
			}
		}

		@Override
		protected void onPostExecute(ArrayList<SubNewsItem> result) {
			super.onPostExecute(result);
			Log.i("", "" + result);
			if (result != null){
				subNewsDloadCmpltListener.onSubNewsDloadComplete(result);
			newsItemListNew=result;
			}
			else {
				subNewsDloadCmpltListener.onFailure();
			}
		}
	}

	public void donwloadTickerValues(
			TickerDloadCmpltListener tickerdnloadlistener) {
		TickerFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);

			task = new TickerFeedDownloaderTask(tickerdnloadlistener);
			task.execute();
		} 
	}

	public class TickerFeedDownloaderTask extends
	AsyncTask<Void, Void, TickerNewsFeedRootObject> {
		TickerDloadCmpltListener tickerdnloadlistener;

		public TickerFeedDownloaderTask(
				TickerDloadCmpltListener tickerdnloadlistener) {
			this.tickerdnloadlistener = tickerdnloadlistener;
		}

		@Override
		protected TickerNewsFeedRootObject doInBackground(Void... params) {
			TickerNewsFeedRootObject tickerFeed = mConnectionManager
					.getTickerFeeds();
			return tickerFeed;
		}

		@Override
		protected void onPostExecute(TickerNewsFeedRootObject result) {
			super.onPostExecute(result);
			if(tickerdnloadlistener != null) {
				if(result != null && result.root != null) {
					tickerdnloadlistener.onTickerDloadCmplt(result);

				} else {
					tickerdnloadlistener.onFailure();
				}
			}
		}

	}
	public  interface SensexDloadCmpltListener extends CallbackListener {
		void OnCompanySearchDloadCmplt(BseStockDataItem[] result);
	}

	/**
	 * @param sensexDloadCmpltListener
	 * @param nseTopGainersurl
	 */
	public void downloadSensexGainersLoosers(
			SensexDloadCmpltListener sensexDloadCmpltListener,
			String nseTopGainersurl) {
		SemsexFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new SemsexFeedDownloaderTask(sensexDloadCmpltListener);
			task.execute(nseTopGainersurl);
		} 
	}
	
	public class SemsexFeedDownloaderTask extends
	AsyncTask<String, String, BseStockDataItem[]> {
		SensexDloadCmpltListener SensexDloadCmpltListener;
		/**
		 * @param sensexDloadCmpltListener
		 */
		public SemsexFeedDownloaderTask(
				SensexDloadCmpltListener SensexDloadCmpltListener) {
			this.SensexDloadCmpltListener= SensexDloadCmpltListener;
		}

		/* (non-Javadoc)
		 * @see android.os.AsyncTask#doInBackground(Params[])
		 */
		@Override
		protected BseStockDataItem[] doInBackground(String... params) {
			String url = params[0];
			BseStockDataItem[] newsFeed =	mConnectionManager.getBSESensexFeeds(url);
			return newsFeed;
		}
		
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(BseStockDataItem[] result) {
			super.onPostExecute(result);
			if(SensexDloadCmpltListener != null) {
				if(result != null && result.length > 0)
					SensexDloadCmpltListener.OnCompanySearchDloadCmplt(result);
				else
					SensexDloadCmpltListener.onFailure();
			}
		}

	}

	public  interface NSESensexDloadCmpltListener extends CallbackListener {
		void OnCompanySearchDloadCmplt(NseStockDataItem[] result);
	}

	/**
	 * @param sensexDloadCmpltListener
	 * @param nseTopGainersurl
	 */
	public void nseDownloadSensexGainersLoosers(
			NSESensexDloadCmpltListener sensexDloadCmpltListener,
			String nseTopGainersurl) {
		NSESensexFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new NSESensexFeedDownloaderTask(sensexDloadCmpltListener);
			task.execute(nseTopGainersurl);
		} else {
			Utility.displayAlert(mActivity.get(), mActivity.get()
					.getString(R.string.app_name), mActivity.get()
					.getString(R.string.no_connection), android.R.string.ok,
					Utility.getOkButtonListener(mActivity.get()));
		}
	}
	public class NSESensexFeedDownloaderTask extends
	AsyncTask<String, String, NseStockDataItem[]> {
		NSESensexDloadCmpltListener sensexDloadCmpltListener;
		/**
		 * @param sensexDloadCmpltListener2
		 */
		public NSESensexFeedDownloaderTask(
				NSESensexDloadCmpltListener sensexDloadCmpltListener2) {
			sensexDloadCmpltListener = sensexDloadCmpltListener2;
		}

		/* (non-Javadoc)
		 * @see android.os.AsyncTask#doInBackground(Params[])
		 */
		@Override
		protected NseStockDataItem[] doInBackground(String... params) {
			String url = params[0];
			NseStockDataItem[] newsFeed =	mConnectionManager.getNSESensexFeeds(url);
			return newsFeed;
		}
		
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(NseStockDataItem[] result) {
			super.onPostExecute(result);
			if(sensexDloadCmpltListener != null) {
				if(result != null && result.length > 0)
					sensexDloadCmpltListener.OnCompanySearchDloadCmplt(result);
				else 
					sensexDloadCmpltListener.onFailure();
			}
		}

	}

	public  interface McxGainersDloadCmpltListener extends CallbackListener {
		void onCompanySearchDloadCmplt(McxAndNcdexRootFeedItem result);
	}

	public  interface McxLoosersDloadCmpltListener extends CallbackListener {
		void onCompanySearchDloadCmplt(McxLoosersRootFeedItem result);
	}
	public  interface NcdexGainersDloadCmpltListener extends CallbackListener {
		void onCompanySearchDloadCmplt(NcdexGainersRootFeedItem result);
	}
	public  interface NcdexLoosersDloadCmpltListener extends CallbackListener {
		void onCompanySearchDloadCmplt(NcdexLoosersRootFeedItem result);
	}

	public  interface McxSpotDloadCmpltListener extends CallbackListener {
		void onCompanySearchDloadCmplt(McxSpotRootFeedItem result);
	}
	public  interface NcdexSpotDloadCmpltListener extends CallbackListener {
		void onCompanySearchDloadCmplt(NcdexSpotRootFeedItem result);
	}
	public  interface McxFutureDloadCmpltListener extends CallbackListener {
		void onCompanySearchDloadCmplt(McxFutureRootFeedItem result);
	}
	public  interface NcdexFutureDloadCmpltListener extends CallbackListener {
		void onCompanySearchDloadCmplt(NcdexFutureRootFeedItem result);
	}
	/**
	 * @param DloadCmpltListener
	 * @param url
	 */
	public void mcxGainersDownload(
			McxGainersDloadCmpltListener DloadCmpltListener,
			String url) {
		McxGainersFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new McxGainersFeedDownloaderTask(DloadCmpltListener);
			task.execute(url);
		} else {
			Utility.displayAlert(mActivity.get(), mActivity.get()
					.getString(R.string.app_name), mActivity.get()
					.getString(R.string.no_connection), android.R.string.ok,
					Utility.getOkButtonListener(mActivity.get()));
		}
	}
	public class McxGainersFeedDownloaderTask extends
	AsyncTask<String, String, McxAndNcdexRootFeedItem> {
		McxGainersDloadCmpltListener DloadCmpltListener;
		/**
		 * @param sensexDloadCmpltListener2
		 */
		public McxGainersFeedDownloaderTask(
				McxGainersDloadCmpltListener DloadCmpltListener) {
			this.DloadCmpltListener = DloadCmpltListener;
		}



		/* (non-Javadoc)
		 * @see android.os.AsyncTask#doInBackground(Params[])
		 */
		@Override
		protected McxAndNcdexRootFeedItem doInBackground(String... params) {
			String url = params[0];
			McxAndNcdexRootFeedItem newsFeed =	mConnectionManager.getMcxGainersFeeds(url);
			return newsFeed;
		}
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(McxAndNcdexRootFeedItem result) {
			super.onPostExecute(result);
			if(DloadCmpltListener != null) {
				if(result != null && result.root != null) {
					DloadCmpltListener.onCompanySearchDloadCmplt(result);

				} else {
					DloadCmpltListener.onFailure();
				}
			}
		}

	}

	/**
	 * @param DloadCmpltListener
	 * @param url
	 */
	public void mcxLoosersDownload(
			McxLoosersDloadCmpltListener DloadCmpltListener,
			String url) {
		McxLoosersFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new McxLoosersFeedDownloaderTask(DloadCmpltListener);
			task.execute(url);
		} 
	}
	public class McxLoosersFeedDownloaderTask extends
	AsyncTask<String, String, McxLoosersRootFeedItem> {
		McxLoosersDloadCmpltListener DloadCmpltListener;
		/**
		 * @param sensexDloadCmpltListener2
		 */
		public McxLoosersFeedDownloaderTask(
				McxLoosersDloadCmpltListener DloadCmpltListener) {
			this.DloadCmpltListener = DloadCmpltListener;
		}

		/* (non-Javadoc)
		 * @see android.os.AsyncTask#doInBackground(Params[])
		 */
		@Override
		protected McxLoosersRootFeedItem doInBackground(String... params) {
			String url = params[0];
			McxLoosersRootFeedItem newsFeed =	mConnectionManager.getMcxLoosersFeeds(url);
			return newsFeed;
		}
		
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(McxLoosersRootFeedItem result) {
			super.onPostExecute(result);
			if(DloadCmpltListener != null) {
				if(result != null && result.root != null) {
					DloadCmpltListener.onCompanySearchDloadCmplt(result);

				} else {
					DloadCmpltListener.onFailure();
				}
			}		
		}

	}

	/**
	 * @param DloadCmpltListener
	 * @param url
	 */
	public void NcdexGainersDownload(
			NcdexGainersDloadCmpltListener DloadCmpltListener,
			String url) {
		NcdexGainersFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new NcdexGainersFeedDownloaderTask(DloadCmpltListener);
			task.execute(url);
		} 
	}
	public class NcdexGainersFeedDownloaderTask extends
	AsyncTask<String, String, NcdexGainersRootFeedItem> {
		NcdexGainersDloadCmpltListener DloadCmpltListener;
		/**
		 * @param sensexDloadCmpltListener2
		 */
		public NcdexGainersFeedDownloaderTask(
				NcdexGainersDloadCmpltListener DloadCmpltListener) {
			this.DloadCmpltListener = DloadCmpltListener;
		}



		/* (non-Javadoc)
		 * @see android.os.AsyncTask#doInBackground(Params[])
		 */
		@Override
		protected NcdexGainersRootFeedItem doInBackground(String... params) {
			String url = params[0];
			NcdexGainersRootFeedItem newsFeed =	mConnectionManager.getNcdexGainersFeeds(url);
			return newsFeed;
		}
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(NcdexGainersRootFeedItem result) {
			super.onPostExecute(result);
			if(DloadCmpltListener != null) {
				if(result != null && result.root != null) {
					DloadCmpltListener.onCompanySearchDloadCmplt(result);

				} else {
					DloadCmpltListener.onFailure();
				}
			}		
		}

	}

	/**
	 * @param DloadCmpltListener
	 * @param url
	 */
	public void NcdexLoosersDownload(
			NcdexLoosersDloadCmpltListener DloadCmpltListener,
			String url) {
		NcdexLoosersFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new NcdexLoosersFeedDownloaderTask(DloadCmpltListener);
			task.execute(url);
		} 
	}
	public class NcdexLoosersFeedDownloaderTask extends
	AsyncTask<String, String, NcdexLoosersRootFeedItem> {
		NcdexLoosersDloadCmpltListener DloadCmpltListener;
		/**
		 * @param sensexDloadCmpltListener2
		 */
		public NcdexLoosersFeedDownloaderTask(
				NcdexLoosersDloadCmpltListener DloadCmpltListener) {
			this.DloadCmpltListener = DloadCmpltListener;
		}

		/* (non-Javadoc)
		 * @see android.os.AsyncTask#doInBackground(Params[])
		 */
		@Override
		protected NcdexLoosersRootFeedItem doInBackground(String... params) {
			String url = params[0];
			NcdexLoosersRootFeedItem newsFeed =	mConnectionManager.getNcdexLoosersFeeds(url);
			return newsFeed;
		}
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(NcdexLoosersRootFeedItem result) {
			super.onPostExecute(result);
			if(DloadCmpltListener != null) {
				if(result != null && result.root != null) {
					DloadCmpltListener.onCompanySearchDloadCmplt(result);

				} else {
					DloadCmpltListener.onFailure();
				}
			}		
		}

	}

	/**
	 * @param DloadCmpltListener
	 * @param url
	 */
	public void mcxSpotDownload(
			McxSpotDloadCmpltListener DloadCmpltListener,
			String url) {
		McxSpotFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new McxSpotFeedDownloaderTask(DloadCmpltListener);
			task.execute(url);
		} 
	}
	public class McxSpotFeedDownloaderTask extends
	AsyncTask<String, String, McxSpotRootFeedItem> {
		McxSpotDloadCmpltListener DloadCmpltListener;
		/**
		 * @param sensexDloadCmpltListener2
		 */
		public McxSpotFeedDownloaderTask(
				McxSpotDloadCmpltListener DloadCmpltListener) {
			this.DloadCmpltListener = DloadCmpltListener;
		}

		/* (non-Javadoc)
		 * @see android.os.AsyncTask#doInBackground(Params[])
		 */
		@Override
		protected McxSpotRootFeedItem doInBackground(String... params) {
			String url = params[0];
			McxSpotRootFeedItem newsFeed =	mConnectionManager.getMcxSpotFeeds(url);
			return newsFeed;
		}
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(McxSpotRootFeedItem result) {
			super.onPostExecute(result);
			if(DloadCmpltListener != null) {
				if(result != null && result.root != null) {
					DloadCmpltListener.onCompanySearchDloadCmplt(result);

				} else {
					DloadCmpltListener.onFailure();
				}
			}		
		}

	}

	/**
	 * @param DloadCmpltListener
	 * @param url
	 */
	public void NcdexSpotDownload(
			NcdexSpotDloadCmpltListener DloadCmpltListener,
			String url) {
		NcdexSpotFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new NcdexSpotFeedDownloaderTask(DloadCmpltListener);
			task.execute(url);
		}
	}
	public class NcdexSpotFeedDownloaderTask extends
	AsyncTask<String, String, NcdexSpotRootFeedItem> {
		NcdexSpotDloadCmpltListener DloadCmpltListener;
		/**
		 * @param sensexDloadCmpltListener2
		 */
		public NcdexSpotFeedDownloaderTask(
				NcdexSpotDloadCmpltListener DloadCmpltListener) {
			this.DloadCmpltListener = DloadCmpltListener;
		}



		/* (non-Javadoc)
		 * @see android.os.AsyncTask#doInBackground(Params[])
		 */
		@Override
		protected NcdexSpotRootFeedItem doInBackground(String... params) {
			String url = params[0];
			NcdexSpotRootFeedItem newsFeed =	mConnectionManager.getNcdexSpotFeeds(url);
			return newsFeed;
		}
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(NcdexSpotRootFeedItem result) {
			super.onPostExecute(result);
			if(DloadCmpltListener != null) {
				if(result != null && result.root != null) {
					DloadCmpltListener.onCompanySearchDloadCmplt(result);

				} else {
					DloadCmpltListener.onFailure();
				}
			}		
		}

	}


	/**
	 * @param DloadCmpltListener
	 * @param url
	 */
	public void mcxFutureDownload(
			McxFutureDloadCmpltListener DloadCmpltListener,
			String url) {
		McxFutureFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new McxFutureFeedDownloaderTask(DloadCmpltListener);
			task.execute(url);
		} 
	}
	public class McxFutureFeedDownloaderTask extends
	AsyncTask<String, String, McxFutureRootFeedItem> {
		McxFutureDloadCmpltListener DloadCmpltListener;
		/**
		 * @param sensexDloadCmpltListener2
		 */
		public McxFutureFeedDownloaderTask(
				McxFutureDloadCmpltListener DloadCmpltListener) {
			this.DloadCmpltListener = DloadCmpltListener;
		}

		/* (non-Javadoc)
		 * @see android.os.AsyncTask#doInBackground(Params[])
		 */
		@Override
		protected McxFutureRootFeedItem doInBackground(String... params) {
			String url = params[0];
			McxFutureRootFeedItem newsFeed =	mConnectionManager.getMcxFutureFeeds(url);
			return newsFeed;
		}
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(McxFutureRootFeedItem result) {
			super.onPostExecute(result);
			if(DloadCmpltListener != null) {
				if(result != null && result.root != null) {
					DloadCmpltListener.onCompanySearchDloadCmplt(result);

				} else {
					DloadCmpltListener.onFailure();
				}
			}		
		}

	}


	/**
	 * @param DloadCmpltListener
	 * @param url
	 */
	public void NcdexFutureDownload(
			NcdexFutureDloadCmpltListener DloadCmpltListener,
			String url) {
		NcdexFutureFeedDownloaderTask task;
		if (Utility.isInternetOn(mActivity.get())) {
			Utility.displayProgressDailog(mActivity.get(), R.string.loading);
			task = new NcdexFutureFeedDownloaderTask(DloadCmpltListener);
			task.execute(url);
		}
	}
	public class NcdexFutureFeedDownloaderTask extends
	AsyncTask<String, String, NcdexFutureRootFeedItem> {
		NcdexFutureDloadCmpltListener DloadCmpltListener;
		/**
		 * @param sensexDloadCmpltListener2
		 */
		public NcdexFutureFeedDownloaderTask(
				NcdexFutureDloadCmpltListener DloadCmpltListener) {
			this.DloadCmpltListener = DloadCmpltListener;
		}



		/* (non-Javadoc)
		 * @see android.os.AsyncTask#doInBackground(Params[])
		 */
		@Override
		protected NcdexFutureRootFeedItem doInBackground(String... params) {
			String url = params[0];
			NcdexFutureRootFeedItem newsFeed =	mConnectionManager.getNcdexFutureFeeds(url);
			return newsFeed;
		}
		/* (non-Javadoc)
		 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
		 */
		@Override
		protected void onPostExecute(NcdexFutureRootFeedItem result) {
			super.onPostExecute(result);
			if(DloadCmpltListener != null) {
				if(result != null && result.root != null) {
					DloadCmpltListener.onCompanySearchDloadCmplt(result);

				} else {
					DloadCmpltListener.onFailure();
				}
			}		
		}

	}
}