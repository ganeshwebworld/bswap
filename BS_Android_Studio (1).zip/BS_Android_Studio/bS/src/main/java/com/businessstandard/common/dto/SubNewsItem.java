/**
   Project      : Economist
   Filename     : SubNewsItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.common.dto;

import org.json.JSONException;
import org.json.JSONObject;

import android.R.bool;

import com.businessstandard.common.util.Constants.NewsData;
import com.businessstandard.todayspaper.ui.TodaysPaperFragment;

import java.io.Serializable;

/**
 * @author lenesha
 *
 */
public class SubNewsItem implements Serializable {

	public String newsId;

	public String title;

	public String author;

	public String city;

	public String dateTime;

	public String newsUrl;

	public String imageUrl;

	public String briefDescription;

	public String newscontent;
	public String key;
	
	public String ispaid;
	public String auhorThumbUrl;
	public String authorBigImageUrl;
	public String Section;
	
	public String short_url;
	
	public String shortDescription;
	

	public void init(JSONObject object) {
		try {
			if (object.has(NewsData.NEWS_ID)) {
				newsId = object.getString(NewsData.NEWS_ID);
			}
			if (object.has(NewsData.NEWS_TITLE)) {
				title = object.getString(NewsData.NEWS_TITLE);
			}
			if (object.has(NewsData.NEWS_AUTHOR)) {
				author = object.getString(NewsData.NEWS_AUTHOR);
			}
			if (object.has(NewsData.NEWS_DATETIME)) {
				dateTime = object.getString(NewsData.NEWS_DATETIME);
			}
			if (object.has(NewsData.NEWS_URL)) {
				newsUrl = object.getString(NewsData.NEWS_URL);
			}
			if (object.has(NewsData.NEWS_IMAGE_URL)) {
				imageUrl = object.getString(NewsData.NEWS_IMAGE_URL);
			}
			if (object.has(NewsData.NEWS_BRIEF_DESCRIPTION)) {
				briefDescription = object
						.getString(NewsData.NEWS_BRIEF_DESCRIPTION);
			}
			if (object.has(NewsData.NEWS_DESCRIPTION)) {
				newscontent = object.getString(NewsData.NEWS_DESCRIPTION);
			}
			if (object.has(NewsData.SHORT_URL)) {
				short_url = object.getString(NewsData.SHORT_URL);
			}
			if(object.has(NewsData.Author_Big_Image_Url)){
				authorBigImageUrl=object.getString(NewsData.Author_Big_Image_Url);
				
			}
			if(object.has(NewsData.Author_Thumb_Url)){
				auhorThumbUrl=object.getString(NewsData.Author_Thumb_Url);
				
			}
			if(object.has(NewsData.Section)){
				Section=object.getString(NewsData.Section);
				
			}
			if(object.has(NewsData.Key)){
				key=object.getString(NewsData.Key);
				
			}
			if (object.has(NewsData.IS_PAID)||object.has("is_paid")) {
				//ispaid="N";
				ispaid = object.getString(NewsData.IS_PAID);
			}
			
			
			if (object.has(NewsData.Short_Disc)) {
				shortDescription = object.getString(NewsData.Short_Disc);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

}
