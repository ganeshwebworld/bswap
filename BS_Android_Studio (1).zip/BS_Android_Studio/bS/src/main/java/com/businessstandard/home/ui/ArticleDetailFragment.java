/**
 * Project      : Economist
 * Filename     : ArticleDetailFragment.java
 * Author       : poojarani
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */

package com.businessstandard.home.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebSettings.ZoomDensity;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.ui.BaseActivity;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.util.Constants.BundleKeys;
import com.businessstandard.common.util.Constants.ViewpagerScrollType;
import com.businessstandard.common.util.EconomistDatabaseHelper;
import com.businessstandard.common.util.FragmentHelper;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.adapters.ArticleViewPagerAdapter;
import com.businessstandard.analytics.GoogleAnalytics;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author poojarani
 */
public class ArticleDetailFragment extends BaseFragment implements OnClickListener {

    private OnNewslistAvailabelListener mOnNewslistAvailabelListener;
    private ArrayList<SubNewsItem> mNewsList;
    private ViewPager mArticleViewpager;
    private ArticleViewPagerAdapter mPagerAdapter;
    //private AdManager mAdManager;
    // private BonzaiAdView mFooterAdHolder;
    private RelativeLayout mFooterAdHolder;
    public static RelativeLayout buttonView;
    private int mSelectdArticlPosition, mCurrentViewpagerPos;
    private Button mFavBtn, mPrevBtn, mNextbtn;
    public static Button mSubscribeNow, mLoginNow, forgotpass;
    public static RelativeLayout mainLayout;
    private boolean mIsFavFrag;
    private String mSelectedCategory;
    private Context mContext;
    private String strAdDown;
    private String strAdUp;
    private WebView webview;
    public static ImageView image;
    public static TextView text;
    PopupWindow feedbackwindow;
    File file;
    String tgpref;
    // String newid;
    String enddate;
    String user_id;
    String password;
    String tillDate;
    String email;
    String pass;
    //String tilldate;
    String apiToken = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
    String subscription;
    TextView tv;
    public static LinearLayout buttomlayout;
    private GoogleAnalytics mGoogleAnalytics;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;
        mOnNewslistAvailabelListener = (OnNewslistAvailabelListener) getActivity();
    }

    public interface OnNewslistAvailabelListener {
        public ArrayList<SubNewsItem> onNewsListAvail();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.business_article, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        initView(view);
    }

    private void initView(View view) {
        buttomlayout = (LinearLayout) view.findViewById(R.id.bottomlayout);
        tv = (TextView) view.findViewById(R.id.newtext);
        mArticleViewpager = (ViewPager) view.findViewById(R.id.pager);
        mFooterAdHolder = (RelativeLayout) view.findViewById(R.id.footer_ad_holder);
        buttonView = (RelativeLayout) view.findViewById(R.id.buttonView);
        mSubscribeNow = (Button) view.findViewById(R.id.subscribeNow);
        forgotpass = (Button) view.findViewById(R.id.forgot);
        mLoginNow = (Button) view.findViewById(R.id.loginNow);
        image = (ImageView) view.findViewById(R.id.paidcontent);
        text = (TextView) view.findViewById(R.id.textnew);
        String fileDirPath = getActivity().getFilesDir() + "/userinfo.json";
        file = new File(fileDirPath);
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        tgpref = preferences.getString("value", "-1");

        // long timestamp=1401786354;
        if (tgpref.equals("N")) {
            tillDate = preferences.getString("Enddate", "-1");
            if (tillDate.length() == 13) {
                long value = Long.parseLong(tillDate);
                long newdate = (value / 1000);
                tillDate = String.valueOf(newdate);

            }
            if (tillDate.equals("0")) {
                email = preferences.getString("user_email", null);
                pass = preferences.getString("pass", null);
                RegisterUser signuptask = new RegisterUser(mContext);
                signuptask.execute(apiToken, email, pass);
            } else if (!tillDate.equals("-1")) {
                tillDate = preferences.getString("Enddate", "-1");
                // tilldate="1401786354";
                try {
                    long tillDatelong = Long.parseLong(tillDate);
                    Date date = new Date(tillDatelong * 1000L); // *1000 is to
                    // convert seconds
                    // to milliseconds
                    Date datenew = new Date();
                    SimpleDateFormat sdf = new SimpleDateFormat(
                            "MM/dd/yyyy HH:mm:ss z"); // the format of your date
// sdf.setTimeZone(TimeZone.getTimeZone("GMT-5:30"));
                    String enddate = sdf.format(tillDatelong);
                    String currentDate = sdf.format(datenew);
                    System.out.println(enddate + currentDate);
                    Date d1 = null;
                    Date d2 = null;


                    try {
                        d1 = sdf.parse(currentDate);
                        d2 = sdf.parse(enddate);

// in milliseconds
                        long diff = d2.getTime() - d1.getTime();
//
// long diffSeconds = diff / 1000 % 60;
// long diffMinutes = diff / (60 * 1000) % 60;
// long diffHours = diff / (60 * 60 * 1000) % 24;
                        long diffDays = diff / (24 * 60 * 60 * 1000);
                        if (diffDays <= 3) {
                            email = preferences.getString("user_email", null);
                            pass = preferences.getString("pass", null);
                            RegisterUser signuptask = new RegisterUser(mContext);
                            signuptask.execute(apiToken, email, pass);
                        }
                        System.out.print(diffDays + " days, ");
// System.out.print(diffHours + " hours, ");
// System.out.print(diffMinutes + " minutes, ");
// System.out.print(diffSeconds + " seconds.");

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } catch (Exception e) {
                    // TODO: handle exception
                }
                // long unixSeconds = 1401786354;
            }
        }


        // enddate=preferences.getString("Enddate", null);
        // user_id=preferences.getString("user_email", null);
        // password=preferences.getString("pass", null);
        // Calendar cal=Calendar.getInstance();
        // cal.set(Calendar.DAY_OF_MONTH, enddate-2);
        // mainLayout=(RelativeLayout)view.findViewById(R.id.buttonView);
        // LoadPaymentGateway.web.addJavascriptInterface(this, "HTMLOUT");
        tv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(getActivity(), KnowMore.class);
                startActivity(intent);
            }
        });

        forgotpass.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utility.isInternetOn(mContext)) {
                    Intent intent = new Intent(getActivity(), Forgotpass.class);
                    startActivity(intent);
                } else {
                    Utility.showToast(getString(R.string.no_connection), mContext);
                }
            }
        });

        mLoginNow.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Utility.isInternetOn(mContext)) {
                    Intent intent = new Intent(getActivity(), LoginNowActivity.class);
                    startActivityForResult(intent, 1);
                } else {
                    Utility.showToast(getString(R.string.no_connection), mContext);
                }
            }
        });

        mSubscribeNow.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                if (Utility.isInternetOn(mContext)) {
                    SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
                    String newid = preferences.getString("newvalue", null);
                    if (file.exists()) {
                        Intent intent = new Intent(getActivity(), PaymentDialog.class);
                        intent.putExtra("value", newid);
                        startActivityForResult(intent, 2);
                    } else {
                        Intent intent = new Intent(getActivity(), RegisterNowActivity.class);
                        startActivityForResult(intent, 5);
                    }
                } else {
                    Utility.showToast(getString(R.string.no_connection), mContext);
                }
            }
        });

        webview = (WebView) view.findViewById(R.id.webView);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webview.getSettings().setLoadWithOverviewMode(true);
        webview.getSettings().setBuiltInZoomControls(false);
        webview.setHorizontalScrollBarEnabled(false);
        webview.getSettings().setDomStorageEnabled(true);
        webview.getSettings().setAllowFileAccess(true);
        webview.getSettings().setLoadsImagesAutomatically(true);
        webview.getSettings().setSupportZoom(false);
        webview.setInitialScale(100);
        webview.getSettings().setDefaultZoom(ZoomDensity.FAR);
        webview.getSettings().setUserAgentString("Safari/534.30 Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 ");
        webview.getSettings().setSaveFormData(true);
        // webview.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        // webview.loadUrl("file:///android_asset/new test.html");
//		webview.loadUrl("file:///android_asset/ComScore.html");
        @SuppressWarnings("static-access")
        Display d = ((WindowManager) Objects.requireNonNull(mContext.getSystemService(mContext.WINDOW_SERVICE))).getDefaultDisplay();
        int width = d.getWidth();

        if (width >= 220 && width < 260) {
            webview.loadUrl("file:///android_asset/Ads_down240.html");
            mFooterAdHolder.addView(webview);
        } else if (width >= 300 && width < 340) {
            webview.loadUrl("file:///android_asset/Ads_down320.html");
            mFooterAdHolder.removeAllViews();
            mFooterAdHolder.addView(webview);

        } else if (width >= 450 && width < 490) {
            mFooterAdHolder.removeAllViews();
            webview.loadUrl("file:///android_asset/Ads_down468.html");
            mFooterAdHolder.addView(webview);

        } else if (width >= 590 && width < 700) {
            mFooterAdHolder.removeAllViews();
            webview.loadUrl("file:///android_asset/Ads_down600.html");
            mFooterAdHolder.addView(webview);

        } else if (width >= 700 && width < 730) {
            mFooterAdHolder.removeAllViews();
            webview.getSettings().setUseWideViewPort(false);
            webview.loadUrl("file:///android_asset/Ads_down720.html");
            mFooterAdHolder.addView(webview);

        } else if (width >= 730 && width < 770) {
            mFooterAdHolder.removeAllViews();
            webview.loadUrl("file:///android_asset/Ads_down768.html");
            mFooterAdHolder.addView(webview);

        } else if (width >= 770 && width <= 800) {
            mFooterAdHolder.removeAllViews();
            webview.loadUrl("file:///android_asset/Ads_down800.html");
            mFooterAdHolder.addView(webview);

        } else if (width >= 1000) {
            mFooterAdHolder.removeAllViews();
            webview.loadUrl("file:///android_asset/Ads_down1024.html");
            mFooterAdHolder.addView(webview);

        } else {
            mFooterAdHolder.removeAllViews();
            webview.loadUrl("file:///android_asset/Ads_down468.html");
            mFooterAdHolder.addView(webview);
        }

        this.strAdDown = BaseActivity.lwrAds;
        this.strAdUp = BaseActivity.upAds;
        if (strAdDown.equalsIgnoreCase("true")) {
            mFooterAdHolder.setVisibility(View.VISIBLE);
        } else {
            mFooterAdHolder.setVisibility(View.GONE);
        }

        view.findViewById(R.id.rel_article).setOnClickListener(this);
        view.findViewById(R.id.share_btn).setOnClickListener(this);
        view.findViewById(R.id.cmmts_btn).setOnClickListener(this);
        mFavBtn = (Button) view.findViewById(R.id.fav_btn);
        mFavBtn.setOnClickListener(this);
        mPrevBtn = (Button) view.findViewById(R.id.prev_btn);
        mPrevBtn.setOnClickListener(this);
        mNextbtn = (Button) view.findViewById(R.id.next_btn);

        mNextbtn.setOnClickListener(this);
        mArticleViewpager.setVerticalFadingEdgeEnabled(false);
        mFooterAdHolder.setHorizontalFadingEdgeEnabled(false);
        mFooterAdHolder.setVerticalFadingEdgeEnabled(false);

        assert getArguments() != null;
        mSelectdArticlPosition = getArguments().getInt(BundleKeys.NEWS_ITEM_POSITION);
        mIsFavFrag = getArguments().getBoolean(BundleKeys.IS_FAV_FRAGMENT);
        mSelectedCategory = getArguments().getString(BundleKeys.SELECTED_CAT_NAME);
        // if(mSelectedCategory.equals("Opinion")){
        // code added By Satish
        // enable only if Subscription implemented

        // buttonView.setVisibility(View.VISIBLE);
        // }
        // buttonView.setVisibility(View.VISIBLE);
        if (file.exists()) {
            mLoginNow.setVisibility(View.GONE);
        } else {
            mLoginNow.setVisibility(View.VISIBLE);
        }
        mCurrentViewpagerPos = mSelectdArticlPosition;
    }

    @Override
    public void onResume() {
        try {
            String fileDirPath = mContext.getFilesDir() + "/userinfo.json";
            File file = new File(fileDirPath);
            //uncomment this code in case of paid version and delete else remaining  code gaurav diwaker
            if (file.exists()) {
                if (!TextUtils.isEmpty(tgpref) && tgpref.equals("N")) {
                    image.setVisibility(View.GONE);
                    text.setVisibility(View.GONE);
                    buttonView.setVisibility(View.GONE);
                    mLoginNow.setVisibility(View.GONE);
                    forgotpass.setVisibility(View.GONE);
                    mSubscribeNow.setVisibility(View.GONE);
                    if (mArticleViewpager != null && mPagerAdapter != null) {
                        int position = mArticleViewpager.getCurrentItem();
                        mArticleViewpager.setAdapter(mPagerAdapter);
                        mArticleViewpager.setCurrentItem(position);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onResume();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //mAdManager = new AdManager();
        initHeaderAds();
        mNewsList = mOnNewslistAvailabelListener.onNewsListAvail();

        if (mNewsList != null && mNewsList.size() > 0) {
            mPagerAdapter = new ArticleViewPagerAdapter(getActivity(), mNewsList, mSelectdArticlPosition);
//			if (mNewsList.get(mSelectdArticlPosition).ispaid!=null) {
            // mArticleViewpager.setOffscreenPageLimit(0);
            // ArticleViewPagerAdapter.count=1;
            //String ddnd=mNewsList.get(mSelectdArticlPosition).ispaid;
            if (mNewsList.get(mSelectdArticlPosition).ispaid.equals("Y")) {
                // count=2;
                String fileDirPath = mContext.getFilesDir() + "/userinfo.json";
                File file = new File(fileDirPath);
                //uncomment this code in case of paid version and delete else remaining  code gaurav diwaker
                if (file.exists()) {

                    if (tgpref.equals("N")) {
                        image.setVisibility(View.GONE);
                        text.setVisibility(View.GONE);
                        buttonView.setVisibility(View.GONE);
                        mLoginNow.setVisibility(View.GONE);
                        forgotpass.setVisibility(View.GONE);
                        mSubscribeNow.setVisibility(View.GONE);
                    } else {
                        //						image.setVisibility(View.GONE);
                        //						text.setVisibility(View.GONE);
                        //						buttonView.setVisibility(View.GONE);
                        //						mLoginNow.setVisibility(View.GONE);
                        //						forgotpass.setVisibility(View.GONE);
                        //						mSubscribeNow.setVisibility(View.GONE);
                        image.setVisibility(View.VISIBLE);
                        text.setVisibility(View.VISIBLE);
                        mSubscribeNow.setVisibility(View.VISIBLE);
                        buttonView.setVisibility(View.VISIBLE);
                        mLoginNow.setVisibility(View.GONE);
                        forgotpass.setVisibility(View.GONE);
                    }
                } else {
                    image.setVisibility(View.VISIBLE);
                    text.setVisibility(View.VISIBLE);
                    mSubscribeNow.setVisibility(View.VISIBLE);
                    buttonView.setVisibility(View.VISIBLE);
                    mLoginNow.setVisibility(View.VISIBLE);
                }
            } else {
                image.setVisibility(View.GONE);
                text.setVisibility(View.GONE);
                buttonView.setVisibility(View.GONE);
                mLoginNow.setVisibility(View.GONE);
            }
			/*}else {
				image.setVisibility(View.GONE);
				text.setVisibility(View.GONE);
				buttonView.setVisibility(View.GONE);
				mLoginNow.setVisibility(View.GONE);

			}*/
            mArticleViewpager.setAdapter(mPagerAdapter);

            // Initialize the first visible item in viewpager
            initFirstItemOfViewPager();

            mArticleViewpager.setOnPageChangeListener(new OnPageChangeListener() {
                @Override
                public void onPageSelected(int position) {
                    /*
                     * mAdManager.displayStartUpInterstitialAd(
                     * mFooterAdHolder, BonzaiZoneIds.COMMON,
                     * Constants.AD_REFERER);
                     */
                    // mPagerAdapter.notifyDataSetChanged();
                    mFavBtn.setBackgroundResource(R.drawable.icon_bookmark);
                    //AnalyticsUtils.getInstAnalyticsUtils(getActivity()).trackPageView(mSelectedCategory + mNewsList.get(position).newsId + mNewsList.get(position).title);
                    if (mGoogleAnalytics != null && getActivity() != null) {
                        mGoogleAnalytics.trackScreenView(mSelectedCategory + mNewsList.get(position).newsId + mNewsList.get(position).title, getActivity());
                    }

                    mCurrentViewpagerPos = position;

                    boolean isFav = getFavoriteStatus(mNewsList.get(position));
                    if (isFav) {
                        mFavBtn.setBackgroundResource(R.drawable.icon_bookmark_selected);
                    }
                    if (position == 0) {
                        mPrevBtn.setBackgroundResource(R.drawable.img_previous_disabled);
                    } else {
                        mPrevBtn.setBackgroundResource(R.drawable.img_previous_selected);
                    }

                    if (position == (mNewsList.size() - 1)) {
                        mNextbtn.setBackgroundResource(R.drawable.img_next_disabled);
                        if (getActivity() != null)
                            Utility.showToast(getString(R.string.last_article), getActivity());
                    } else {
                        mNextbtn.setBackgroundResource(R.drawable.img_next_selected);

                    }
                    if (mNewsList.get(position).ispaid != null) {
                        if (mNewsList.get(position).ispaid.equals("Y")) {
                            //Article is Paid
                            // count=2;
                            String fileDirPath = mContext.getFilesDir() + "/userinfo.json";
                            File file = new File(fileDirPath);
                            //uncomment this code in case of paid version and delete else remaining  code gaurav diwaker
                            if (file.exists()) {
                                ArticleDetailFragment.mLoginNow.setVisibility(View.GONE);
                                //									 ArticleDetailFragment.image.setBackground(R.drawable.arrow_red);
                                if (tgpref.equals("N")) {
                                    //Article is Paid and User is logged in

                                    image.setVisibility(View.GONE);
                                    text.setVisibility(View.GONE);
                                    buttonView.setVisibility(View.GONE);
                                    mLoginNow.setVisibility(View.GONE);
                                    forgotpass.setVisibility(View.GONE);
                                    mSubscribeNow.setVisibility(View.GONE);
                                } else {
                                    //Article is Paid and No Login

                                    //										image.setVisibility(View.GONE);
                                    //										text.setVisibility(View.GONE);
                                    //										buttonView.setVisibility(View.GONE);
                                    //										mLoginNow.setVisibility(View.GONE);
                                    //										forgotpass.setVisibility(View.GONE);
                                    //										mSubscribeNow.setVisibility(View.GONE);
                                    image.setVisibility(View.VISIBLE);
                                    text.setVisibility(View.VISIBLE);
                                    mSubscribeNow.setVisibility(View.VISIBLE);
                                    buttonView.setVisibility(View.VISIBLE);
                                    mLoginNow.setVisibility(View.GONE);
                                    forgotpass.setVisibility(View.GONE);
                                }
                            } else {
                                //Article is Paid and No Login

                                image.setVisibility(View.VISIBLE);
                                text.setVisibility(View.VISIBLE);
                                mSubscribeNow.setVisibility(View.VISIBLE);
                                buttonView.setVisibility(View.VISIBLE);
                                mLoginNow.setVisibility(View.VISIBLE);
                            }
                        } else {
                            //Article is Free

                            image.setVisibility(View.GONE);
                            text.setVisibility(View.GONE);
                            buttonView.setVisibility(View.GONE);
                            mLoginNow.setVisibility(View.GONE);

                        }
                    } else {
                        //Article is Free

                        image.setVisibility(View.GONE);
                        text.setVisibility(View.GONE);
                        buttonView.setVisibility(View.GONE);
                        mLoginNow.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onPageScrolled(int arg0, float arg1, int arg2) {

                }

                @Override
                public void onPageScrollStateChanged(int arg0) {

                }

            });
        }

        if (mIsFavFrag) {
            mFavBtn.setBackgroundResource(R.drawable.icon_bookmark_selected);
        }

    }

    /**
     *
     */
    private void initFirstItemOfViewPager() {
        if (mSelectdArticlPosition < mNewsList.size()) {

            mArticleViewpager.setCurrentItem(mSelectdArticlPosition);
            //AnalyticsUtils.getInstAnalyticsUtils(getActivity()).trackPageView(mSelectedCategory + mNewsList.get(0).newsId + mNewsList.get(0).title);
            if (mGoogleAnalytics != null && getActivity() != null && mNewsList != null) {
                mGoogleAnalytics.trackScreenView(mSelectedCategory + mNewsList.get(0).newsId + mNewsList.get(0).title, getActivity());
            }
            if (getFavoriteStatus(mNewsList.get(mSelectdArticlPosition))) {
                mFavBtn.setBackgroundResource(R.drawable.icon_bookmark_selected);
            }
            if (mSelectdArticlPosition == 0) {
                mPrevBtn.setBackgroundResource(R.drawable.img_previous_disabled);

            } else {
                mPrevBtn.setBackgroundResource(R.drawable.img_previous_selected);
            }

            if (mSelectdArticlPosition == (mNewsList.size() - 1)) {
                mNextbtn.setBackgroundResource(R.drawable.img_next_disabled);
                if (getActivity() != null)
                    Utility.showToast(getString(R.string.last_article), getActivity());
            } else {
                mNextbtn.setBackgroundResource(R.drawable.img_next_selected);
            }
        }
    }

    private void initHeaderAds() {
        /*
         * mAdManager.displayStartUpInterstitialAd(mFooterAdHolder,
         * BonzaiZoneIds.COMMON, Constants.AD_REFERER);
         */
    }

    private void addNewsItemToFav(SubNewsItem subNewsItem, int isPaidUser) { // if paid user then isPaidUser=1 otherwise 0

        EconomistDatabaseHelper eDataBaseHelper = EconomistDatabaseHelper.getInstance(getActivity().getApplicationContext());

        if (eDataBaseHelper.isInFavorites(subNewsItem.title)) {
            Utility.showToast(getString(R.string.already_fav), getActivity().getApplicationContext());
        } else {
            long newsid;
            if (isPaidUser == 1) {
                newsid = eDataBaseHelper.addFavouritNewsItem1(subNewsItem);
                //newsid = eDataBaseHelper.addFavouritNewsItem1(subNewsItem,true);
            } else {
                newsid = eDataBaseHelper.addFavouritNewsItem1(subNewsItem);
            }
            if (newsid != -1) {
                Utility.showToast(getString(R.string.added_to_fav), getActivity().getApplicationContext());
            }
        }
    }

    private void removeFromFav(SubNewsItem item) {
        EconomistDatabaseHelper eDataBaseHelper = EconomistDatabaseHelper.getInstance(getActivity().getApplicationContext());
        if (eDataBaseHelper.isInFavorites(item.title)) {
            Utility.showToast(getString(R.string.removd_from_fav), getActivity().getApplicationContext());
            mNewsList.remove(item);
            eDataBaseHelper.removeFavouriteNewsItem(item.title);
        }
    }

    /*
     * (non-Javadoc)
     *
     * @see android.view.View.OnClickListener#onClick(android.view.View)
     */
    @Override
    public void onClick(View v) {
        int btnId;
        btnId = v.getId();
        switch (btnId) {

            case R.id.rel_article:
                mCurrentViewpagerPos = mArticleViewpager.getCurrentItem();
                Log.d("ID: ", " " + mCurrentViewpagerPos);
                String id = mNewsList.get(mCurrentViewpagerPos).newsId;
                Bundle bundle = new Bundle();
                bundle.putString(BundleKeys.NEWS_ID, id);
                RelatedStoriesFragment frag = new RelatedStoriesFragment();
                frag.setArguments(bundle);
                FragmentHelper.replaceAndAddContentFragment(Objects.requireNonNull(getActivity()), R.id.realTabContent, frag);
                break;

            case R.id.cmmts_btn:
                mCurrentViewpagerPos = mArticleViewpager.getCurrentItem();
                Log.d("ID: ", " " + mCurrentViewpagerPos);
                String news_id = mNewsList.get(mCurrentViewpagerPos).newsId;
                Bundle bundle1 = new Bundle();
                bundle1.putString(BundleKeys.NEWS_ID, news_id);
                CommentsFragment fragment = new CommentsFragment();
                fragment.setArguments(bundle1);
                FragmentHelper.replaceAndAddContentFragment(Objects.requireNonNull(getActivity()), R.id.realTabContent, fragment);
                break;

            case R.id.share_btn:
                if (Utility.isInternetOn(mContext)) {
                    SubNewsItem newsItem = mNewsList.get(mCurrentViewpagerPos);
                    ShareDialogFragment frgmt = new ShareDialogFragment(newsItem);
                    frgmt.show(Objects.requireNonNull(getActivity()).getSupportFragmentManager(), "share");
                } else {
                    Utility.showToast(getString(R.string.no_connection), mContext);
                }
                break;

            case R.id.fav_btn:
                if (mIsFavFrag) {
                    removeFromFav(mNewsList.get(mCurrentViewpagerPos));
                    mPagerAdapter.notifyDataSetChanged();
                    if ((mNewsList.size() == 0) && isVisible()) {
                        assert getFragmentManager() != null;
                        getFragmentManager().popBackStackImmediate();
                    }
                    //		mFavBtn.setBackgroundResource(R.drawable.icon_bookmark_deselected);

                } else {
                    if ((tgpref != null) && (tgpref.equals("N"))) {
                        addNewsItemToFav(mNewsList.get(mCurrentViewpagerPos), 1);
                    } else {
                        addNewsItemToFav(mNewsList.get(mCurrentViewpagerPos), 0);
                    }
                    mFavBtn.setBackgroundResource(R.drawable.icon_bookmark_selected);

                }
                break;

            case R.id.prev_btn:
                mNextbtn.setBackgroundResource(R.drawable.img_next_selected);
                int prevPosition = getCurrentPosition(ViewpagerScrollType.PREVIOUS);
                mArticleViewpager.setCurrentItem(prevPosition, true);
                if (prevPosition == 0) {
                    mPrevBtn.setBackgroundResource(R.drawable.img_previous_disabled);
                    if (getActivity() != null) {
                        Utility.showToast(getString(R.string.first_article), getActivity());
                    }
                }
                break;

            case R.id.next_btn:
                mPrevBtn.setBackgroundResource(R.drawable.img_previous_selected);
                int nextPosition = getCurrentPosition(ViewpagerScrollType.NEXT);
                mArticleViewpager.setCurrentItem(nextPosition, true);
                if (nextPosition == (mNewsList.size() - 1)) {
                    mNextbtn.setBackgroundResource(R.drawable.img_next_disabled);
                    if (getActivity() != null)
                        Utility.showToast(getString(R.string.last_article), getActivity());
                }
                break;

        }
    }

    /**
     * @author poojarani
     */
    private int getCurrentPosition(int positionType) {
        int currPosition = mArticleViewpager.getCurrentItem();
        switch (positionType) {
            case ViewpagerScrollType.PREVIOUS:
                currPosition--;
                break;
            case ViewpagerScrollType.NEXT:
                currPosition++;
                break;
        }
        return currPosition;
    }

    /**
     * @author poojarani
     */

    private boolean getFavoriteStatus(SubNewsItem subNewsItem) {
        EconomistDatabaseHelper dataBaseHelper = EconomistDatabaseHelper.getInstance(Objects.requireNonNull(getActivity()).getApplicationContext());
        return (dataBaseHelper.isInFavorites(subNewsItem.title));
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        tgpref = preferences.getString("value", "-1");

        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                mPagerAdapter.notifyDataSetChanged();
                if (tgpref.equals("Y")) {
                    String newid = preferences.getString("newvalue", null);
                    Intent intent = new Intent(getActivity(), PaymentDialog.class);
                    intent.putExtra("value", newid);
                    startActivityForResult(intent, 2);
                }
            }
        }
        if (requestCode == 2 || requestCode == 5) {
            if (resultCode == Activity.RESULT_OK) {
                mPagerAdapter.notifyDataSetChanged();
                if (tgpref.equals("Y")) {
                    String newid = preferences.getString("newvalue", null);
                    Intent intent = new Intent(getActivity(), PaymentDialog.class);
                    intent.putExtra("value", newid);
                    startActivityForResult(intent, 2);
                } else if (tgpref.equals("N")) {
                    //Article is Paid and User is logged in
                    buttonView.setVisibility(View.GONE);
                    image.setVisibility(View.GONE);
                    text.setVisibility(View.GONE);
                    mLoginNow.setVisibility(View.GONE);
                    forgotpass.setVisibility(View.GONE);
                    mPagerAdapter.notifyDataSetChanged();
                }
//				if (tgpref.equals("-1")) {
//					buttonView.setVisibility(View.GONE);
//					image.setVisibility(View.GONE);
//					text.setVisibility(View.GONE);
//					mLoginNow.setVisibility(View.GONE);
//					forgotpass.setVisibility(View.GONE);
//					mPagerAdapter.notifyDataSetChanged();
//				}
                else {
                    mLoginNow.setVisibility(View.GONE);
                    forgotpass.setVisibility(View.GONE);
                }
            }

            // if(resultCode == RESULT_OK){
            //
            // }
            // if (resultCode == RESULT_CANCELED) {
            // //Write your code if there's no result
            // }
        }
        if (requestCode == 11) {
            if (resultCode == Activity.RESULT_OK) {
                Toast.makeText(getActivity(), "Password send to your mail id", Toast.LENGTH_LONG).show();
            }
        }
    }

    private class RegisterUser extends AsyncTask<String, String, JSONObject> {

        private final ProgressDialog progressDialog;
        Context ctx;
        String response;

        String errorMessage;

        public RegisterUser(Context context) {
            ctx = context;
            progressDialog = new ProgressDialog(context);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setTitle("Validating..");
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
            // showDialog(DIALOG_DOWNLOAD_PROGRESS);
        }

        @Override
        protected JSONObject doInBackground(String... args) {
            //String strUrl = ctx.getString(R.string.api_base_url) + Constants.SIGN_IN_API;
            SaveSharedPref saveSharedPref = SaveSharedPref.getInstance(mContext);
            String strUrl = "";
            if (saveSharedPref != null && !TextUtils.isEmpty(saveSharedPref.getString(SharedPreferencesKey.KEY_SIGN_IN_API, ""))) {
                strUrl = saveSharedPref.getString(SharedPreferencesKey.KEY_SIGN_IN_API, "");
            }
/*            InputStream is = null;

            JSONParser jsonParser = new JSONParser();
//			List<NameValuePair> params = new ArrayList<NameValuePair>();
//			params.add(new BasicNameValuePair("api_token", args[0]));
//			params.add(new BasicNameValuePair("login_email", args[1]));
//			params.add(new BasicNameValuePair("login_password", args[2]));
            org.apache.commons.httpclient.NameValuePair[] request = {
                    new org.apache.commons.httpclient.NameValuePair(
                            "api_token", args[0]),
                    new org.apache.commons.httpclient.NameValuePair("login_email",
                            args[1]),
                    new org.apache.commons.httpclient.NameValuePair("login_password",
                            args[2])};
            JSONObject json = null;
            try {
                json = new JSONObject(jsonParser.callWebservice(request, strUrl));
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return json;*/

            OkHttpClient client = new OkHttpClient();
            JSONObject json = null;

            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("api_token", args[0])
                    .addFormDataPart("login_email", args[1])
                    .addFormDataPart("login_password", args[2])
                    .build();

            Request request = new Request.Builder()
                    .url(strUrl)
                    .post(requestBody)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                try {
                    assert response.body() != null;
                    json = new JSONObject(response.body().string());
                    return json;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onProgressUpdate(String... progress) {
            super.onProgressUpdate(progress);
        }

        protected void onPostExecute(JSONObject json) {
            progressDialog.cancel();
            StringBuilder sb = new StringBuilder();
            String status = null;
            JSONObject id = null;

            try {
                id = json.getJSONObject("message");
                try {
                    tillDate = id.getString("subscription_end_date");
                    subscription = id.getString("is_unsubscribed");
                } catch (Exception e) {
                    // TODO: handle exception
                    tillDate = "0";
                }
                // userId = id.getString("user_id");
                status = json.getString("status");

                if (!status.equals("success")) {
                    String message;
                    message = json.getString("message");
                    errorMessage = message;
                } else {
                    SharedPreferences sharedpreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("tilldate", null);
                    editor.putString("value", null);
                    editor.putString("value", subscription);
                    editor.putString("tilldate", tillDate);
                    tgpref = subscription;
                    // editor.putString("Enddate", subscription_enddate);
                    try {
                        editor.apply();
                        editor.commit();
                    } catch (Exception e) {
                        editor.commit();
                    }
                    // ArticleDetailFragment.mLoginNow.setVisibility(View.GONE);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
