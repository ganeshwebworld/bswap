/**
   Project      : Economist
   Filename     : ImageManager.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.common.util;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v4.util.LruCache;
import android.util.Log;
import android.widget.ImageView;

import com.businessstandard.R;

/**
 * @author lenesha
 *
 */

public enum ImageManager {

	INSTANCE;

	private int mSize;
	private LruCache<String, Bitmap> mMemoryCache;

	private ImageManager() {
		mSize = 30;
		createCashe(30);
	}

	

	private void createCashe(int cacheSize) {
		mMemoryCache = new LruCache<String, Bitmap>(cacheSize);
		
	}

	

	public void addBitmapToMemoryCache(String key, Bitmap bitmap) {

		if (getBitmapFromMemCache(key) == null) {
			if (mMemoryCache != null)
				mMemoryCache.put(key, bitmap);
		}
	}

	public Bitmap getBitmapFromMemCache(String key) {
		if (mMemoryCache != null)
			return mMemoryCache.get(key);
		return null;
	}

	public void loadBitmap(String url, ImageView imageView) {

		if (mMemoryCache == null) {
			createCashe(mSize);
		}
		Log.d("TEST",
				"*******************************************************IMAGE MANAGER loadBitmap************"
						+ mMemoryCache.size());

		if (url != null && url !="") {
			final Bitmap bitmap = getBitmapFromMemCache(url);
			if (bitmap != null) {

				imageView.setImageBitmap(bitmap);
			} else {
				imageView.setImageResource(R.drawable.imageplaceholder);
				BitmapWorkerTask task = new BitmapWorkerTask(imageView);
				task.execute(url);
			}
		}
	}

	public void loadThumbnail(String url, ImageView imageview, int width,
			int height) {
		if (url != null && url !="") {
			final Bitmap bitmap = getBitmapFromMemCache(url);

			if (bitmap != null) {
				imageview.setImageBitmap(bitmap);
			} else {
				imageview.setImageResource(R.drawable.imageplaceholder);
				BitmapThumbnailWorkerTask task = new BitmapThumbnailWorkerTask(
						imageview, width, height);
				task.execute(url);
			}
		}

	}

	class BitmapThumbnailWorkerTask extends AsyncTask<String, Void, Bitmap> {

		private ImageView mView;
		private int mWidth, mHeight;

		public BitmapThumbnailWorkerTask(ImageView view, int width, int height) {
			mView = view;
			mWidth = width;
			mHeight = height;
		}

		@Override
		protected Bitmap doInBackground(String... params) {
			String url = params[0];

			BitmapFactory.Options options = new BitmapFactory.Options();
			options.inJustDecodeBounds = true;
			Bitmap bitmap = null;
			try {
				bitmap = BitmapFactory.decodeStream(
						(InputStream) new URL(url).getContent(), null, options);
			} catch (MalformedURLException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			options.inSampleSize = calculateInSampleSize(options, mWidth,
					mWidth);

			Log.d("TEST",
					"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%SAMPLE SIZE%%%%%%%%%%%%%%%%%%%%%%%%%%"
							+ options.inSampleSize);
			options.inJustDecodeBounds = false;
			try {
				bitmap = BitmapFactory.decodeStream(
						(InputStream) new URL(url).getContent(), null, options);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			if (bitmap != null)
				addBitmapToMemoryCache(url, bitmap);
			return bitmap;
		}

		public int calculateInSampleSize(BitmapFactory.Options options,
				int reqWidth, int reqHeight) {
			// Raw height and width of image
			final int height = options.outHeight;
			final int width = options.outWidth;
			int inSampleSize = 1;

			if (height > reqHeight || width > reqWidth) {
				if (width > height) {
					inSampleSize = Math.round((float) height
							/ (float) reqHeight);
				} else {
					inSampleSize = Math.round((float) width / (float) reqWidth);
				}
			}
			return inSampleSize;
		}

		@Override
		protected void onPostExecute(Bitmap result) {
			super.onPostExecute(result);
			if (result != null)
				mView.setImageBitmap(result);
		}
	}

	class BitmapWorkerTask extends AsyncTask<String, Void, Bitmap> {

		private ImageView mView;

		public BitmapWorkerTask(ImageView view) {
			mView = view;
		}

		@Override
		protected Bitmap doInBackground(String... params) {
			String url = params[0];

			BitmapFactory.Options options = new BitmapFactory.Options();
			options.inSampleSize = 3;

			Bitmap bitmap = null;
			try {
				bitmap = BitmapFactory.decodeStream(
						(InputStream) new URL(url).getContent(), null, options);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			if (bitmap != null)
				addBitmapToMemoryCache(url, bitmap);
			return bitmap;
		}

		@Override
		protected void onPostExecute(Bitmap result) {
			super.onPostExecute(result);
			if (result != null)
				mView.setImageBitmap(result);
		}
	}
}
