package com.businessstandard.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Constants implements Serializable {

    @SerializedName("COMMON_JSON")
    @Expose
    private String commonJson;
    @SerializedName("REGISTRATION_API")
    @Expose
    private String registrationApi;
    @SerializedName("SIGN_IN_API")
    @Expose
    private String signinApi;
    @SerializedName("SAVE_DATA_API_V2")
    @Expose
    private String saveDataApiV2;
    @SerializedName("FORGOT_PASSWORD_API")
    @Expose
    private String forgotPasswordApi;
    @SerializedName("DELETE_COUPON_API")
    @Expose
    private String deletecouponApi;
    @SerializedName("GET_COUPONS_API")
    @Expose
    private String getCouponsApi;
    @SerializedName("GET_DEVICE_NOTIFICATION_SETTING_V2")
    @Expose
    private String getDeviceNotificationSettingV2;
    @SerializedName("POST_DEVICE_NOTIFICATION_SETTING_V2")
    @Expose
    private String postDeviceNotificationSettingV2;
    @SerializedName("ACTIVE_NOTIFICATION_FIELD_V2")
    @Expose
    private String activeNotificationFieldV2;
    @SerializedName("SEND_FEEDBACK")
    @Expose
    private String sendFeedback;
    @SerializedName("APP_UPDATE")
    @Expose
    private String appUpdate;
    @SerializedName("NOTIFICATION_ARTICLE_DETAIL")
    @Expose
    private String notificationArticleDetail;
    @SerializedName("GET_PAGE_DATA_BY_CATEGORY")
    @Expose
    private String getPageDataByCategory;
    @SerializedName("GET_GALLERY_VIDEOS")
    @Expose
    private String getGalleryVideos;
    @SerializedName("GET_GALLERY_VIDEO_DETAILS")
    @Expose
    private String getGalleryVideoDetails;
    @SerializedName("BASE_URL")
    @Expose
    private String baseUrl;
    @SerializedName("dynamicSplash")
    @Expose
    private DynamicSplash dynamicSplash;

    public String getCommonJson() {
        return commonJson;
    }

    public void setCommonJson(String commonJson) {
        this.commonJson = commonJson;
    }

    public String getRegistrationApi() {
        return registrationApi;
    }

    public void setRegistrationApi(String registrationApi) {
        this.registrationApi = registrationApi;
    }

    public String getSigninApi() {
        return signinApi;
    }

    public void setSigninApi(String signinApi) {
        this.signinApi = signinApi;
    }

    public String getSaveDataApiV2() {
        return saveDataApiV2;
    }

    public void setSaveDataApiV2(String saveDataApiV2) {
        this.saveDataApiV2 = saveDataApiV2;
    }

    public String getForgotPasswordApi() {
        return forgotPasswordApi;
    }

    public void setForgotPasswordApi(String forgotPasswordApi) {
        this.forgotPasswordApi = forgotPasswordApi;
    }

    public String getDeletecouponApi() {
        return deletecouponApi;
    }

    public void setDeletecouponApi(String deletecouponApi) {
        this.deletecouponApi = deletecouponApi;
    }

    public String getGetCouponsApi() {
        return getCouponsApi;
    }

    public void setGetCouponsApi(String getCouponsApi) {
        this.getCouponsApi = getCouponsApi;
    }

    public String getGetDeviceNotificationSettingV2() {
        return getDeviceNotificationSettingV2;
    }

    public void setGetDeviceNotificationSettingV2(String getDeviceNotificationSettingV2) {
        this.getDeviceNotificationSettingV2 = getDeviceNotificationSettingV2;
    }

    public String getPostDeviceNotificationSettingV2() {
        return postDeviceNotificationSettingV2;
    }

    public void setPostDeviceNotificationSettingV2(String postDeviceNotificationSettingV2) {
        this.postDeviceNotificationSettingV2 = postDeviceNotificationSettingV2;
    }

    public String getActiveNotificationFieldV2() {
        return activeNotificationFieldV2;
    }

    public void setActiveNotificationFieldV2(String activeNotificationFieldV2) {
        this.activeNotificationFieldV2 = activeNotificationFieldV2;
    }

    public String getSendFeedback() {
        return sendFeedback;
    }

    public void setSendFeedback(String sendFeedback) {
        this.sendFeedback = sendFeedback;
    }

    public String getAppUpdate() {
        return appUpdate;
    }

    public void setAppUpdate(String appUpdate) {
        this.appUpdate = appUpdate;
    }

    public String getNotificationArticleDetail() {
        return notificationArticleDetail;
    }

    public void setNotificationArticleDetail(String notificationArticleDetail) {
        this.notificationArticleDetail = notificationArticleDetail;
    }

    public String getGetPageDataByCategory() {
        return getPageDataByCategory;
    }

    public void setGetPageDataByCategory(String getPageDataByCategory) {
        this.getPageDataByCategory = getPageDataByCategory;
    }

    public String getGetGalleryVideos() {
        return getGalleryVideos;
    }

    public void setGetGalleryVideos(String getGalleryVideos) {
        this.getGalleryVideos = getGalleryVideos;
    }

    public String getGetGalleryVideoDetails() {
        return getGalleryVideoDetails;
    }

    public void setGetGalleryVideoDetails(String getGalleryVideoDetails) {
        this.getGalleryVideoDetails = getGalleryVideoDetails;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public DynamicSplash getDynamicSplash() {
        return dynamicSplash;
    }

    public void setDynamicSplash(DynamicSplash dynamicSplash) {
        this.dynamicSplash = dynamicSplash;
    }
}
