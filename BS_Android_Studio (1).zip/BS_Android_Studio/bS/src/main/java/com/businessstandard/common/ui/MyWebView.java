package com.businessstandard.common.ui;



import android.content.Context;
import android.util.AttributeSet;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MyWebView extends WebView  {
	  public MyWebView(Context context) {
		   super(context);
		   this.setClipToPadding(true);
	  }
	  
	  public MyWebView(Context context, AttributeSet attrs) {
	        super(context, attrs);
	    }

	    public MyWebView(Context context, AttributeSet attrs, int defStyle) {
	        super(context, attrs, defStyle);
	    }

	    @SuppressWarnings("deprecation")
		@Override
	    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
	    	 super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	    	 int width = MeasureSpec.getSize(widthMeasureSpec);
	    	 int height = MeasureSpec.getSize(heightMeasureSpec);
	    	 System.out.println("Width of web view -->>>>>>>>>"+width);
	    	 System.out.println("height of web view -->>>>>>>>>"+height);
	    	  //setMeasuredDimension(250,300);
	    	 if(width < 250){	    		 
	    		 System.out.println("Hello web view width--->>>"+ width );
	    		 width = 220;
	    		 height = 250;
	    		 setMeasuredDimension(width, height);
	    	 }
	    	 else
	    	 {
	    		 setMeasuredDimension(width, height);
	    	 }
	    	 //setMeasuredDimension(width, height);
	    	 
	    }
	    /* (non-Javadoc)
	     * @see android.webkit.WebView#setWebViewClient(android.webkit.WebViewClient)
	     */
	    @Override
	    public void setWebViewClient(WebViewClient client) {
	    	// TODO Auto-generated method stub
	    	super.setWebViewClient(client);
	    }
}

