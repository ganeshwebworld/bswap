/**
 * Project      : Economist
 * Filename     : SettingsContentActivity.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.settings.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.common.dto.SectionMainItem;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.ui.MainFragmentActivity;
import com.businessstandard.common.util.Constants.SettingsKeys;
import com.businessstandard.common.util.Utility;

import java.io.File;

/**
 * @author lenesha
 */
public class SettingsContentActivity extends FragmentActivity implements OnClickListener {

    private ImageView mHeaderTxt;
    private WebView mWebViewDesc;
    Button menu;

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        int positionId;
        BaseFragment.numCount = 1;
        setContentView(R.layout.setting_content_activity);
//		menu=(Button)findViewById(R.id.menu);
//		menu.setVisibility(View.GONE);

        Intent intent = getIntent();
        mHeaderTxt = (ImageView) findViewById(R.id.header_txt);
        String item = intent.getStringExtra(SettingsKeys.CLICKED_ITEM);
        positionId = intent.getIntExtra(SettingsKeys.POSITION, 0);
        TextView title_item = (TextView) findViewById(R.id.page_title);
        TextView date = (TextView) findViewById(R.id.header_date);
        date.setText(Utility.getTodaysData());
        findViewById(R.id.search_button).setVisibility(View.GONE);
        findViewById(R.id.refresh_btn).setVisibility(View.GONE);
        mWebViewDesc = (WebView) findViewById(R.id.page_description);
        if (!TextUtils.isEmpty(item)) {
            title_item.setText(item);
            loadWebViewContent(item, positionId);
        }
        initListeners();
    }

    /**
     * @author nagaraj
     */
    private void initListeners() {
        mHeaderTxt.setOnClickListener(this);
    }

    /**
     * @param positionId
     * @author nagaraj
     */
    private void loadWebViewContent(String item, int positionId) {

        BaseFragment.numCount = 3;

        if (SettingsFragment.lstDynamicItems != null && SettingsFragment.lstDynamicItems.size() > 0) {
            int curpos = 0;
            for (int i = 0; i < SettingsFragment.lstDynamicItems.size(); i++) {
                if (!TextUtils.isEmpty(SettingsFragment.lstDynamicItems.get(i).categoryName) &&
                        SettingsFragment.lstDynamicItems.get(i).categoryName.equalsIgnoreCase(item)) {
                    curpos = i;
                    break;
                }
            }

            SectionMainItem itemVal = SettingsFragment.lstDynamicItems.get(curpos);

            mWebViewDesc.loadUrl(itemVal.feedUrl);
        }

        if (item.equalsIgnoreCase("logout")) {

//			mWebViewDesc.f
            String fileDirPath = getApplicationContext().getFilesDir() + "/userinfo.json";
            File f1 = new File(fileDirPath);
            if (f1.exists()) {
                final boolean blnStatus = f1.delete();
                Toast.makeText(getApplicationContext(), "LOGOUT SUCCESSFUL", Toast.LENGTH_SHORT).show();
            }
        }

    }

    /**
     *
     */

    /*
     * (non-Javadoc)
     *
     * @see android.view.View.OnClickListener#onClick(android.view.View)
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.header_txt:
                launchHome();
        }

    }

    /**
     * @author nagaraj
     */
    private void launchHome() {
        Intent intent = new Intent(this, MainFragmentActivity.class);
        intent.setFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onStop() {
        super.onStop();
        BaseFragment.numCount = 1;
    }

    @Override
    public void onResume() {
        super.onResume();
        BaseFragment.numCount = 1;
    }
}
