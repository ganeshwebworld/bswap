/**
   Project      : Economist
   Filename     : Menulsitadaper.java
   Author       : android
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
				  Modified under contract by Robosoft Technologies Pvt. Ltd.
   History      : NA
*/

package com.businessstandard.common.ui;

import java.util.ArrayList;

import com.businessstandard.R;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * @author android
 *
 */

public class Menulsitadaper extends BaseAdapter {

	/**
	 * @param context
	 * @param resource
	 */
	TextView txt;
	Context context;
	 ArrayList<String> data;
	LayoutInflater layoutInflater;
	ImageView image;
	ImageView imagenew;
	public Menulsitadaper(Context context, ArrayList<String> lvMenuItemsNew) {
		super();
		// TODO Auto-generated constructor stub
		 this.data = lvMenuItemsNew;
	        this.context = context;
	        layoutInflater = LayoutInflater.from(context);
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getCount()
	 */
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return data.size();
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getItem(int)
	 */
	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getItemId(int)
	 */
	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getView(int, android.view.View, android.view.ViewGroup)
	 */
	@SuppressLint("ViewHolder")
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		
		convertView= layoutInflater.inflate(R.layout.menulistitemrow, null);
		imagenew=(ImageView)convertView.findViewById(R.id.newsItemImagenew);
		if(!data.get(position).equals("Home") && !data.get(position).equals("Market") && !data.get(position).equals("Todays Newspaper") && !data.get(position).equals("Settings")){
			if(position==0){
				imagenew.setBackgroundResource(R.drawable.leftnewarrow);
				convertView.setBackgroundColor(Color.parseColor("#a81800"));
				txt=(TextView)convertView.findViewById(R.id.newsTitle);
				txt.setTextColor(Color.WHITE);
			}
		}
		
        txt=(TextView)convertView.findViewById(R.id.newsTitle);
        image=(ImageView)convertView.findViewById(R.id.image);
		
			if(position==0 && data.get(position).equals("Home")){
				image.setVisibility(View.GONE);
			}
			if(data.get(position).equals("") || data.get(position).equals("Market") || data.get(position).equals("Today's Paper") ){
				image.setVisibility(View.VISIBLE);
			}
        txt.setText(data.get(position));
		
		return convertView;
	}

}
