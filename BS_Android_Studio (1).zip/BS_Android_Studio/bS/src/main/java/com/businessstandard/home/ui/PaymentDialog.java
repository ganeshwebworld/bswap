/**
 * Project      : Economist
 * Filename     : PaymentDialog.java
 * Author       : android-ubantu
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.home.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.analytics.FirebaseAnalyticsTracker;
import com.businessstandard.analytics.GAConstants;
import com.businessstandard.analytics.GoogleAnalytics;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

/**
 * @author android-ubantu
 */
public class PaymentDialog extends Activity {
    /* (non-Javadoc)
     * @see android.app.Activity#onCreate(android.os.Bundle)
     */
    String id;
    int amount;
    String type = "upgrade";
    TextView terms;
    CheckBox check;
    private GoogleAnalytics mGoogleAnalytics;
    private FirebaseAnalyticsTracker mFirebaseAnalyticsTracker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.paymentdialog);
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        mFirebaseAnalyticsTracker = FirebaseAnalyticsTracker.getInstance(this);
        Button yearly = (Button) findViewById(R.id.buttonh);
        Button monthly = (Button) findViewById(R.id.buttonh2);
//		 terms=(TextView)findViewById(R.id.terms);
//		 check=(CheckBox)findViewById(R.id.checkbox);
        Intent i = getIntent();
        id = i.getStringExtra("value");
        //gaurav-terms & conditions checkbox!!
//		terms.setOnClickListener(new View.OnClickListener() {
//			
//			@Override
//			public void onClick(View v) {
////				SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
////				String currentTime = sdf.format(new Date());
////				String newID=id+currentTime;
////				if(check.isChecked()){
//				Intent i=new Intent(PaymentDialog.this,TermsConditions.class);
//				startActivity(i);
////				}
////				else{
////					Toast.makeText(getApplicationContext(), "Please check terms & conditions", Toast.LENGTH_LONG).show();
////				}
//				
////				finish();
////				RegisterUser signuptask = new RegisterUser(getApplicationContext());
////				signuptask.execute(type,id,amount);
//			}
//		});	

        //gaurav-button click for yearly and monthly if check box is checked!!!
        yearly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                amount = 1500;
//				SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
//				String currentTime = sdf.format(new Date());
//				String newID=id+currentTime;

                Intent i = new Intent(PaymentDialog.this, TermsConditions.class);
                i.putExtra("value", id);
                i.putExtra("package", amount);
                trackAddToCartGAEvent(amount, id);
                startActivityForResult(i, 3);
//				finish();
//				RegisterUser signuptask = new RegisterUser(getApplicationContext());
//				signuptask.execute(type,id,amount);
            }
        });

        monthly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                amount = 149;
//				SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
//				String currentTime = sdf.format(new Date());
//				String newID=id+currentTime;
                Intent i = new Intent(PaymentDialog.this, TermsConditions.class);
                i.putExtra("value", id);
                i.putExtra("package", amount);
                trackAddToCartGAEvent(amount, id);
                startActivityForResult(i, 3);
//				finish();
//				RegisterUser signuptask = new RegisterUser(getApplicationContext());
//				signuptask.execute(type,id,amount);
            }
        });
    }

    private void trackAddToCartGAEvent(int amount, String id) {
        SaveSharedPref.getInstance(PaymentDialog.this).saveString(SharedPreferencesKey.SUBSCRIPTION_AMOUNT_SELECTED, String.valueOf(amount));
        if (mGoogleAnalytics != null) {
            mGoogleAnalytics.trackEvent(GAConstants.ADD_TO_CART_EVENT_CATEGORY, id, "Currency :INR" + "Value :" + amount);
            mGoogleAnalytics.trackEvent(GAConstants.SELECT_PRODUCT_EVENT_CATEGORY, id, GAConstants.SELECT_PRODUCT_EVENT_LABEL);
        }

        mFirebaseAnalyticsTracker.trackEvent(GAConstants.ADD_TO_CART_EVENT_CATEGORY, id, "Currency :INR" + "Value :" + amount);

        mFirebaseAnalyticsTracker.trackEvent(GAConstants.SELECT_PRODUCT_EVENT_CATEGORY, id, GAConstants.SELECT_PRODUCT_EVENT_LABEL);
    }

    /* (non-Javadoc)
     * @see android.app.Activity#onActivityResult(int, int, android.content.Intent)
     */
    //gaurav-activity result to update articles!!
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            if (requestCode == 3 && data.getAction() != null) {
                String status = "ok";
                Intent returnIntent = new Intent();
                returnIntent.putExtra("result", status);
                setResult(RESULT_OK, returnIntent);
            } else {
                String status = "-3";
                Intent returnIntent = new Intent();
                returnIntent.putExtra("result", status);
                setResult(RESULT_CANCELED, returnIntent);
            }
            finish();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
