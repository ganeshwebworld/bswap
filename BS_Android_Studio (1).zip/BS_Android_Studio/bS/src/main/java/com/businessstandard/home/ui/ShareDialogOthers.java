/**
   Project      : Economist
   Filename     : ShareDialogOthers.java
   Author       : android
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
				  Modified under contract by Robosoft Technologies Pvt. Ltd.
   History      : NA
*/

package com.businessstandard.home.ui;

import com.businessstandard.R;
import com.businessstandard.common.dto.SubNewsItem;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.TextView;

/**
 * @author android
 *
 */
public class ShareDialogOthers extends DialogFragment implements OnClickListener{
	private SubNewsItem newsItem;
	/* (non-Javadoc)
	 * @see android.view.View.OnClickListener#onClick(android.view.View)
	 */
	public ShareDialogOthers(SubNewsItem item) {
		newsItem = item;
	}
	
	public ShareDialogOthers() {
		
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
	}
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		Dialog dialog = getDialog();
		getDialog().setTitle(R.string.share_hdr);
		WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();

		dialog.getWindow().setAttributes(lp);
		dialog.getWindow().setFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND,
				WindowManager.LayoutParams.FLAG_DIM_BEHIND);

		View view = inflater.inflate(R.layout.share_layout, container, false);

		initViews(view);

		return view;
	}
	private void initViews(View view) {

		TextView facebook = (TextView) view.findViewById(R.id.fbook);
		TextView twitter = (TextView) view.findViewById(R.id.twit);
		TextView email = (TextView) view.findViewById(R.id.mail);
		TextView whats_app = (TextView) view.findViewById(R.id.whats_app);

		facebook.setOnClickListener(this);
		twitter.setOnClickListener(this);
		email.setOnClickListener(this);
		whats_app.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}

}
