/**
   Project      : Economist
   Filename     : RestTemplateContainer.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.common.util;

import org.springframework.http.HttpEntity;
import org.springframework.web.client.RestTemplate;

/**
 * @author lenesha
 *
 */
public class RestTemplateContainer {

	public HttpEntity<Object> httpEntity;
	public RestTemplate restTemplate;

	public RestTemplateContainer(RestTemplate restTemplate,HttpEntity<Object> requestEntity) {
		this.httpEntity = requestEntity;
		this.restTemplate = restTemplate;
	}

}
