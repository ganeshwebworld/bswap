/**
   Project      : Economist
   Filename     : SectionNewsItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.common.dto;

import com.google.gson.annotations.SerializedName;

/**
 * @author lenesha
 *
 */
public class SectionNewsItem {

	@SerializedName("subcatID")
	public String categoryId;

	@SerializedName("subcatName")
	public String categoryName;

	@SerializedName("layoutid")
	public int layoutId;

	@SerializedName("feedURL")
	public String feedUrl;
	
	public String IsPaidNews; // Naveen
	
}
