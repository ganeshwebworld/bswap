package com.businessstandard.analytics;

import android.content.Context;
import android.os.Bundle;

import com.google.firebase.analytics.FirebaseAnalytics;

public class FirebaseAnalyticsTracker {

    private static FirebaseAnalyticsTracker mInstance;
    private static Context mContext;

    public static synchronized FirebaseAnalyticsTracker getInstance(Context context) {
        mContext = context;
        if (mInstance == null) {
            mInstance = new FirebaseAnalyticsTracker();
        }
        return mInstance;
    }

    public synchronized FirebaseAnalytics getFirebaseAnalyticsTracker() {
        return FirebaseAnalytics.getInstance(mContext);
    }

    /***
     * Tracking event
     *
     * @param category event category
     * @param action   action of the event
     * @param label    label
     */
    public void trackEvent(String category, String action, String label) {
        Bundle params = new Bundle();
        params.putString(FirebaseConstants.FIREBASE_BUNDLE_ACTION_KEY, action);
        params.putString(FirebaseConstants.FIREBASE_BUNDLE_LABEL_KEY, label);
        if (getFirebaseAnalyticsTracker() != null) {
            getFirebaseAnalyticsTracker().logEvent(category, params);
        }
    }
}
