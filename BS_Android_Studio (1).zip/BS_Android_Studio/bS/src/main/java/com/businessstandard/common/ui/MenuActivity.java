package com.businessstandard.common.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ExpandableListView;

import com.businessstandard.R;
import com.businessstandard.common.adapters.MenuAdapter;
import com.businessstandard.common.util.Utility;
import com.businessstandard.model.MenuItemModel;
import com.businessstandard.utils.SaveSharedPref;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MenuActivity extends Activity {

    private ExpandableListView expListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.menu_main);
        expListView = (ExpandableListView) findViewById(R.id.ex_list);


        SaveSharedPref prefUtility = SaveSharedPref.getInstance(this);
        if (!prefUtility.getMenu().equals("") && prefUtility.getMenu() != null) {
            createGroup(prefUtility.getMenu());
        }
    }

    private List<MenuItemModel> menuList = new ArrayList<>();

    private void createGroup(String response) {
        try {
            JSONObject root = new JSONObject(response);
            JSONObject msg = root.getJSONObject("message");

            JSONArray menuArray = msg.getJSONArray("menu");

            for (int i = 0; i < menuArray.length(); i++) {

                MenuItemModel menuItemModel = null;
                List<MenuItemModel> groupChildList = new ArrayList<>();

                JSONObject object = menuArray.getJSONObject(i);

                if (object != null) {

                    if (!TextUtils.isEmpty(object.getString("is_mobile")) && object.getString("is_mobile").equalsIgnoreCase("Y")) {
                        menuItemModel = new MenuItemModel();
                        if (!TextUtils.isEmpty(object.getString("menu_name"))) {
                            menuItemModel.setMenuName(object.getString("menu_name"));
                        }
                        if (!TextUtils.isEmpty(object.getString("menu_id"))) {
                            menuItemModel.setMenuId(object.getString("menu_id"));
                        }
                        if (!TextUtils.isEmpty(object.getString("feed_url"))) {
                            menuItemModel.setFeedUrl(object.getString("feed_url"));
                        }
                    }

                    JSONArray menuChildArray = object.getJSONArray("childMenu");

                    if (menuChildArray != null) {
                        for (int j = 0; j < menuChildArray.length(); j++) {
                            if (!TextUtils.isEmpty(menuChildArray.getJSONObject(j).getString("is_mobile")) &&
                                    menuChildArray.getJSONObject(j).getString("is_mobile").equalsIgnoreCase("Y")) {
                                MenuItemModel childMenuModel = new MenuItemModel();
                                if (!TextUtils.isEmpty(menuChildArray.getJSONObject(j).getString("menu_name"))) {
                                    childMenuModel.setMenuName(menuChildArray.getJSONObject(j).getString("menu_name"));
                                }
                                if (!TextUtils.isEmpty(menuChildArray.getJSONObject(j).getString("menu_id"))) {
                                    childMenuModel.setMenuId(menuChildArray.getJSONObject(j).getString("menu_id"));
                                }
                                if (!TextUtils.isEmpty(menuChildArray.getJSONObject(j).getString("feed_url"))) {
                                    childMenuModel.setFeedUrl(menuChildArray.getJSONObject(j).getString("feed_url"));
                                }
                                groupChildList.add(childMenuModel);
                            }
                        }
                    }
                }
                if (menuItemModel != null && menuList != null) {
                    menuItemModel.setChildMenuList(groupChildList);
                    menuList.add(menuItemModel);
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        MenuAdapter menuAdapter = new MenuAdapter(this, menuList);
        expListView.setAdapter(menuAdapter);
        expListView.setGroupIndicator(null);

        expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                MenuAdapter.groupPosition = groupPosition;
            }
        });

        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                //Utility.showToast(menuList.get(groupPosition).getMenuName() + " : " + menuList.get(groupPosition).getChildMenuList().get(childPosition).getMenuName(), MenuActivity.this);

                //Stocks Click Handle
                if (menuList.get(groupPosition).getChildMenuList().get(childPosition).getMenuId().equalsIgnoreCase("1020300000")) {
                    Intent i = new Intent(MenuActivity.this, MainFragmentActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    i.putExtra("MainCat", "Market");
                    i.putExtra("SabCat", "Market Data");
                    i.putExtra("feedURL", menuList.get(groupPosition).getChildMenuList().get(childPosition).getFeedUrl());
                    startActivity(i);
                    finish();
                }
                //commodities click handle
                else if (menuList.get(groupPosition).getChildMenuList().get(childPosition).getMenuId().equalsIgnoreCase("1020400000")) {
                    Intent i = new Intent(MenuActivity.this, MainFragmentActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    i.putExtra("MainCat", "Market");
                    i.putExtra("SabCat", "Market Data");
                    i.putExtra("feedURL", menuList.get(groupPosition).getChildMenuList().get(childPosition).getFeedUrl());
                    startActivity(i);
                    finish();
                }
                //Rest of the News Listing Handle
                else {
                    Intent i = new Intent(MenuActivity.this, MainFragmentActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    i.putExtra("MainCat", "Home");
                    i.putExtra("SabCat", menuList.get(groupPosition).getChildMenuList().get(childPosition).getMenuName());
                    i.putExtra("feedURL", menuList.get(groupPosition).getChildMenuList().get(childPosition).getFeedUrl());
                    startActivity(i);
                    finish();
                }
                return false;
            }
        });


        expListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
    /*            if (menuList.get(groupPosition).getChildMenuList() != null && menuList.get(groupPosition).getChildMenuList().size() > 0) {
                    if (parent.isGroupExpanded(groupPosition)) {
                        Utility.showToast(menuList.get(groupPosition).getMenuName() + ": Collapsed", MenuActivity.this);
                    } else {
                        Utility.showToast(menuList.get(groupPosition).getMenuName() + ": Expanded", MenuActivity.this);
                    }
                } else {
                    Utility.showToast(menuList.get(groupPosition).getMenuName(), MenuActivity.this);
                }*/
                //Home Group Click Handle
                if (menuList.get(groupPosition).getMenuId().equalsIgnoreCase("1010000000")) {
                    Intent i = new Intent(MenuActivity.this, MainFragmentActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    i.putExtra("MainCat", "Home");
                    i.putExtra("SabCat", "Top Stories");
                     i.putExtra("feedURL",  "http://mobileapps.business-standard.com/wireless/iphone/home_page_top_stories.json");
                    startActivity(i);
                    finish();
                }
                return true;
            }
        });
    }

}
