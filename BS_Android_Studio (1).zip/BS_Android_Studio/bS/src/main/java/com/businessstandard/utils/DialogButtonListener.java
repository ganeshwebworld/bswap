/*
 * Copyright (c) WEBDUNIA
 * All rights reserved.
 */

package com.businessstandard.utils;


public interface DialogButtonListener {

    void onPositiveButtonClick();

    void onNegativeButtonClick();

    void onNeutralButtonClick();

}
