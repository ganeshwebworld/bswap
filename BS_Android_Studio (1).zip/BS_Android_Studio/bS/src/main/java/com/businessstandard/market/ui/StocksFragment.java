/**
 * Project      : Economist
 * Filename     : StocksFragment.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.market.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.manager.BaseManager.TickerDloadCmpltListener;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.ui.CompanyDetailsActivity;
import com.businessstandard.common.util.Constants;
import com.businessstandard.common.util.Constants.CompanyKeys;
import com.businessstandard.common.util.Utility;
import com.businessstandard.market.MarketsManager;
import com.businessstandard.market.MarketsManager.NSESensexDloadCmpltListener;
import com.businessstandard.market.MarketsManager.SensexDloadCmpltListener;
import com.businessstandard.market.dto.BseNseNewsItem;
import com.businessstandard.market.dto.BseStockDataItem;
import com.businessstandard.market.dto.CompanyStockNewsFeed;
import com.businessstandard.market.dto.NseStockDataItem;
import com.businessstandard.market.dto.NseStockDataItems;
import com.businessstandard.market.dto.StockHolder;
import com.businessstandard.market.dto.TickerNewsFeedRootObject;
import com.businessstandard.market.dto.TickerNewsItemFeed;
import com.businessstandard.analytics.GoogleAnalytics;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * @author lenesha
 *
 */
public class StocksFragment extends BaseFragment {

    private FragmentActivity mcontext;
    private FragmentListner listner;
    private View view;
    private ListView stockListview;
    private OnClickListener mOnCompanyRowItemClkLstnr;
    public SensexAdapter mAdapter;
    private TextView emptyList;
    StockHolder[] mstHolders = new StockHolder[5];
    protected NseStockDataItems topGainersItems = new NseStockDataItems();
    protected NseStockDataItems topLoosersItems = new NseStockDataItems();
    protected NseStockDataItems fivetwoWeekHigh = new NseStockDataItems();
    protected NseStockDataItems fivetwoWeekLow = new NseStockDataItems();
    private GoogleAnalytics mGoogleAnalytics;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mcontext = getActivity();
        listner = (FragmentListner) mcontext;
    }

    public void refreshContent() {
        getTickerValues();
        getGainersLoosersData();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        view = inflater.inflate(R.layout.stock_fragment, container, false);
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        stockListview = (ListView) view.findViewById(R.id.stock_listview);
        emptyList = (TextView) view.findViewById(R.id.empty_text);
        initialiseNseBseClickListener();
        mAdapter = new SensexAdapter(mcontext, R.layout.stock_list, mstHolders, mNonTickerNseBsebtnClickListnr, mTickerNseBsebtnClickListnr, mOnCompanyRowItemClkLstnr);
        stockListview.setVerticalFadingEdgeEnabled(false);
        stockListview.setAdapter(mAdapter);
        //AnalyticsUtils.getInstAnalyticsUtils(getActivity()).trackPageView(getString(R.string.tab_market) + getString(R.string.cat_stocks));
        if (mGoogleAnalytics != null && getActivity() != null) {
            mGoogleAnalytics.trackScreenView(getString(R.string.tab_market) + getString(R.string.cat_stocks), getActivity());
        }
        return view;
    }

    /**
     *
     */
    private void getGainersLoosersData() {

        SectionNewsRootFeedItem dataFeed = listner.getDataFromActivity();

        if (getActivity() != null && Utility.isInternetOn(getActivity())) {

            if (dataFeed != null && dataFeed.root != null) {
                stockListview.setVisibility(View.VISIBLE);
                emptyList.setVisibility(View.INVISIBLE);

                String bse52WeekHighurl = dataFeed.root.getmBse52weekHigh().feedUrl;
                String bse52WeekLowurl = dataFeed.root.getmBse52weekLow().feedUrl;

                String nse52WeekHighurl = dataFeed.root.getmNse52weekHigh().feedUrl;
                String nse52WeekLowurl = dataFeed.root.getmNse52weekLow().feedUrl;

                String bseTopGainersurl = dataFeed.root.getmBseTopGainers().feedUrl;
                String bseTopLoosersurl = dataFeed.root.getmBseTopLoosers().feedUrl;

                String nseTopGainersurl = dataFeed.root.getmNseTopGainers().feedUrl;
                String nseTopLoosersurl = dataFeed.root.getmNseTopLoosers().feedUrl;

                MarketsManager manager = new MarketsManager(getActivity());
                manager.nseDownloadSensexGainersLoosers(
                        new NSESensexDloadCmpltListener() {

                            @Override
                            public void onFailure() {
                                if (isAdded() && isVisible() && getActivity() != null)
                                    Utility.hideProgressDialog();
                                displayEmptylist();
                            }

                            @Override
                            public void OnCompanySearchDloadCmplt(NseStockDataItem[] result) {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();

                                topGainersItems.nseStockitems = result;
                                topGainersItems.isToppers = true;

                                mstHolders[1] = topGainersItems;
                                mAdapter.notifyDataSetChanged();
                            }
                        }, nseTopGainersurl);

                manager.downloadSensexGainersLoosers(
                        new SensexDloadCmpltListener() {

                            @Override
                            public void onFailure() {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();

                            }

                            @Override
                            public void OnCompanySearchDloadCmplt(
                                    BseStockDataItem[] result) {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();
                                topGainersItems.bseStockitems = result;

                                mAdapter.notifyDataSetChanged();

                            }

                        }, bseTopGainersurl);

                manager.nseDownloadSensexGainersLoosers(
                        new NSESensexDloadCmpltListener() {

                            @Override
                            public void onFailure() {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();

                            }

                            @Override
                            public void OnCompanySearchDloadCmplt(
                                    NseStockDataItem[] result) {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();

                                topLoosersItems.nseStockitems = result;
                                topLoosersItems.isLoosers = true;
                                mstHolders[2] = topLoosersItems;

                                mAdapter.notifyDataSetChanged();
                            }
                        }, nseTopLoosersurl);
                manager.downloadSensexGainersLoosers(
                        new SensexDloadCmpltListener() {

                            @Override
                            public void onFailure() {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();

                            }

                            @Override
                            public void OnCompanySearchDloadCmplt(
                                    BseStockDataItem[] result) {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();
                                if (result != null && result.length > 0) {
                                    topLoosersItems.bseStockitems = result;
                                    mAdapter.notifyDataSetChanged();
                                }

                            }

                        }, bseTopLoosersurl);
                manager.downloadSensexGainersLoosers(
                        new SensexDloadCmpltListener() {

                            @Override
                            public void onFailure() {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();
                            }

                            @Override
                            public void OnCompanySearchDloadCmplt(
                                    BseStockDataItem[] result) {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();

                                if (result != null && result.length > 0) {

                                    fivetwoWeekHigh.bseStockitems = result;
                                    fivetwoWeekHigh.is52WeekHigh = true;
//									fivetwoWeekHigh.is52WeekLow=true;
                                    mstHolders[3] = fivetwoWeekHigh;
                                    mAdapter.notifyDataSetChanged();
                                }
                            }

                        }, bse52WeekHighurl);
                manager.nseDownloadSensexGainersLoosers(
                        new NSESensexDloadCmpltListener() {

                            @Override
                            public void onFailure() {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();
                                fivetwoWeekHigh.is52WeekHigh = true;

                                mstHolders[3] = fivetwoWeekHigh;
                            }

                            @Override
                            public void OnCompanySearchDloadCmplt(
                                    NseStockDataItem[] result) {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();
                                if (result != null && result.length > 0) {
                                    fivetwoWeekHigh.nseStockitems = result;
                                    fivetwoWeekHigh.is52WeekHigh = true;

                                    mstHolders[3] = fivetwoWeekHigh;

                                    mAdapter.notifyDataSetChanged();
                                }
                            }
                        }, nse52WeekHighurl);
                manager.downloadSensexGainersLoosers(
                        new SensexDloadCmpltListener() {

                            @Override
                            public void onFailure() {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();

                            }

                            @Override
                            public void OnCompanySearchDloadCmplt(
                                    BseStockDataItem[] result) {
                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();
                                if (result != null && result.length > 0) {
                                    fivetwoWeekLow.bseStockitems = result;

                                    mAdapter.notifyDataSetChanged();
                                }
                            }

                        }, bse52WeekLowurl);
                manager.nseDownloadSensexGainersLoosers(
                        new NSESensexDloadCmpltListener() {

                            @Override
                            public void onFailure() {

                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();
                                fivetwoWeekLow.is52WeekLow = true;
//								fivetwoWeekLow.nseStockitems = result;
                                mstHolders[4] = fivetwoWeekLow;
                            }

                            @Override
                            public void OnCompanySearchDloadCmplt(
                                    NseStockDataItem[] result) {

                                if (isAdded() && isVisible()
                                        && getActivity() != null)
                                    Utility.hideProgressDialog();
                                if (result != null && result.length > 0) {
                                    fivetwoWeekLow.is52WeekLow = true;
                                    fivetwoWeekLow.nseStockitems = result;
                                    mstHolders[4] = fivetwoWeekLow;
                                    mAdapter.notifyDataSetChanged();
                                }

                            }
                        }, nse52WeekLowurl);
            } else {
                if (getActivity() != null)
                    Utility.displayAlert(getActivity(), getActivity()
                                    .getString(R.string.app_name), getActivity()
                                    .getString(R.string.unable_to_fetch_data),
                            android.R.string.ok, Utility
                                    .getOkButtonListener(getActivity()));
                displayEmptylist();

            }
        } else {
            if (isAdded() && isVisible() && getActivity() != null)
                Utility.hideProgressDialog();
            displayEmptylist();
            if (getActivity() != null)

                Utility.displayAlert(getActivity(),
                        getActivity().getString(R.string.app_name),
                        getActivity().getString(R.string.no_connection),
                        android.R.string.ok,
                        Utility.getOkButtonListener(getActivity()));
        }

    }

    /**
     *
     */
    private void displayEmptylist() {
        emptyList.setVisibility(View.VISIBLE);
        stockListview.setVisibility(View.INVISIBLE);
    }

    private void getTickerValues() {

        MarketsManager manager = new MarketsManager(getActivity());
        manager.donwloadTickerValues(new TickerDloadCmpltListener() {

            @Override
            public void onFailure() {

                if (isAdded() && isVisible() && getActivity() != null)
                    Utility.hideProgressDialog();

            }

            @Override
            public void onTickerDloadCmplt(TickerNewsFeedRootObject result) {
                TickerNewsItemFeed tickerFeed = result.root;
                if (isAdded() && isVisible() && getActivity() != null)
                    Utility.hideProgressDialog();

                mstHolders[0] = tickerFeed;

                mAdapter.notifyDataSetChanged();

            }
        });

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getTickerValues();
        getGainersLoosersData();
        setHasOptionsMenu(false);
        setMenuVisibility(false);

    }

    private void initialiseNseBseClickListener() {

        mNonTickerNseBsebtnClickListnr = new OnClickListener() {

            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.nse_button:

                        StockHolder item = (StockHolder) view.getTag();
                        if (item instanceof NseStockDataItems) {
                            ((NseStockDataItems) item).isNSE = true;

                        }
                        mAdapter.notifyDataSetChanged();
                        break;
                    case R.id.bse_button:

                        StockHolder item1 = (StockHolder) view.getTag();
                        if (item1 instanceof NseStockDataItems) {
                            ((NseStockDataItems) item1).isNSE = false;

                        }
                        mAdapter.notifyDataSetChanged();

                        break;
                    default:
                        break;
                }

            }
        };

        mTickerNseBsebtnClickListnr = new OnClickListener() {

            @Override
            public void onClick(View v) {
                TickerNewsItemFeed item = (TickerNewsItemFeed) v.getTag();

                mNonTickerNseBsebtnClickListnr.onClick(v);


                if (item != null) {
                    switch (v.getId()) {
                        case R.id.nse_button:

                            item.isNse = true;
                            NseStockDataItems.isNSE = true;
                            mAdapter.notifyDataSetChanged();

                            break;
                        case R.id.bse_button:

                            item.isNse = false;
                            NseStockDataItems.isNSE = false;
                            mAdapter.notifyDataSetChanged();
                            break;
                        default:
                            break;
                    }
                }
            }

        };

        mOnCompanyRowItemClkLstnr = new OnClickListener() {

            @Override
            public void onClick(View v) {
                CompanyStockNewsFeed selectedCompanyObject = null;
                LinkedHashMap<String, NseStockDataItem> nseCompanyList = new LinkedHashMap<String, NseStockDataItem>();
                LinkedHashMap<String, BseStockDataItem> bseCompanyList = new LinkedHashMap<String, BseStockDataItem>();
                List<CompanyStockNewsFeed> compList = new ArrayList<CompanyStockNewsFeed>();

                NseStockDataItem[] nseCompanyArray = (NseStockDataItem[]) v
                        .getTag();
                BseStockDataItem[] bseCompanyArray = (BseStockDataItem[]) v
                        .getTag(R.string.sensex_row_item_tag);
                String selectedCompName = (String) v
                        .getTag(R.string.sensex_position_tag);
                Log.d("SEL COM", selectedCompName);

                if (nseCompanyArray != null && nseCompanyArray.length > 0) {
                    for (NseStockDataItem item : nseCompanyArray) {
                        Log.d("COM NSE", " " + item.coName);
                        nseCompanyList.put(item.coName, item);
                    }
                }

                if (bseCompanyArray != null && bseCompanyArray.length > 0) {
                    for (BseStockDataItem item : bseCompanyArray) {
                        Log.d("COM BSE", " " + item.coName);
                        bseCompanyList.put(item.coName, item);
                    }
                }

                Iterator<String> customNseIterator = nseCompanyList.keySet()
                        .iterator();
                while (customNseIterator.hasNext()) {
                    String key = (String) customNseIterator.next();
                    NseStockDataItem nseItem = nseCompanyList.get(key);

                    CompanyStockNewsFeed nsebseItem = new CompanyStockNewsFeed();
                    nsebseItem.nsestock = new BseNseNewsItem();
                    nsebseItem.bsestock = new BseNseNewsItem();

                    nsebseItem.nsestock.archiveCSVPath = nseItem.archiveCSVPath;
                    nsebseItem.nsestock.changePercent = nseItem.changePercent;
                    nsebseItem.nsestock.changeValue = nseItem.changeValue;
                    nsebseItem.nsestock.prevClose = nseItem.close;
                    nsebseItem.nsestock.coCode = nseItem.coCode;
                    nsebseItem.nsestock.coName = nseItem.coName;
                    nsebseItem.nsestock.dayOpen = nseItem.dayOpen;
                    nsebseItem.nsestock.high = nseItem.high;
                    nsebseItem.nsestock.intradayCSVPath = nseItem.intradayCSVPath;
                    nsebseItem.nsestock.lastName = nseItem.lName;
                    nsebseItem.nsestock.low = nseItem.low;
                    nsebseItem.nsestock.marketCap = nseItem.marketCap;
                    nsebseItem.nsestock.prev52weekHigh = nseItem.prev52weekHigh;
                    nsebseItem.nsestock.prev52weekLow = nseItem.prev52weekLow;
                    nsebseItem.nsestock.price = nseItem.price;
                    nsebseItem.nsestock.updateTime = nseItem.updateTime;
                    nsebseItem.nsestock.volume = nseItem.volume;
                    if (bseCompanyList.containsKey(nseItem.coName)) {
                        BseStockDataItem bseItem = bseCompanyList
                                .get(nseItem.coName);
                        nsebseItem.bsestock.archiveCSVPath = bseItem.archiveCSVPath;
                        nsebseItem.bsestock.changePercent = bseItem.changePercent;
                        nsebseItem.bsestock.changeValue = bseItem.changeValue;
                        nsebseItem.bsestock.prevClose = bseItem.close;
                        nsebseItem.bsestock.coCode = bseItem.coCode;
                        nsebseItem.bsestock.coName = bseItem.coName;
                        nsebseItem.bsestock.dayOpen = bseItem.dayOpen;
                        nsebseItem.bsestock.high = bseItem.high;
                        nsebseItem.bsestock.intradayCSVPath = bseItem.intradayCSVPath;
                        nsebseItem.bsestock.lastName = bseItem.lName;
                        nsebseItem.bsestock.low = bseItem.low;
                        nsebseItem.bsestock.marketCap = bseItem.marketCap;
                        nsebseItem.bsestock.prev52weekHigh = bseItem.prev52weekHigh;
                        nsebseItem.bsestock.prev52weekLow = bseItem.prev52weekLow;
                        nsebseItem.bsestock.price = bseItem.price;
                        nsebseItem.bsestock.updateTime = bseItem.updateTime;
                        nsebseItem.bsestock.volume = bseItem.volume;
                    }
                    compList.add(nsebseItem);
                    // Company which was clicked
                    if (nsebseItem.nsestock != null
                            && nsebseItem.nsestock.coName
                            .equalsIgnoreCase(selectedCompName)) {
                        selectedCompanyObject = nsebseItem;
                    }
                }

                Iterator<String> customBseIterator = bseCompanyList.keySet()
                        .iterator();
                while (customBseIterator.hasNext()) {

                    String key = (String) customBseIterator.next();
                    BseStockDataItem bseItem = bseCompanyList.get(key);

                    CompanyStockNewsFeed bseCompItem = new CompanyStockNewsFeed();
                    bseCompItem.bsestock = new BseNseNewsItem();

                    if (!(nseCompanyList.containsKey(bseItem.coName))) {
                        bseCompItem.bsestock.archiveCSVPath = bseItem.archiveCSVPath;
                        bseCompItem.bsestock.changePercent = bseItem.changePercent;
                        bseCompItem.bsestock.changeValue = bseItem.changeValue;
                        bseCompItem.bsestock.prevClose = bseItem.close;
                        bseCompItem.bsestock.coCode = bseItem.coCode;
                        bseCompItem.bsestock.coName = bseItem.coName;
                        bseCompItem.bsestock.dayOpen = bseItem.dayOpen;
                        bseCompItem.bsestock.high = bseItem.high;
                        bseCompItem.bsestock.intradayCSVPath = bseItem.intradayCSVPath;
                        bseCompItem.bsestock.lastName = bseItem.lName;
                        bseCompItem.bsestock.low = bseItem.low;
                        bseCompItem.bsestock.marketCap = bseItem.marketCap;
                        bseCompItem.bsestock.prev52weekHigh = bseItem.prev52weekHigh;
                        bseCompItem.bsestock.prev52weekLow = bseItem.prev52weekLow;
                        bseCompItem.bsestock.price = bseItem.price;
                        bseCompItem.bsestock.updateTime = bseItem.updateTime;
                        bseCompItem.bsestock.volume = bseItem.volume;
                        compList.add(bseCompItem);
                        // Company which was clicked
                        if (bseCompItem != null
                                && bseCompItem.bsestock != null
                                && bseCompItem.bsestock.coName
                                .equalsIgnoreCase(selectedCompName)) {
                            selectedCompanyObject = bseCompItem;
                        }
                    }

                }

                Constants
                        .setCompny_list_items((ArrayList<CompanyStockNewsFeed>) compList);
                Intent intent = new Intent(getActivity(),
                        CompanyDetailsActivity.class);
                intent.putExtra(Constants.IS_INDICES_FRAGMENT, false);
                // Position of item clicked so that pager can display clicked
                // company detail first.
                intent.putExtra(CompanyKeys.POSITION,
                        compList.indexOf(selectedCompanyObject));
                // Used in GA to identify the .
                intent.putExtra(Constants.MARKET_SUB_CAT,
                        getString(R.string.cat_stocks));

                startActivity(intent);
            }
        };

    }

}
