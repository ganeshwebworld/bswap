/**
 * Project      : Economist
 * Filename     : TermsConditions.java
 * Author       : android-ubantu
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.home.ui;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.webkit.WebView;
import android.widget.Button;

import com.businessstandard.R;
import com.businessstandard.common.ui.LoadPaymentGateway;
import com.businessstandard.analytics.FirebaseAnalyticsTracker;
import com.businessstandard.analytics.GAConstants;
import com.businessstandard.analytics.GoogleAnalytics;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;


/**
 * @author android-ubantu
 */

public class TermsConditions extends Activity {

    WebView terms;
    Button agree, disagree;
    String ids;
    int d;
    private GoogleAnalytics mGoogleAnalytics;
    private FirebaseAnalyticsTracker mFirebaseAnalyticsTracker;

    /* (non-Javadoc)
     * @see android.app.Activity#onCreate(android.os.Bundle)
     */
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_terms_conditions);
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        mFirebaseAnalyticsTracker = FirebaseAnalyticsTracker.getInstance(this);
        if (android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        terms = (WebView) findViewById(R.id.termsconditions);
        agree = (Button) findViewById(R.id.agree);
        disagree = (Button) findViewById(R.id.disagree);
        //Loading terms & conditions page here!!
        terms.loadUrl("file:///android_asset/terms&conditions.html");
        Intent i = getIntent();
        ids = i.getStringExtra("value");
        d = i.getIntExtra("package", 0);

        agree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(TermsConditions.this, LoadPaymentGateway.class);
                i.putExtra("value", ids);
                i.putExtra("package", d);
                trackGAEvent();
                startActivityForResult(i, 20);
            }
        });

        disagree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showdilaog();
            }
        });
    }

    private void trackGAEvent() {
        //Google Analytics Tracking
        if (!TextUtils.isEmpty(SaveSharedPref.getInstance(TermsConditions.this).getString(SharedPreferencesKey.KEY_USER_ID, ""))) {
            mGoogleAnalytics.trackEvent(GAConstants.TandC_EVENT_CATEGORY,
                    SaveSharedPref.getInstance(TermsConditions.this).getString(SharedPreferencesKey.KEY_USER_ID, ""),
                    GAConstants.TandC_EVENT_LABEL);
        }

        mFirebaseAnalyticsTracker.trackEvent(GAConstants.TandC_EVENT_CATEGORY, SaveSharedPref.getInstance(TermsConditions.this).getString(SharedPreferencesKey.KEY_USER_ID, ""), GAConstants.TandC_EVENT_LABEL);
    }

    private void showdilaog() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(TermsConditions.this);

        // Setting Dialog Title
        alertDialog.setTitle("\tBS");

        // Setting Dialog Message
        alertDialog.setMessage("Business Standard's premium content provides valuable insights and information. Are you sure you do not want to subscribe?");

        // Setting Positive "Yes" Button
        alertDialog.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
//						String fileDirPath = getApplicationContext().getFilesDir()+"/userinfo.json";
//						File f1 = new File(fileDirPath);
//						if (f1.exists()) {
//							final boolean blnStatus = f1.delete();
//							SharedPreferences	preferences=	PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
//						       SharedPreferences.Editor edit=preferences.edit();
//						          edit.clear().commit();
//							   Toast.makeText(TermsConditions.this, "LOGOUT SUCCESSFUL", Toast.LENGTH_LONG).show();
//							   Intent i=new Intent(TermsConditions.this,MainFragmentActivity.class);
//							   startActivity(i);
                        finish();

                    }
                });
        // Setting Negative "NO" Button
        alertDialog.setNegativeButton("NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to execute after dialog
                        dialog.cancel();
                    }
                });

        // Showing Alert Message
        alertDialog.show();
    }

    /* (non-Javadoc)
     * @see android.app.Activity#onActivityResult(int, int, android.content.Intent)
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        if (requestCode == 20 && resultCode == RESULT_OK) {
            String status = "ok";
            Intent returnIntent = new Intent();
            returnIntent.putExtra("result", status);
            setResult(RESULT_OK, returnIntent);
            finish();
        } else {
            finish();
        }
    }
}
