/**
   Project      : Economist
   Filename     : McxNcdexFutureItems.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.market.dto;

import java.util.List;

/**
 * @author lenesha
 *
 */
public class McxNcdexFutureItems extends StockHolder {

	public	List<McxAndNcdexFutureItem> mcxOrNcdexFutureItems;
	
	public boolean isMcxFuture = false;
	public boolean isNcdexFuture = false;
}
