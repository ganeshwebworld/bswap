/**
   Project      : Economist
   Filename     : McxFutureRootFeedItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.market.dto;

/**
 * @author lenesha
 *
 */
public class McxFutureRootFeedItem {
	public 	McxFutureItem root;
}
