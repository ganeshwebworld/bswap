/**
   Project      : Economist
   Filename     : TodaysPaperItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.todayspaper.dto;

/**
 * @author lenesha
 *
 */
public class TodaysPaperItem {

	public String name;
	public String feedURL;
}
