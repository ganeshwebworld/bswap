package com.businessstandard.common.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class MyFrameLayout extends FrameLayout {

	/**
	 * @param context
	 */
	public MyFrameLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public MyFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyFrameLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

	@Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    	 super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    	 int width = MeasureSpec.getSize(widthMeasureSpec)/2;
    	 System.out.println("Width-->>>>>>>>>"+width);
    	 if(width < 360){
    		 width = 280;
    	 }
    	 else if (width < 250)
    	 {
    		 System.out.println("Hello Ashish");
    		 width = 200;
    	 }
    	 
    	 //width = width-60;
    	 int height = MeasureSpec.getSize(heightMeasureSpec)/2;
    	 System.out.println("height-->>>>>>>>>"+height);
    	 height = height-200;
    	 if( height < 480){
    		 height = 390;
    	 }
    	 else if(height < 330)
    	 {
    		 height = 230;
    	 }
    	  //setMeasuredDimension(250,300);
    	 setMeasuredDimension(width, height);
    }
}
