/**
 * Project      : Economist
 * Filename     : TodaysPaperFragment.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.todayspaper.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.customviews.CategoryScrollView;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.manager.BaseManager.SubNewsDloadCmpltListener;
import com.businessstandard.common.manager.BaseManager.TickerDloadCmpltListener;
import com.businessstandard.common.manager.BaseManager.TodaysPaperCatgryDownldListner;
import com.businessstandard.common.ui.BaseActivity;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.ui.MainFragmentActivity;
import com.businessstandard.common.util.Constants.SelectedCat;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.HomeManager;
import com.businessstandard.home.ui.HomeFragment.OnNewsListDwnloadedListener;
import com.businessstandard.home.ui.NewsListAdapter;
import com.businessstandard.market.dto.TickerNewsFeedRootObject;
import com.businessstandard.market.dto.TickerNewsItemFeed;
import com.businessstandard.todayspaper.TodaysPaperManager;
import com.businessstandard.todayspaper.dto.TodaysPaperItem;
import com.businessstandard.todayspaper.dto.TodaysPaperNewsRootItem;
import com.businessstandard.analytics.GoogleAnalytics;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author lenesha
 */
public class TodaysPaperFragment extends BaseFragment implements OnItemClickListener {

    private FragmentListner mFragmntListner;
    private CategoryScrollView mCategoryScroll;
    private NewsItemClickListner mNewsClickListener;
    private ListView mNewsListView;
    private TextView mEmptyView;
    private NewsListAdapter adapter;
    private FragmentActivity mcontext;
    protected ArrayList<SubNewsItem> subnewsItem;
    private HashMap<String, String> subCatgryMap;
    public static ArrayList<String> mSubCategoryList;
    private OnNewsListDwnloadedListener mOnNewsListDwnloadedListener;
    private String mSelectedcat;
    private TickerNewsItemFeed tickernewsFeed = null;
    private TextView mNseLabel;
    private TextView mBseLabel;
    private boolean isLeftScroll = true;
    private LinearLayout mSensexTicker;
    private String mUrl;
    private String mSelectedCategory;
    private boolean isCntntDloaded = false;
    int counter = 0;
    public static int counternew = 0;
    private GoogleAnalytics mGoogleAnalytics;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mcontext = getActivity();
        mFragmntListner = (FragmentListner) mcontext;
        mOnNewsListDwnloadedListener = (OnNewsListDwnloadedListener) mcontext;
        subnewsItem = new ArrayList<SubNewsItem>();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        isCntntDloaded = false;
        super.onCreate(savedInstanceState);
        BaseActivity.numAdCount = 2;
        BaseFragment.numCount = 2;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.hometab_fragment, container, false);
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        Bundle bundle = getArguments();
        if (bundle != null) {
            mSelectedCategory = getArguments().getString(SelectedCat.CATEGORY);
        }

        mSensexTicker = (LinearLayout) view.findViewById(R.id.sensex_ticker);
        mSensexTicker.setVisibility(View.GONE); // just comment this line if
        // want ticker

        mNewsClickListener = castToListener(getActivity());
        mBseLabel = (TextView) view.findViewById(R.id.bselabel);

        mBseText = (TextView) view.findViewById(R.id.bseValue);
        mNseLabel = (TextView) view.findViewById(R.id.nselabel);

        mNseText = (TextView) view.findViewById(R.id.nseValue);
        mBseImg = (ImageView) view.findViewById(R.id.bseimg);
        mNseImg = (ImageView) view.findViewById(R.id.nseimg);
        mNewsListView = (ListView) view.findViewById(R.id.newsList);
        mEmptyView = (TextView) view.findViewById(R.id.empty_text);
        adapter = new NewsListAdapter(mcontext, R.layout.news_listitem);
        mNewsListView.setAdapter(adapter);

        mNewsListView.setOnItemClickListener(this);
        subCatgryMap = new HashMap<String, String>();
        mSelectedcat = new String();
        mNewsListView.setVerticalFadingEdgeEnabled(false);

        return view;
    }

    private void initScrollView() {
        if (mSelectedcat != null && mSelectedcat.length() > 0 && isLeftScroll) {
            TextView catToBeSelected = mCategoryScroll.getCategory(mSelectedcat);
            int x = catToBeSelected.getLeft();
            int y = 0;
            mCategoryScroll.scrollTo(x, y);
            // addSubCategory(mSubCategoryList, (String)
            // catToBeSelected.getText());
        }

    }

    private void getCategories(SectionNewsRootFeedItem dataFromActivity) {

        if (getActivity() != null && Utility.isInternetOn(getActivity())) {

            if (dataFromActivity != null && dataFromActivity.root != null && dataFromActivity.root.getmTodaysPaper() != null) {

                String feedUrl = dataFromActivity.root.getmTodaysPaper().feedUrl;

                TodaysPaperManager manager = new TodaysPaperManager(getActivity());

                manager.DonwloadCategories(new TodaysPaperCatgryDownldListner() {

                    @Override
                    public void onFailure() {
                        Utility.hideProgressDialog();
                        displayEmptyListview();

                    }

                    @Override
                    public void onSubNewsDloadComplete(TodaysPaperNewsRootItem result) {
                        if (!MainFragmentActivity.maincat.equals("Home"))
                            Utility.hideProgressDialog();
                        showCategories(result);
                    }
                }, feedUrl);
            } else {
                if (getActivity() != null)
                    Utility.displayAlert(getActivity(), getString(R.string.app_name), getResources()
                            .getString(R.string.unable_to_fetch_data), android.R.string.ok, Utility.getOkButtonListener(getActivity()));
                displayEmptyListview();
            }
        } else {
            if (getActivity() != null)

                Utility.displayAlert(getActivity(),
                        getString(R.string.app_name),
                        getResources().getString(R.string.no_connection),
                        android.R.string.ok,
                        Utility.getOkButtonListener(getActivity()));
            displayEmptyListview();
        }
    }

    private NewsItemClickListner castToListener(Activity activity) {
        return (NewsItemClickListner) activity;
    }

    protected void loadSelectedCategoryContent(String category) {
//		displayNewsForCategory(subCatgryMap.get(category));

    }

    /*
     * private void addSubCategory(ArrayList<String> mSubCategoryList1, String
     * string) { mCategoryScroll.addCategory(mSubCategoryList1, string); }
     */

    private void displayNews(ArrayList<SubNewsItem> result) {
        //itemlist null pointer handling
        mNewsListView.setVisibility(View.VISIBLE);
        mEmptyView.setVisibility(View.INVISIBLE);
        if (subnewsItem != null && result != null && result.size() > 0) {
//			for(int j=0;j<=mSubCategoryList.size();j++){
//				for(int k=0;k<=result.size()-1;k++){
//					if(mSubCategoryList.get(j)==result.get(k).key){
//						SubNewsItem item : result;
//						adapter.add(item);
//					}
//				}
//			}
            adapter.clear();
//			ArrayList<SubNewsItem> dgdgd=result.get(TodaysPaperFragment.mSubCategoryList.get(0));


            for (SubNewsItem item : result) {

                adapter.add(item);

                adapter.setNotifyOnChange(false);
            }
            adapter.setNotifyOnChange(true);
//			adapter = new NewsListAdapter(mcontext, R.layout.news_listitem,result);
//			mNewsListView.setAdapter(adapter);

        } else {
            displayEmptyListview();

        }

    }

    @SuppressWarnings("null")
    public void showCategories(TodaysPaperNewsRootItem result) {
        boolean dataAvail = false;
        mSubCategoryList = new ArrayList<String>();
        if (result.root != null) {
            ArrayList<TodaysPaperItem> catgryList = result.root.section;
            for (int i = 0; i < catgryList.size(); i++) {
                TodaysPaperItem arrayItem = catgryList.get(i);
                if (arrayItem.name != null && arrayItem.feedURL != null) {
                    String subCategory = arrayItem.name;
                    subCatgryMap.put(subCategory, arrayItem.feedURL);
                    if (subCategory.equals("Front Page")) {
                        mSubCategoryList.add("Back");
                        mSubCategoryList.add(subCategory);
                    } else
                        mSubCategoryList.add(subCategory);

                    dataAvail = true;
                } else {
                    dataAvail = false;

                    displayEmptyListview();

                    break;
                }

            }
            if (mSubCategoryList.size() > 0 && subCatgryMap.size() > 0) {
                if (mFragmntListner != null) {
                    // mFragmntListner.setCatgeroes(mSubCategoryList,
                    // subCatgryMap);
                    mFragmntListner.setTopStoriesCatgeroes(mSubCategoryList,
                            subCatgryMap, mSelectedCategory);
                }
            }
            if (dataAvail && !MainFragmentActivity.maincat.equals("Home")) {
                /*
                 * if(mFragmntListner.getSelectedCategory() !=null &&
                 * subCatgryMap
                 * .containsKey(mFragmntListner.getSelectedCategory()))
                 * mSelectedcat = mFragmntListner.getSelectedCategory(); else
                 * mSelectedcat = mSubCategoryList.get(0);
                 */
                // addSubCategory(mSubCategoryList, mSelectedcat);
                isLeftScroll = true;
                String sectionUrl = null;
//				ArrayList<String> sectionUrl = new ArrayList<String>();
                if (mSelectedCategory == null) {
                    sectionUrl = subCatgryMap.get(mSubCategoryList.get(0));
                } else {
                    if (subCatgryMap.containsKey(mSelectedCategory)) {
                        sectionUrl = subCatgryMap.get(mSelectedCategory);
                    } else {
                        sectionUrl = subCatgryMap.get(mSubCategoryList.get(0));
                    }
                    /*
                     * sectionUrl = subCatgryMap.get(mSelectedCategory);
                     */
                }
                if (!MainFragmentActivity.maincat.equals("Home"))
                    displayNewsForCategory(sectionUrl);

                //gaurav
//				if (mSelectedCategory == null) {
//					sectionUrl.add(subCatgryMap.get(mSubCategoryList.get(0)))  ;
//				} else {
//					if (subCatgryMap.containsKey(mSelectedCategory)) {
//						for(int i=0;i<=mSubCategoryList.size()-1;i++){
//						sectionUrl.add (subCatgryMap.get(mSubCategoryList.get(i)));
////						displayNewsForCategory(sectionUrl[i]);
////						
////						counter=i;
//						}
//						for (int k=0;k<=sectionUrl.size()-1;k++){
//							displayNewsForCategory(sectionUrl);
//							counter=k;
//						}
//					} else {
//						
////						sectionUrl[0] = subCatgryMap.get(mSubCategoryList.get(0));
//						sectionUrl.add(subCatgryMap.get(mSubCategoryList.get(0)))  ;
//					}
//					/*
//					 * sectionUrl = subCatgryMap.get(mSelectedCategory);
//					 */
//				}
//				displayNewsForCategory(sectionUrl);
//				if (mSelectedCategory == null) {
//					sectionUrl = subCatgryMap.get(mSubCategoryList.get(0));
//				} else {
//					if (subCatgryMap.containsKey(mSelectedCategory)) {
//						sectionUrl = subCatgryMap.get(mSelectedCategory);
//					} else {
//						sectionUrl = subCatgryMap.get(mSubCategoryList.get(0));
//					}
                /*
                 * sectionUrl = subCatgryMap.get(mSelectedCategory);
                 */
//				}
//				displayNewsForCategory(sectionUrl);

/*				if (getActivity() != null)
					AnalyticsUtils.getInstAnalyticsUtils(getActivity()).trackPageView(getString(R.string.tab_todays_paper) + mSelectedcat);*/

                if (mGoogleAnalytics != null && getActivity() != null) {
                    mGoogleAnalytics.trackScreenView(getString(R.string.tab_todays_paper) + mSelectedcat, getActivity());
                }

            }

        } else {
            if (getActivity() != null)
                Utility.displayAlert(getActivity(), "", getResources()
                        .getString(R.string.no_data), android.R.string.ok, Utility.getOkButtonListener(getActivity()));
        }
    }

    private void displayNewsForCategory(String url) {
        mUrl = url;
        if (getActivity() != null) {
            TodaysPaperManager manager = new TodaysPaperManager(getActivity());
            TodaysPaperManager.setManager(manager);
            manager.downloadNewsFeedData(new SubNewsDloadCmpltListener() {

                @Override
                public void onFailure() {
                    Utility.hideProgressDialog();
                    displayEmptyListview();
                }

                @Override
                public void onSubNewsDloadComplete(ArrayList<SubNewsItem> result) {
                    Utility.hideProgressDialog();
                    initScrollView();

//					subnewsItem=result;

//					for(int j=0;j<=result.size()-1;j++)
//					subnewsItem.add( result.get(j));
                    mOnNewsListDwnloadedListener.onNewsListDownloaded(result);
//					if(counter==mSubCategoryList.size()-1)
                    displayNews(result);
                }

//				@Override
//				public void onSubNewsDloadComplete(ArrayList<SubNewsItem> result) {
//					// TODO Auto-generated method stub
//					
//				}

            }, url);
        }

    }


    protected void displayEmptyListview() {

        mEmptyView.setVisibility(View.VISIBLE);
        mNewsListView.setVisibility(View.INVISIBLE);

    }

    @Override
    public void onItemClick(AdapterView<?> arg0, View view, int position, long id) {
        SubNewsItem subNewsitemClicked = adapter.getItem(position);
        mNewsClickListener.onNewsItemClick(subNewsitemClicked, position, mSelectedCategory, mSelectedCategory);
    }

    public void refreshContent() {
        if (getActivity() != null) {
            /*
             * if(subCatgryMap.size()>0) { if(mSelectedcat!=null)
             * displayNewsForCategory(subCatgryMap.get(mSelectedcat)); else
             * displayNewsForCategory(subCatgryMap.get(0));
             *
             * }
             *
             * else { getCategories(HomeManager.feedObjct); }
             */
            if (mUrl != null)
                displayNewsForCategory(mUrl);
        }

        // showCategories(listner.getDataFromActivity());
        else
            Utility.showToast(getString(R.string.no_connection), getActivity());

    }

    protected void getTickerFeeds() {
        HomeManager homeManager = new HomeManager(getActivity());
        homeManager.donwloadTickerValues(new TickerDloadCmpltListener() {

            @Override
            public void onFailure() {
                // Utility.displayAlert(getActivity(),
                // getResources().getString(R.string.app_name),
                // getResources().getString(R.string.no_result),
                // android.R.string.ok,
                // Utility.getOkButtonListener(getActivity()));
                if (getActivity() != null) {
                    mBseLabel.setText(mBseLabel.getText() + " " + 0.0 + " ");
                    mBseText.setText("0.0");
                    mBseImg.setBackgroundResource(R.drawable.arrow_green);
                    mBseText.setTextColor(getResources().getColor(R.color.black));

                    mNseLabel.setText(mNseLabel.getText() + " " + 0.0 + " ");
                    mNseText.setText("0.0");
                    mNseImg.setBackgroundResource(R.drawable.arrow_green);
                    mNseText.setTextColor(getResources().getColor(R.color.black));
                }

            }

            @Override
            public void onTickerDloadCmplt(TickerNewsFeedRootObject result) {
                TickerNewsItemFeed tickerFeed = result.root;
                if (tickerFeed != null && tickerFeed.bsestock != null && tickerFeed.nsestock != null) {
                    tickernewsFeed = tickerFeed;
                    dipslayTicker();
                }
            }
        });

    }

    private void dipslayTicker() {
        if (getActivity() != null) {
            if (tickernewsFeed.bsestock.changePercent != null) {
                try {
                    Float bseVal = Float.valueOf(tickernewsFeed.bsestock.changePercent);
                    if (bseVal >= 0) {
                        mBseLabel.setText(mBseLabel.getText() + " " + tickernewsFeed.bsestock.price + " ");
                        mBseText.setText(tickernewsFeed.bsestock.changeValue);
                        mBseText.setTextColor(getActivity().getResources().getColor(R.color.ticker_green));
                        mBseImg.setBackgroundResource(R.drawable.arrow_green);
                    } else {
                        mBseLabel.setText(mBseLabel.getText() + " " + tickernewsFeed.bsestock.price + " ");
                        mBseText.setText(tickernewsFeed.bsestock.changeValue);
                        mBseImg.setBackgroundResource(R.drawable.arrow_red);
                        mBseText.setTextColor(getResources().getColor(R.color.ticker_red));
                    }
                } catch (NumberFormatException exception) {
                    mBseLabel.setText(mBseLabel.getText() + " " + 0.0 + " ");

                    mBseText.setText("0.0");
                    mBseImg.setBackgroundResource(R.drawable.arrow_green);

                    mBseText.setTextColor(getResources().getColor(R.color.black));
                }

            }
            if (tickernewsFeed.nsestock.changePercent != null) {

                try {
                    Float nseVal = Float.valueOf(tickernewsFeed.nsestock.changePercent);
                    if (nseVal >= 0) {
                        mNseLabel.setText(mNseLabel.getText() + " " + tickernewsFeed.nsestock.price + " ");

                        mNseText.setText(tickernewsFeed.nsestock.changeValue);
                        mNseImg.setBackgroundResource(R.drawable.arrow_green);
                        mNseText.setTextColor(getResources().getColor(R.color.ticker_green));

                    } else {
                        mNseLabel.setText(mNseLabel.getText() + " " + tickernewsFeed.nsestock.price + " ");
                        mNseText.setText(tickernewsFeed.nsestock.changeValue);
                        mNseImg.setBackgroundResource(R.drawable.arrow_red);
                        mNseText.setTextColor(getResources().getColor(R.color.ticker_red));

                    }

                } catch (NumberFormatException exception) {
                    mNseLabel.setText(mNseLabel.getText() + " " + 0.0 + " ");
                    mNseText.setText("0.0");
                    mNseImg.setBackgroundResource(R.drawable.arrow_green);
                    mNseText.setTextColor(getResources().getColor(R.color.black));
                }
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getTickerFeeds();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (!isCntntDloaded) {
            if (mFragmntListner != null) {
                getCategories(HomeManager.feedObjct);
            } else {
                getCategories(mFragmntListner.getDataFromActivity());
            }

        }
        isCntntDloaded = false;
    }

}
