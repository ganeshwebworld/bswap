/**
   Project      : Economist
   Filename     : SearchCompanyStockActivity.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */

package com.businessstandard.common.ui;

import java.text.MessageFormat;
import java.util.ArrayList;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.util.Constants;
import com.businessstandard.common.util.FragmentHelper;
import com.businessstandard.common.util.Constants.CompanyKeys;
import com.businessstandard.common.util.Constants.MarketKeys;
import com.businessstandard.common.util.Constants.SearchStock;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.HomeManager;
import com.businessstandard.home.HomeManager.CompanySearchDloadCmpltListener;
import com.businessstandard.market.dto.CompanyStockNewsFeed;
import com.businessstandard.market.ui.MarketActivity;
import com.businessstandard.settings.ui.SettingsFragment;
/**
 * @author lenesha
 * 
 */
public class SearchCompanyStockActivity extends BaseActivity
		implements
			OnClickListener,
			OnItemClickListener {

	private EditText mCompanySearch;
	private String mSearchStockUrl;
	protected ArrayList<CompanyStockNewsFeed> mCompnyList;
	private ListView mNewsListView;
	private CompanyListAdapter mAdapter;
	private boolean isFromMraketActivity;
	Button menu;

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.support.v4.app.FragmentActivity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		BaseFragment.numCount=2;
		BaseActivity.numAdCount=2;
		BaseActivity.select="search";
		Bundle bundle = getIntent().getExtras();
		if (bundle != null) {
			isFromMraketActivity = bundle.getBoolean(MarketKeys.MARKET_ACTIVITY);
		}
			setLayout(R.layout.get_quotes);
			setting = (Button) findViewById(R.id.setting_button);
			setting.setPadding(0, 0, 0, 0);
			setting.setVisibility(View.GONE);
			setting.setOnClickListener(this);
			hideCatScrollView();
			hideadView();
			hideRadiogroup();
			Intent intent = getIntent();
			mSearchStockUrl = intent.getStringExtra(SearchStock.SEARCH_STOCK_URL);
			mCompanySearch = (EditText) findViewById(R.id.searchCompany);
			Button searchButton = (Button) findViewById(R.id.searchButton);
			TextView date = (TextView) findViewById(R.id.header_date);
//			date.setMa
			date.setText(Utility.getTodaysData());
			date.setPadding(0, 0, 0, 0);
			
			date.setTextSize(30);
			date.setText("Search");
			menu=(Button)findViewById(R.id.menu);
			
			menu.setVisibility(View.GONE);
			findViewById(R.id.refresh_btn).setVisibility(View.GONE);
			findViewById(R.id.setting_button).setVisibility(View.GONE);

			searchButton.setOnClickListener(this);

			mNewsListView = (ListView) findViewById(R.id.companyListView);
			mCompnyList = new ArrayList<CompanyStockNewsFeed>();

			mNewsListView.setOnItemClickListener(this);
			TextView emptyView = (TextView) findViewById(android.R.id.empty);
			mAdapter = new CompanyListAdapter(this, R.layout.company_list_item,
					mCompnyList);
			mNewsListView.setAdapter(mAdapter);
		

	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see android.view.View.OnClickListener#onClick(android.view.View)
	 */
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.searchButton :
				Utility.hideKeyboard(this);
				getCompanyList();
				break;
			case R.id.header_txt :
				launchHome();
				break;
			/*case R.id.setting_button :
				hideCatScrollView();
				hideTickers();
				Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.realTabContent);
				fragment = new SettingsFragment();
				FragmentHelper.replaceFragment(this, R.id.realTabContent, fragment);*/
			default :
				break;
		}
	}

	private void launchHome() {
		if (isFromMraketActivity) {
			Intent intent = new Intent(this, MarketActivity.class);
			intent.setFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
			intent.putExtra(MarketKeys.LAUNCH_MARKET, true);
			startActivity(intent);
		} else {
			Intent intent = new Intent(this, MainFragmentActivity.class);
			intent.setFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
		}

	}

	/**
	 * 
	 */
	private void getCompanyList() {

		// Clearing list: To avoid appending of new data.
		if (mCompnyList.size() > 0) {
			mCompnyList.clear();
		}

		String searchString = mCompanySearch.getText().toString();
		if (searchString.length() > 0) {
			String url = MessageFormat.format("{0}?co_name={1}",
					mSearchStockUrl, searchString);

			HomeManager manager = new HomeManager(this);
			manager.downloadCompanyData(new CompanySearchDloadCmpltListener() {

				@Override
				public void onFailure() {
					Utility.hideProgressDialog();
					if (mCompnyList != null && mCompnyList.size() > 0)
						mCompnyList.clear();
					if (mAdapter != null)
						mAdapter.clear();
					Utility.displayAlert(
							SearchCompanyStockActivity.this,
							getString(R.string.app_name),
							getString(R.string.alert_no_search_res),
							android.R.string.ok,
							Utility.getOkButtonListener(SearchCompanyStockActivity.this));
				}

				@Override
				public void OnCompanySearchDloadCmplt(
						CompanyStockNewsFeed[] result) {
					Utility.hideProgressDialog();
					displayCompnyList(result);
				}

			}, url);

		} else {
			Utility.displayAlert(
					SearchCompanyStockActivity.this,
					getString(R.string.app_name),
					getString(R.string.alert_no_search_txt_entered),
					android.R.string.ok,
					Utility.getOkButtonListener(SearchCompanyStockActivity.this));
			if (mCompnyList != null && mCompnyList.size() > 0)
				mCompnyList.clear();
			if (mAdapter != null)
				mAdapter.clear();
		}

	}

	/**
	 * @param result
	 */
	protected void displayCompnyList(CompanyStockNewsFeed[] result) {
		if (result != null && result.length > 0) {
			mAdapter.clear();
			for (int i = 0; i < result.length; i++) {
				CompanyStockNewsFeed item = result[i];
				if (item.bsestock.coName == null
						&& item.nsestock.coName == null) {

					// don't add to array
				} else {
					mCompnyList.add(item);
					

				}
			}
		} else {
			mCompnyList.clear();
			mAdapter.clear();
			Utility.displayAlert(this, getString(R.string.app_name),
					getString(R.string.alert_no_search_res),
					android.R.string.ok, Utility.getOkButtonListener(this));
		}
		mAdapter.notifyDataSetChanged();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * android.widget.AdapterView.OnItemClickListener#onItemClick(android.widget
	 * .AdapterView, android.view.View, int, long)
	 */
	@Override
	public void onItemClick(AdapterView<?> arg0, View view, int position,
			long id) {
		Constants.setCompny_list_items(mCompnyList);
		Intent intent = new Intent(SearchCompanyStockActivity.this,
				CompanyDetailsActivity.class);
		intent.putExtra(CompanyKeys.POSITION, position);
		intent.putExtra(Constants.IS_INDICES_FRAGMENT, false);
		intent.putExtra(Constants.SEARCH_BTN_VISIBLE, false);
		intent.putExtra(Constants.MARKET_SUB_CAT,
				getString(R.string.cat_indices));

		startActivity(intent);
	}
}
