/**
 * Project      : Economist
 * Filename     : SettingsFragment.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.settings.ui;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.businessstandard.R;
import com.businessstandard.common.dto.SectionMainItem;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.ui.BaseFragment.FragmentListner;

import java.io.File;
import java.util.ArrayList;
import java.util.Objects;

/**
 * @author lenesha
 */
public class SettingsFragment extends Fragment implements OnItemClickListener {

    private SettingsItemClickListner mSettingsClickListener;
    private ArrayAdapter<String> mAdapter;
    private FragmentActivity mcontext;
    public static ArrayList<SectionMainItem> lstDynamicItems;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mcontext = getActivity();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        FragmentListner mFragmntListner = (FragmentListner) mcontext;
        View view = inflater.inflate(R.layout.settings_fragment, container, false);

        ListView mListview = (ListView) view.findViewById(R.id.settingsItems);

        Resources res = getResources();
        String[] settingsArray = res.getStringArray(R.array.settingsArray);
        String fileDirPath = Objects.requireNonNull(getActivity()).getFilesDir() + "/userinfo.json";
        File file = new File(fileDirPath);
        SectionNewsRootFeedItem feed1 = mFragmntListner.getDataFromActivity();

        lstDynamicItems = new ArrayList<SectionMainItem>();
        String[] temparray = new String[1];
        if (feed1 != null) {
            lstDynamicItems = feed1.getSettings();
            int totalskip = 0;
            for (int i = 0; i < feed1.getSettings().size(); i++) {
                if (feed1.getSettings().get(i).categoryId.equalsIgnoreCase("80011") || feed1.getSettings().get(i).categoryId.equalsIgnoreCase("80012") || feed1.getSettings().get(i).categoryId.equalsIgnoreCase("80013") || feed1.getSettings().get(i).categoryId.equalsIgnoreCase("80008")) {
                    totalskip++;
                }
            }
            temparray = new String[5 + feed1.getSettings().size() - totalskip];

            int i = 0;
            for (SectionMainItem item : feed1.getSettings()) {
//				!item.categoryId.equalsIgnoreCase("80009")&& for Notification Setting
                if (!item.categoryId.equalsIgnoreCase("80011") && !item.categoryId.equalsIgnoreCase("80012") && !item.categoryId.equalsIgnoreCase("80013") && !item.categoryId.equalsIgnoreCase("80008")) {
                    temparray[i] = item.categoryName;
                    i++;
                }
            }
            temparray[i] = settingsArray[0]; //To add Account Settings in Settings Page
            temparray[i + 1] = settingsArray[2]; //To add Share App in Settings Page
            temparray[i + 2] = settingsArray[3]; //To add Rate Us in Settings Page
            temparray[i + 3] = settingsArray[5]; //To add Gallery in Settings Page
        } else {
            temparray = settingsArray;
        }

        if (file.exists()) {
            //Paid Login
            String[] newarray = new String[temparray.length - 1];
            for (int i = 0; i < temparray.length - 1; i++) {
                newarray[i] = temparray[i];
            }
            mAdapter = new ArrayAdapter<String>(getActivity(), R.layout.settings_list_item, R.id.list_txt, newarray);
            mListview.setAdapter(mAdapter);
        } else {
            //No Login
            String[] newarray1 = new String[temparray.length - 1];
            for (int i = 0; i < temparray.length - 1; i++) {
                newarray1[i] = temparray[i];
            }
            mAdapter = new ArrayAdapter<String>(getActivity(), R.layout.settings_list_item, R.id.list_txt, newarray1);
            mListview.setAdapter(mAdapter);
        }

        mSettingsClickListener = castToListener(getActivity());

        mListview.setOnItemClickListener(this);
        return view;
    }

    @Override
    public void onItemClick(AdapterView<?> arg0, View view, int position, long id) {
        String clickedItem = mAdapter.getItem(position);
        mSettingsClickListener.onSettingsItemClick(position, clickedItem);
    }

    private SettingsItemClickListner castToListener(Activity activity) {
        return (SettingsItemClickListner) activity;
    }

    public interface SettingsItemClickListner {
        public void onSettingsItemClick(int position, String clickedItem);
    }
}
