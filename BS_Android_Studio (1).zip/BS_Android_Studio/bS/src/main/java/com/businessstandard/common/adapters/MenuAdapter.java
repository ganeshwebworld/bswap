package com.businessstandard.common.adapters;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.model.MenuItemModel;

import java.util.List;

public class MenuAdapter extends BaseExpandableListAdapter {

    public static int groupPosition = 0;
    private Activity activity;
    private List<MenuItemModel> menuList;

    public MenuAdapter(Activity activity, List<MenuItemModel> menuList) {
        this.activity = activity;
        this.menuList = menuList;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return menuList.get(groupPosition).getChildMenuList().get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        MenuItemModel menuChildItemModel = menuList.get(groupPosition).getChildMenuList().get(childPosition);
        if (convertView == null) {
            convertView = activity.getLayoutInflater().inflate(R.layout.child_item, null);
        }
        ((TextView) convertView.findViewById(R.id.tvChildName)).setText(menuChildItemModel.getMenuName());
        return convertView;
    }


    public int getChildrenCount(int groupPosition) {
        return menuList.get(groupPosition).getChildMenuList().size();
    }

    public Object getGroup(int groupPosition) {
        return menuList.get(groupPosition);
    }

    public int getGroupCount() {
        return menuList.size();
    }

    public long getGroupId(int groupPosition) {
        return groupPosition;
    }


    public View getGroupView(int groupPosition, final boolean isExpanded, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = activity.getLayoutInflater().inflate(R.layout.group_item, null);
        }
        TextView tvname = ((TextView) convertView.findViewById(R.id.tvName));
        tvname.setText(menuList.get(groupPosition).getMenuName());

        final ImageView ivExpand = ((ImageView) convertView.findViewById(R.id.ivExpand));

        ivExpand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isExpanded) {
                    ((ExpandableListView) parent).collapseGroup(groupPosition);
                } else {
                    ((ExpandableListView) parent).expandGroup(groupPosition, true);
                }

            }
        });

        if (menuList.get(groupPosition).getChildMenuList().size() == 0) {
            ivExpand.setVisibility(View.INVISIBLE);
        } else {
            if (this.groupPosition == groupPosition) {
                ivExpand.setBackgroundResource(R.drawable.collapse);
                if (!isExpanded) {
                    this.groupPosition = -100;
                    ivExpand.setBackgroundResource(R.drawable.expand);
                }
            } else {
                ivExpand.setBackgroundResource(R.drawable.expand);
            }
        }
        return convertView;
    }

    public boolean hasStableIds() {
        return true;
    }

    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

}
