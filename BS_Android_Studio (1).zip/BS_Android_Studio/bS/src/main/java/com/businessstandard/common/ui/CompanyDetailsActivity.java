/**
 * Project      : Economist
 * Filename     : CompanyDetailsActivity.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */

package com.businessstandard.common.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.adapters.CompanyDetailViewPagerAdapter;
import com.businessstandard.common.adapters.CompanyDetailViewPagerAdapter.OnBseNotAvailListener;
import com.businessstandard.common.adapters.CompanyDetailViewPagerAdapter.OnNseNotAvailListener;
import com.businessstandard.common.customviews.CategoryScrollView;
import com.businessstandard.common.customviews.CategoryScrollView.OnCategorySelectedListener;
import com.businessstandard.common.customviews.CategoryScrollView.OnIndicatorsChangesListener;
import com.businessstandard.common.ui.BaseFragment.CompanyDataListner;
import com.businessstandard.common.util.Constants;
import com.businessstandard.common.util.Constants.CompanyKeys;
import com.businessstandard.common.util.Constants.MarketKeys;
import com.businessstandard.common.util.Constants.SearchStock;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.HomeManager;
import com.businessstandard.market.dto.CompanyStockNewsFeed;
import com.businessstandard.market.ui.MarketActivity;
import com.businessstandard.analytics.GoogleAnalytics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author lenesha
 */
public class CompanyDetailsActivity extends FragmentActivity implements CompanyDataListner, OnNseNotAvailListener, OnBseNotAvailListener, OnClickListener {

    protected ArrayList<CompanyStockNewsFeed> mCompnyList;
    private CategoryScrollView mCategoryScrollView;
    protected ArrayList<String> mSubCategoryList;
    private CompanyStockNewsFeed mItemCLicked;
    private HashMap<String, CompanyStockNewsFeed> mSubCatgryMap;
    private CompanyStockNewsFeed mCategoryItemCLicked;
    private ViewPager mCompanyViewpager;
    private List<CompanyStockNewsFeed> mCompanyDetlist;
    private CompanyDetailViewPagerAdapter mPagerAdapter;
    private int mPositionOfItemFocused, mCurrentViewpagerPos;
    private String mSelectedCategry;
    private Button mSearchBtn;
    private boolean mIsIndicesFrag = false, mIsSearchBtnVisible;
    private ImageView mHeaderTxt;
    Button menu;
    private GoogleAnalytics mGoogleAnalytics;

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setContentView(R.layout.company_details);
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        mCompanyViewpager = (ViewPager) findViewById(R.id.company_pager);
        TextView date = (TextView) findViewById(R.id.header_date);
        date.setText(Utility.getTodaysData());
        mCompnyList = Constants.getCompny_list_items();
        Constants.setCompny_list_items(null);
        mSearchBtn = (Button) findViewById(R.id.search_button);
        findViewById(R.id.refresh_btn).setVisibility(View.INVISIBLE);
        Intent intent = getIntent();
        mPositionOfItemFocused = intent.getIntExtra(CompanyKeys.POSITION, 0);
        mIsIndicesFrag = intent.getBooleanExtra(Constants.IS_INDICES_FRAGMENT, false);
        mIsSearchBtnVisible = intent.getBooleanExtra(Constants.SEARCH_BTN_VISIBLE, true);
        mSelectedCategry = intent.getStringExtra(Constants.MARKET_SUB_CAT);
        menu = (Button) findViewById(R.id.menu);
        menu.setVisibility(View.GONE);
        if (mCompnyList != null)
            mItemCLicked = mCompnyList.get(mPositionOfItemFocused);
        mCategoryScrollView = (CategoryScrollView) findViewById(R.id.category_scrollview);
        mCurrentViewpagerPos = mPositionOfItemFocused;
        mHeaderTxt = (ImageView) findViewById(R.id.header_txt);
        if (!mIsSearchBtnVisible) {
            mSearchBtn.setVisibility(View.INVISIBLE);
        } else {
            mSearchBtn.setVisibility(View.VISIBLE);
            mSearchBtn.setOnClickListener(this);

        }

        mCategoryScrollView.setOnCategorySelectedListener(new OnCategorySelectedListener() {

            @Override
            public void onCategorySelected(String category) {
                loadSelectedCategoryContent(category);
                addSubCategory(mSubCategoryList, category);
            }
        });
        mCategoryScrollView
                .setOnIndicatorsChangedListener(new OnIndicatorsChangesListener() {

                    @Override
                    public void onIndicatorsChanged(boolean showLeft,
                                                    boolean showRight) {
                    }
                });

        mCategoryScrollView.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {

            @Override
            public void onGlobalLayout() {

                mCategoryScrollView.getViewTreeObserver().removeGlobalOnLayoutListener(this);

                initaliseScrollView(mPositionOfItemFocused);

            }
        });
        loadCategories();
        initPager();
        intiListeners();
    }

    /**
     * @author nagaraj
     */
    private void intiListeners() {
        mHeaderTxt.setOnClickListener(this);

    }


    private void initPager() {
        mPagerAdapter = new CompanyDetailViewPagerAdapter(this, mCompanyDetlist, mIsIndicesFrag);
        mCompanyViewpager.setAdapter(mPagerAdapter);
        mCompanyViewpager.setCurrentItem(mPositionOfItemFocused);
        onNseDataNotAvailable();
        onBseDataNotAvailable();

        mCompanyViewpager.setOnPageChangeListener(new OnPageChangeListener() {

            @Override
            public void onPageSelected(int position) {

                initaliseScrollView(position);
                mPositionOfItemFocused = position;
                mCurrentViewpagerPos = position;

            }


            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {

            }

            @Override
            public void onPageScrollStateChanged(int arg0) {

            }
        });

    }

    private void initaliseScrollView(int position) {
        String categoryToBeSel = null;

        if ((mCompanyDetlist.get(position).bsestock != null && mCompanyDetlist.get(position).bsestock.coName != null)) {
            //AnalyticsUtils.getInstAnalyticsUtils(CompanyDetailsActivity.this).trackPageView(mSelectedCategry + mCompanyDetlist.get(position).bsestock.coName);
            if (mGoogleAnalytics != null) {
                mGoogleAnalytics.trackScreenView(mSelectedCategry + mCompanyDetlist.get(position).bsestock.coName, CompanyDetailsActivity.this);
            }
            categoryToBeSel = mCompanyDetlist.get(position).bsestock.coName;

        }
        if (mCompanyDetlist.get(position).nsestock != null && mCompanyDetlist.get(position).nsestock.coName != null) {
            //AnalyticsUtils.getInstAnalyticsUtils(CompanyDetailsActivity.this).trackPageView(mSelectedCategry + mCompanyDetlist.get(position).nsestock.coName);
            if (mGoogleAnalytics != null) {
                mGoogleAnalytics.trackScreenView(mSelectedCategry + mCompanyDetlist.get(position).nsestock.coName, CompanyDetailsActivity.this);
            }
            categoryToBeSel = mCompanyDetlist.get(position).nsestock.coName;
        }


        TextView selCat = mCategoryScrollView.getCategory(categoryToBeSel);
        int x = selCat.getLeft();
        int y = selCat.getTop();

        mCategoryScrollView.scrollTo(x, y);
        addSubCategory(mSubCategoryList, (String) selCat.getText());

    }


    //	/**
//	 * @param item
//	 */
    private void loadCategories() {
        mSubCatgryMap = new HashMap<String, CompanyStockNewsFeed>();
        mSubCategoryList = new ArrayList<String>();
        mCompanyDetlist = new ArrayList<CompanyStockNewsFeed>();

        String coName = null;
        if (mCompnyList != null) {
            for (CompanyStockNewsFeed item : mCompnyList) {
                if (item.bsestock != null && item.bsestock.coName != null)
                    coName = item.bsestock.coName;
                else {
                    if (item.nsestock != null)
                        coName = item.nsestock.coName;
                }
                mSubCategoryList.add(coName);
                mSubCatgryMap.put(coName, item);
                mCompanyDetlist.add(item);
            }
        }
        String selected_coname = null;
        if (mItemCLicked != null && mItemCLicked.bsestock != null && mItemCLicked.bsestock.coName != null)
            selected_coname = mItemCLicked.bsestock.coName;
        else {
            if (mItemCLicked != null && mItemCLicked.nsestock != null)
                selected_coname = mItemCLicked.nsestock.coName;
        }
        addSubCategory(mSubCategoryList, selected_coname);
        loadSelectedCategoryContent(selected_coname);
    }

    /**
     * @param selected_coname
     */
    private void loadSelectedCategoryContent(String selected_coname) {

        int position = 0;
        for (int loopcount = 0; loopcount < mCompanyDetlist.size(); loopcount++) {
            String nseCompName = null;
            String bseCompname = null;
            if (mCompanyDetlist.get(loopcount).nsestock != null) {
                nseCompName = mCompanyDetlist.get(loopcount).nsestock.coName;
            }
            if (mCompanyDetlist.get(loopcount).bsestock != null) {
                bseCompname = mCompanyDetlist.get(loopcount).bsestock.coName;
            }
            if (nseCompName != null) {
                if (nseCompName.equals(selected_coname)) {
                    position = loopcount;
                    break;
                }
            }
            if (bseCompname != null) {
                if (bseCompname.equals(selected_coname)) {
                    position = loopcount;
                    break;
                }
            }
        }
        Log.d("Scroll", " " + position);

        mCompanyViewpager.setCurrentItem(position);
    }

    //	/**
//	 * @param mSubCategoryList2
//	 * @param category
//	 */
    protected void addSubCategory(ArrayList<String> mSubCategoryList2,
                                  String selected_coname) {
        Log.i("", "" + selected_coname);
        mCategoryScrollView.addCategory(mSubCategoryList2, selected_coname);

    }

    /* (non-Javadoc)
     * @see com.businessstandard.common.ui.BaseFragment.CompanyDataListner#onCompanySelectListner()
     */
    @Override
    public CompanyStockNewsFeed onCompanySelectListner() {
        return mCategoryItemCLicked;
    }

    /* (non-Javadoc)
     * @see com.businessstandard.common.adapters.CompanyDetailViewPagerAdapter.OnNseNotAvailListener#onNseBseNotAvailable()
     */
    @Override
    public void onNseDataNotAvailable() {

        if (mCompanyDetlist.get(mCurrentViewpagerPos).nsestock != null && mCompanyDetlist.get(mCurrentViewpagerPos).nsestock.coName == null) {

            Utility.showToast(getString(R.string.no_nse_data), this);

        } else if (mCompanyDetlist.get(mCurrentViewpagerPos).nsestock == null) {

            Utility.showToast(getString(R.string.no_nse_data), this);

        }
    }

    /* (non-Javadoc)
     * @see com.businessstandard.common.adapters.CompanyDetailViewPagerAdapter.OnBseNotAvailListener#onBseDataNotAvailable()
     */
    @Override
    public void onBseDataNotAvailable() {
        if (mCompanyDetlist.get(mCurrentViewpagerPos).bsestock != null && mCompanyDetlist.get(mCurrentViewpagerPos).bsestock.coName == null) {
            Utility.showToast(getString(R.string.no_bse_data), this);
        } else if (mCompanyDetlist.get(mCurrentViewpagerPos).bsestock == null) {
            Utility.showToast(getString(R.string.no_bse_data), this);

        }
    }

    /* (non-Javadoc)
     * @see android.view.View.OnClickListener#onClick(android.view.View)
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.search_button:
                String searchUrl = HomeManager.sSearchUrl;
                Intent searchIntent = new Intent(this, SearchCompanyStockActivity.class);
                searchIntent.putExtra(SearchStock.SEARCH_STOCK_URL, searchUrl);
                searchIntent.putExtra(MarketKeys.MARKET_ACTIVITY, true);
                startActivity(searchIntent);
                break;
            case R.id.header_txt:
                LaunchHome();
                break;
        }

    }


    /**
     * @author nagaraj
     */
    private void LaunchHome() {
        Intent intent = new Intent(this, MarketActivity.class);
        intent.setFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra(MarketKeys.LAUNCH_MARKET, true);
        startActivity(intent);

    }


}
