package com.businessstandard.gallery;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.model.GalleryVideoslist;

import java.util.ArrayList;
import java.util.List;

public class VideosListAdapter extends BaseAdapter {

    private List<GalleryVideoslist> mGalleryVideoslist;
    private Context mContext;
    private LayoutInflater layoutInflater;

    public VideosListAdapter(List<GalleryVideoslist> galleryVideoslist, Context context) {
        this.mGalleryVideoslist = galleryVideoslist;
        this.mContext = context;
        layoutInflater = LayoutInflater.from(context);
    }

    public void setVideosList(List<GalleryVideoslist> videoList) {
        this.mGalleryVideoslist = new ArrayList<>(videoList);
    }

    @Override
    public int getCount() {
        return mGalleryVideoslist.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = layoutInflater.inflate(R.layout.gallery_item_layout, null);
        TextView videoTitle = (TextView) convertView.findViewById(R.id.videoTitle);
        if (mGalleryVideoslist != null && mGalleryVideoslist.size() > 0) {
            if (!TextUtils.isEmpty(mGalleryVideoslist.get(position).getTitle())) {
                videoTitle.setText(mGalleryVideoslist.get(position).getTitle());
            }
        }
        return convertView;
    }
}
