package com.businessstandard.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class GalleryDetailResponseModel implements Serializable {

    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("galleryVideo")
    @Expose
    private List<GalleryVideo> galleryVideo = null;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<GalleryVideo> getGalleryVideo() {
        return galleryVideo;
    }

    public void setGalleryVideo(List<GalleryVideo> galleryVideo) {
        this.galleryVideo = galleryVideo;
    }

}