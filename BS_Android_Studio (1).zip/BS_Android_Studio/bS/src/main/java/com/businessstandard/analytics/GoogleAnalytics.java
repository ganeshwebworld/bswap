package com.businessstandard.analytics;

import android.content.Context;

import com.google.android.gms.analytics.HitBuilders;
import com.google.android.gms.analytics.StandardExceptionParser;
import com.google.android.gms.analytics.Tracker;

public class GoogleAnalytics {

    private static GoogleAnalytics mInstance;

    public static synchronized GoogleAnalytics getInstance() {
        if (mInstance == null) {
            mInstance = new GoogleAnalytics();
        }
        return mInstance;
    }

    public synchronized Tracker getGoogleAnalyticsTracker() {
        AnalyticsTrackers analyticsTrackers = AnalyticsTrackers.getInstance();
        return analyticsTrackers.get(AnalyticsTrackers.Target.APP);
    }

    /***
     * Tracking screen view
     *
     * @param screenName screen name to be displayed on GA dashboard
     */
    public void trackScreenView(String screenName, Context context) {
        Tracker t = getGoogleAnalyticsTracker();
        if (t != null) {
            // Set screen name.
            t.setScreenName("Android : " + screenName);

            // Send a screen view.
            t.send(new HitBuilders.ScreenViewBuilder().build());

            com.google.android.gms.analytics.GoogleAnalytics.getInstance(context).dispatchLocalHits();
        }
    }

    /***
     * Tracking exception
     *
     * @param e exception to be tracked
     */
    public void trackException(Exception e, Context context) {
        if (e != null) {
            Tracker t = getGoogleAnalyticsTracker();
            if (t != null) {
                t.send(new HitBuilders.ExceptionBuilder()
                        .setDescription(
                                new StandardExceptionParser(context, null)
                                        .getDescription(Thread.currentThread().getName(), e))
                        .setFatal(false)
                        .build()
                );
            }
        }
    }

    /***
     * Tracking event
     *
     * @param category event category
     * @param action   action of the event
     * @param label    label
     */
    public void trackEvent(String category, String action, String label) {
        Tracker t = getGoogleAnalyticsTracker();
        if (t != null) {
            // Build and send an Event.
            t.send(new HitBuilders.EventBuilder().setCategory(category).setAction(action).setLabel(label).build());
        }
    }

}
