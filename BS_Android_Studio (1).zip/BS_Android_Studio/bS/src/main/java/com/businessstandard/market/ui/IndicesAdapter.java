/**
   Project      : Economist
   Filename     : IndicesAdapter.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */

package com.businessstandard.market.ui;

import java.util.ArrayList;

import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.market.dto.BseIndicesItems;
import com.businessstandard.market.dto.BseStockDataItem;
import com.businessstandard.market.dto.NseIndicesItems;
import com.businessstandard.market.dto.NseStockDataItem;
import com.businessstandard.market.dto.StockHolder;

/**
 * @author lenesha
 * 
 */
public class IndicesAdapter extends ArrayAdapter<StockHolder> {

	private LayoutInflater mInflater;
	private OnClickListener mRowItemClkListner;

//	/**
//	 * @param mcontext
//	 * @param stockList
//	 * @param stock_list
//	 */

	public IndicesAdapter(FragmentActivity context, int stockList,
			ArrayList<StockHolder> stock_list, OnClickListener rowItemClkListner) {
		super(context, stockList, stock_list);
		mInflater = LayoutInflater.from(context);
		mRowItemClkListner = rowItemClkListner;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.widget.ArrayAdapter#getView(int, android.view.View,
	 * android.view.ViewGroup)
	 */

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.indices_list_item, null);
			holder = new ViewHolder();
			holder.headerLabel = (TextView) convertView
					.findViewById(R.id.header_label);

			holder.table = (TableLayout) convertView
					.findViewById(R.id.the_table);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		StockHolder item = getItem(position);

		if (item instanceof BseIndicesItems) {
			BseIndicesItems bseItems = (BseIndicesItems) item;
			holder.headerLabel.setText(getContext().getResources().getString(
					R.string.bse));
			holder.table.removeAllViews();
			if (bseItems != null && bseItems.bseIndicesItem != null) {
				for (int current = 0; current < bseItems.bseIndicesItem.length; current++) {
					TableRow rowItem = (TableRow) mInflater.inflate(
							R.layout.indices_row, null);
					TextView cmpny = (TextView) rowItem
							.findViewById(R.id.indices_coname);
					TextView price = (TextView) rowItem
							.findViewById(R.id.indices_price);
					TextView stockChange = (TextView) rowItem
							.findViewById(R.id.indices_change);
					TextView stockChangepercntg = (TextView) rowItem
							.findViewById(R.id.indices_changprcnt);

					final BseStockDataItem bseItem = bseItems.bseIndicesItem[current];
					cmpny.setText(bseItem.coName);
					try {
						Float priceValue = Float.valueOf(bseItem.price);
						price.setText(bseItem.price);

					} catch (NumberFormatException e) {
						price.setText("0.0");

					}
					
					try {
						Float changeValue = Float.valueOf(bseItem.changeValue);
						stockChange.setText(bseItem.changeValue);

					} catch (NumberFormatException e) {
						stockChange.setText("0.0");

					}
					try {
						Float changePercent = Float
								.valueOf(bseItem.changePercent);
						stockChangepercntg.setText(bseItem.changePercent);

					} catch (NumberFormatException e) {
						stockChangepercntg.setText("0.0");

					}

					holder.table.addView(rowItem);
					rowItem.setTag(bseItem.coName);
					rowItem.setOnClickListener(mRowItemClkListner);
				}
			}
		} else {
			NseIndicesItems nseItems = (NseIndicesItems) item;
			holder.headerLabel.setText(getContext().getResources().getString(
					R.string.nse));

			holder.table.removeAllViews();
			if (nseItems != null && nseItems.nseIndicesItem != null) {
				for (int current = 0; current < nseItems.nseIndicesItem.length; current++) {
					TableRow rowItem = (TableRow) mInflater.inflate(
							R.layout.indices_row, null);
					TextView cmpny = (TextView) rowItem
							.findViewById(R.id.indices_coname);
					TextView price = (TextView) rowItem
							.findViewById(R.id.indices_price);
					TextView stockChange = (TextView) rowItem
							.findViewById(R.id.indices_change);
					TextView stockChangepercntg = (TextView) rowItem
							.findViewById(R.id.indices_changprcnt);

					final NseStockDataItem nseItem = nseItems.nseIndicesItem[current];
					cmpny.setText(nseItem.coName);

					try {
						Float priceValue = Float.valueOf(nseItem.price);
						price.setText(nseItem.price);

					} catch (NumberFormatException e) {
						price.setText("0.0");

					}

					try {
						Float changeValue = Float.valueOf(nseItem.changeValue);
						stockChange.setText(nseItem.changeValue);

					} catch (NumberFormatException e) {
						stockChange.setText("0.0");

					}
					try {
						Float changePercent = Float
								.valueOf(nseItem.changePercent);
						stockChangepercntg.setText(nseItem.changePercent);
					} catch (NumberFormatException e) {
						stockChangepercntg.setText("0.0");

					}
					holder.table.addView(rowItem);
					rowItem.setTag(nseItem.coName);
					rowItem.setOnClickListener(mRowItemClkListner);

				}
			}
		}
		return convertView;
	}

	private static class ViewHolder {
		TextView headerLabel;
		TableLayout table;
	}
}
