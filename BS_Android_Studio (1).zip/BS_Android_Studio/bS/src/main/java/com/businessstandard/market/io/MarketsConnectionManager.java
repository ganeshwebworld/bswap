/**
   Project      : Economist
   Filename     : MarketsConnectionManager.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.market.io;

import java.lang.ref.WeakReference;

import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import android.content.Context;
import android.util.Log;

import com.businessstandard.R;
import com.businessstandard.common.util.ConnectionUtility;
import com.businessstandard.common.util.RestTemplateContainer;
import com.businessstandard.home.HomeManager;
import com.businessstandard.market.dto.BseStockDataItem;
import com.businessstandard.market.dto.McxAndNcdexRootFeedItem;
import com.businessstandard.market.dto.McxFutureRootFeedItem;
import com.businessstandard.market.dto.McxLoosersRootFeedItem;
import com.businessstandard.market.dto.McxSpotRootFeedItem;
import com.businessstandard.market.dto.NcdexFutureRootFeedItem;
import com.businessstandard.market.dto.NcdexGainersRootFeedItem;
import com.businessstandard.market.dto.NcdexLoosersRootFeedItem;
import com.businessstandard.market.dto.NcdexSpotRootFeedItem;
import com.businessstandard.market.dto.NseStockDataItem;
import com.businessstandard.market.dto.TickerNewsFeedRootObject;

/**
 * @author lenesha
 *
 */
public class MarketsConnectionManager {

	private WeakReference<Context> mContext;

	
	/**
	 * @param applicationContext
	 */
	public MarketsConnectionManager(Context applicationContext) {
		mContext = new WeakReference<Context>(applicationContext);

	}


	/**
	 * @param url
	 * @return
	 */
		public String getSubNewsFeeds(String url) {
		MultiValueMap<String, String> param = new LinkedMultiValueMap<String, String>();
		RestTemplateContainer restTemplateContainer = ConnectionUtility
				.createRestTemplate(param);
		ResponseEntity<String> responseEntity = null;

		try {
			responseEntity = restTemplateContainer.restTemplate.exchange(url,
					HttpMethod.GET, restTemplateContainer.httpEntity,
					String.class);
			if (responseEntity.getStatusCode() == HttpStatus.OK)
				return responseEntity.getBody();
			else
				return null;
		} catch (Exception e) {
			Log.i("EXCEPTION", e.getMessage());
			return null;
		}
	}
		public TickerNewsFeedRootObject getTickerFeeds() {
			try {
				MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
				RestTemplateContainer restTemplateContainer = ConnectionUtility
						.createRestTemplate(params, mContext.get());
				ResponseEntity<TickerNewsFeedRootObject> responseEntity;

				String finalUrl = HomeManager.sStock_graph;
				responseEntity = restTemplateContainer.restTemplate.exchange(
						finalUrl, HttpMethod.GET, restTemplateContainer.httpEntity,
						TickerNewsFeedRootObject.class);
				if (responseEntity.getStatusCode() == HttpStatus.OK)
					return responseEntity.getBody();
				else
					return null;

			} catch (Exception e) {
				Log.i("EXCEPTION", e.getMessage());

				return null;

			}

		}


		/**
		 * @param url
		 * @return
		 */
		public BseStockDataItem[] getBSESensexFeeds(String url) {
			try {
				MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
				RestTemplateContainer restTemplateContainer = ConnectionUtility
						.createRestTemplate(params,mContext.get());
				ResponseEntity<BseStockDataItem[]> responseEntity;

				responseEntity = restTemplateContainer.restTemplate.exchange(
						url, HttpMethod.GET, restTemplateContainer.httpEntity,
						BseStockDataItem[].class);
				if (responseEntity.getStatusCode() == HttpStatus.OK)
					return responseEntity.getBody();
				else
					return null;

			} catch (Exception e) {
				Log.i("EXCEPTION", e.getMessage());

				return null;

			}
		}
		public NseStockDataItem[] getNSESensexFeeds(String url) {
			try {
				MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
				RestTemplateContainer restTemplateContainer = ConnectionUtility
						.createRestTemplate(params,mContext.get());
				ResponseEntity<NseStockDataItem[]> responseEntity;

				responseEntity = restTemplateContainer.restTemplate.exchange(
						url, HttpMethod.GET, restTemplateContainer.httpEntity,
						NseStockDataItem[].class);
				if (responseEntity.getStatusCode() == HttpStatus.OK)
					return responseEntity.getBody();
				else
					return null;

			} catch (Exception e) {
				Log.i("EXCEPTION", e.getMessage());

				return null;

			}
		}
public McxAndNcdexRootFeedItem getMcxGainersFeeds(String url){
			
			try {
				MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
				RestTemplateContainer restTemplateContainer = ConnectionUtility
						.createRestTemplate(params,mContext.get());
				ResponseEntity<McxAndNcdexRootFeedItem> responseEntity;

				responseEntity = restTemplateContainer.restTemplate.exchange(
						url, HttpMethod.GET, restTemplateContainer.httpEntity,
						McxAndNcdexRootFeedItem.class);
				if (responseEntity.getStatusCode() == HttpStatus.OK)
					return responseEntity.getBody();
				else
					return null;

			} catch (Exception e) {
				Log.i("EXCEPTION", e.getMessage());

				return null;

			}
			
		}


		/**
		 * @param url
		 * @return
		 */
		public McxLoosersRootFeedItem getMcxLoosersFeeds(String url) {
			try {
				MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
				RestTemplateContainer restTemplateContainer = ConnectionUtility
						.createRestTemplate(params,mContext.get());
				ResponseEntity<McxLoosersRootFeedItem> responseEntity;

				responseEntity = restTemplateContainer.restTemplate.exchange(
						url, HttpMethod.GET, restTemplateContainer.httpEntity,
						McxLoosersRootFeedItem.class);
				if (responseEntity.getStatusCode() == HttpStatus.OK)
					return responseEntity.getBody();
				else
					return null;

			} catch (Exception e) {
				Log.i("EXCEPTION", e.getMessage());

				return null;

			}
		}


		/**
		 * @param url
		 * @return
		 */
		public NcdexGainersRootFeedItem getNcdexGainersFeeds(String url) {
			try {
				MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
				RestTemplateContainer restTemplateContainer = ConnectionUtility
						.createRestTemplate(params,mContext.get());
				ResponseEntity<NcdexGainersRootFeedItem> responseEntity;

				responseEntity = restTemplateContainer.restTemplate.exchange(
						url, HttpMethod.GET, restTemplateContainer.httpEntity,
						NcdexGainersRootFeedItem.class);
				if (responseEntity.getStatusCode() == HttpStatus.OK)
					return responseEntity.getBody();
				else
					return null;

			} catch (Exception e) {
				Log.i("EXCEPTION", e.getMessage());

				return null;

			}
		}


		/**
		 * @param url
		 * @return
		 */
		public NcdexLoosersRootFeedItem getNcdexLoosersFeeds(String url) {
			try {
				MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
				RestTemplateContainer restTemplateContainer = ConnectionUtility
						.createRestTemplate(params,mContext.get());
				ResponseEntity<NcdexLoosersRootFeedItem> responseEntity;

				responseEntity = restTemplateContainer.restTemplate.exchange(
						url, HttpMethod.GET, restTemplateContainer.httpEntity,
						NcdexLoosersRootFeedItem.class);
				if (responseEntity.getStatusCode() == HttpStatus.OK)
					return responseEntity.getBody();
				else
					return null;

			} catch (Exception e) {
				Log.i("EXCEPTION", e.getMessage());

				return null;

			}
		}


		/**
		 * @param url
		 * @return
		 */
		public McxSpotRootFeedItem getMcxSpotFeeds(String url) {
			try {
				MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
				RestTemplateContainer restTemplateContainer = ConnectionUtility
						.createRestTemplate(params,mContext.get());
				ResponseEntity<McxSpotRootFeedItem> responseEntity;

				responseEntity = restTemplateContainer.restTemplate.exchange(
						url, HttpMethod.GET, restTemplateContainer.httpEntity,
						McxSpotRootFeedItem.class);
				if (responseEntity.getStatusCode() == HttpStatus.OK)
					return responseEntity.getBody();
				else
					return null;

			} catch (Exception e) {
				Log.i("EXCEPTION", e.getMessage());

				return null;

			}
		}


		/**
		 * @param url
		 * @return
		 */
		public NcdexSpotRootFeedItem getNcdexSpotFeeds(String url) {
			try {
				MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
				RestTemplateContainer restTemplateContainer = ConnectionUtility
						.createRestTemplate(params,mContext.get());
				ResponseEntity<NcdexSpotRootFeedItem> responseEntity;

				responseEntity = restTemplateContainer.restTemplate.exchange(
						url, HttpMethod.GET, restTemplateContainer.httpEntity,
						NcdexSpotRootFeedItem.class);
				if (responseEntity.getStatusCode() == HttpStatus.OK)
					return responseEntity.getBody();
				else
					return null;

			} catch (Exception e) {
				Log.i("EXCEPTION", e.getMessage());

				return null;

			}
		}


		/**
		 * @param url
		 * @return
		 */
		public McxFutureRootFeedItem getMcxFutureFeeds(String url) {
			try {
				MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
				RestTemplateContainer restTemplateContainer = ConnectionUtility
						.createRestTemplate(params,mContext.get());
				ResponseEntity<McxFutureRootFeedItem> responseEntity;

				responseEntity = restTemplateContainer.restTemplate.exchange(
						url, HttpMethod.GET, restTemplateContainer.httpEntity,
						McxFutureRootFeedItem.class);
				if (responseEntity.getStatusCode() == HttpStatus.OK)
					return responseEntity.getBody();
				else
					return null;

			} catch (Exception e) {
				Log.i("EXCEPTION", e.getMessage());

				return null;

			}

		}


		/**
		 * @param url
		 * @return
		 */
		public NcdexFutureRootFeedItem getNcdexFutureFeeds(String url) {
			try {
				MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
				RestTemplateContainer restTemplateContainer = ConnectionUtility
						.createRestTemplate(params,mContext.get());
				ResponseEntity<NcdexFutureRootFeedItem> responseEntity;

				responseEntity = restTemplateContainer.restTemplate.exchange(
						url, HttpMethod.GET, restTemplateContainer.httpEntity,
						NcdexFutureRootFeedItem.class);
				if (responseEntity.getStatusCode() == HttpStatus.OK)
					return responseEntity.getBody();
				else
					return null;

			} catch (Exception e) {
				Log.i("EXCEPTION", e.getMessage());

				return null;

			}
		}
}
