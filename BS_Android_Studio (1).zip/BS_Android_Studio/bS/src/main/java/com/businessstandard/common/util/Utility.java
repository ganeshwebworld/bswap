/**
 * Project      : Economist
 * Filename     : Utility.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */

package com.businessstandard.common.util;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.app.FragmentActivity;
import android.view.WindowManager.BadTokenException;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

/**
 * @author lenesha
 */
public class Utility {
    public static final String NEWLINE_CHARACTER = "\n";


    private static ProgressDialog sProgressDialog;

    public static boolean showNormalDialog() {
        return true;
    }

    public static boolean isInternetOn(Context context) {
        ConnectivityManager conn = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        assert conn != null;
        NetworkInfo networkInfo = conn.getActiveNetworkInfo();
        if (networkInfo != null) {
            return networkInfo.isConnected();
        }
        return false;
    }

    public static void displayProgressDailog(final FragmentActivity activity, int stringID) {

        OnCancelListener listener = new OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                activity.finish();
            }
        };

        displayProgressDialog(activity, listener, stringID);
    }

    private static void displayProgressDialog(final Activity activity, OnCancelListener listener, int stringID) {
        if (sProgressDialog != null && sProgressDialog.isShowing()) {
            return;
        }

        if (activity != null) {
            sProgressDialog = new ProgressDialog(activity);
            // DONE Audumb: Use strings.xml
            sProgressDialog.setMessage(activity.getString(stringID));
            sProgressDialog.setTitle(R.string.app_name);
            sProgressDialog.setCanceledOnTouchOutside(false);

            sProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            sProgressDialog.setOnCancelListener(listener);
            try {
                sProgressDialog.show();
            } catch (BadTokenException e) {
                e.printStackTrace();
            }
        }
    }

    public static void hideKeyboard(Activity context) {
        try {
            InputMethodManager keyBoardHandle = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            assert keyBoardHandle != null;
            keyBoardHandle.hideSoftInputFromWindow(Objects.requireNonNull(context.getCurrentFocus()).getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void hideProgressDialog() {
        if (sProgressDialog != null && sProgressDialog.isShowing()) {
            try {
                sProgressDialog.dismiss();

            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }

            sProgressDialog = null;
        }
    }

    public static DialogInterface.OnClickListener getOkButtonListener(final Activity activity) {
        OnClickListener clickListener = new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

            }
        };
        return clickListener;
    }

    public static void displayAlert(Context ctx, int titleId, int msgId, int positiveBtnId, OnClickListener positiveBtnListener) {
        if (ctx != null) {
            displayAlert(ctx, ctx.getString(titleId), ctx.getString(msgId), positiveBtnId, positiveBtnListener);
        }
    }

    public static void displayAlert(Context ctx, String title, String msg, int positiveBtnId, OnClickListener positiveBtnListener) {
        try {
            if (ctx != null && title != null && msg != null)
                new AlertDialog.Builder(ctx).setTitle(title).setMessage(msg)
                        .setCancelable(false)
                        .setPositiveButton(positiveBtnId, positiveBtnListener)
                        .create().show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void displayAlert(Context ctx, String title, String msg, int positiveBtnId, int cancelBtnId, OnClickListener positiveBtnListener, OnClickListener negBtnListener) {
        try {
            if (ctx != null && title != null && msg != null)
                new AlertDialog.Builder(ctx).setTitle(title).setMessage(msg)
                        .setCancelable(false)
                        .setPositiveButton(positiveBtnId, positiveBtnListener)
                        .setNegativeButton(cancelBtnId, negBtnListener)
                        .create().show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showToast(String msg, Context ctx) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
    }

    public static String getPublishedTime(String mDateTime) {
        String timeOfPubish = null;
        Date currentTime = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date convertedTime = null;
        try {
            convertedTime = dateFormat.parse(mDateTime);
            timeOfPubish = getTimeDiff(currentTime, convertedTime);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return timeOfPubish;

    }


    private static String getTimeDiff(Date currentTime, Date convertedTime) {
        long diff = currentTime.getTime() - convertedTime.getTime();
//		int days=	(int) ((currentTime.getTime() - convertedTime.getTime()) / (1000 * 60 * 60 * 24));
        long days = diff / (24 * 60 * 60 * 1000);
        String relativeTime = null;
        if (days > 1) {
            relativeTime = new String(days + " days ago");
        } else if (days == 1) {
            relativeTime = new String(days + " day ago");
        }
//		else if(days >= 6){
//			int week=(int) (days%2);
//			if(week>1)
//			relativeTime = new String(week + " weeks ago"); 
//			if(week==1)
//				relativeTime = new String(week + " weeks ago"); 
//		} 
        else {
            long hours = diff / (60 * 60 * 1000);
            if (hours >= 8) {
                relativeTime = new String(hours + " hours ago");
            } else {
                if (hours > 1) {
                    relativeTime = new String(hours + " hours ago");
                } else if (hours == 1) {
                    relativeTime = new String(hours + " hour ago");
                } else {
                    long minutes = diff / (60 * 1000);
                    if (minutes > 1) {
                        relativeTime = new String(minutes + " minutes ago");
                    } else if (minutes == 1) {
                        relativeTime = new String(minutes + " minute ago");
                    }
                }
            }
        }
        return relativeTime;
    }

    /**
     * @param updated_time
     */
    public static Date getUpdatedDate(String updated_time) {
        Date time = null;
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, dd MMM yyyyy HH:mm:ss z");//EEE, dd MMM yyyyy HH:mm:ss z
        try {
            time = dateFormat.parse(updated_time);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return time;
    }

    //gaurav- for description news
    public static Date getUpdatedDatenew(String updated_time) {
        Date time = null;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//EEE, dd MMM yyyyy HH:mm:ss z
        try {
            time = dateFormat.parse(updated_time);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return time;
    }

    public static String getDate(Date inDate) {
        String dateString = "";
        String pattern = "dd/MM/yyyy";
        SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
        try {
            dateString = dateFormat.format(inDate);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dateString;
    }

    public static String getTimeFromDate(Date inDate) {
        if (inDate != null) {
            String time = "";
            String pattern = "hh:mm a";
            SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
            try {
                time = dateFormat.format(inDate);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return time;
        } else {
            return "";
        }
    }

    public static String getTodaysData() {
        DateFormat.getDateTimeInstance();
        return DateFormat.getDateInstance().format(new Date());
    }

    private static SectionNewsRootFeedItem sectnRootItem;

    public static void setDataToActvty(SectionNewsRootFeedItem sectnRootItem) {
        Utility.sectnRootItem = sectnRootItem;
    }

}
