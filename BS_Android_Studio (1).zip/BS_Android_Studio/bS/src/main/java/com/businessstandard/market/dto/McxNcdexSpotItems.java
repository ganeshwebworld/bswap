/**
   Project      : Economist
   Filename     : McxNcdexSpotItems.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.market.dto;

import java.util.List;

/**
 * @author lenesha
 *
 */
public class McxNcdexSpotItems extends StockHolder {

	public List<McxAndNcdexSpotItem> mcxOrNcdexSpot;
	public boolean isMcxSpot = false;
	public boolean isNcdexSpot = false;
}
