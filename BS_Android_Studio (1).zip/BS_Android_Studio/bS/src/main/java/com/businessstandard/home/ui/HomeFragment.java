/**
 * Project      : Economist
 * Filename     : HomeFragment.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.home.ui;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.analytics.GoogleAnalytics;
import com.businessstandard.common.customviews.CategoryScrollView;
import com.businessstandard.common.dto.SectionNewsItem;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.manager.BaseManager.SubNewsDloadCmpltListener;
import com.businessstandard.common.manager.BaseManager.TickerDloadCmpltListener;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.util.Constants.SelectedCat;
import com.businessstandard.common.util.Utility;
import com.businessstandard.home.HomeManager;
import com.businessstandard.market.dto.TickerNewsFeedRootObject;
import com.businessstandard.market.dto.TickerNewsItemFeed;
import com.kosalgeek.android.caching.FileCacher;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author lenesha
 */
public class HomeFragment extends BaseFragment implements OnItemClickListener {

    private FragmentActivity mcontext;
    public static ArrayList<String> mSubCategoryList;
    private CategoryScrollView mCategoryScroll;
    private FragmentListner listner;
    private NewsListAdapter adapter;
    private TickerNewsItemFeed tickernewsFeed = null;
    private HashMap<String, String> subCatgryMap;
    private OnNewsListDwnloadedListener mOnNewsListDwnloadedListener;
    private NewsItemClickListner mNewsClickListener;
    private TextView emptyView;
    protected ArrayList<SubNewsItem> subnewsItem;
    private String mSelectedCatName;
    private TextView mBseLabel;
    private TextView mNseLabel;
    private LinearLayout mSensexTicker;
    private String mUrl;
    private String mSelectedCat;
    int counter = 0;
    private GoogleAnalytics mGoogleAnalytics;
    private String mFeedURL = "";

    public interface OnNewsListDwnloadedListener {
        public void onNewsListDownloaded(ArrayList<SubNewsItem> newsList);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mcontext = getActivity();
        listner = (FragmentListner) mcontext;
        mOnNewsListDwnloadedListener = (OnNewsListDwnloadedListener) mcontext;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.hometab_fragment, container, false);
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        Bundle bundle = getArguments();
        if (bundle != null) {
            mSelectedCat = getArguments().getString(SelectedCat.CATEGORY);
            mFeedURL = getArguments().getString("feedURL");
        }
        mSensexTicker = (LinearLayout) view.findViewById(R.id.sensex_ticker);
        mSensexTicker.setVisibility(View.GONE);
        mNewsClickListener = castToListener(getActivity());
        mBseLabel = (TextView) view.findViewById(R.id.bselabel);

        mBseText = (TextView) view.findViewById(R.id.bseValue);
        mNseLabel = (TextView) view.findViewById(R.id.nselabel);

        mNseText = (TextView) view.findViewById(R.id.nseValue);
        mBseImg = (ImageView) view.findViewById(R.id.bseimg);
        mNseImg = (ImageView) view.findViewById(R.id.nseimg);
        mNewsListView = (ListView) view.findViewById(R.id.newsList);
        emptyView = (TextView) view.findViewById(R.id.empty_text);
        adapter = new NewsListAdapter(mcontext, R.layout.news_listitem);
        mNewsListView.setAdapter(adapter);
        mNewsListView.setOnItemClickListener(this);
        mSelectedCatName = new String();

        mNewsListView.setVerticalFadingEdgeEnabled(false);
        if (mSelectedCat != null && mGoogleAnalytics != null && getActivity() != null) {
            //AnalyticsUtils.getInstAnalyticsUtils(getActivity()).trackPageView(getString(R.string.tab_home) + mSelectedCat);
            mGoogleAnalytics.trackScreenView(getString(R.string.tab_home) + mSelectedCat, getActivity());
        }
        return view;
    }

    private void displayTicker() {
        if (getActivity() != null) {
            if (tickernewsFeed.bsestock.changePercent != null) {
                try {
                    Float bseVal = Float.valueOf(tickernewsFeed.bsestock.changePercent);
                    if (bseVal >= 0) {
                        mBseLabel.setText(mBseLabel.getText() + " " + tickernewsFeed.bsestock.price + " ");
                        mBseText.setText(tickernewsFeed.bsestock.changeValue);
                        mBseText.setTextColor(getActivity().getResources().getColor(R.color.ticker_green));
                        mBseImg.setBackgroundResource(R.drawable.arrow_green);
                    } else {
                        mBseLabel.setText(mBseLabel.getText() + " " + tickernewsFeed.bsestock.price + " ");
                        mBseText.setText(tickernewsFeed.bsestock.changeValue);
                        mBseImg.setBackgroundResource(R.drawable.arrow_red);
                        mBseText.setTextColor(getResources().getColor(R.color.ticker_red));
                    }
                } catch (NumberFormatException exception) {
                    mBseLabel.setText(mBseLabel.getText() + " " + 0.0 + " ");
                    mBseText.setText("0.0");
                    mBseImg.setBackgroundResource(R.drawable.arrow_green);
                    mBseText.setTextColor(getResources().getColor(R.color.black));
                }
            }
            if (tickernewsFeed.nsestock.changePercent != null) {
                try {
                    Float nseVal = Float.valueOf(tickernewsFeed.nsestock.changePercent);
                    if (nseVal >= 0) {
                        mNseLabel.setText(mNseLabel.getText() + " " + tickernewsFeed.nsestock.price + " ");
                        mNseText.setText(tickernewsFeed.nsestock.changeValue);
                        mNseImg.setBackgroundResource(R.drawable.arrow_green);
                        mNseText.setTextColor(getResources().getColor(R.color.ticker_green));
                    } else {
                        mNseLabel.setText(mNseLabel.getText() + " " + tickernewsFeed.nsestock.price + " ");
                        mNseText.setText(tickernewsFeed.nsestock.changeValue);
                        mNseImg.setBackgroundResource(R.drawable.arrow_red);
                        mNseText.setTextColor(getResources().getColor(R.color.ticker_red));
                    }
                } catch (NumberFormatException exception) {
                    mNseLabel.setText(mNseLabel.getText() + " " + 0.0 + " ");
                    mNseText.setText("0.0");
                    mNseImg.setBackgroundResource(R.drawable.arrow_green);
                    mNseText.setTextColor(getResources().getColor(R.color.black));
                }
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    private NewsItemClickListner castToListener(Activity activity) {
        return (NewsItemClickListner) activity;
    }

    private void displayNews(ArrayList<SubNewsItem> result) {
        // itemlist null pointer handling
        mNewsListView.setVisibility(View.VISIBLE);
        emptyView.setVisibility(View.INVISIBLE);

        if (subnewsItem != null && result != null && result.size() > 0) {
            adapter.clear();
            for (SubNewsItem item : result) {
                adapter.add(item);
                adapter.setNotifyOnChange(false);
            }
            adapter.notifyDataSetChanged();
        } else {
            displayEmptyListview();
        }
    }

    public void showCategories(SectionNewsRootFeedItem feedItem) {
        subCatgryMap = new HashMap<String, String>();
        mSubCategoryList = new ArrayList<String>();
        if (getActivity() != null && Utility.isInternetOn(getActivity())) {
            if (feedItem != null && feedItem.root != null) {
                List<SectionNewsItem> listOfHomeFeeds = feedItem.root.getmHome();
                for (SectionNewsItem item : listOfHomeFeeds) {
                    subCatgryMap.put(item.categoryName, item.feedUrl);
                    if (item.categoryName.equals("Top Stories")) {
                        mSubCategoryList.add("Home");
                    } else {
                        mSubCategoryList.add(item.categoryName);
                    }
                }
                mSubCategoryList.add("Today's Paper");
                mSelectedCatName = mSubCategoryList.get(0);
                if (subCatgryMap != null && mSelectedCat != null && subCatgryMap.containsKey(mSelectedCat)) {
                    mSelectedCatName = mSelectedCat;
                    listner.setCatgeroes(mSubCategoryList, subCatgryMap, mSelectedCat);
                    if (!TextUtils.isEmpty(mFeedURL)) {
                        displayNewsForCategory(mFeedURL);
                    } else {
                        displayNewsForCategory(subCatgryMap.get(mSelectedCat));
                    }


                } else {
                    if (listner != null) {
                        listner.setCatgeroes(mSubCategoryList, subCatgryMap, mSubCategoryList.get(0));
                    }
                    if (!TextUtils.isEmpty(mFeedURL)) {
                        displayNewsForCategory(mFeedURL);
                    } else {
                        displayNewsForCategory(subCatgryMap.get(mSelectedCat));
                    }
                }
            } else {
                displayEmptyListview();
                if (getActivity() != null) {
                    Utility.displayAlert(getActivity(), getString(R.string.app_name), getResources().getString(R.string.unable_to_fetch_data), android.R.string.ok, Utility.getOkButtonListener(getActivity()));
                }
            }
        } else {
            if (fileCacher == null) {
                fileCacher = new FileCacher<>(mcontext, "homecaching");
            }
            if (fileCacher.hasCache()) {
                try {
                    if (!TextUtils.isEmpty(mSelectedCat) && mSelectedCat.equalsIgnoreCase("Top Stories")) {
                        subnewsItem = fileCacher.readCache();
                        displayNews(subnewsItem);
                        mOnNewsListDwnloadedListener.onNewsListDownloaded(subnewsItem);
                        Utility.hideProgressDialog();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                displayEmptyListview();
                if (getActivity() != null)
                    Utility.displayAlert(getActivity(), getString(R.string.app_name),
                            getResources().getString(R.string.no_connection), android.R.string.ok,
                            Utility.getOkButtonListener(getActivity()));
            }
        }
    }

    private FileCacher<ArrayList<SubNewsItem>> fileCacher;

    private void displayNewsForCategory(String url) {
        boolean isShowProgressBar = true;
        if (fileCacher == null) {
            fileCacher = new FileCacher<>(mcontext, "homecaching");
        }

        if (fileCacher.hasCache()) {
            try {
                if (!TextUtils.isEmpty(mSelectedCat) && mSelectedCat.equalsIgnoreCase("Top Stories")) {
                    isShowProgressBar = false;
                    subnewsItem = fileCacher.readCache();
                    displayNews(subnewsItem);
                    mOnNewsListDwnloadedListener.onNewsListDownloaded(subnewsItem);
                    Utility.hideProgressDialog();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        mUrl = url;
        HomeManager homeManager = new HomeManager(getActivity());
        homeManager.downloadNewsFeedData(isShowProgressBar, new SubNewsDloadCmpltListener() {

            @Override
            public void onFailure() {
                Utility.hideProgressDialog();
                displayEmptyListview();
            }

            @Override
            public void onSubNewsDloadComplete(ArrayList<SubNewsItem> result) {
                if (result != null && result.size() > 0) {
                    try {
                        if (!TextUtils.isEmpty(mSelectedCat) && mSelectedCat.equalsIgnoreCase("Top Stories")) {
                            if (fileCacher.hasCache()) {
                                fileCacher.clearCache();
                                fileCacher.writeCache(result);
                            } else {
                                fileCacher.writeCache(result);
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                subnewsItem = result;
                mOnNewsListDwnloadedListener.onNewsListDownloaded(result);
                displayNews(result);
                Utility.hideProgressDialog();
            }
        }, url);
    }

    protected void displayEmptyListview() {
        emptyView.setVisibility(View.VISIBLE);
        mNewsListView.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onItemClick(AdapterView<?> arg0, View view, int position, long id) {
        SubNewsItem subNewsitemClicked = adapter.getItem(position);
        mNewsClickListener.onNewsItemClick(subNewsitemClicked, position, mSelectedCatName, mSelectedCatName);
    }

    public void refreshContent() {
        if (mUrl != null && getActivity() != null) {
            displayNewsForCategory(mUrl);
        } else {
            Utility.showToast(getString(R.string.no_connection), getActivity());
        }
    }

    protected void getTickerFeeds() {
        if (getActivity() != null) {
            HomeManager homeManager = new HomeManager(getActivity());
            homeManager.donwloadTickerValues(new TickerDloadCmpltListener() {

                @Override
                public void onFailure() {
                    if (getActivity() != null) {
                        mBseLabel.setText(mBseLabel.getText() + " " + 0.0 + " ");
                        mBseText.setText("0.0");
                        mBseImg.setBackgroundResource(R.drawable.arrow_green);
                        mBseText.setTextColor(getResources().getColor(R.color.black));
                        mNseLabel.setText(mNseLabel.getText() + " " + 0.0 + " ");
                        mNseText.setText("0.0");
                        mNseImg.setBackgroundResource(R.drawable.arrow_green);
                        mNseText.setTextColor(getResources().getColor(R.color.black));
                    }
                }

                @Override
                public void onTickerDloadCmplt(TickerNewsFeedRootObject result) {
                    TickerNewsItemFeed tickerFeed = result.root;
                    if (tickerFeed != null && tickerFeed.bsestock != null && tickerFeed.nsestock != null) {
                        tickernewsFeed = tickerFeed;
                        displayTicker();
                    }
                }
            });
        }
    }


    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (listner != null) {
            showCategories(listner.getDataFromActivity());
        } else {
            showCategories(HomeManager.feedObjct);
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        mBseLabel.setText("BSE");
        mNseLabel.setText("NSE");
        mBseText.setText("");
        mNseText.setText("");
        getTickerFeeds();
    }

    @Override
    public void onPause() {
        super.onPause();
        mBseLabel.setText("BSE");
        mNseLabel.setText("NSE");
        mBseText.setText("");
        mNseText.setText("");
    }
}
