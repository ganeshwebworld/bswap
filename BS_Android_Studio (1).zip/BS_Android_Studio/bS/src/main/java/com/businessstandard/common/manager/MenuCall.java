package com.businessstandard.common.manager;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.businessstandard.R;
import com.businessstandard.common.util.Utility;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import cz.msebera.android.httpclient.Header;

public class MenuCall {

    private AsyncHttpClient client;
    Context context;
    private MenuInterface menuInterface;

    public MenuCall(Activity activity,MenuInterface menuInterface) {
        this.menuInterface = menuInterface;

        if (Utility.isInternetOn(activity)) {
            getMenuItemPost("https://betabs.business-standard.com/user/process-api/bs-android-menu-api", 100);
        } else {
            Utility.displayAlert(activity, activity.getResources().getString(R.string.app_name)
                    , activity.getResources().getString(R.string.no_connection)
                    , android.R.string.ok, Utility.getOkButtonListener(activity));
        }
    }

    public void getMenuItemPost(String url, final int requestCode) {
        RequestParams params = new RequestParams();
        params.put("api_token", "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6");
        client = new AsyncHttpClient();

        AsyncHttpResponseHandler asyncHttpResponseHandler = new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                Log.i("onSuccess", statusCode + "");
                menuInterface.onSelectResult(new String(responseBody));
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.i("requestCode", statusCode + "");
            }

            @Override
            public void onStart() {
            }

            @Override
            public void onRetry(int retryNo) {
                Log.i("onRetry", retryNo + "");
            }

        };
        post(url, params, asyncHttpResponseHandler);
    }

    /**
     * create post hit
     *
     * @param params
     * @param responseHandler
     */
    public void post(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.post(url, params, responseHandler);
    }

}
