/**
   Project      : Economist
   Filename     : SensexAdapter.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */

package com.businessstandard.market.ui;

import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.market.dto.BseStockDataItem;
import com.businessstandard.market.dto.NseStockDataItem;
import com.businessstandard.market.dto.NseStockDataItems;
import com.businessstandard.market.dto.StockHolder;
import com.businessstandard.market.dto.TickerNewsItemFeed;

/**
 * @author lenesha
 * 
 */
public class SensexAdapter extends ArrayAdapter<StockHolder> {
	public static String TAG = SensexAdapter.class.getSimpleName();
	private OnClickListener mNonTickerBtnClickListnr;
	private OnClickListener mTickerBtnClickListnr;
	private OnClickListener mOnRowItemClkLstnr;
	private Context mContext;

	private interface ItemType {
		int SENSEX_NIFTY = 0;
		int TOPPERS_LOOSERS = 1;

	}

	private LayoutInflater mInflater;
	private SensexNiftyViewHolder mSensexNiftyHolder;
	private ToppersLoosersViewHolder mToppersLoosersHolder;

//	/**
//	 * @param context
//	 * @param resource
//	 * @param mstHolders
//	 * @param mTickerNseBsebtnClickListnr
//	 * @param mOnCompanyRowItemClkLstnr
//	 * @param mNonTickerNseBsebtnClickListnr
//	 * @param textViewResourceId
//	 * @param objects
//	 */
	public SensexAdapter(FragmentActivity context, int resource, StockHolder[] mstHolders,
			OnClickListener mNonTickerBtnClickListnr, OnClickListener mTickerNseBsebtnClickListnr,
			OnClickListener mOnCompanyRowItemClkLstnr) {
		super(context, resource, mstHolders);
		mInflater = LayoutInflater.from(context);
		this.mNonTickerBtnClickListnr = mNonTickerBtnClickListnr;
		mTickerBtnClickListnr = mTickerNseBsebtnClickListnr;
		mOnRowItemClkLstnr = mOnCompanyRowItemClkLstnr;
		mContext = context;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.widget.BaseAdapter#getItemViewType(int)
	 */
	@Override
	public int getItemViewType(int position) {
		if (position == 0) {
			return ItemType.SENSEX_NIFTY;
		} else
			return ItemType.TOPPERS_LOOSERS;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.widget.ArrayAdapter#getView(int, android.view.View,
	 * android.view.ViewGroup)
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Log.d(TAG, "position " + position);

		if (convertView == null) {
			if (getItemViewType(position) == ItemType.SENSEX_NIFTY) {

				mSensexNiftyHolder = new SensexNiftyViewHolder();
				convertView = mInflater.inflate(R.layout.stock_sensexnifty_listitem, null);

				mSensexNiftyHolder.sensex = (View) convertView.findViewById(R.id.sensex);

				mSensexNiftyHolder.sensexNiftyLabel = (TextView) mSensexNiftyHolder.sensex
						.findViewById(R.id.sensex_nifty_label);

				mSensexNiftyHolder.sensexNiftyPrice = (TextView) mSensexNiftyHolder.sensex
						.findViewById(R.id.sensex_nifty_price);
				mSensexNiftyHolder.sensexNiftyChange = (TextView) mSensexNiftyHolder.sensex
						.findViewById(R.id.sensex_nifty_change);
				mSensexNiftyHolder.sensexNiftyChangepercntg = (TextView) mSensexNiftyHolder.sensex
						.findViewById(R.id.sensex_nifty_changepercntg);

				mSensexNiftyHolder.nifty = (View) convertView.findViewById(R.id.nifty);

				mSensexNiftyHolder.niftyLabel = (TextView) mSensexNiftyHolder.nifty
						.findViewById(R.id.sensex_nifty_label);

				mSensexNiftyHolder.niftyPrice = (TextView) mSensexNiftyHolder.nifty
						.findViewById(R.id.sensex_nifty_price);
				mSensexNiftyHolder.niftyChange = (TextView) mSensexNiftyHolder.nifty
						.findViewById(R.id.sensex_nifty_change);
				mSensexNiftyHolder.niftyChangepercntg = (TextView) mSensexNiftyHolder.nifty
						.findViewById(R.id.sensex_nifty_changepercntg);

				mSensexNiftyHolder.nseButton = (Button) convertView.findViewById(R.id.nse_button);
				mSensexNiftyHolder.bseButton = (Button) convertView.findViewById(R.id.bse_button);

				mSensexNiftyHolder.intradayCSV = (WebView) convertView.findViewById(R.id.intradayCSV);

				mSensexNiftyHolder.nseButton.setClickable(false);
				mSensexNiftyHolder.bseButton.setClickable(false);

				mSensexNiftyHolder.nseButton.setBackgroundResource(R.drawable.btn_toggle_nse_pressed);

				mSensexNiftyHolder.nseButton.setFocusable(false);
				mSensexNiftyHolder.bseButton.setFocusable(false);

				convertView.setTag(mSensexNiftyHolder);

			} else {
				mToppersLoosersHolder = new ToppersLoosersViewHolder();
				convertView = mInflater.inflate(R.layout.stock_gainers_loosers_listitem, null);

				mToppersLoosersHolder.headerLabel = (TextView) convertView.findViewById(R.id.header_label);
				mToppersLoosersHolder.nseButton = (Button) convertView.findViewById(R.id.nse_button);
				mToppersLoosersHolder.bseButton = (Button) convertView.findViewById(R.id.bse_button);
				mToppersLoosersHolder.theTable = (TableLayout) convertView.findViewById(R.id.the_table);

				mToppersLoosersHolder.nseButton.setClickable(false);
				mToppersLoosersHolder.bseButton.setClickable(false);
				mToppersLoosersHolder.nseButton.setBackgroundResource(R.drawable.btn_toggle_nse_pressed);
				mToppersLoosersHolder.nseButton.setFocusable(false);
				mToppersLoosersHolder.bseButton.setFocusable(false);

				convertView.setTag(mToppersLoosersHolder);

			}
		}
		if (getItemViewType(position) == ItemType.SENSEX_NIFTY) {

			mSensexNiftyHolder = (SensexNiftyViewHolder) convertView.getTag();
			mSensexNiftyHolder.bseButton.setOnClickListener(mTickerBtnClickListnr);
			mSensexNiftyHolder.nseButton.setOnClickListener(mTickerBtnClickListnr);
			StockHolder item = getItem(position);
			if (item instanceof TickerNewsItemFeed) {
				TickerNewsItemFeed tickerFeed = (TickerNewsItemFeed) item;
				if (tickerFeed != null) {
					mSensexNiftyHolder.sensexNiftyLabel.setText("Sensex");

					try {
						Float priceValue = Float.valueOf(tickerFeed.bsestock.price);
						mSensexNiftyHolder.sensexNiftyPrice.setText(tickerFeed.bsestock.price);
					} catch (NumberFormatException e) {
						mSensexNiftyHolder.sensexNiftyPrice.setText("0.0");

					}
					try {
						Float changeValue = Float.valueOf(tickerFeed.bsestock.changeValue);
						mSensexNiftyHolder.sensexNiftyChange.setText(tickerFeed.bsestock.changeValue);
					} catch (NumberFormatException e) {
						mSensexNiftyHolder.sensexNiftyChange.setText("0.0");

					}
					try {
						Float changePercent = Float.valueOf(tickerFeed.bsestock.changePercent);
						mSensexNiftyHolder.sensexNiftyChangepercntg.setText(tickerFeed.bsestock.changePercent + "%");
					} catch (NumberFormatException e) {
						mSensexNiftyHolder.sensexNiftyChangepercntg.setText("0.0" + "%");

					}

					mSensexNiftyHolder.niftyLabel.setText("Nifty");

					try {
						Float priceValue = Float.valueOf(tickerFeed.nsestock.price);
						mSensexNiftyHolder.niftyPrice.setText(tickerFeed.nsestock.price);
					} catch (NumberFormatException e) {
						mSensexNiftyHolder.niftyPrice.setText("0.0");

					}
					try {
						Float changeValue = Float.valueOf(tickerFeed.nsestock.changeValue);
						mSensexNiftyHolder.niftyChange.setText(tickerFeed.nsestock.changeValue);
					} catch (NumberFormatException e) {
						mSensexNiftyHolder.niftyChange.setText("0.0");

					}
					try {
						Float changePercent = Float.valueOf(tickerFeed.nsestock.changePercent);
						mSensexNiftyHolder.niftyChangepercntg.setText(tickerFeed.nsestock.changePercent + "%");
					} catch (NumberFormatException e) {
						mSensexNiftyHolder.niftyChangepercntg.setText("0.0" + "%");

					}

					if (tickerFeed.isNse) {
						mSensexNiftyHolder.nseButton.setBackgroundResource(R.drawable.btn_toggle_nse_pressed);
						mSensexNiftyHolder.bseButton.setBackgroundResource(R.drawable.btn_toggle_bse_normal);

						mSensexNiftyHolder.intradayCSV.loadUrl(tickerFeed.nsestock.intradayCSVPath);
					}

					else {
						mSensexNiftyHolder.nseButton.setBackgroundResource(R.drawable.btn_toggle_nse_normal);

						mSensexNiftyHolder.bseButton.setBackgroundResource(R.drawable.btn_toggle_bse_pressed);
						mSensexNiftyHolder.intradayCSV.loadUrl(tickerFeed.bsestock.intradayCSVPath);
					}
				}
			}
			mSensexNiftyHolder.bseButton.setTag(item);
			mSensexNiftyHolder.nseButton.setTag(item);

		} else if (getItemViewType(position) == ItemType.TOPPERS_LOOSERS) {

			mToppersLoosersHolder = (ToppersLoosersViewHolder) convertView.getTag();
			mToppersLoosersHolder.bseButton.setOnClickListener(mNonTickerBtnClickListnr);

			mToppersLoosersHolder.nseButton.setOnClickListener(mNonTickerBtnClickListnr);
			mToppersLoosersHolder.bseButton.setVisibility(View.GONE);
			mToppersLoosersHolder.nseButton.setVisibility(View.GONE);
			StockHolder item = getItem(position);

			if (item instanceof NseStockDataItems) {
				NseStockDataItems nseItems = (NseStockDataItems) item;

				if (nseItems.isToppers == true) {

					mToppersLoosersHolder.headerLabel.setText(getContext().getResources().getString(
							R.string.top_gainers));

				}
				if (nseItems.is52WeekHigh == true) {
					mToppersLoosersHolder.headerLabel.setText(getContext().getResources().getString(
							R.string.five_two_week_high));
				}
				if (nseItems.isLoosers == true) {
					mToppersLoosersHolder.headerLabel.setText(getContext().getResources().getString(
							R.string.top_loosers));

				}

				if (nseItems.is52WeekLow == true) {
					mToppersLoosersHolder.headerLabel.setText(getContext().getResources().getString(
							R.string.five_two_week_low));

				}

				if (((NseStockDataItems) item).isNSE) {
					mToppersLoosersHolder.theTable.removeAllViews();
					if (nseItems != null && nseItems.nseStockitems != null) {
						for (int current = 0; current < nseItems.nseStockitems.length; current++) {
							mToppersLoosersHolder.nseButton.setBackgroundResource(R.drawable.btn_toggle_nse_pressed);
							mToppersLoosersHolder.bseButton.setBackgroundResource(R.drawable.btn_toggle_bse_normal);

							TableRow rowItem = (TableRow) ((LayoutInflater) mInflater).inflate(
									R.layout.stock_table_row, null);
							TextView cmpny = (TextView) rowItem.findViewById(R.id.stock_company);
							TextView stock_price = (TextView) rowItem.findViewById(R.id.stock_price);
							TextView stock_changepercntg = (TextView) rowItem.findViewById(R.id.stock_changepercntg);
							final NseStockDataItem nseItem = nseItems.nseStockitems[current];
							cmpny.setText(nseItem.coName);
							try {
								Float priceValue = Float.valueOf(nseItem.price);
								stock_price.setText(nseItem.price);

							} catch (NumberFormatException e) {
								stock_price.setText("0.0");

							}
							try {
								Float changePercntg = Float.valueOf(nseItem.changePercent);
								stock_changepercntg.setText(nseItem.changePercent);
								if (changePercntg >= 0) {
									stock_changepercntg.setTextColor(mContext.getResources().getColor(
											R.color.ticker_green));
									stock_price.setTextColor(mContext.getResources().getColor(R.color.ticker_green));

								} else {
									stock_changepercntg.setTextColor(mContext.getResources().getColor(
											R.color.ticker_red));
									stock_price.setTextColor(mContext.getResources().getColor(R.color.ticker_red));
								}

							} catch (NumberFormatException e) {
								stock_changepercntg.setText("0.0");

							}
							mToppersLoosersHolder.theTable.addView(rowItem);
							// It is used in company VIEWPAGER.
							rowItem.setTag(nseItems.nseStockitems);
							rowItem.setTag(R.string.sensex_position_tag, nseItem.coName);
							rowItem.setTag(R.string.sensex_row_item_tag, nseItems.bseStockitems);
							rowItem.setOnClickListener(mOnRowItemClkLstnr);
						}
					}
				} else {
					mToppersLoosersHolder.theTable.removeAllViews();
					if (nseItems != null && nseItems.bseStockitems != null) {
//						nseItems.is52WeekHigh=true;

						for (int current = 0; current < nseItems.bseStockitems.length; current++) {
							mToppersLoosersHolder.bseButton.setBackgroundResource(R.drawable.btn_toggle_bse_pressed);
							mToppersLoosersHolder.nseButton.setBackgroundResource(R.drawable.btn_toggle_nse_normal);

							TableRow rowItem = (TableRow) ((LayoutInflater) mInflater).inflate(
									R.layout.stock_table_row, null);
							TextView cmpny = (TextView) rowItem.findViewById(R.id.stock_company);
							TextView stock_price = (TextView) rowItem.findViewById(R.id.stock_price);
							TextView stock_changepercntg = (TextView) rowItem.findViewById(R.id.stock_changepercntg);
							final BseStockDataItem bseItem = nseItems.bseStockitems[current];
							cmpny.setText(bseItem.coName);

							try {
								Float priceValue = Float.valueOf(bseItem.price);
								stock_price.setText(bseItem.price);

							} catch (NumberFormatException e) {
								stock_price.setText("0.0");

							}
							try {
								Float changePercntg = Float.valueOf(bseItem.changePercent);
								stock_changepercntg.setText(bseItem.changePercent);
								if (changePercntg >= 0) {
									stock_changepercntg.setTextColor(mContext.getResources().getColor(
											R.color.ticker_green));
									stock_price.setTextColor(mContext.getResources().getColor(R.color.ticker_green));

								} else {
									stock_changepercntg.setTextColor(mContext.getResources().getColor(
											R.color.ticker_red));
									stock_price.setTextColor(mContext.getResources().getColor(R.color.ticker_red));
								}

							} catch (NumberFormatException e) {
								stock_changepercntg.setText("0.0");

							}

							mToppersLoosersHolder.theTable.addView(rowItem);
							// It is used in company VIEWPAGER.

							rowItem.setTag(nseItems.nseStockitems);
							rowItem.setTag(R.string.sensex_row_item_tag, nseItems.bseStockitems);
							rowItem.setTag(R.string.sensex_position_tag, bseItem.coName);
							rowItem.setOnClickListener(mOnRowItemClkLstnr);
						}
					}

				}
			}
			mToppersLoosersHolder.bseButton.setTag(item);
			mToppersLoosersHolder.nseButton.setTag(item);
		}

		return convertView;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.widget.BaseAdapter#getViewTypeCount()
	 */
	@Override
	public int getViewTypeCount() {
		return 2;
	}

	private static class SensexNiftyViewHolder {
		TextView sensexNiftyLabel;
		TextView sensexNiftyPrice;
		TextView sensexNiftyChange;
		TextView sensexNiftyChangepercntg;

		TextView niftyLabel;
		TextView niftyPrice;
		TextView niftyChange;
		TextView niftyChangepercntg;

		View sensex;
		View nifty;

		Button nseButton;
		Button bseButton;

		WebView intradayCSV;
	}

	private static class ToppersLoosersViewHolder {
		TextView headerLabel;

		Button nseButton;
		Button bseButton;
		TableLayout theTable;
	}
}
