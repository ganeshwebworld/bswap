/**
 * Project      : Economist
 * Filename     : ConnectionUtility.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.common.util;

import android.content.Context;

import com.businessstandard.R;

import org.springframework.http.HttpAuthentication;
import org.springframework.http.HttpBasicAuthentication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.GsonHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;

/**
 * @author lenesha
 *
 */
public class ConnectionUtility {

    private static final String TAG = ConnectionUtility.class.getSimpleName();

    public static synchronized RestTemplateContainer createRestTemplate(Object params) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders requestHeaders = new HttpHeaders();
        HttpEntity<Object> requestEntity = new HttpEntity<Object>(params, requestHeaders);
        GsonHttpMessageConverter converter = new GsonHttpMessageConverter();
        converter.setSupportedMediaTypes(Collections.singletonList(MediaType.ALL));
        restTemplate.getMessageConverters().add(converter);
        return new RestTemplateContainer(restTemplate, requestEntity);
    }

    public static synchronized RestTemplateContainer createRestTemplate(Object params, Context ctx) {
        String name = ctx.getString(R.string.ticker_username);
        String password = ctx.getString(R.string.ticker_password);

        // Populate the HTTP Basic Authentitcation header with the username and
        // password
        HttpAuthentication authHeader = new HttpBasicAuthentication(name, password);
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setAuthorization(authHeader);
        requestHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        // Create a new RestTemplate instance
        RestTemplate restTemplate = new RestTemplate();
        HttpEntity<Object> requestEntity = new HttpEntity<Object>(params, requestHeaders);
        GsonHttpMessageConverter converter = new GsonHttpMessageConverter();
        converter.setSupportedMediaTypes(Collections.singletonList(MediaType.ALL));
        restTemplate.getMessageConverters().add(converter);
        return new RestTemplateContainer(restTemplate, requestEntity);
    }


/*	public static String appendBaseUrl(String url, Context ctx) {
		StringBuilder baseUrl = new StringBuilder(ctx.getString(R.string.base_url));
		baseUrl.append(url);
		Log.v(TAG, "Connecting to-" + baseUrl.toString());
		return baseUrl.toString();
	}*/
}
