package com.businessstandard.settings.ui;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.ui.MainFragmentActivity;
import com.businessstandard.common.util.Constants.SettingsKeys;
import com.businessstandard.common.util.NotificationUtils;
import com.businessstandard.common.util.Utility;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author DevStringx
 */
public class NotificationSettingsActivity extends FragmentActivity implements OnClickListener {

    private ImageView mHeaderTxt;
    Button menu, fromtime_txt, totime_txt, save;
    private LinearLayout show_time_ll;
    private CheckBox notification_chk, notificationatnight_chk, sound_chk, vibration_chk;
    private TextView notificationatnight_txt, sound_txt, vibration_txt, line_txt;
    private LinearLayout notification_ll, notificationatnight_ll, sound_ll, vibration_ll;
    private ArrayList<NotificationUtils> arrayList;
    private ArrayList<String> Enable_Settings = new ArrayList<String>();
    final int TIME_DIALOG_ID = 1111;
    final int TIME_DIALOG_ID2 = 1112;
    private int hour, hour2;
    private int minute, minute2;
    private String tab = "";
    private String uuid;
    private String StartTime = "", EndTime = "";
    public static String regId;
    private SaveSharedPref mSharedPreferenceManager;
    private com.businessstandard.model.Constants mConstants = null;

    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        int positionId;
        BaseFragment.numCount = 1;
        //regId = MainFragmentActivity.mPreferences.getString("device_token", null);
        setContentView(R.layout.notification_settings_activity);
        mSharedPreferenceManager = SaveSharedPref.getInstance(this);
        if (mSharedPreferenceManager.exists(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA)) {
            if (mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class) != null) {
                mConstants = mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class);
            }
        }
        // menu=(Button)findViewById(R.id.menu);
        // menu.setVisibility(View.GONE);
     /*   TelephonyManager tManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        uuid = tManager.getDeviceId();*/

        //Secure id added in place of telephony manager
        uuid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        //API Calling using AsyncTask
        new getNotificationSetting(NotificationSettingsActivity.this).execute(MainFragmentActivity.api_key, uuid);
        Intent intent = getIntent();

        mHeaderTxt = (ImageView) findViewById(R.id.header_txt);
        String item = intent.getStringExtra(SettingsKeys.CLICKED_ITEM);
        positionId = intent.getIntExtra(SettingsKeys.POSITION, 0);
        TextView title_item = (TextView) findViewById(R.id.page_title);
        TextView date = (TextView) findViewById(R.id.header_date);
        date.setText(Utility.getTodaysData());
        findViewById(R.id.search_button).setVisibility(View.GONE);
        findViewById(R.id.refresh_btn).setVisibility(View.GONE);
        title_item.setText(item);
        initListeners();
        initView();
        Enabled(false);
        show_time_ll.setVisibility(View.GONE);

        notification_chk.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {
                for (int i = 0; i < arrayList.size(); i++) {
                    if (arrayList.get(i).getName()
                            .equalsIgnoreCase("Notification")) {
                        arrayList.get(i).setEnabled(
                                notification_chk.isChecked() ? "Y"
                                        : "N");
                        break;
                    }
                }
                Enabled(isChecked);
            }
        });

        notificationatnight_chk.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                for (int i = 0; i < arrayList.size(); i++) {
                    if (arrayList.get(i).getName().equalsIgnoreCase("Notification at night")) {
                        arrayList.get(i).setEnabled(notificationatnight_chk.isChecked() ? "Y" : "N");
                        break;
                    }
                }
                if (isChecked) {
                    show_time_ll.setVisibility(View.VISIBLE);
                } else {
                    show_time_ll.setVisibility(View.GONE);
                }
            }
        });

        sound_chk.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                for (int i = 0; i < arrayList.size(); i++) {

                    if (arrayList.get(i).getName().equalsIgnoreCase("Sound")) {
                        arrayList.get(i).setEnabled(sound_chk.isChecked() ? "Y" : "N");
                        break;
                    }
                }
            }
        });
        vibration_chk.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                for (int i = 0; i < arrayList.size(); i++) {

                    if (arrayList.get(i).getName().equalsIgnoreCase("Vibration")) {
                        arrayList.get(i).setEnabled(vibration_chk.isChecked() ? "Y" : "N");
                        break;
                    }
                }
            }
        });

    }

    /**
     *
     */
    private void initView() {
        notification_chk = (CheckBox) findViewById(R.id.notification_chk);
        notificationatnight_chk = (CheckBox) findViewById(R.id.notificationatnight_chk);
        sound_chk = (CheckBox) findViewById(R.id.sound_chk);
        vibration_chk = (CheckBox) findViewById(R.id.vibration_chk);
        notification_ll = (LinearLayout) findViewById(R.id.notifi_ll);
        notificationatnight_ll = (LinearLayout) findViewById(R.id.notifi_at_night_ll);
        sound_ll = (LinearLayout) findViewById(R.id.sound_ll);
        vibration_ll = (LinearLayout) findViewById(R.id.vibrate_ll);
        notificationatnight_txt = (TextView) findViewById(R.id.notificationatnight_txt);
        sound_txt = (TextView) findViewById(R.id.sound_txt);
        vibration_txt = (TextView) findViewById(R.id.notificationatnight_txt);
        fromtime_txt = (Button) findViewById(R.id.fromtime_txt);
        totime_txt = (Button) findViewById(R.id.totime_txt);
        line_txt = (TextView) findViewById(R.id.line_txt);
        save = (Button) findViewById(R.id.save);
        show_time_ll = (LinearLayout) findViewById(R.id.show_time_ll);
        fromtime_txt.setOnClickListener(this);
        totime_txt.setOnClickListener(this);
        save.setOnClickListener(this);
    }

    private void Enabled(boolean value) {
        notificationatnight_txt.setEnabled(value);
        sound_txt.setEnabled(value);
        vibration_txt.setEnabled(value);
        notificationatnight_chk.setChecked(value);
        sound_chk.setChecked(value);
        vibration_chk.setChecked(value);
        // if (!value) {
        notificationatnight_chk.setClickable(value);
        sound_chk.setClickable(value);
        vibration_chk.setClickable(value);
        // }
    }

    /**
     * @author nagaraj
     */
    private void initListeners() {
        mHeaderTxt.setOnClickListener(this);

    }

    /**
     * @author nagaraj
     * @param positionId
     */
    /**
     *
     */

    /*
     * (non-Javadoc)
     *
     * @see android.view.View.OnClickListener#onClick(android.view.View)
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.header_txt:
                launchHome();
                break;
            case R.id.fromtime_txt:
                tab = "from";
                // set time picker as current time
                if (tab.equalsIgnoreCase("from")) {
                    String fromTxt = fromtime_txt.getText().toString();
                    fromTxt = Convert12HoursTo24Hours(fromTxt);
                    hour = Integer.parseInt(fromTxt.substring(0, fromTxt.indexOf(":")));
                    minute = Integer.parseInt(fromTxt.substring(fromTxt.indexOf(":") + 1));
                    String s = hour + ":" + minute;

                } else {
                    String toTxt = totime_txt.getText().toString();
                    toTxt = Convert12HoursTo24Hours(toTxt);
                    hour2 = Integer.parseInt(toTxt.substring(0, toTxt.indexOf(":")));
                    minute2 = Integer.parseInt(toTxt.substring(toTxt.indexOf(":") + 1));
                    String s = hour2 + ":" + minute2;
                }
                showDialog(TIME_DIALOG_ID);
                break;
            case R.id.totime_txt:
                tab = "to";
                // set time picker as current time
                if (tab.equalsIgnoreCase("from")) {
                    String fromTxt = fromtime_txt.getText().toString();
                    fromTxt = Convert12HoursTo24Hours(fromTxt);
                    hour = Integer.parseInt(fromTxt.substring(0, fromTxt.indexOf(":")));
                    minute = Integer.parseInt(fromTxt.substring(fromTxt.indexOf(":") + 1));

                } else {
                    String toTxt = totime_txt.getText().toString();
                    toTxt = Convert12HoursTo24Hours(toTxt);
                    hour2 = Integer.parseInt(toTxt.substring(0, toTxt.indexOf(":")));
                    minute2 = Integer.parseInt(toTxt.substring(toTxt.indexOf(":") + 1));

                }
                showDialog(TIME_DIALOG_ID2);
                break;
            case R.id.save:
                //API Calling using AsyncTask
                new saveNotificationSetting(NotificationSettingsActivity.this).execute(MainFragmentActivity.api_key, uuid);
                break;
        }

    }

    /**
     * @author nagaraj
     */
    private void launchHome() {
        Intent intent = new Intent(this, MainFragmentActivity.class);
        intent.setFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }

    @Override
    public void onStop() {
        super.onStop();
        BaseFragment.numCount = 1;
    }

    @Override
    public void onResume() {
        super.onResume();
        BaseFragment.numCount = 1;
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case TIME_DIALOG_ID:
                return new TimePickerDialog(this, timePickerListener, hour, minute, false);
            case TIME_DIALOG_ID2:
                return new TimePickerDialog(this, timePickerListener, hour2, minute2, false);
        }
        return null;
    }

    private TimePickerDialog.OnTimeSetListener timePickerListener = new TimePickerDialog.OnTimeSetListener() {

        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minutes) {
            if (tab.equalsIgnoreCase("from")) {
                hour = hourOfDay;
                minute = minutes;
                updateTime(hour, minute);
            } else {
                hour2 = hourOfDay;
                minute2 = minutes;
                updateTime(hour2, minute2);
            }

        }

    };

	/*// Used to convert 24hr format to 12hr format with AM/PM values
	private void updateTime(int hours, int mins) {

		String timeSet = "";
		if (hours > 12) {
			hours -= 12;
			timeSet = "PM";
		} else if (hours == 0) {
			hours += 12;
			timeSet = "AM";
		} else if (hours == 12)
			timeSet = "PM";
		else
			timeSet = "AM";

		String minutes = "";
		if (mins < 10)
			minutes = "0" + mins;
		else
			minutes = String.valueOf(mins);

		// Append in a StringBuilder
		String selectedhour = String.valueOf(hours).length() == 2 ? String
				.valueOf(hours) : "0" + String.valueOf(hours);
		String aTime = selectedhour + ":" + String.valueOf(minutes) + " "
				+ timeSet;
		// String aTime = new StringBuilder().append(hours).append(':')
		// .append(minutes).append(" ").append(timeSet).toString();

		if (tab.equalsIgnoreCase("from")) {
			fromtime_txt.setText(aTime);
		} else if (tab.equalsIgnoreCase("to")) {
			totime_txt.setText(aTime);
		} else {
			fromtime_txt.setText(aTime);
			totime_txt.setText(aTime);
		}
	}*/

    private void updateTime(int hours, int mins) {
        String time = hours + ":" + mins;
        time = Convert24HoursTo12Hours(time);
        if (tab.equalsIgnoreCase("from")) {
            fromtime_txt.setText(time);
        } else if (tab.equalsIgnoreCase("to")) {
            totime_txt.setText(time);
        } else {
            fromtime_txt.setText(time);
            totime_txt.setText(time);
        }
    }

    public class getNotificationSetting extends AsyncTask<String, String, JSONObject> {

        ProgressDialog dialog;
        Context context;

        getNotificationSetting(Context mContext) {
            context = mContext;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(NotificationSettingsActivity.this, "", "Please wait...");
        }

        @Override
        protected JSONObject doInBackground(String... args) {
            //String strUrl = Constants.BaseUrl_V2;
            String activeNotificationUrl = "";
            String deviceNotificationSettingUrl = "";
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getActiveNotificationFieldV2())) {
                activeNotificationUrl = mConstants.getActiveNotificationFieldV2();
            }
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getGetDeviceNotificationSettingV2())) {
                deviceNotificationSettingUrl = mConstants.getGetDeviceNotificationSettingV2();
            }
            JSONObject json2 = null;
            JSONObject json = null;

            try {
                //1st API Call "Active Notification"
                OkHttpClient client = new OkHttpClient();

                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("api_token", args[0])
                        .addFormDataPart("device_uniqueid", args[1])
                        .build();

                Request request = new Request.Builder()
                        //.url(strUrl + Constants.ACTIVE_NOTIFICATION_FIELD_V2)
                        .url(activeNotificationUrl)
                        .post(requestBody)
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    try {
                        assert response.body() != null;
                        json2 = new JSONObject(response.body().string());

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                //2st API Call "Get Notification Setting based on Device ID"
                OkHttpClient client = new OkHttpClient();

                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("api_token", args[0])
                        .addFormDataPart("device_uniqueid", args[1])
                        .build();

                Request request = new Request.Builder()
                        //.url(strUrl + Constants.GET_DEVICE_NOTIFICATION_SETTING_V2)
                        .url(deviceNotificationSettingUrl)
                        .post(requestBody)
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    try {
                        assert response.body() != null;
                        json = new JSONObject(response.body().string());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

            } catch (Exception e1) {
                e1.printStackTrace();
            }

            try {
                if (json2 != null) {
                    if (json2.getString("status").equalsIgnoreCase("success")) {
                        JSONObject jsonObject = json2.getJSONObject("message");

                        JSONArray jsonArray = jsonObject.getJSONArray("settings");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            Enable_Settings.add(object.optString("notification_name"));
                        }
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return json;
        }

        protected void onPostExecute(JSONObject json) {
            if (dialog != null) {
                dialog.dismiss();
            }
            String msg = "";
            try {
                if (json != null) {
                    if (json.getString("status").equalsIgnoreCase("success")) {
                        JSONObject jsonObject = json.getJSONObject("message");
                        StartTime = jsonObject.getString("notificationOffFrom");
                        EndTime = jsonObject.getString("notificationOffTo");

                        JSONArray jsonArray = jsonObject.getJSONArray("settings");
                        arrayList = new ArrayList<NotificationUtils>();

                        for (int i = 0; i < jsonArray.length(); i++) {
                            NotificationUtils notificationUtils = new NotificationUtils();
                            JSONObject object = jsonArray.getJSONObject(i);
                            notificationUtils.setId(object.getString("id"));
                            notificationUtils.setType(object.getString("type"));
                            notificationUtils.setEnabled(object.getString("enabled"));
                            notificationUtils.setName(object.getString("name"));
                            arrayList.add(notificationUtils);
                            String NotificationId = object.getString("id");
                            if ((object.getString("name")).equalsIgnoreCase("Sound")) {
                                savedSoundAndNotification(getApplicationContext(), (object.getString("enabled")), null);
                            }
                            if ((object.getString("name")).equalsIgnoreCase("Vibration")) {
                                savedSoundAndNotification(getApplicationContext(), null, (object.getString("enabled")));
                            }
                            if (NotificationId.equalsIgnoreCase("1")) {
                                if (object.getString("enabled").equalsIgnoreCase("Y")) {
                                    notification_chk.setChecked(true);
                                } else {
                                    notification_chk.setChecked(false);
                                }
                            } else if (NotificationId.equalsIgnoreCase("2")) {
                                if (object.getString("enabled").equalsIgnoreCase("Y")) {
                                    notificationatnight_chk.setChecked(true);
                                } else {
                                    notificationatnight_chk.setChecked(false);
                                }
                                ;
                                totime_txt.setText(Convert24HoursTo12Hours(EndTime));
                                fromtime_txt.setText(Convert24HoursTo12Hours(StartTime));


                            } else if (NotificationId.equalsIgnoreCase("3")) {
                                if (object.getString("enabled").equalsIgnoreCase("Y")) {
                                    sound_chk.setChecked(true);
                                } else {
                                    sound_chk.setChecked(false);
                                }

                            } else if (NotificationId.equalsIgnoreCase("4")) {
                                if (object.getString("enabled").equalsIgnoreCase("Y")) {
                                    vibration_chk.setChecked(true);
                                } else {
                                    vibration_chk.setChecked(false);
                                }
                            }
                        }

                    } else {
                        msg = json.getString("message");
                        Toast.makeText(NotificationSettingsActivity.this, msg,
                                Toast.LENGTH_LONG).show();
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            for (int i = 0; i < Enable_Settings.size(); i++) {
                if (Enable_Settings.get(i).equalsIgnoreCase("Notification")) {
                    notification_ll.setVisibility(View.VISIBLE);
                    line_txt.setVisibility(View.VISIBLE);
                } else if (Enable_Settings.get(i).equalsIgnoreCase(
                        "Notification at night")) {
                    notificationatnight_ll.setVisibility(View.VISIBLE);
                } else if (Enable_Settings.get(i).equalsIgnoreCase("Sound")) {
                    sound_ll.setVisibility(View.VISIBLE);
                } else if (Enable_Settings.get(i).equalsIgnoreCase("Vibration")) {
                    vibration_ll.setVisibility(View.VISIBLE);
                }
            }
            for (int i = 0; i < arrayList.size(); i++) {

                NotificationUtils v = arrayList.get(i);
                switch (Integer.parseInt(v.getId())) {
                    case 1:
                        if (v.getEnabled().equalsIgnoreCase("Y")) {
                            notification_chk.setChecked(true);
                        } else {
                            notification_chk.setChecked(false);
                        }
                        break;
                    case 2:
                        if (v.getEnabled().equalsIgnoreCase("Y")) {
                            notificationatnight_chk.setChecked(true);
                        } else {
                            notificationatnight_chk.setChecked(false);
                        }
                        totime_txt.setText(Convert24HoursTo12Hours(EndTime));
                        fromtime_txt.setText(Convert24HoursTo12Hours(StartTime));

                        // fromtime_txt.setText(StartTime);
                        // totime_txt.setText(EndTime);
                        break;
                    case 3:
                        savedSoundAndNotification(getApplicationContext(), (v.getEnabled()), null);
                        if (v.getEnabled().equalsIgnoreCase("Y")) {
                            sound_chk.setChecked(true);
                        } else {
                            sound_chk.setChecked(false);
                        }
                        break;
                    case 4:
                        savedSoundAndNotification(getApplicationContext(), null, (v.getEnabled()));
                        if (v.getEnabled().equalsIgnoreCase("Y")) {
                            vibration_chk.setChecked(true);
                        } else {
                            vibration_chk.setChecked(false);
                        }
                        break;
                }
            }
        }
    }

    private class saveNotificationSetting extends AsyncTask<String, String, JSONObject> {
        /**
         * @param mContext
         */
        ProgressDialog dialog;
        Context context;

        public saveNotificationSetting(Context mContext) {
            context = mContext;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(NotificationSettingsActivity.this, "", "Please wait...");
        }

        @Override
        protected JSONObject doInBackground(String... args) {
            //String strUrl = Constants.BaseUrl_V2;
            String postDeviceNotificationSettingUrl = "";
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getPostDeviceNotificationSettingV2())) {
                postDeviceNotificationSettingUrl = mConstants.getPostDeviceNotificationSettingV2();
            }
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("status", "configure");
                JSONObject object = new JSONObject();
                object.put("section", "Notification");
                @SuppressLint("WrongThread") String startTime = Convert12HoursTo24Hours(fromtime_txt.getText().toString());
                object.put("notificationOffFrom", startTime);

                @SuppressLint("WrongThread") String toTime = Convert12HoursTo24Hours(totime_txt.getText().toString());
                object.put("notificationOffTo", toTime);
                JSONArray array = new JSONArray();

                for (int i = 0; i < arrayList.size(); i++) {
                    JSONObject object2 = new JSONObject();
                    object2.put("id", arrayList.get(i).getId());
                    object2.put("type", arrayList.get(i).getType());
                    object2.put("enabled", arrayList.get(i).getEnabled());
                    object2.put("name", arrayList.get(i).getName());
                    array.put(object2);
                }

                object.put("settings", array);
                jsonObject.put("message", object);
            } catch (Exception e) {
                e.printStackTrace();
            }

            JSONObject json = null;

            try {
                OkHttpClient client = new OkHttpClient();

                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("api_token", args[0])
                        .addFormDataPart("device_uniqueid", args[1])
                        .addFormDataPart("notification_data", jsonObject.toString())
                        .build();

                Request request = new Request.Builder()
                        //.url(strUrl + Constants.POST_DEVICE_NOTIFICATION_SETTING_V2)
                        .url(postDeviceNotificationSettingUrl)
                        .post(requestBody)
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    try {
                        assert response.body() != null;
                        json = new JSONObject(response.body().string());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return json;
        }

        protected void onPostExecute(JSONObject json) {

            if (dialog != null) {
                dialog.dismiss();
            }
            String msg = "";
            try {
                if (json.getString("status").equalsIgnoreCase("success")) {
                    JSONObject jsonObject = json.getJSONObject("message");
                    StartTime = jsonObject.getString("notificationOffFrom");
                    EndTime = jsonObject.getString("notificationOffTo");
                    JSONArray jsonArray = jsonObject.getJSONArray("settings");
                    arrayList = new ArrayList<NotificationUtils>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        NotificationUtils notificationUtils = new NotificationUtils();
                        JSONObject object = jsonArray.getJSONObject(i);
                        notificationUtils.setId(object.getString("id"));
                        notificationUtils.setType(object.getString("type"));
                        notificationUtils.setEnabled(object
                                .getString("enabled"));
                        notificationUtils.setName(object.getString("name"));
                        arrayList.add(notificationUtils);
                        if ((object.getString("name")).equalsIgnoreCase("Sound")) {
                            savedSoundAndNotification(getApplicationContext(), (object.getString("enabled")), null);
                        }
                        if ((object.getString("name")).equalsIgnoreCase("Vibration")) {
                            savedSoundAndNotification(getApplicationContext(), null, (object.getString("enabled")));
                        }
                    }

                } else {
                    msg = json.getString("message");
                    Toast.makeText(NotificationSettingsActivity.this, msg, Toast.LENGTH_LONG)
                            .show();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            for (int i = 0; i < arrayList.size(); i++) {

                NotificationUtils v = arrayList.get(i);
                switch (Integer.parseInt(v.getId())) {
                    case 1:
                        if (v.getEnabled().equalsIgnoreCase("Y")) {
                            notification_chk.setChecked(true);
                        } else {
                            notification_chk.setChecked(false);
                        }
                        break;
                    case 2:
                        if (v.getEnabled().equalsIgnoreCase("Y")) {
                            notificationatnight_chk.setChecked(true);
                        } else {
                            notificationatnight_chk.setChecked(false);
                        }
                        totime_txt.setText(Convert24HoursTo12Hours(EndTime));
                        fromtime_txt.setText(Convert24HoursTo12Hours(StartTime));

                        break;
                    case 3:
                        savedSoundAndNotification(getApplicationContext(), (v.getEnabled()), null);
                        if (v.getEnabled().equalsIgnoreCase("Y")) {
                            sound_chk.setChecked(true);
                        } else {
                            sound_chk.setChecked(false);
                        }
                        break;
                    case 4:
                        savedSoundAndNotification(getApplicationContext(), null, (v.getEnabled()));
                        if (v.getEnabled().equalsIgnoreCase("Y")) {
                            vibration_chk.setChecked(true);
                        } else {
                            vibration_chk.setChecked(false);
                        }
                        break;
                }
            }

        }
    }

    public static void savedSoundAndNotification(Context context, String isSound, String isVibration) {
        SharedPreferences sharedpreferences = context.getSharedPreferences("NotificationSettings", Context.MODE_PRIVATE);
        Editor editor = sharedpreferences.edit();
        if (isSound != null) {
            editor.putBoolean("isSound", isSound.equalsIgnoreCase("Y") ? true : false);
        }
        if (isVibration != null) {
            editor.putBoolean("isVibration", isVibration.equalsIgnoreCase("Y") ? true : false);
        }
        boolean sucess = editor.commit();
        if (!sucess) {
            editor.apply();
        }

    }

    public static Boolean isSound(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences("NotificationSettings", Context.MODE_PRIVATE);
        return sharedpreferences.getBoolean("isSound", true);
    }

    public static Boolean isVibration(Context context) {
        SharedPreferences sharedpreferences = context.getSharedPreferences("NotificationSettings", Context.MODE_PRIVATE);
        return sharedpreferences.getBoolean("isVibration", true);
    }

    public String Convert12HoursTo24Hours(String Time12Hour) {
        try {
            final SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
            final Date dateObj = sdf.parse(Time12Hour);
            return new SimpleDateFormat("HH:mm").format(dateObj);
        } catch (final ParseException e) {
            e.printStackTrace();
            return "error";
        }
    }

    public String Convert24HoursTo12Hours(String Time24Hour) {
        try {
            final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            final Date dateObj = sdf.parse(Time24Hour);
            return new SimpleDateFormat("hh:mm a").format(dateObj);
        } catch (final ParseException e) {
            e.printStackTrace();
            return "error";
        }
    }
}