/**
 * Project      : Economist
 * Filename     : RegisterNowActivity.java
 * Author       : nchauhan
 * Comments     :
 * Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.home.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.analytics.FirebaseAnalyticsTracker;
import com.businessstandard.analytics.GAConstants;
import com.businessstandard.analytics.GoogleAnalytics;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author nchauhan
 */
public class RegisterNowActivity extends Activity {

    private final String TAG = "RegisterNowActivity";
    final static String PREFERENCE_NAME = "login";
    SharedPreferences sharedpreferences;
    String subscription;
    EditText email, fname, lname, username, password, repass;
    TextView txtErrorMessage;
    Spinner gender;
    String apiToken;
    Context mContext;
    private RadioGroup radioSexGroup;
    private RadioButton radioSexButton;
    private Button save;
    private SaveSharedPref mSharedPreferenceManager;
    private com.businessstandard.model.Constants mConstants = null;
    private GoogleAnalytics mGoogleAnalytics;
    private FirebaseAnalyticsTracker mFirebaseAnalyticsTracker;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.signup_form);
        mContext = this;
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        mFirebaseAnalyticsTracker = FirebaseAnalyticsTracker.getInstance(this);
        mSharedPreferenceManager = SaveSharedPref.getInstance(this);
        if (mSharedPreferenceManager.exists(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA)) {
            if (mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class) != null) {
                mConstants = mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class);
            }
        }
        apiToken = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
        fname = (EditText) findViewById(R.id.fname);
        // lname = (EditText)findViewById(R.id.lname);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        repass = (EditText) findViewById(R.id.repassword);
        // username.getText().insert(username.getSelectionStart(), "");
        // password.getText().insert(password.getSelectionStart(), "  ");
        // cpassword = (EditText)findViewById(R.id.cpassword);
        // mobile = (EditText)findViewById(R.id.mobile);
        save = (Button) findViewById(R.id.save);
        // radioSexGroup = (RadioGroup) findViewById(R.id.radioSex);

        txtErrorMessage = (TextView) findViewById(R.id.error);

        save.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                String fnameStr = fname.getText().toString();
                // String lnameStr = lname.getText().toString();
                String usernameStr = username.getText().toString();
                String passwordStr = password.getText().toString();
                String repassword = repass.getText().toString();

                if (fnameStr.length() == 0) {
                    txtErrorMessage.setText("Please enter First Name");
                } else if (usernameStr.length() == 0) {
                    txtErrorMessage.setText("Please enter Email Id");
                } else if (isValidEmail(usernameStr)) {
                    if (passwordStr.equals(repassword)) {
                        RegisterUser signuptask = new RegisterUser(mContext);
                        signuptask.execute(apiToken, fnameStr, usernameStr, passwordStr);
                    } else {
                        RegisterNowActivity.this.txtErrorMessage
                                .setText("Password does not match!!");
                    }
                } else {
                    txtErrorMessage.setText("Please enter valid Email Id");
                }
                //

                // Intent inte = new
                // Intent(RegisterNowActivity.this,LoginNowActivity.class);
                // // startActivity(inte);
                //
                // Bundle bndlanimation =
                // ActivityOptions.makeCustomAnimation(getApplicationContext(),
                // R.anim.lefttoright,R.anim.righttoleft).toBundle();
                // startActivity(inte, bndlanimation);
            }
        });

    }

    public void getUser(String url) throws JSONException {

    }

    // gaurav-after successfully register autologin user class!!
    private class AutoLogin extends AsyncTask<String, String, JSONObject> {

        private ProgressDialog progressDialognew;
        Context ctx;
        String response;

        String errorMessage;

        /**
         * @param mContext
         */
        public AutoLogin(Context mContext) {
            ctx = mContext;
            progressDialognew = new ProgressDialog(mContext);
            progressDialognew.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialognew.setTitle("Validating..");
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialognew.show();
            // showDialog(DIALOG_DOWNLOAD_PROGRESS);
        }

        @Override
        protected JSONObject doInBackground(String... args) {
            //String strUrl = ctx.getString(R.string.api_base_url) + Constants.SIGN_IN_API;

            SaveSharedPref saveSharedPref = SaveSharedPref.getInstance(mContext);
            String signInApiUrl = "";
            if (saveSharedPref != null && !TextUtils.isEmpty(saveSharedPref.getString(SharedPreferencesKey.KEY_SIGN_IN_API, ""))) {
                signInApiUrl = saveSharedPref.getString(SharedPreferencesKey.KEY_SIGN_IN_API, "");
            }

            OkHttpClient client = new OkHttpClient();
            JSONObject json = null;

            RequestBody formBody = new FormBody.Builder()
                    .add("api_token", args[0])
                    .add("login_email", args[1])
                    .add("login_password", args[2])
                    .build();

            Request request = new Request.Builder()
                    .url(signInApiUrl)
                    .post(formBody)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    String jsonStr = response.body().string();
                    json = new JSONObject(jsonStr);
                    return json;
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;

        }

        protected void onProgressUpdate(String... progress) {
            super.onProgressUpdate(progress);

        }

        protected void onPostExecute(JSONObject json) {
            progressDialognew.cancel();
            System.out.println("==jsonAUTORegTest==" + json);
            StringBuilder sb = new StringBuilder();
            String status = null;
            JSONObject id = null;
            try {
                id = json.getJSONObject("message");
                try {
                    subscription = id.getString("is_unsubscribed");
                } catch (Exception e) {
                    // TODO: handle exception
                    subscription = "Y";
                }

                id = json.getJSONObject("message");
                String newid = id.getString("user_id");
                status = json.getString("status");

                if (!status.equals("success")) {
                    String message;
                    message = json.getString("message");
                    errorMessage = message;
                    RegisterNowActivity.this.txtErrorMessage.setText(message);

                } else {
                    String fileDirPath = RegisterNowActivity.this.getFilesDir() + "/userinfo.json";
                    String fileContent = json.toString();
                    File file = new File(fileDirPath);
                    try {
                        if (!file.exists()) {
                            file.createNewFile();
                        }

                        FileWriter fw = new FileWriter(file);
                        BufferedWriter bw = new BufferedWriter(fw);
                        bw.write(fileContent);
                        bw.close();
                    } catch (IOException io) {
                        io.printStackTrace();
                    }

                    sharedpreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("value", subscription);
                    editor.putString("newvalue", newid);
                    editor.commit();

                    if (!TextUtils.isEmpty(newid)) {
                        //Store User ID to Shared Preferences for Future GA Event Tracking
                        SaveSharedPref.getInstance(RegisterNowActivity.this).saveString(SharedPreferencesKey.KEY_USER_ID, newid);
                        trackCreateAccountGAEvent(newid);
                    }
                    Intent returnIntent = new Intent();
                    returnIntent.putExtra("result", status);
                    setResult(RESULT_OK, returnIntent);
                    finish();
                    // Toast toast = Toast.makeText(RegisterNowActivity.this,
                    // "Login Successfull.", Toast.LENGTH_SHORT);

                    // finish();
					/*if (subscription.equals("Y")) {
						Intent i = new Intent(RegisterNowActivity.this,
								PaymentDialog.class);
						i.putExtra("value", newid);
						startActivityForResult(i, 4);
						finish();
					} else {
						Intent returnIntent = new Intent();
						returnIntent.putExtra("result", status);
						setResult(RESULT_OK, returnIntent);

						finish();
					}*/
                    // finish();
                    // ArticleDetailFragment.mLoginNow.setVisibility(View.GONE);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private void trackCreateAccountGAEvent(String userId) {
        if (mGoogleAnalytics != null) {
            mGoogleAnalytics.trackEvent(GAConstants.CREATE_ACCOUNT_EVENT_CATEGORY, userId, GAConstants.COMPLETE_REGISTRATION_EVENT_LABEL);
        }
        mFirebaseAnalyticsTracker.trackEvent(GAConstants.CREATE_ACCOUNT_EVENT_CATEGORY, userId, GAConstants.COMPLETE_REGISTRATION_EVENT_LABEL);
    }

    // gaurav-calling register post Api!!
    private class RegisterUser extends AsyncTask<String, String, JSONObject> {

        private final ProgressDialog progressDialog;
        Context ctx;
        String response;

        String errorMessage;

        public RegisterUser(Context context) {
            ctx = context;
            progressDialog = new ProgressDialog(context);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setTitle("Validating..");

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
            // showDialog(DIALOG_DOWNLOAD_PROGRESS);
        }

        @Override
        protected JSONObject doInBackground(String... args) {
            //String strUrl = ctx.getString(R.string.api_base_url) + Constants.REGISTRATION_API;
            String registartionApiUrl = "";
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getRegistrationApi())) {
                registartionApiUrl = mConstants.getRegistrationApi();
            }
            OkHttpClient client = new OkHttpClient();
            JSONObject json;

            RequestBody formBody = new FormBody.Builder()
                    .add("api_token", args[0])
                    .add("user_email", args[2])
                    .add("first_name", args[1])
                    .add("last_name", args[1])
                    .add("user_password", args[3])
                    .add("confirm_password", args[3])
                    .add("mobile_no", "mobile")
                    .add("gender", "male")
                    .build();

            Request request = new Request.Builder()
                    .url(registartionApiUrl)
                    .post(formBody)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String jsonStr = response.body().string();
                    json = new JSONObject(jsonStr);
                    return json;
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onProgressUpdate(String... progress) {
            super.onProgressUpdate(progress);
        }

        @SuppressLint("ShowToast")
        protected void onPostExecute(JSONObject json) {
            progressDialog.dismiss();
            if (json != null) {
                String message;
                StringBuilder sb = new StringBuilder();
                String status = null;
                String message1;
                try {
                    // message = json.getJSONObject("message");
                    // message.get("")
                    System.out.println("==jsonRegTest==" + json);

                    status = json.getString("status");
                    if (status.equals("error")) {
                        message = json.getString("message");
                        RegisterNowActivity.this.txtErrorMessage.setText(message);
                        String stauscode = json.getString("status_code");
                        if (stauscode.equals("303")) {
                            String usernameStr = username.getText().toString();
                            String passwordStr = password.getText().toString();
                            // finish();
                            AutoLogin signuptasknew = new AutoLogin(mContext);
                            signuptasknew.execute(apiToken, usernameStr, passwordStr);
                            Toast.makeText(RegisterNowActivity.this, message, Toast.LENGTH_SHORT).show();
                        } else {
                            message = json.getString("message");
                            RegisterNowActivity.this.txtErrorMessage.setText(message);
                            Intent i = new Intent(RegisterNowActivity.this, Forgotpass.class);
                            startActivity(i);
                            finish();
                            Toast.makeText(RegisterNowActivity.this, message, Toast.LENGTH_SHORT).show();
                        }
                    }

                    if (!status.equals("success")) {
                        message = json.getString("message");
                        RegisterNowActivity.this.txtErrorMessage.setText(message);

                    } else {
                        message1 = json.getString("message");
                        Toast.makeText(RegisterNowActivity.this, message1, Toast.LENGTH_SHORT).show();
                        // ArticleDetailFragment.mSubscribeNow.setVisibility(View.GONE);
                        String usernameStr = username.getText().toString();
                        String passwordStr = password.getText().toString();
                        // finish();
                        trackCompleteRegistrationGAEvent();
                        AutoLogin signuptasknew = new AutoLogin(mContext);
                        signuptasknew.execute(apiToken, usernameStr, passwordStr);
                    }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block e.printStackTrace();
                }

            }
        }

    }

    private void trackCompleteRegistrationGAEvent() {
        //Google Analytics Tracking
        if (mGoogleAnalytics != null && !TextUtils.isEmpty(SaveSharedPref.getInstance(RegisterNowActivity.this).getString(SharedPreferencesKey.KEY_DEVICE_ID, ""))) {
            mGoogleAnalytics.trackEvent(GAConstants.COMPLETE_REGISTRATION_EVENT_CATEGORY,
                    SaveSharedPref.getInstance(RegisterNowActivity.this).getString(SharedPreferencesKey.KEY_DEVICE_ID, ""),
                    GAConstants.COMPLETE_REGISTRATION_EVENT_LABEL);
        }

        mFirebaseAnalyticsTracker.trackEvent(GAConstants.COMPLETE_REGISTRATION_EVENT_CATEGORY,
                SaveSharedPref.getInstance(RegisterNowActivity.this).getString(SharedPreferencesKey.KEY_DEVICE_ID, ""),
                GAConstants.COMPLETE_REGISTRATION_EVENT_LABEL);
    }

    /*
     * (non-Javadoc)
     *
     * @see android.app.Activity#onActivityResult(int, int,
     * android.content.Intent)
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        String status = "ok";
        if (requestCode == 4) {
            if (resultCode == Activity.RESULT_OK) {
                Intent returnIntent = new Intent();
                returnIntent.putExtra("result", status);
                setResult(RESULT_OK, returnIntent);

                finish();
            }
        }
        Intent returnIntent = new Intent();
        returnIntent.putExtra("result", status);
        setResult(RESULT_OK, returnIntent);
        finish();
    }

    public final static boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target)
                    .matches();
        }
    }

}
