package com.businessstandard.gallery;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.businessstandard.R;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.util.Utility;
import com.businessstandard.model.GalleryResponseModel;
import com.businessstandard.model.GalleryVideoslist;
import com.businessstandard.network.NetworkClient;
import com.businessstandard.network.NetworkInterface;
import com.businessstandard.network.RequestCode;
import com.businessstandard.utils.AppConstants;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GalleryFragment extends BaseFragment implements AdapterView.OnItemClickListener {

    private Context mContext;
    private SaveSharedPref mSharedPreferenceManager;
    private String galleryUrl;
    private NetworkInterface mNetworkInterface;
    public static final String apiToken = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
    private int pageNumber = 0;
    private String itemsPerPage = "10";
    private ProgressBar progressBar;
    private ListView videosListView;
    private VideosListAdapter videosListAdapter = null;
    private List<GalleryVideoslist> mVideoList = new ArrayList<>();
    private com.businessstandard.model.Constants mConstants = null;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_gallery, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mSharedPreferenceManager = SaveSharedPref.getInstance(mContext);
        mNetworkInterface = NetworkClient.getClient().create(NetworkInterface.class);
        initView(view);
        getVideosTabUrlFromConfig();
        getDataFromServer(true);
    }

    private void initView(View view) {
        progressBar = (ProgressBar) view.findViewById(R.id.progressBar);
        videosListView = (ListView) view.findViewById(R.id.videosListView);
        videosListView.setOnItemClickListener(this);

        videosListView.setOnScrollListener(new AbsListView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE
                        && (videosListView.getLastVisiblePosition() - videosListView.getHeaderViewsCount() -
                        videosListView.getFooterViewsCount()) >= (videosListAdapter.getCount() - 1)) {
                    // Now your listview has hit the bottom
                    getDataFromServer(false);
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }

        });
    }

    private void getVideosTabUrlFromConfig() {
        if (mSharedPreferenceManager.exists(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA)) {
            if (mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class) != null) {
                mConstants = mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class);
            }
        }
        if (mConstants != null && !TextUtils.isEmpty(mConstants.getGetGalleryVideos())) {
            galleryUrl = mConstants.getGetGalleryVideos();
        }
        //galleryUrl = "http://api.business-standard.com/user/process-api/gallery-videos-list";
    }

    private void getDataFromServer(boolean showProgress) {
        if (Utility.isInternetOn(mContext)) {
            if (!TextUtils.isEmpty(galleryUrl)) {
                pageNumber = pageNumber + 1;
                if (showProgress) {
                    showProgress();
                }
                getVideoListing(RequestCode.GET_VIDEOS_TAB, galleryUrl, apiToken, String.valueOf(pageNumber), itemsPerPage);
            }
        }
    }

    public void getVideoListing(final int requestCode, String galleryUrl, String apiToken, String pageNumber, String itemsPerPage) {
        Call<GalleryResponseModel> videoListingResponseModelCall = mNetworkInterface.getVideosListingData(galleryUrl, apiToken, pageNumber, itemsPerPage);
        videoListingResponseModelCall.enqueue(new Callback<GalleryResponseModel>() {
            @Override
            public void onResponse(Call<GalleryResponseModel> call, Response<GalleryResponseModel> response) {
                if (response.isSuccessful()) {
                    onResponseListener(requestCode, response.body());
                }
            }

            @Override
            public void onFailure(Call<GalleryResponseModel> call, Throwable t) {
                onErrorListener(requestCode, t.getMessage());
            }
        });
    }

    private void onResponseListener(int requestCode, GalleryResponseModel responseModel) {
        try {
            if (requestCode == RequestCode.GET_VIDEOS_TAB) {
                if (responseModel != null) {
                    hideProgress();
                    List<GalleryVideoslist> galleryVideoslist = responseModel.getGalleryVideoslist();
                    if (galleryVideoslist != null && galleryVideoslist.size() > 0) {
                        mVideoList.addAll(galleryVideoslist);
                        setListView(mVideoList);
                    }
                }
            }
        } catch (Exception e) {
            hideProgress();
            e.printStackTrace();
        }
    }

    private void setListView(List<GalleryVideoslist> galleryVideoslist) {
        if (videosListAdapter == null) {
            videosListAdapter = new VideosListAdapter(galleryVideoslist, mContext);
            videosListView.setAdapter(videosListAdapter);
        } else {
            videosListAdapter.setVideosList(galleryVideoslist);
            videosListAdapter.notifyDataSetChanged();
        }
    }

    private void onErrorListener(int requestCode, String message) {
        hideProgress();
    }

    public void showProgress() {
        if (progressBar != null) {
            progressBar.setVisibility(ProgressBar.VISIBLE);
        }
    }

    public void hideProgress() {
        if (progressBar != null) {
            progressBar.setVisibility(ProgressBar.INVISIBLE);
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(mContext, VideoConsumptionActivity.class);
        GalleryVideoslist galleryVideoslist = mVideoList.get(position);
        if (galleryVideoslist != null) {
            if (!TextUtils.isEmpty(galleryVideoslist.getGalleryId())) {
                intent.putExtra(AppConstants.GALLERY_ID, galleryVideoslist.getGalleryId());
            }
            if (!TextUtils.isEmpty(galleryVideoslist.getTitle())) {
                intent.putExtra(AppConstants.GALLERY_VIDEO_TITLE, galleryVideoslist.getTitle());
            }
            mContext.startActivity(intent);
        }
    }
}
