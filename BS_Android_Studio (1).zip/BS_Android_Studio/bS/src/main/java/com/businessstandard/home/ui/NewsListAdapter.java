/**
 * Project      : Economist
 * Filename     : NewsListAdapter.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.home.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentActivity;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.SubNewsItem;
import com.businessstandard.common.ui.MainFragmentActivity;
import com.businessstandard.common.util.Constants;
import com.businessstandard.common.util.ImageManager;
import com.businessstandard.common.util.Utility;

import java.io.File;
import java.util.List;

public class NewsListAdapter extends ArrayAdapter<SubNewsItem> {

    private LayoutInflater mInflater;
    String fileDirPath;
    String tgpref;
    int counter = 0;
    private Context mContext;

    public NewsListAdapter(FragmentActivity mcontext, int newsListitem) {
        super(mcontext, newsListitem);
        mInflater = LayoutInflater.from(mcontext);
        mContext = mcontext;
        fileDirPath = mcontext.getFilesDir() + "/userinfo.json";
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(mcontext);
        tgpref = preferences.getString("value", null);
    }

    public NewsListAdapter(Context context, List<SubNewsItem> newsList) {
        super(context, 0, newsList);
        mContext = context;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        fileDirPath = context.getFilesDir() + "/userinfo.json";
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        tgpref = preferences.getString("value", null);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = null;
        ViewHolder holder;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.news_listitem, null);
            holder = new ViewHolder();
            holder.newsImage = (ImageView) convertView.findViewById(R.id.newsItemImage);
            holder.paid = (ImageView) convertView.findViewById(R.id.newsItemImagenew);
            holder.newsTitle = (TextView) convertView.findViewById(R.id.newsTitle);
            holder.newsAuthor = (TextView) convertView.findViewById(R.id.newsAuthor);
            holder.newsTime = (TextView) convertView.findViewById(R.id.newsTime);
            // if(MainFragmentActivity.maincat.equals("Todays paper")){
            // holder.header_text=(TextView)
            // convertView.findViewById(R.id.header_text);

            // }
            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        SubNewsItem newsItem = getItem(position);

        // if(MainFragmentActivity.maincat.equals("Todays paper") &&
        // newsItem.key!=null)
        // {
        // BaseActivity.name=newsItem.key;
        // holder.header_text.setText(Html.fromHtml(newsItem.key));
        // holder.header_text.setVisibility(View.VISIBLE);
        //
        // // if(BaseActivity.name.equalsIgnoreCase(newsItem.key)){
        // // holder.header_text.setVisibility(View.VISIBLE);
        // // }
        //
        //
        // }

        // if (newsItem.ispaid != null) {
        // if(MainFragmentActivity.maincat.equals("Todays paper") &&
        // BaseActivity.name!=null ){
        // if(BaseActivity.name.equals(newsItem.key)){}
        // else
        // holder.header_text.setText(Html.fromHtml(newsItem.key));
        // BaseActivity.name=newsItem.key;
        // }
        //
        // uncomment this code in case of paid version gaurav diwaker
        if (newsItem.ispaid.equals("Y")) {
            holder.paid.setVisibility(View.VISIBLE);
            File file = new File(fileDirPath);
            if (file.exists()) {
                if (tgpref.equals("N")) {
                    holder.paid.setVisibility(View.GONE);// BackgroundResource(R.drawable.unlock);
                } else {
                    holder.paid.setPadding(8, 0, 0, 0);
                    holder.newsTitle.setPadding(80, 0, 20, 0);
                    holder.paid.setImageResource(R.drawable.locksmall);
                    // holder.paid.setBackgroundResource(R.drawable.locksmall);
                }
            } else {
                holder.paid.setPadding(8, 0, 0, 0);
                holder.newsTitle.setPadding(80, 0, 20, 0);
                holder.paid.setImageResource(R.drawable.locksmall);
                // holder.paid.setBackgroundResource(R.drawable.locksmall);
            }
        } else {
            holder.paid.setVisibility(View.GONE);
            // holder.paid.w
            System.out.println("<<<<<<<<<" + newsItem.ispaid);
        }
        // } else {
        // holder.paid.setVisibility(View.GONE);
        // // holder.paid.w
        // System.out.println("<<<<<<<<<" + newsItem.ispaid);
        // }

        // String date = "Sat, 27 Apr 2013 01:11:30 GMT";
        // 2014-06-24 12:14:00
        holder.newsTitle.setText(Html.fromHtml(newsItem.title));
        holder.newsTitle.setMaxLines(Constants.MAX_LINES);
        holder.newsAuthor.setText(Html.fromHtml(newsItem.author));
        String publishedRelativeTime = Utility.getPublishedTime(newsItem.dateTime);
        // String publishedRelativeTime = Utility.getPublishedTime(date);

        holder.newsTime.setText(publishedRelativeTime);
        holder.newsImage.setImageResource(R.drawable.imageplaceholder);
        if (newsItem.Section != null && newsItem.Section != " ") {
            if (MainFragmentActivity.sabcat.equals("Opinion")
                    || newsItem.Section.equals("Opinion")) {
                if (!newsItem.auhorThumbUrl.equals("")) {
                    ImageManager.INSTANCE.loadBitmap(newsItem.auhorThumbUrl, holder.newsImage);
                } else {
                    ImageManager.INSTANCE.loadBitmap(newsItem.imageUrl, holder.newsImage);
                }
            }
            else {
                ImageManager.INSTANCE.loadBitmap(newsItem.imageUrl, holder.newsImage);
            }
        } else {
            ImageManager.INSTANCE.loadBitmap(newsItem.imageUrl, holder.newsImage);
        }
        return convertView;
    }

    private class ViewHolder {
        ImageView newsImage;
        ImageView paid;
        TextView newsTitle;
        TextView newsAuthor;
        TextView newsTime;
        TextView header_text;
    }
}
