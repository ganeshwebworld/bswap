/**
   Project      : Economist
   Filename     : SectionMainItem.java
   Author       : android
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
				  Modified under contract by Robosoft Technologies Pvt. Ltd.
   History      : NA
*/

package com.businessstandard.common.dto;

import com.google.gson.annotations.SerializedName;

/**
 * @author android
 *
 */
public class SectionMainItem {
	@SerializedName("catID")
	public String categoryId;

	@SerializedName("catName")
	public String categoryName;

	@SerializedName("layoutid")
	public int layoutId;

	@SerializedName("feedURL")
	public String feedUrl;
	
}
