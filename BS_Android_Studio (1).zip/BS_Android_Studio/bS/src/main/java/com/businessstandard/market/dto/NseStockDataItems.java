/**
   Project      : Economist
   Filename     : NseStockDataItems.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.market.dto;

/**
 * @author lenesha
 *
 */
public class NseStockDataItems extends StockHolder{
	public NseStockDataItem[] nseStockitems;
	public BseStockDataItem[] bseStockitems;
	public boolean isToppers =false;
	public boolean is52WeekHigh =false;
	public boolean isLoosers=false;
	public boolean is52WeekLow=false;
	
	public static  boolean  isNSE = true;
}
