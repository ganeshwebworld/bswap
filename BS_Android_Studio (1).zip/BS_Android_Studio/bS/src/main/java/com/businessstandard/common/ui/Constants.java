/**
   Project      : Economist
   Filename     : Constant.java
   Author       : amishra
   Comments     : 
   Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
				  Modified under contract by Robosoft Technologies Pvt. Ltd.
   History      : NA
*/

package com.businessstandard.common.ui;

/**
 * @author amishra
 *
 */
public class Constants {
	
	public static final String ad_up_Portrait_240 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"240\"; var zflag_height=\"38\"; var zflag_sz=\"66\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	//public static final String ad_up_Landscape = "<script language=\'JavaScript\'> var zflag_nid=\'749\'; var zflag_cid=\'4135\'; var zflag_sid=\'371\'; var zflag_width=\'320\'; var zflag_height=\'50\'; var zflag_sz=\'65\'; var zflag_charset=\'utf-8\'; </script> <script language=\'JavaScript\' src=\'http://d3.zedo.com/jsc/d3/fo.js\'></script>";
	
	public static final String ad_down_Portrait_240 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"240\"; var zflag_height=\"38\"; var zflag_sz=\"70\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	//public static final String ad_down_Landscape = "<script language=\'JavaScript\'> var zflag_nid=\'749\'; var zflag_cid=\'4135\'; var zflag_sid=\'371\'; var zflag_width=\'320\'; var zflag_height=\'50\'; var zflag_sz=\'65\'; var zflag_charset=\'utf-8\'; </script> <script language=\'JavaScript\' src=\'http://d3.zedo.com/jsc/d3/fo.js\'></script>";
	
	public static final String ad_up_Portrait_320 = "<script language=\"JavaScript\"> var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"320\"; var zflag_height=\"50\"; var zflag_sz=\"50\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	
	public static final String ad_down_Portrait_320= "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"320\"; var zflag_height=\"50\"; var zflag_sz=\"65\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	public static final String ad_up_Portrait_480 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"480\"; var zflag_height=\"60\"; var zflag_sz=\"67\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	
	public static final String ad_down_Portrait_480 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"468\"; var zflag_height=\"60\"; var zflag_sz=\"71\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	public static final String ad_up_Portrait_600 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"600\"; var zflag_height=\"60\"; var zflag_sz=\"44\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	
	public static final String ad_down_Portrait_600 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"600\"; var zflag_height=\"60\"; var zflag_sz=\"40\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	public static final String ad_up_Portrait_720 = "script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"720\"; var zflag_height=\"60\"; var zflag_sz=\"55\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	
	public static final String ad_down_Portrait_720 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"720\"; var zflag_height=\"60\"; var zflag_sz=\"59\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	
	public static final String ad_up_Portrait_768 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"768\"; var zflag_height=\"60\"; var zflag_sz=\"68\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	
	public static final String ad_down_Portrait_768 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"768\"; var zflag_height=\"60\"; var zflag_sz=\"72\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	public static final String ad_up_Portrait_800 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"800\"; var zflag_height=\"60\"; var zflag_sz=\"74\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	
	public static final String ad_down_Portrait_800 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"800\"; var zflag_height=\"60\"; var zflag_sz=\"75\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	public static final String ad_up_Portrait_1024 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"1024\"; var zflag_height=\"60\"; var zflag_sz=\"69\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	
	public static final String ad_down_Portrait_1024 = "<script language=\"JavaScript\">var zflag_nid=\"1429\"; var zflag_cid=\"81\"; var zflag_sid=\"0\"; var zflag_width=\"1024\"; var zflag_height=\"60\"; var zflag_sz=\"73\";</script><script language=\"JavaScript\" src=\"http://c1.zedo.com/jsc/c1/fo.js\"></script>";
	

	public static final String BaseUrl_V2="http://api.business-standard.com";
	
}
