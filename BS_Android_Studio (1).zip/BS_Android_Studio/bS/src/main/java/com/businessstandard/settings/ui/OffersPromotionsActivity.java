/**
 * Project      : Economist
 * Filename     : OffersPromotionsActivity.java
 * Author       : android
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.settings.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebSettings.ZoomDensity;
import android.webkit.WebView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.coupon.database.CouponDataBase;
import com.android.downloadimages.ImageLoader;
import com.businessstandard.R;
import com.businessstandard.common.ui.MainFragmentActivity;
import com.businessstandard.common.util.CouponUtils;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author android
 */
public class OffersPromotionsActivity extends Activity {
    private WebView webview;
    LinearLayout layout;
    private ListView listView;
    private LayoutInflater mInflater;
    public ImageLoader imageLoader;
    private CouponDataBase dataBase;
    MyCustomAdapter adapter;
    private SaveSharedPref mSharedPreferenceManager;
    private com.businessstandard.model.Constants mConstants = null;
//	ArrayList<CouponUtils> arrayList = new ArrayList<CouponUtils>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.offerspromotions);
        mSharedPreferenceManager = SaveSharedPref.getInstance(this);
        if (mSharedPreferenceManager.exists(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA)) {
            if (mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class) != null) {
                mConstants = mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class);
            }
        }
        layout = (LinearLayout) findViewById(R.id.ll);
        dataBase = new CouponDataBase(OffersPromotionsActivity.this);
//		arrayList = MainFragmentActivity.arrayList;
        adapter = new MyCustomAdapter(MainFragmentActivity.arrayList);
        imageLoader = new ImageLoader(OffersPromotionsActivity.this);
        mInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        listView = (ListView) findViewById(R.id.listview);
        listView.setAdapter(adapter);
        webview = (WebView) findViewById(R.id.webView);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webview.getSettings().setLoadWithOverviewMode(true);
        webview.getSettings().setBuiltInZoomControls(false);
        webview.setHorizontalScrollBarEnabled(false);
        webview.getSettings().setDomStorageEnabled(true);
        webview.getSettings().setAllowFileAccess(true);
        webview.getSettings().setLoadsImagesAutomatically(true);
        webview.getSettings().setSupportZoom(false);
        webview.setInitialScale(100);
        webview.getSettings().setDefaultZoom(ZoomDensity.FAR);
        webview.getSettings()
                .setUserAgentString(
                        "Safari/534.30 Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 ");
        webview.loadUrl("file:///android_asset/Ads_up600.html");

    }

    private void conformationDialog(final String offer_id, final int pos) {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

        LinearLayout layout = new LinearLayout(this);
        TextView tvMessage = new TextView(this);
        layout.setGravity(Gravity.CENTER);
        tvMessage.setText("    Are you sure, you want to delete this coupon?");

        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(tvMessage);

        builder1.setTitle("Delete Confirmation");
        builder1.setView(layout);

        builder1.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        getCouponCode(offer_id, pos);
                    }
                });
        builder1.setNegativeButton("No", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        // builder1.setTitle("Latests News");
        // builder1.setMessage("I am here!!!!!!!!!!!!");
        // builder1.setCancelable(true);
        // builder1.setPositiveButton("Yes",
        // new DialogInterface.OnClickListener() {
        // public void onClick(DialogInterface dialog, int id) {
        // dialog.cancel();
        // }
        // });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private void getCouponCode(String offer_id, int pos) {

        // if (isopen.equalsIgnoreCase("error")) {
	/*	TelephonyManager tManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		@SuppressLint("MissingPermission")

		String uuid = tManager.getDeviceId();*/
        //Secure Id added in place of telephony id
        String uuid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        CouponCode signuptasknew = new CouponCode(OffersPromotionsActivity.this);
        signuptasknew.execute(MainFragmentActivity.api_key, uuid, offer_id, String.valueOf(pos));
        // }
    }

    class MyCustomAdapter extends BaseAdapter {
        /**
         *
         */
        ArrayList<CouponUtils> arrayList = new ArrayList<CouponUtils>();

        public MyCustomAdapter(ArrayList<CouponUtils> arrayList) {
            this.arrayList = arrayList;
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return 0;
        }

        class Myholder {
            Button viewdetail;
            Button delete;
            TextView couponcode, offer_des, validtill;
            ImageView image;
        }

        @Override
        public View getView(final int position, View convertView,
                            ViewGroup parent) {
            convertView = null;
            Myholder myholder = null;
            if (convertView == null) {
                myholder = new Myholder();

                convertView = mInflater.inflate(
                        R.layout.offerpromotions_list_row, null);
                myholder.viewdetail = (Button) convertView
                        .findViewById(R.id.viewdetail_btn);
                myholder.delete = (Button) convertView
                        .findViewById(R.id.delete_btn);
                myholder.couponcode = (TextView) convertView
                        .findViewById(R.id.coupon_code);
                myholder.offer_des = (TextView) convertView
                        .findViewById(R.id.offer_des);
                myholder.validtill = (TextView) convertView
                        .findViewById(R.id.validtill);
                myholder.image = (ImageView) convertView
                        .findViewById(R.id.img);
                convertView.setTag(myholder);
            } else
                myholder = (Myholder) convertView.getTag();
            myholder.couponcode.setText(arrayList.get(position).getCouponcode());
            myholder.offer_des.setText(arrayList.get(position).getOfferdesc());


            try {
                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                SimpleDateFormat outputFormat = new SimpleDateFormat("MMMM dd, yyyy");

                java.util.Date validDate = inputFormat.parse(arrayList.get(position).getValidtill());
                if (validDate != null)
                    myholder.validtill.setText(outputFormat.format(validDate));
            } catch (Exception e) {
            }

            imageLoader.DisplayImage(arrayList.get(position).getOfferid(),
                    arrayList.get(position).getLogourl(), myholder.image);
            myholder.viewdetail.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(
                            OffersPromotionsActivity.this,
                            CouponDetailsActivity.class);
                    intent.putExtra("couponcode", arrayList.get(position)
                            .getCouponcode());
                    startActivity(intent);
                }
            });
            myholder.delete.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    conformationDialog(arrayList.get(position).getOfferid(), position);
//						offerid = arrayList.get(position).getOfferid();
                }
            });


            return convertView;
        }

    }

    private class CouponCode extends AsyncTask<String, String, String> {

        /**
         * @param mContext
         */
        ProgressDialog dialog;
        Context context;

        CouponCode(Context mContext) {
            context = mContext;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = ProgressDialog.show(OffersPromotionsActivity.this, "", "Deleting Coupon...");
        }

        @Override
        protected String doInBackground(String... args) {
            Context ctx = getApplicationContext();
            //String strUrl = ctx.getString(R.string.api_base_url);
            String strUrl = "";
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getDeletecouponApi())) {
                strUrl = mConstants.getDeletecouponApi();
            }

/*            InputStream is = null;

            JSONParser jsonParser = new JSONParser();
//			List<NameValuePair> params = new ArrayList<NameValuePair>();
//			params.add(new BasicNameValuePair("api_token", args[0]));
//			params.add(new BasicNameValuePair("device_udid", args[1]));
//			params.add(new BasicNameValuePair("offer_id", args[2]));

            JSONObject json = null;

            org.apache.commons.httpclient.NameValuePair[] request = {
                    new org.apache.commons.httpclient.NameValuePair(
                            "api_token", args[0]),
                    new org.apache.commons.httpclient.NameValuePair("device_udid",
                            args[1]),
                    new org.apache.commons.httpclient.NameValuePair("offer_id",
                            args[2])};


            String msg = "";
            try {
                json = new JSONObject(jsonParser.callWebservice(request, strUrl
                        + Constants.DELETE_COUPON_API));
                if (json.getString("status").equalsIgnoreCase("success")) {
//					arrayList.remove(Integer.parseInt(args[3]));
                    dataBase.deleteByOfferid(args[2]);
                    MainFragmentActivity.arrayList.remove(Integer.parseInt(args[3]));

                }
                msg = json.getString("message");

            } catch (JSONException e) {
                e.printStackTrace();
            }*/

            OkHttpClient client = new OkHttpClient();
            JSONObject json = null;
            String msg = "";

            RequestBody formBody = new FormBody.Builder()
                    .add("api_token", args[0])
                    .add("device_udid", args[1])
                    .add("offer_id", args[2])
                    .build();

            Request request = new Request.Builder()
                    .url(strUrl)
                    .post(formBody)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    if (response.body() != null) {
                        json = new JSONObject(response.body().string());
                        if (json.getString("status").equalsIgnoreCase("success")) {
//					arrayList.remove(Integer.parseInt(args[3]));
                            dataBase.deleteByOfferid(args[2]);
                            MainFragmentActivity.arrayList.remove(Integer.parseInt(args[3]));
                        }
                    }
                    if (json != null && !TextUtils.isEmpty(json.getString("message"))) {
                        msg = json.getString("message");
                    }
                    return msg;
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(String str) {
            if (dialog != null) {
                dialog.dismiss();
            }
            adapter.notifyDataSetChanged();
            Toast.makeText(OffersPromotionsActivity.this, str, Toast.LENGTH_LONG).show();

        }
    }
}
