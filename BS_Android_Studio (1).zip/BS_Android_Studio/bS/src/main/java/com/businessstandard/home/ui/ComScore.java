/**
 * Project      : Economist
 * Filename     : ComScore.java
 * Author       : android
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.home.ui;

import android.app.Application;
import android.util.Log;

import com.businessstandard.BuildConfig;
import com.businessstandard.R;
import com.businessstandard.analytics.AnalyticsTrackers;
import com.businessstandard.utils.AppConstants;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;
import com.comscore.analytics.comScore;
import com.crashlytics.android.Crashlytics;
import com.twitter.sdk.android.core.DefaultLogger;
import com.twitter.sdk.android.core.Twitter;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterConfig;

import io.fabric.sdk.android.Fabric;

/**
 * @author android
 */
public class ComScore extends Application {

    public static final String API_VERSION = AppConstants.API_VERSION;

    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
        super.onCreate();
        SaveSharedPref.getInstance(this).saveBoolean(SharedPreferencesKey.FRESH_LAUNCH, true);
        Crashlytics crashlytics = new Crashlytics.Builder().disabled(BuildConfig.DEBUG).build();
        Fabric.with(this, crashlytics);
        TwitterConfig config = new TwitterConfig.Builder(this)
                .logger(new DefaultLogger(Log.DEBUG))//enable logging when app is in debug mode
                .twitterAuthConfig(new TwitterAuthConfig(getResources().getString(R.string.com_twitter_sdk_android_CONSUMER_KEY), getResources().getString(R.string.com_twitter_sdk_android_CONSUMER_SECRET)))//pass the created app Consumer KEY and Secret also called API Key and Secret
                .debug(true)//enable debug mode
                .build();

        //finally initialize twitter with created configs
        Twitter.initialize(config);

        comScore.setAppContext(this.getApplicationContext());
        comScore.setCustomerC2("8021726");
        comScore.setPublisherSecret("9c25837893baca4ceae98f1a481c49a9");
        comScore.setAppName("BS");

        AnalyticsTrackers.initialize(this);
        AnalyticsTrackers.getInstance().get(AnalyticsTrackers.Target.APP);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }
}
