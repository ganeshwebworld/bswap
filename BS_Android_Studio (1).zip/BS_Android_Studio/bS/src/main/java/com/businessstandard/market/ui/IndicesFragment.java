/**
 * Project      : Economist
 * Filename     : IndicesFragment.java
 * Author       : lenesha
 * Comments     :
 * Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
 * History      : NA
 */
package com.businessstandard.market.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.common.dto.SectionNewsRootFeedItem;
import com.businessstandard.common.ui.BaseFragment;
import com.businessstandard.common.ui.CompanyDetailsActivity;
import com.businessstandard.common.util.Constants;
import com.businessstandard.common.util.Constants.CompanyKeys;
import com.businessstandard.common.util.Utility;
import com.businessstandard.market.MarketsManager;
import com.businessstandard.market.MarketsManager.NSESensexDloadCmpltListener;
import com.businessstandard.market.MarketsManager.SensexDloadCmpltListener;
import com.businessstandard.market.dto.BseIndicesItems;
import com.businessstandard.market.dto.BseNseNewsItem;
import com.businessstandard.market.dto.BseStockDataItem;
import com.businessstandard.market.dto.CompanyStockNewsFeed;
import com.businessstandard.market.dto.NseIndicesItems;
import com.businessstandard.market.dto.NseStockDataItem;
import com.businessstandard.market.dto.StockHolder;
import com.businessstandard.analytics.GoogleAnalytics;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * @author lenesha
 */
public class IndicesFragment extends BaseFragment {

    private FragmentActivity mcontext;
    private FragmentListner listner;
    private ListView indices_listview;
    private IndicesAdapter mAdapter;
    private TextView emptyView;
    private OnClickListener mRowItemClcklistener;
    private List<StockHolder> stock_list = new ArrayList<StockHolder>();
    private GoogleAnalytics mGoogleAnalytics;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mcontext = getActivity();
        listner = (FragmentListner) mcontext;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.indices, container, false);
        mGoogleAnalytics = GoogleAnalytics.getInstance();
        indices_listview = (ListView) view.findViewById(R.id.indices_list);
        emptyView = (TextView) view.findViewById(android.R.id.empty);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initaliseClickListener();
        mAdapter = new IndicesAdapter(mcontext, R.layout.stock_list, (ArrayList<StockHolder>) stock_list, mRowItemClcklistener);
        indices_listview.setCacheColorHint(Color.WHITE);
        indices_listview.setVerticalFadingEdgeEnabled(false);
        indices_listview.setAdapter(mAdapter);
        //AnalyticsUtils.getInstAnalyticsUtils(getActivity()).trackPageView(getString(R.string.tab_market) + getString(R.string.cat_indices));
        if (mGoogleAnalytics != null && getActivity() != null) {
            mGoogleAnalytics.trackScreenView(getString(R.string.tab_market) + getString(R.string.cat_indices), getActivity());
        }
        getListItems();
    }

    /**
     * @author poojarani
     */
    private void initaliseClickListener() {

        mRowItemClcklistener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                CompanyStockNewsFeed selectdCompanyObject = null;
                String selectedCompName = (String) v.getTag();
                LinkedHashMap<String, CompanyStockNewsFeed> companyDetList = new LinkedHashMap<String, CompanyStockNewsFeed>();

                //creating company list(nse, bse) using seperate nse and bse company lists
                for (StockHolder stockHolder : stock_list) {

                    if (stockHolder instanceof NseIndicesItems) {

                        if (((NseIndicesItems) stockHolder).nseIndicesItem.length > 0) {

                            NseStockDataItem[] nseIndicesArray = ((NseIndicesItems) stockHolder).nseIndicesItem;

                            for (NseStockDataItem nseItem : nseIndicesArray) {

                                CompanyStockNewsFeed companyItem = new CompanyStockNewsFeed();
                                companyItem.nsestock = new BseNseNewsItem();

                                companyItem.nsestock.archiveCSVPath = nseItem.archiveCSVPath;
                                companyItem.nsestock.changePercent = nseItem.changePercent;
                                companyItem.nsestock.changeValue = nseItem.changeValue;
                                companyItem.nsestock.prevClose = nseItem.close;
                                companyItem.nsestock.coCode = nseItem.coCode;
                                companyItem.nsestock.coName = nseItem.coName;
                                companyItem.nsestock.dayOpen = nseItem.dayOpen;
                                companyItem.nsestock.high = nseItem.high;
                                companyItem.nsestock.intradayCSVPath = nseItem.intradayCSVPath;
                                companyItem.nsestock.lastName = nseItem.lName;
                                companyItem.nsestock.low = nseItem.low;
                                companyItem.nsestock.marketCap = nseItem.marketCap;
                                companyItem.nsestock.prev52weekHigh = nseItem.prev52weekHigh;
                                companyItem.nsestock.prev52weekLow = nseItem.prev52weekLow;
                                companyItem.nsestock.price = nseItem.price;
                                companyItem.nsestock.updateTime = nseItem.updateTime;
                                companyItem.nsestock.volume = nseItem.volume;

                                companyDetList.put(nseItem.coName, companyItem);
                                if (selectedCompName.length() > 0 && nseItem.coName.equalsIgnoreCase(selectedCompName)) {
                                    selectdCompanyObject = companyItem;
                                }

                            }
                        }
                    } else {
                        BseStockDataItem[] bseIndicesArray = ((BseIndicesItems) stockHolder).bseIndicesItem;
                        if (bseIndicesArray.length > 0) {
                            for (BseStockDataItem bseItem : bseIndicesArray) {

                                if (companyDetList.containsKey(bseItem.coName)) {
                                    String nsebseCompanyname = bseItem.coName;

                                    companyDetList.get(nsebseCompanyname).bsestock.archiveCSVPath = bseItem.archiveCSVPath;
                                    companyDetList.get(nsebseCompanyname).bsestock.changePercent = bseItem.changePercent;
                                    companyDetList.get(nsebseCompanyname).bsestock.changeValue = bseItem.changeValue;
                                    companyDetList.get(nsebseCompanyname).bsestock.prevClose = bseItem.close;
                                    companyDetList.get(nsebseCompanyname).bsestock.coCode = bseItem.coCode;
                                    companyDetList.get(nsebseCompanyname).bsestock.coName = bseItem.coName;
                                    companyDetList.get(nsebseCompanyname).bsestock.dayOpen = bseItem.dayOpen;
                                    companyDetList.get(nsebseCompanyname).bsestock.high = bseItem.high;
                                    companyDetList.get(nsebseCompanyname).bsestock.intradayCSVPath = bseItem.intradayCSVPath;
                                    companyDetList.get(nsebseCompanyname).bsestock.lastName = bseItem.lName;
                                    companyDetList.get(nsebseCompanyname).bsestock.low = bseItem.low;
                                    companyDetList.get(nsebseCompanyname).bsestock.marketCap = bseItem.marketCap;
                                    companyDetList.get(nsebseCompanyname).bsestock.prev52weekHigh = bseItem.prev52weekHigh;
                                    companyDetList.get(nsebseCompanyname).bsestock.prev52weekLow = bseItem.prev52weekLow;
                                    companyDetList.get(nsebseCompanyname).bsestock.price = bseItem.price;
                                    companyDetList.get(nsebseCompanyname).bsestock.updateTime = bseItem.updateTime;
                                    companyDetList.get(nsebseCompanyname).bsestock.volume = bseItem.volume;
                                    ;

                                } else {

                                    CompanyStockNewsFeed companyItem = new CompanyStockNewsFeed();
                                    companyItem.bsestock = new BseNseNewsItem();

                                    companyItem.bsestock.archiveCSVPath = bseItem.archiveCSVPath;
                                    companyItem.bsestock.changePercent = bseItem.changePercent;
                                    companyItem.bsestock.changeValue = bseItem.changeValue;
                                    companyItem.bsestock.prevClose = bseItem.close;
                                    companyItem.bsestock.coCode = bseItem.coCode;
                                    companyItem.bsestock.coName = bseItem.coName;
                                    companyItem.bsestock.dayOpen = bseItem.dayOpen;
                                    companyItem.bsestock.high = bseItem.high;
                                    companyItem.bsestock.intradayCSVPath = bseItem.intradayCSVPath;
                                    companyItem.bsestock.lastName = bseItem.lName;
                                    companyItem.bsestock.low = bseItem.low;
                                    companyItem.bsestock.marketCap = bseItem.marketCap;
                                    companyItem.bsestock.prev52weekHigh = bseItem.prev52weekHigh;
                                    companyItem.bsestock.prev52weekLow = bseItem.prev52weekLow;
                                    companyItem.bsestock.price = bseItem.price;
                                    companyItem.bsestock.updateTime = bseItem.updateTime;
                                    companyItem.bsestock.volume = bseItem.volume;

                                    companyDetList.put(bseItem.coName, companyItem);
                                    if (selectedCompName.length() > 0 &&
                                            bseItem.coName.equalsIgnoreCase(selectedCompName)) {
                                        selectdCompanyObject = companyItem;
                                    }
                                }

                            }
                        }
                    }
                }

                ArrayList<CompanyStockNewsFeed> companiesList = new ArrayList<CompanyStockNewsFeed>();
                if (companyDetList != null && companyDetList.size() > 0) {
                    Iterator customIterator = companyDetList.keySet().iterator();
                    while (customIterator.hasNext()) {
                        String key = (String) customIterator.next();
                        companiesList.add(companyDetList.get(key));
                    }
                }

                if (companiesList != null && companiesList.size() > 0) {
                    Constants.setCompny_list_items((ArrayList<CompanyStockNewsFeed>) companiesList);
                    Intent intent = new Intent(getActivity(), CompanyDetailsActivity.class);
                    intent.putExtra(CompanyKeys.POSITION, companiesList.indexOf(selectdCompanyObject));
                    intent.putExtra(Constants.IS_INDICES_FRAGMENT, true);

                    intent.putExtra(Constants.MARKET_SUB_CAT, getString(R.string.cat_indices));
                    startActivity(intent);
                }

            }
        };
    }

    /**
     *
     */
    private void getListItems() {
        if (getActivity() != null && Utility.isInternetOn(getActivity())) {

            if (listner != null && listner.getDataFromActivity() != null &&
                    listner.getDataFromActivity().root != null) {
                SectionNewsRootFeedItem dataFeed = listner.getDataFromActivity();
                String indicesBSEUrl = dataFeed.root.getmIndicesBseStockData().feedUrl;
                String indicesNSEUrl = dataFeed.root.getmIndicesNseStockData().feedUrl;

                MarketsManager manager = new MarketsManager(getActivity());
                emptyView.setVisibility(View.INVISIBLE);

                manager.nseDownloadSensexGainersLoosers(new NSESensexDloadCmpltListener() {

                    @Override
                    public void onFailure() {
                        Utility.hideProgressDialog();
                    }

                    @Override
                    public void OnCompanySearchDloadCmplt(NseStockDataItem[] result) {
                        Utility.hideProgressDialog();

                        NseIndicesItems item = new NseIndicesItems();
                        item.nseIndicesItem = result;
                        stock_list.add(item);

                        mAdapter.notifyDataSetChanged();
                    }
                }, indicesNSEUrl);


                manager.downloadSensexGainersLoosers(new SensexDloadCmpltListener() {

                    @Override
                    public void onFailure() {
                        Utility.hideProgressDialog();
                    }

                    @Override
                    public void OnCompanySearchDloadCmplt(BseStockDataItem[] result) {
                        Utility.hideProgressDialog();
                        BseIndicesItems items = new BseIndicesItems();
                        items.bseIndicesItem = result;
                        stock_list.add(0, items);
                        mAdapter.notifyDataSetChanged();
                    }

                }, indicesBSEUrl);
            } else {
                emptyView.setVisibility(View.VISIBLE);
                if (getActivity() != null)

                    Utility.displayAlert(getActivity(), getString(R.string.app_name), getResources()
                                    .getString(R.string.unable_to_fetch_data), android.R.string.ok,
                            Utility.getOkButtonListener(getActivity()));
            }
        } else {
            emptyView.setVisibility(View.VISIBLE);
            if (getActivity() != null)

                Utility.displayAlert(getActivity(), getString(R.string.app_name), getResources()
                                .getString(R.string.no_connection), android.R.string.ok,
                        Utility.getOkButtonListener(getActivity()));
        }
    }

    public void refreshContent() {
        stock_list.clear();
        getListItems();

    }


}
