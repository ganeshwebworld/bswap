/**
   Project      : Economist
   Filename     : CommoditiesAdapter.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
 */

package com.businessstandard.market.ui;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.businessstandard.R;
import com.businessstandard.market.dto.McxAndNcdexFutureItem;
import com.businessstandard.market.dto.McxAndNcdexNewsItem;
import com.businessstandard.market.dto.McxAndNcdexSpotItem;
import com.businessstandard.market.dto.McxNcdexFutureItems;
import com.businessstandard.market.dto.McxNcdexGainersLoosersItems;
import com.businessstandard.market.dto.McxNcdexSpotItems;
import com.businessstandard.market.dto.StockHolder;

/**
 * @author lenesha
 *
 */
public class CommoditiesAdapter extends ArrayAdapter<StockHolder> {


	private LayoutInflater mInflater;
	private Context mContext;

	private interface ItemType {
		int TOPPERS_LOOSERS = 0;
		int SPOT = 1;
		int FUTURE = 2;

	}
	/**
	 * @param context
	 * @param resource
	 * @param mstockArray
	 */
	public CommoditiesAdapter(Context context, int resource,
			StockHolder[] mstockArray) {
		super(context, resource, resource, mstockArray);
		mInflater = LayoutInflater.from(context);
		mContext = context;
	}



	/* (non-Javadoc)
	 * @see android.widget.Adapter#getView(int, android.view.View, android.view.ViewGroup)
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.commodities_list_item, null);
			holder = new ViewHolder();
			holder.header_label = (TextView) convertView
					.findViewById(R.id.header_label);
			holder.label_company = (TextView) convertView
					.findViewById(R.id.label_company);
			holder.label_price = (TextView) convertView
					.findViewById(R.id.label_price);
			holder.label_changepercntg = (TextView) convertView
					.findViewById(R.id.label_changepercntg);
			holder.the_table = (TableLayout) convertView
					.findViewById(R.id.table);

			convertView.setTag(holder);
		}
		else {
			holder = (ViewHolder) convertView.getTag();
		}
		StockHolder item = getItem(position);
		if(item instanceof McxNcdexGainersLoosersItems)
		{
			holder.label_company.setText(getContext()
					.getResources().getString(R.string.commodities));
			holder.label_price.setText(getContext()
					.getResources().getString(R.string.commodites_price));
			holder.label_changepercntg.setText(getContext()
					.getResources().getString(R.string.stock_chngpercnt));
			McxNcdexGainersLoosersItems items = (McxNcdexGainersLoosersItems) item;

			if(items.isMcxGainer)
			{
				holder.header_label.setText(getContext()
						.getResources().getString(R.string.mcxgainers));

			}
			if(items.isMcxLooser){
				holder.header_label.setText(getContext()
						.getResources().getString(R.string.mcxloosers));

			}
			if(items.isNcdexGainer){
				holder.header_label.setText(getContext()
						.getResources().getString(R.string.ncdex_gainers));

			}
			if(items.isNcdexLooser){
				holder.header_label.setText(getContext()
						.getResources().getString(R.string.ncdex_loosers));

			}

			holder.the_table.removeAllViews();


			for (int current = 0; current < items.mcxOrNcdex.size(); current++) {

				TableRow rowItem = (TableRow) ((LayoutInflater) mInflater)
						.inflate(R.layout.stock_table_row, null);
				TextView cmpny = (TextView) rowItem
						.findViewById(R.id.stock_company);
				TextView stock_price = (TextView) rowItem
						.findViewById(R.id.stock_price);
				TextView stock_changepercntg = (TextView) rowItem
						.findViewById(R.id.stock_changepercntg);

				List<McxAndNcdexNewsItem> gainers_loosers_item_list = items.mcxOrNcdex;
				cmpny.setText(gainers_loosers_item_list.get(current).getmSymbol());


				try {
					Float priceValue = Float.valueOf(gainers_loosers_item_list.get(current).getmPrice());
					stock_price.setText(gainers_loosers_item_list.get(current).getmPrice());

				} catch (NumberFormatException e) {
					stock_price.setText("0.0");

				}
				try {
					Float changePercent = Float.valueOf(gainers_loosers_item_list.get(current).getmChangePercent());
					stock_changepercntg.setText(gainers_loosers_item_list.get(current).getmChangePercent());

				} catch (NumberFormatException e) {
					stock_changepercntg.setText("0.0");

				}

				holder.the_table.addView(rowItem);

			}
		}
		else if(item instanceof McxNcdexSpotItems)
		{
			McxNcdexSpotItems items = (McxNcdexSpotItems) item;

			holder.label_company.setText(getContext()
					.getResources().getString(R.string.commodities));
			holder.label_price.setText(getContext()
					.getResources().getString(R.string.commodites_price));
			holder.label_changepercntg.setText(getContext()
					.getResources().getString(R.string.prevclose));
			if(items.isMcxSpot){
				holder.header_label.setText(getContext()
						.getResources().getString(R.string.mcx_spot));
			}
			if(items.isNcdexSpot){
				holder.header_label.setText(getContext()
						.getResources().getString(R.string.ncdex_spot));
			}
			holder.the_table.removeAllViews();


			for (int current = 0; current < items.mcxOrNcdexSpot.size(); current++) {

				TableRow rowItem = (TableRow) ((LayoutInflater) mInflater)
						.inflate(R.layout.stock_table_row, null);
				TextView cmpny = (TextView) rowItem
						.findViewById(R.id.stock_company);
				TextView stock_price = (TextView) rowItem
						.findViewById(R.id.stock_price);
				TextView stock_changepercntg = (TextView) rowItem
						.findViewById(R.id.stock_changepercntg);

				List<McxAndNcdexSpotItem> gainers_loosers_item_list = items.mcxOrNcdexSpot;
				cmpny.setText(gainers_loosers_item_list.get(current).getmSymbol());
				
				
				try {
					Float priceValue = Float.valueOf(gainers_loosers_item_list.get(current).getmPrice());
					stock_price.setText(gainers_loosers_item_list.get(current).getmPrice());

				} catch (NumberFormatException e) {
					stock_price.setText("0.0");

				}
				try {
					Float changePercent = Float.valueOf(gainers_loosers_item_list.get(current).getmPreviousClose());
					stock_changepercntg.setText(gainers_loosers_item_list.get(current).getmPreviousClose());

				} catch (NumberFormatException e) {
					stock_changepercntg.setText("0.0");

				}
				
				holder.the_table.addView(rowItem);

			}
		}
		else if(item instanceof McxNcdexFutureItems)
		{
			McxNcdexFutureItems items = (McxNcdexFutureItems) item;
			holder.label_company.setText(getContext()
					.getResources().getString(R.string.commodities));
			holder.label_price.setText(getContext()
					.getResources().getString(R.string.ltp));
			holder.label_changepercntg.setText(getContext()
					.getResources().getString(R.string.stock_chngpercnt));
			if(items.isMcxFuture){
				holder.header_label.setText(getContext()
						.getResources().getString(R.string.mcx_future));
			}
			if(items.isNcdexFuture){
				holder.header_label.setText(getContext()
						.getResources().getString(R.string.ncdex_future));
			}
			holder.the_table.removeAllViews();


			for (int current = 0; current < items.mcxOrNcdexFutureItems.size(); current++) {

				TableRow rowItem = (TableRow) ((LayoutInflater) mInflater)
						.inflate(R.layout.stock_table_row, null);
				TextView cmpny = (TextView) rowItem
						.findViewById(R.id.stock_company);
				TextView stock_price = (TextView) rowItem
						.findViewById(R.id.stock_price);
				TextView stock_changepercntg = (TextView) rowItem
						.findViewById(R.id.stock_changepercntg);

				List<McxAndNcdexFutureItem> gainers_loosers_item_list = items.mcxOrNcdexFutureItems;
				cmpny.setText(gainers_loosers_item_list.get(current).getmSymbol());
				
				
				try {
					Float priceValue = Float.valueOf(gainers_loosers_item_list.get(current).getmLtp());
					stock_price.setText(gainers_loosers_item_list.get(current).getmLtp());

				} catch (NumberFormatException e) {
					stock_price.setText("0.0");

				}
				try {
					Float changePercent = Float.valueOf(gainers_loosers_item_list.get(current).getmChangePercentage());
					stock_changepercntg.setText(gainers_loosers_item_list.get(current).getmChangePercentage());

				} catch (NumberFormatException e) {
					stock_changepercntg.setText("0.0");

				}
			
				holder.the_table.addView(rowItem);

			}
		}
		return convertView;
	}
	private  class ViewHolder {
		TextView header_label;
		TextView label_company;
		TextView label_price;
		TextView label_changepercntg;
		TableLayout the_table;
	}
}
