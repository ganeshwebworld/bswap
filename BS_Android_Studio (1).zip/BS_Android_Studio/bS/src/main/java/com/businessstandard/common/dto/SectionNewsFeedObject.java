/**
   Project      : Economist
   Filename     : SectionNewsFeedObject.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/
package com.businessstandard.common.dto;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

/**
 * @author lenesha
 *
 */
public class SectionNewsFeedObject {

	@SerializedName("Home")
	private ArrayList<SectionNewsItem> mHome;

	@SerializedName("Markets")
	private ArrayList<SectionNewsItem> mMarket;

	@SerializedName("Todays Paper")
	private SectionNewsItem mTodaysPaper;
	
	@SerializedName("Stock Graphs")
	private SectionNewsItem mStockGraphs;

	@SerializedName("BSE Top Gainers")
	private SectionNewsItem mBseTopGainers;

	@SerializedName("NSE Top Gainers")
	private SectionNewsItem mNseTopGainers;

	@SerializedName("BSE Top Loosers")
	private SectionNewsItem mBseTopLoosers;

	@SerializedName("NSE Top Loosers")
	private SectionNewsItem mNseTopLoosers;

	@SerializedName("BSE 52 Week High")
	private SectionNewsItem mBse52weekHigh;

	@SerializedName("NSE 52 Week High")
	private SectionNewsItem mNse52weekHigh;

	@SerializedName("BSE 52 Week Low")
	private SectionNewsItem mBse52weekLow;

	@SerializedName("NSE 52 Week Low")
	private SectionNewsItem mNse52weekLow;

	@SerializedName("BSE Stock Data")
	private SectionNewsItem mBseStockData;

	@SerializedName("NSE Stock Data")
	private SectionNewsItem mNseStockData;

	@SerializedName("Indices BSE Stock Data")
	private SectionNewsItem mIndicesBseStockData;

	@SerializedName("Indices NSE Stock Data")
	private SectionNewsItem mIndicesNseStockData;

	@SerializedName("MCX Loosers")
	private SectionNewsItem mMCXLoosers;

	@SerializedName("MCX Gainers")
	private SectionNewsItem mMCXGainers;

	@SerializedName("NCDEX Loosers")
	private SectionNewsItem mNCDEXLoosers;

	@SerializedName("NCDEX Gainers")
	private SectionNewsItem mNCDEXGainers;

	@SerializedName("MCX Spot")
	private SectionNewsItem mMCXSpot;

	@SerializedName("NCDEX Spot")
	private SectionNewsItem mNCDEXSpot;

	@SerializedName("MCX Future")
	private SectionNewsItem mMCXFuture;

	@SerializedName("NCDEX Future")
	private SectionNewsItem mNCDEXFuture;

	@SerializedName("Stcok Search")
	private SectionNewsItem mStockSearch;

	@SerializedName("Portfolio")
	private ArrayList<SectionNewsItem> mPortfolio;

	@SerializedName("News Comment")
	private SectionNewsItem mNewsComment;

	@SerializedName("News Search")
	private ArrayList<SectionNewsItem> mNewsSearch;

	@SerializedName("register")
	private SectionNewsItem mRegister;

	@SerializedName("login")
	private SectionNewsItem mLogin;

	@SerializedName("comment")
	private SectionNewsItem mComment;

	public ArrayList<SectionNewsItem> getmHome() {
		return mHome;
	}

	public ArrayList<SectionNewsItem> getmMarket() {
		return mMarket;
	}

	public SectionNewsItem getmTodaysPaper() {
		return mTodaysPaper;
	}

	public SectionNewsItem getmStockGraph() {
		return mStockGraphs;
	}

	public SectionNewsItem getmBseTopGainers() {
		return mBseTopGainers;
	}

	public SectionNewsItem getmNseTopGainers() {
		return mNseTopGainers;
	}

	public SectionNewsItem getmBseTopLoosers() {
		return mBseTopLoosers;
	}

	public SectionNewsItem getmNseTopLoosers() {
		return mNseTopLoosers;
	}

	public SectionNewsItem getmBse52weekHigh() {
		return mBse52weekHigh;
	}
	

	public SectionNewsItem getmNse52weekHigh() {
		return mNse52weekHigh;
	}

	public SectionNewsItem getmBse52weekLow() {
		return mBse52weekLow;
	}

	public SectionNewsItem getmNse52weekLow() {
		return mNse52weekLow;
	}

	public SectionNewsItem getmBseStockData() {
		return mBseStockData;
	}

	public SectionNewsItem getmNseStockData() {
		return mNseStockData;
	}

	public SectionNewsItem getmIndicesBseStockData() {
		return mIndicesBseStockData;
	}

	public SectionNewsItem getmIndicesNseStockData() {
		return mIndicesNseStockData;
	}

	public SectionNewsItem getmMCXLoosers() {
		return mMCXLoosers;
	}

	public SectionNewsItem getmMCXGainers() {
		return mMCXGainers;
	}

	public SectionNewsItem getmNCDEXLoosers() {
		return mNCDEXLoosers;
	}

	public SectionNewsItem getmNCDEXGainers() {
		return mNCDEXGainers;
	}

	public SectionNewsItem getmMCXSpot() {
		return mMCXSpot;
	}

	public SectionNewsItem getmNCDEXSpot() {
		return mNCDEXSpot;
	}

	public SectionNewsItem getmMCXFuture() {
		return mMCXFuture;
	}

	public SectionNewsItem getmNCDEXFuture() {
		return mNCDEXFuture;
	}

	public SectionNewsItem getmStockSearch() {
		return mStockSearch;
	}

	public ArrayList<SectionNewsItem> getmPortfolio() {
		return mPortfolio;
	}

	public SectionNewsItem getmNewsComment() {
		return mNewsComment;
	}

	public ArrayList<SectionNewsItem> getmNewsSearch() {
		return mNewsSearch;
	}

	public SectionNewsItem getmRegister() {
		return mRegister;
	}

	public SectionNewsItem getmLogin() {
		return mLogin;
	}

	public SectionNewsItem getmComment() {
		return mComment;
	}
}
