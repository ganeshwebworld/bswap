package com.businessstandard.deeplinking;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.businessstandard.common.ui.BaseActivity;
import com.businessstandard.common.ui.MainFragmentActivity;
import com.businessstandard.common.util.Utility;

public class CommoditiesDeepLinkActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getIntent() != null) {
            String action = getIntent().getAction();
            String scheme = getIntent().getScheme();
            Uri data = getIntent().getData();

            if (Intent.ACTION_VIEW.equals(action) && scheme != null && data != null) {
                if (Utility.isInternetOn(this)) {
                    Intent i = new Intent(this, MainFragmentActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    i.putExtra("MainCat", "Market");
                    //i.putExtra("SabCat", "Commodities");
                    i.putExtra("SabCat", "Market Data");
                    startActivity(i);
                    this.finish();
                } else {
                    Utility.showToast("Please check your internet connection", this);
                    finish();
                }
            }
        }
    }
}
