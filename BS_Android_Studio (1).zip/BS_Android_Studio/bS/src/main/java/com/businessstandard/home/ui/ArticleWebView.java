/**
 * Project      : Economist
 * Filename     : ArticleWebView.java
 * Author       : abcd
 * Comments     :
 * Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
 * Modified under contract by Robosoft Technologies Pvt. Ltd.
 * History      : NA
 */

package com.businessstandard.home.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.businessstandard.R;
import com.businessstandard.common.ui.MainFragmentActivity;
import com.businessstandard.common.util.Utility;
import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ArticleWebView extends Activity {

    WebView webView;
    public static String apiToken = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
    TextView tv_Title, tv_Author, tv_date, tv_time;
    ImageView BackButton;
    private com.businessstandard.model.Constants mConstants = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_articleweb);
        SaveSharedPref mSharedPreferenceManager = SaveSharedPref.getInstance(this);
        if (mSharedPreferenceManager.exists(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA)) {
            if (mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class) != null) {
                mConstants = mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class);
            }
        }
        Intent intent = getIntent();
        String articalId = intent.getStringExtra("ArticleId");
        //	String articalId="116060600003";
        webView = (WebView) findViewById(R.id.webview_artical);
        tv_Title = (TextView) findViewById(R.id.articleTitle);
        tv_Author = (TextView) findViewById(R.id.articleAuthor);
        tv_date = (TextView) findViewById(R.id.articleDate);
        tv_time = (TextView) findViewById(R.id.articleTime);
        BackButton = (ImageView) findViewById(R.id.header_back);
        BackButton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                startActivity(new Intent(ArticleWebView.this, MainFragmentActivity.class));
                finish();

            }
        });
        if (articalId != null) {
            new LoadData().execute(apiToken, articalId);
        } else {
            Toast.makeText(getApplicationContext(), "Artical ID not recive", Toast.LENGTH_SHORT).show();
        }
    }

    private class LoadData extends AsyncTask<String, String, String> {

        private final ProgressDialog progressDialog;
        String response;

        LoadData() {
            progressDialog = new ProgressDialog(ArticleWebView.this);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setTitle("Please Wait..");
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.show();
            // showDialog(DIALOG_DOWNLOAD_PROGRESS);
        }

        @Override
        protected String doInBackground(String... args) {
            //String strUrl = Constants.BaseUrl_V2 + "/user/process-api/get-notification-article-detail";

            String strUrl = "";
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getNotificationArticleDetail())) {
                strUrl = mConstants.getNotificationArticleDetail();
            }

            OkHttpClient client = new OkHttpClient();

            RequestBody formBody = new FormBody.Builder()
                    .add("api_token", args[0])
                    .add("articleId", args[1])
                    .build();

            Request request = new Request.Builder()
                    .url(strUrl)
                    .post(formBody)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String jsonStr = response.body().string();
                    return jsonStr;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onProgressUpdate(String... progress) {
            super.onProgressUpdate(progress);
        }

        protected void onPostExecute(String jsonStr) {
            progressDialog.cancel();
            try {
                JSONObject json = new JSONObject(jsonStr);
                JSONObject root = json.getJSONObject("root");
                Log.d("Json_Mayank", root.toString());
                String fileUpdateDateTime = root.getString("fileupdatedatetime");
                JSONObject item = root.getJSONObject("item");
                //String section = item.getString("section");
                //String Id = item.getString("id");
                //String shortUrl = item.getString("shorturl");
                //String newsUrl = item.getString("newsurl");
                String title = item.getString("title");
                String author = item.getString("author");
                //String city = item.getString("city");
                String dateTime = item.getString("datetime");
                String newsContent = item.getString("newscontent");
                webView.loadDataWithBaseURL("file:///android_asset/", newsContent, "text/html; charset=utf-8", "utf-8", null);
                tv_Title.setVisibility(View.VISIBLE);
                tv_Author.setVisibility(View.VISIBLE);
                tv_date.setVisibility(View.VISIBLE);
                tv_time.setVisibility(View.VISIBLE);
                tv_Title.setText(title);
                tv_Author.setText(author);
                tv_date.setText(fileUpdateDateTime);
                String publishedRelativeTime = Utility.getPublishedTime(dateTime);

                if (publishedRelativeTime != null
                        && publishedRelativeTime.length() > 0
                        && (publishedRelativeTime.contains(" hours ago")
                        || publishedRelativeTime.contains(" minutes ago") || publishedRelativeTime
                        .contains(" days ago")))
                    tv_time.setText(publishedRelativeTime);
                else {
                    tv_time.setVisibility(View.INVISIBLE);
                }
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(), "Unable to load data", Toast.LENGTH_SHORT);
            }
        }
    }
}
