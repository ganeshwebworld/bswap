/**
   Project      : Economist
   Filename     : McxFutureItem.java
   Author       : lenesha
   Comments     : 
   Copyright    : Copyright� 2011, Business Standard Ltd . All rights reserved
   History      : NA
*/

package com.businessstandard.market.dto;

import java.util.List;

import com.google.gson.annotations.SerializedName;

/**
 * @author lenesha
 *
 */
public class McxFutureItem {
	@SerializedName("MCX Future")
	public List<McxAndNcdexFutureItem> mcxFuture;
}
