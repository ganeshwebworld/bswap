/**
   Project      : Economist
   Filename     : CouponDataBase.java
   Author       : android
   Comments     : 
   Copyright    : Copyright© 2011, Business Standard Ltd . All rights reserved
				  Modified under contract by Robosoft Technologies Pvt. Ltd.
   History      : NA
 */

package com.android.coupon.database;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;

import com.businessstandard.common.util.CouponUtils;

/**
 * @author android
 * 
 */
public class CouponDataBase {
	private final String DATABASENAME = "CouponDatabase";
	private final String TABLENAME = "CouponTable";
	private final String COLUMNNAME = "offerid";
	private final String COLUMNNAME2 = "offerdesc";
	private final String COLUMNNAME3 = "couponcode";
	private final String COLUMNNAME4 = "validtill";
	private final String COLUMNNAME5 = "showfirsttime";
	private final String COLUMNNAME6 = "source";
	private final String COLUMNNAME7 = "logourl";
	private final String COLUMNNAME8 = "logo";

	/**
	 * 
	 */
	private DataBaseHelper helper;
	private SQLiteDatabase database;

	public CouponDataBase(Context context) {
		// TODO Auto-generated constructor stub
		helper = new DataBaseHelper(context);
		database = helper.getWritableDatabase();
	}

	public void updateBitmap(String offerid, Bitmap bitmap) {
		System.out.println("bitmap====="+bitmap+"=====offerid=="+offerid);
		ContentValues contentValues = new ContentValues();
		contentValues.put(COLUMNNAME8, getBytes(bitmap));
		database.update(TABLENAME, contentValues, COLUMNNAME + " ='" + offerid
				+ "'", null);
	}
	

	public void insertCoupon(ArrayList<CouponUtils> arrayList) {
		for (int i = 0; i < arrayList.size(); i++) {
			ContentValues values = new ContentValues();
			values.put(COLUMNNAME, arrayList.get(i).getOfferid());
			values.put(COLUMNNAME2, arrayList.get(i).getOfferdesc());
			values.put(COLUMNNAME3, arrayList.get(i).getCouponcode());
			values.put(COLUMNNAME4, arrayList.get(i).getValidtill());
			values.put(COLUMNNAME5, arrayList.get(i).getShowfirsttime());
			values.put(COLUMNNAME6, arrayList.get(i).getSource());
			values.put(COLUMNNAME7, arrayList.get(i).getLogourl());
			values.put(COLUMNNAME8, "");
			database.insert(TABLENAME, null, values);
		}
	}

	public ArrayList<CouponUtils> getJson() {
		ArrayList<CouponUtils> arrayList = new ArrayList<CouponUtils>();
		Cursor cursor = database.query(TABLENAME, new String[] { COLUMNNAME,
				COLUMNNAME2, COLUMNNAME3, COLUMNNAME4, COLUMNNAME5,
				COLUMNNAME6, COLUMNNAME7, COLUMNNAME8 }, null, null, null,
				null, null);
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			CouponUtils couponUtils = new CouponUtils();
			couponUtils.setOfferid(cursor.getString(cursor
					.getColumnIndex(COLUMNNAME)));
			couponUtils.setOfferdesc(cursor.getString(cursor
					.getColumnIndex(COLUMNNAME2)));
			couponUtils.setCouponcode(cursor.getString(cursor
					.getColumnIndex(COLUMNNAME3)));
			couponUtils.setValidtill(cursor.getString(cursor
					.getColumnIndex(COLUMNNAME4)));
			couponUtils.setShowfirsttime(cursor.getString(cursor
					.getColumnIndex(COLUMNNAME5)));
			couponUtils.setSource(cursor.getString(cursor
					.getColumnIndex(COLUMNNAME6)));
			couponUtils.setLogourl(cursor.getString(cursor
					.getColumnIndex(COLUMNNAME7)));
			couponUtils.setBitmap(getImage(cursor.getBlob(cursor
					.getColumnIndex(COLUMNNAME8))));
			cursor.moveToNext();
		}
		return arrayList;
	}

	public void deleteAll() {
		database.delete(TABLENAME, null, null);

	}
	public void deleteByOfferid(String offerid) {
		database.delete(TABLENAME, COLUMNNAME+" ='"+offerid+"'", null);

	}

	class DataBaseHelper extends SQLiteOpenHelper {

//		/**
//		 * @param context
//		 * @param name
//		 * @param factory
//		 * @param version
//		 */
		public DataBaseHelper(Context context) {
			super(context, DATABASENAME, null, 1);
			// TODO Auto-generated constructor stub
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * android.database.sqlite.SQLiteOpenHelper#onCreate(android.database
		 * .sqlite.SQLiteDatabase)
		 */
		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			String quary = "Create Table " + TABLENAME + " ( " + COLUMNNAME
					+ " TEXT, " + COLUMNNAME2 + " TEXT, " + COLUMNNAME3 + " TEXT, "
					+ COLUMNNAME4 + " TEXT, " + COLUMNNAME5 + " TEXT, "
					+ COLUMNNAME6 + " TEXT, " + COLUMNNAME7 + " TEXT, "
					+ COLUMNNAME8 + " BLOB);";
			db.execSQL(quary);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * android.database.sqlite.SQLiteOpenHelper#onUpgrade(android.database
		 * .sqlite.SQLiteDatabase, int, int)
		 */
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub

		}

	}

	// convert from bitmap to byte array
	public static byte[] getBytes(Bitmap bitmap) {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		bitmap.compress(CompressFormat.PNG, 0, stream);
		return stream.toByteArray();
	}

	// convert from byte array to bitmap
	public static Bitmap getImage(byte[] image) {
		return BitmapFactory.decodeByteArray(image, 0, image.length);
	}
}
