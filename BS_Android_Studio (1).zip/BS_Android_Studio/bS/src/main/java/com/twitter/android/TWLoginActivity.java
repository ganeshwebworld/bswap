/*
 * Copyright 2010 Facebook, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.twitter.android;



import oauth.signpost.commonshttp.CommonsHttpOAuthConsumer;
import oauth.signpost.commonshttp.CommonsHttpOAuthProvider;
import oauth.signpost.exception.OAuthCommunicationException;
import oauth.signpost.exception.OAuthExpectationFailedException;
import oauth.signpost.exception.OAuthMessageSignerException;
import oauth.signpost.exception.OAuthNotAuthorizedException;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.businessstandard.R;


public class TWLoginActivity extends Activity {

	public static final String TAG = "twitter";

	public static final String LOGEDIN = "isLogedIn";	

    static final int TW_BLUE = 0xFFC0DEED;
    static final float[] DIMENSIONS_LANDSCAPE = {460, 260};
    static final float[] DIMENSIONS_PORTRAIT = {280, 420};
    static final FrameLayout.LayoutParams FILL = 
        new FrameLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, 
                         ViewGroup.LayoutParams.FILL_PARENT);
    static final int MARGIN = 4;
    static final int PADDING = 2;
    
    private String mUrl;
    private ProgressDialog mSpinner;
    private WebView mWebView;
    private LinearLayout mContent;
    private TextView mTitle;

	private CommonsHttpOAuthConsumer mConsumer;
	private CommonsHttpOAuthProvider mProvider;

	private SharedPreferences mTweetPreferences;
	private static final int LOADING_PROGRESS = 101;
	
    @Override
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    
    @Override
    protected void onResume() {
    	super.onResume();
    	showDialog(LOADING_PROGRESS);
    	mContent = new LinearLayout(this);
        mContent.setOrientation(LinearLayout.VERTICAL);
        mContent.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
        Log.d(TAG, "mUrl: " + mUrl);
        Util.clearCookies(this);
        setUpTitle();
        setUpWebView();
        setContentView(mContent);
        
        mConsumer = Twitter.mHttpOauthConsumer;
        mProvider = Twitter.mHttpOauthProvider;
        
        retrieveRequestToken();
    }

    @Override
    protected void onDestroy() {
    	super.onDestroy();
    	mSpinner = null;
    }
    
    @Override
    public void finish() {
    	super.finish();
    	mSpinner = null;
    }
    
    @Override
    protected Dialog onCreateDialog(int id) {
    	Dialog dialog = null;
    	if (id == LOADING_PROGRESS)
    		dialog = createProgressDialog();
    	return dialog;
    }
    
    private Dialog createProgressDialog() {
    	 mSpinner = new ProgressDialog(this);
         mSpinner.requestWindowFeature(Window.FEATURE_NO_TITLE);
         mSpinner.setMessage("Loading...");
         
         return mSpinner;

    }
  

	private void setUpTitle() {
        Drawable icon = this.getResources().getDrawable(
                R.drawable.ic_action_search);
        mTitle = new TextView(this);
        mTitle.setText("Twitter");
        mTitle.setTextColor(Color.WHITE);
        mTitle.setTypeface(Typeface.DEFAULT_BOLD);
        mTitle.setBackgroundColor(TW_BLUE);
        mTitle.setPadding(MARGIN + PADDING, MARGIN, MARGIN, MARGIN);
        mTitle.setCompoundDrawablePadding(MARGIN + PADDING);
        mTitle.setCompoundDrawablesWithIntrinsicBounds(
                icon, null, null, null);
        mContent.addView(mTitle);
    }

    private void setUpWebView() {
        
        mWebView = new WebView(this);
        mWebView.setVerticalScrollBarEnabled(false);
        mWebView.setHorizontalScrollBarEnabled(false);
        mWebView.setWebViewClient(new TWLoginActivity.TwWebViewClient());
        mWebView.getSettings().setJavaScriptEnabled(true);
       // mWebView.clearFormData();
        //mWebView.clearCache(true);
        mWebView.setVerticalScrollBarEnabled(false);
        mWebView.setHorizontalScrollBarEnabled(false);
        mWebView.setLayoutParams(FILL);
        mContent.addView(mWebView);
    }

    private void retrieveRequestToken() {
       // mSpinner.show();
        new Thread() {
        	@Override
        	public void run() {
            	try { // https://api.twitter.com/oauth/authorize?oauth_token=234352991-xBgFunbklDgzqLQC162V21d36ExeuZ3KEZob0sSU
        			mUrl = mProvider.retrieveRequestToken(mConsumer, Twitter.CALLBACK_URI);
        			Log.d(TAG, "callback url: "+ mUrl);
        	    	mWebView.loadUrl(mUrl);
        		}catch (Exception e) {
        			Log.w(TAG, e);
        		}
        			/*catch (OAuthMessageSignerException e) {
        		}
        			mListener.onError(new DialogError(e.getMessage(), -1, Twitter.OAUTH_REQUEST_TOKEN));
        		} catch (OAuthNotAuthorizedException e) {
        			mListener.onError(new DialogError(e.getMessage(), -1, Twitter.OAUTH_REQUEST_TOKEN));
        		} catch (OAuthExpectationFailedException e) {
        			mListener.onError(new DialogError(e.getMessage(), -1, Twitter.OAUTH_REQUEST_TOKEN));
        		} catch (OAuthCommunicationException e) {
        			mListener.onError(new DialogError(e.getMessage(), -1, Twitter.OAUTH_REQUEST_TOKEN));
        		}*/
        	}
        }.start();
    }
    
    private void retrieveAccessToken(final String url) {
        mSpinner.show();
    	new Thread() {
    		@Override
    		public void run() {
    			Uri uri = Uri.parse(url);
    			String verifier = uri.getQueryParameter(oauth.signpost.OAuth.OAUTH_VERIFIER);
    			final Bundle values = new Bundle();
    			try {
					mProvider.retrieveAccessToken(mConsumer, verifier);
					values.putString(Constants.ACCESS_TOKEN, mConsumer.getToken());
					values.putString(Constants.SECRET_TOKEN, mConsumer.getTokenSecret());
					
					//Shared preferences to save the access tokens.
					mTweetPreferences = PreferenceManager.getDefaultSharedPreferences(getApplication());
					final Editor edit = mTweetPreferences.edit();
					edit.putBoolean(LOGEDIN, true);
					edit.putString(Constants.ACCESS_TOKEN, mConsumer.getToken());
					edit.putString(Constants.SECRET_TOKEN, mConsumer.getTokenSecret());
					edit.commit();
					
					Intent result = new Intent();
					result.putExtra("result", true);
					result.putExtra("values", values);
					setResult(1, result);
					
					finish();
					//mListener.onComplete(values);
					
				} catch (OAuthMessageSignerException e) {
					Intent result = new Intent();
					result.putExtra("result", false);
					setResult(1, result);
					finish();
					
				} catch (OAuthNotAuthorizedException e) {
					Intent result = new Intent();
					result.putExtra("result", false);
					setResult(1, result);
					finish();
				} catch (OAuthExpectationFailedException e) {
					Intent result = new Intent();
					result.putExtra("result", false);
					setResult(1, result);
					finish();
				} catch (OAuthCommunicationException e) {
					Intent result = new Intent();
					result.putExtra("result", false);
					setResult(1, result);
					finish();
				}
				
    		}
    	}.start();
    }
    

    private class TwWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            Log.d("NEWTWEET", "Redirect URL: " + url);
            if (url.startsWith(Twitter.CALLBACK_URI)) {
            	retrieveAccessToken(url);
                return true;
            } else if (url.startsWith(Twitter.CANCEL_URI)) {
            	 Log.d("NEWTWEET", "Cancle Uri: " + url);
            	Intent result = new Intent();
				result.putExtra("result", false);
				setResult(1, result);
				finish();
                return true;
            }
            // launch non-dialog URLs in a full browser
          startActivity(
                   new Intent(Intent.ACTION_VIEW, Uri.parse(url))); 
           // finish();
            return true;
        }

        @Override
        public void onReceivedError(WebView view, int errorCode,
                String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            Log.d("NEWTWEET", "onReceivedError: ");
           // mListener.onError(
             //       new DialogError(description, errorCode, failingUrl));
           // TwDialog.this.dismiss();
            
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            Log.d(TAG, "WebView loading URL: " + url);
            super.onPageStarted(view, url, favicon);
            if (mSpinner != null && mSpinner.isShowing()) {
            	mSpinner.dismiss();
            }
            if (mSpinner != null) {
            	mSpinner.show();
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            String title = mWebView.getTitle();
            if (title != null && title.length() > 0) {
                mTitle.setText(title);
            }
            if (mSpinner != null)
            	mSpinner.dismiss();
        }   
        
    }
}
