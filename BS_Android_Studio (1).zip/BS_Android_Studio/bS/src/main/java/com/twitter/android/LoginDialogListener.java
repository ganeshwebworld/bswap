package com.twitter.android;

import android.os.Bundle;
import android.util.Log;

import com.twitter.android.Twitter.TwitterAuthListener;


public class LoginDialogListener implements TwitterAuthListener {

	public void onCancel() {
		// TODO Auto-generated method stub

	}

	public void onComplete(Bundle values) {
		Log.d("TWITTER", "Log-in success");

	}

	public void onError(DialogError e) {

	}

	public void onTwitterError(TwitterError e) {

	}
}
