package com.twitter.android;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;

import com.businessstandard.utils.SaveSharedPref;
import com.businessstandard.utils.SharedPreferencesKey;

import org.json.JSONObject;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class NotificationUtils {

    private static NotificationUtils notificationUtils = null;
    public static String api_key = "6e8b83adf0cee4f191f5d9a242949dbd7294c7c6";
    private String devicename = "android";
    private com.businessstandard.model.Constants mConstants = null;

    public static NotificationUtils getInstance() {
        if (notificationUtils == null) {
            notificationUtils = new NotificationUtils();
        }
        return notificationUtils;
    }

    public void sendDataToServer(Context context, String fcmToken) {

        SaveSharedPref mSharedPreferenceManager = SaveSharedPref.getInstance(context);
        if (mSharedPreferenceManager.exists(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA)) {
            if (mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class) != null) {
                mConstants = mSharedPreferenceManager.getObject(SharedPreferencesKey.KEY_CONFIG_CONSTANTS_DATA, com.businessstandard.model.Constants.class);
            }
        }
/*        TelephonyManager tManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		String uuid = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);*/

        //Secure Id added in place of telephony id
        String uuid = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);

        if (!TextUtils.isEmpty(uuid)) {
            SaveSharedPref.getInstance(context).saveString(SharedPreferencesKey.KEY_DEVICE_ID, uuid);
        }
        String appversion = "";
        try {
            appversion = Integer.toString(context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode);
        } catch (PackageManager.NameNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        String osversion = android.os.Build.VERSION.RELEASE; // e.g. myVersion := "1.6"
        try {
            String versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
            String devicemodel = getDeviceName();

            AutoLogin signuptasknew = new AutoLogin(context, fcmToken);
            signuptasknew.execute(api_key, uuid, "Email@example.com", "android", devicename, devicemodel, osversion, appversion);

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

    }

    public String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return capitalize(model);
        } else {
            return capitalize(manufacturer) + " " + model;
        }
    }

    private String capitalize(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        char first = s.charAt(0);
        if (Character.isUpperCase(first)) {
            return s;
        } else {
            return Character.toUpperCase(first) + s.substring(1);
        }
    }

    public class AutoLogin extends AsyncTask<String, String, JSONObject> {

        /**
         * @param mContext
         */
        Context mContext;
        String RegID;

        public AutoLogin(Context mContext, String RegID) {
            // TODO Auto-generated constructor stub
            this.mContext = mContext;
            this.RegID = RegID;

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //
        }

        @Override
        protected JSONObject doInBackground(String... args) {
            //String strUrl = com.businessstandard.common.util.Constants.BaseUrl_V2 + Constants.SAVE_DATA_API_V2;
            String strUrl = "";
            if (mConstants != null && !TextUtils.isEmpty(mConstants.getSaveDataApiV2())) {
                strUrl = mConstants.getSaveDataApiV2();
            }
            JSONObject object = null;
            try {
                OkHttpClient client = new OkHttpClient();

                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("api_token", args[0])
                        .addFormDataPart("device_token", RegID)
                        .addFormDataPart("user_email", args[2])
                        .addFormDataPart("device_type", args[3])
                        .addFormDataPart("device_name", args[4])
                        .addFormDataPart("device_model", args[5])
                        .addFormDataPart("os_version", args[6])
                        .addFormDataPart("app_version", args[7])
                        .addFormDataPart("device_uniqueid", args[1])
                        .build();

                Request request = new Request.Builder()
                        .url(strUrl)
                        .post(requestBody)
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    try {
                        assert response.body() != null;
                        object = new JSONObject(response.body().string());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return object;
        }

        protected void onPostExecute(JSONObject json) {
            // progressDialognew.cancel();
            if (json != null) {
                StringBuilder sb = new StringBuilder();
                String status = null;
                JSONObject id = null;
            }
        }
    }
}
